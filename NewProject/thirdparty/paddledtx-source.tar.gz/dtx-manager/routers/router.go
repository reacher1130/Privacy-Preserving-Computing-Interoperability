// Package routers
package routers

import (
	"baidu/blockchain/dtx-manager/controllers"

	"github.com/beego/beego/v2/server/web"
	"github.com/beego/beego/v2/server/web/context"
	"github.com/beego/beego/v2/server/web/filter/cors"
)

func init() {

	// 跨域设置
	web.InsertFilter("*", web.BeforeRouter, cors.Allow(&cors.Options{
		AllowOrigins:     []string{},
		AllowMethods:     []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"},
		AllowHeaders:     []string{"Origin", "Authorization", "Access-Control-Allow-Origin", "Access-Control-Allow-Headers", "Content-Type", "X-Request-Id", "X-BCAP-AppCode-Header", "X-UserId", "X-Baas-App-Uuid"},
		ExposeHeaders:    []string{"Content-Length", "Access-Control-Allow-Origin", "Access-Control-Allow-Headers", "Content-Type", "X-Request-Id", "X-BCAP-AppCode-Header", "X-UserId", "X-Baas-App-Uuid"},
		AllowCredentials: true,
	}))

	// 域名访问转发到主页
	web.Get("/", func(ctx *context.Context) {
		ctx.Redirect(302, "/dtx/console")
	})

	// 前端路由
	console := web.NewNamespace("/dtx/",
		web.NSNamespace("console",
			web.NSRouter("*", &controllers.ConsoleController{}, "get:Get"),
		),
	)

	// https://beego.vip/docs/mvc/controller/router.md
	ns := web.NewNamespace(controllers.PathPrefix,
		// 前端路由
		//web.NSNamespace("console",
		//	web.NSRouter("/", &controllers.ConsoleController{}, "get:Get"),
		//),

		// 用户登陆系统
		web.NSNamespace("user",
			// 用户登录
			web.NSRouter("login", &controllers.UserController{}, "post:Login"),
			// 用户注册
			web.NSRouter("register", &controllers.UserController{}, "post:Register"),
			// 管理员重置密码
			web.NSRouter("clearpwd", &controllers.UserController{}, "post:ClearPwd"),
			// 用户修改密码
			web.NSRouter("resetpwd", &controllers.UserController{}, "post:ResetPwd"),
			// 用户信息查询
			web.NSRouter("info", &controllers.UserController{}, "get:GetInfo"),
		),

		// 用户权限系统
		web.NSNamespace("permission",
			// 角色创建
			web.NSRouter("role/create", &controllers.RoleController{}, "post:Create"),
			// 角色修改
			web.NSRouter("role/modify", &controllers.RoleController{}, "post:Modify"),
			// 角色列表
			web.NSRouter("role/list", &controllers.RoleController{}, "get:List"),
			// 角色绑定
			web.NSRouter("role/bind", &controllers.RoleController{}, "post:Bind"),
			// 角色查询
			web.NSRouter("role/get", &controllers.RoleController{}, "get:Query"),
			// 删除角色
			web.NSRouter("role/delete", &controllers.RoleController{}, "get:Delete"),
			// 绑定列表
			web.NSRouter("bind/list", &controllers.RoleController{}, "get:BindList"),
		),

		// 运维管理
		web.NSNamespace("op",
			// 查询区块链网络节点
			web.NSRouter("blockchain/netInfo", &controllers.OPController{}, "get:ChainNetInfo"),
			// 查询存储网络概览
			web.NSRouter("xdb/netInfo", &controllers.OPController{}, "get:XdbNetInfo"),
			// 查询存储网络节点列表
			web.NSRouter("xdb/nodeInfo", &controllers.OPController{}, "get:XdbNodeInfo"),
			// 新增存储网络节点
			web.NSRouter("dai/newStorageNode", &controllers.OPController{}, "post:NewStorageNode"),
			// 修改存储网络节点
			web.NSRouter("dai/modifyStorageNode", &controllers.OPController{}, "post:ModifyStorageNode"),
			// 删除存储网络节点
			web.NSRouter("dai/deleteStorageNode", &controllers.OPController{}, "post:DeleteStorageNode"),
			// 新增数据存储节点
			web.NSRouter("dai/newDataownerNode", &controllers.OPController{}, "post:NewDataownerNode"),
			// 修改数据存储节点
			web.NSRouter("dai/modifyDataownerNode", &controllers.OPController{}, "post:ModifyDataownerNode"),
			// 删除数据存储节点
			web.NSRouter("dai/deleteDataownerNode", &controllers.OPController{}, "post:DeleteDataownerNode"),
			// 查询计算网络任务概览信息
			web.NSRouter("dai/taskInfo", &controllers.OPController{}, "get:DaiTaskInfo"),
			// 查询计算网络节点列表
			web.NSRouter("dai/netInfo", &controllers.OPController{}, "get:DaiNetInfo"),
			// 新增计算网络节点
			web.NSRouter("dai/newExecutorNode", &controllers.OPController{}, "post:NewExecutorNode"),
			// 修改计算网络节点
			web.NSRouter("dai/modifyExecutorNode", &controllers.OPController{}, "post:ModifyExecutorNode"),
			// 删除计算网络节点
			web.NSRouter("dai/deleteExecutorNode", &controllers.OPController{}, "post:DeleteExecutorNode"),
		),

		// 数据资源管理
		web.NSNamespace("data",
			// 文件上传
			web.NSRouter("fileupload", &controllers.DataController{}, "post:FileUpload"),
			// 文件下载
			web.NSRouter("download", &controllers.DataController{}, "get:FileDownload"),
			// 新增数据资源
			web.NSRouter("create", &controllers.DataController{}, "post:Create"),
			// 数据资源列表
			web.NSRouter("list", &controllers.DataController{}, "get:GetList"),
			// 数据资源详情
			web.NSRouter("detail", &controllers.DataController{}, "get:Detail"),
			// 数据资源发布
			web.NSRouter("publish", &controllers.DataController{}, "post:Publish"),
			// 数据资源更新
			web.NSRouter("update", &controllers.DataController{}, "post:Update"),
			// 数据特征详情维护
			web.NSRouter("meta/update", &controllers.DataController{}, "post:MetaUpdate"),
			// 数据删除
			web.NSRouter("delete", &controllers.DataController{}, "post:Delete"),
			// 数据上线
			web.NSRouter("online", &controllers.DataController{}, "post:Online"),
			// 数据下线
			web.NSRouter("offline", &controllers.DataController{}, "post:Offline"),
			// 已发布数据列表
			web.NSRouter("list/published", &controllers.DataController{}, "get:ListPublished"),
			// 已获取授权数据列表
			web.NSRouter("list/approved", &controllers.DataController{}, "get:ListApproved"),
		),

		// 模型资源管理
		web.NSNamespace("model",
			// 新增模型资源
			web.NSRouter("create", &controllers.ModelController{}, "post:Create"),
			// 模型资源列表
			web.NSRouter("list", &controllers.ModelController{}, "get:GetList"),
			// 模型资源详情
			web.NSRouter("detail", &controllers.ModelController{}, "get:Detail"),
			// 模型资源发布
			web.NSRouter("publish", &controllers.ModelController{}, "post:Publish"),
			// 模型资源删除
			web.NSRouter("delete", &controllers.ModelController{}, "post:Delete"),
			// 数据上线
			web.NSRouter("online", &controllers.ModelController{}, "post:Online"),
			// 数据下线
			web.NSRouter("offline", &controllers.ModelController{}, "post:Offline"),
			// 模型任务列表
			web.NSRouter("tasklist", &controllers.ModelController{}, "get:TaskList"),
			// 可用模型列表
			web.NSRouter("usable", &controllers.ModelController{}, "get:Usable"),
			// 已发布模型列表
			web.NSRouter("list/published", &controllers.ModelController{}, "get:ListPublished"),
			// 已获取授权模型列表
			web.NSRouter("list/approved", &controllers.ModelController{}, "get:ListApproved"),
		),

		// 资源空间
		web.NSNamespace("/:dataType(data|model)/ns",
			// 新增资源空间
			web.NSRouter("add", &controllers.NameSpaceController{}, "post:AddNamespace"),
			// 资源空间列表
			web.NSRouter("list", &controllers.NameSpaceController{}, "get:List"),
			// 资源空间列表
			web.NSRouter("replicaLimit", &controllers.NameSpaceController{}, "get:ReplicaLimit"),
			// 资源空间名称列表
			web.NSRouter("simplelist", &controllers.NameSpaceController{}, "get:Simplelist"),
			// 资源空间
			web.NSRouter("resource/detail", &controllers.NameSpaceController{}, "get:ResourceDetail"),
			// 机构资源统计数据
			web.NSRouter("orgStat", &controllers.NameSpaceController{}, "get:OrgStat"),
		),

		// 资源授权
		web.NSNamespace("/:dataType(data|model)/auth",
			// 申请授权
			web.NSRouter("apply", &controllers.ResourceAuthController{}, "post:Apply"),
			// 申请操作
			web.NSRouter("operate", &controllers.ResourceAuthController{}, "post:Operate"),
			// 授权列表
			web.NSRouter("list", &controllers.ResourceAuthController{}, "get:List"),
			// 授权详情
			web.NSRouter("detail", &controllers.ResourceAuthController{}, "get:Detail"),
		),

		// 任务管理
		web.NSNamespace("task",
			// 任务创建
			web.NSRouter("create", &controllers.TaskController{}, "post:Create"),
			// 任务复制
			web.NSRouter("clone", &controllers.TaskController{}, "post:Clone"),
			// 任务删除
			web.NSRouter("delete", &controllers.TaskController{}, "post:Delete"),
			// 任务修改
			web.NSRouter("update", &controllers.TaskController{}, "post:Update"),
			// 任务列表
			web.NSRouter("list", &controllers.TaskController{}, "get:List"),
			// 任务详情
			web.NSRouter("detail", &controllers.TaskController{}, "get:Detail"),
			// 任务名称是否存在
			web.NSRouter("exists", &controllers.TaskController{}, "get:Exists"),
			// 任务发布
			web.NSRouter("publish", &controllers.TaskController{}, "post:Publish"),
			// 可用计算节点获取
			web.NSRouter("executors", &controllers.TaskController{}, "get:GetTaskExecutors"),
			// 任务启动
			web.NSRouter("start", &controllers.TaskController{}, "post:Start"),
			// 评估结果下载
			web.NSRouter("eval/res", &controllers.TaskController{}, "get:QueryEvalResult"),
			// 预测结果下载
			web.NSRouter("result/download", &controllers.TaskController{}, "get:DownloadResult"),
			// 获取计算日志
			web.NSRouter("log", &controllers.TaskController{}, "get:GetTaskLog"),
		),

		// 算法管理
		web.NSNamespace("algo",
			// 算法列表
			web.NSRouter("list", &controllers.AlgoController{}, "get:List"),
			// 算法详情
			web.NSRouter("detail", &controllers.AlgoController{}, "get:Detail"),
			// 算法下载
			web.NSRouter("download", &controllers.AlgoController{}, "get:Download"),
		),

		// 登录客户baas平台 http://106.74.25.95:8081/explorer/summary
		web.NSNamespace("baas",
			// 获取baas登录token
			web.NSRouter("gettoken", &controllers.BaaSController{}, "get:GetBaasToken"),
		),
	)

	web.AddNamespace(ns)
	web.AddNamespace(console)
}
