// Package op 平台运维管理逻辑实现
package op

// RespChainNode
type RespChainNode struct {
	Mnemonic     string      `json:"mnemonic",omitempty`
	ContractName string      `json:"contractName",omitempty`
	NodeList     []ChainNode `json:"nodeList",omitempty`
}

// ChainNode
type ChainNode struct {
	Name   string `json:"name",omitempty`
	Host   string `json:"host",omitempty`
	Status string `json:"status",omitempty`
}
