// Package op 平台运维管理逻辑实现
package op

import (
	"baidu/blockchain/dtx-manager/config"
	"baidu/blockchain/dtx-manager/pkg/cache"
	"baidu/blockchain/dtx-manager/pkg/codeerror"
	"baidu/blockchain/dtx-manager/pkg/xdb"
)

// NetInfo 网络概率
type NetInfo struct {
	SysHealth       string  `json:"sysHealth"`       // system health status, green/yellow/red
	FilesHealthRate float64 `json:"filesHealthRate"` // file health rate
	NodeHealthRate  float64 `json:"nodeHealthRate"`  // node health rate
	NodeNum         int     `json:"nodeNum"`         // total nodes number
	GreenNodeNum    int     `json:"greenNodeNum"`    // green node number
	YellowNodeNum   int     `json:"yellowNodeNum"`   // yellow node number
	RedNodeNum      int     `json:"redNodeNum"`      // red node number
	NsNum           int     `json:"nsNum"`           // namespace number
	FileNum         int     `json:"fileNum"`
	FileExpiredNum  int     `json:"fileExpiredNum"`
	GreenFileNum    int     `json:"greenFileNum"`  // green files number
	YellowFileNum   int     `json:"yellowFileNum"` // yellow files number
	RedFileNum      int     `json:"redFileNum"`    // red files number
}

// NodeInfo 节点概览
type NodeInfo struct {
	StorageNodeList []*StorageNode `json:"storageNodeList"`
	DataNodeList    []*DataNode    `json:"dataNodeList"`
}

// DataNode 数据持有节点
type DataNode struct {
	Name   string `json:"name"`
	Host   string `json:"host"`
	Status string `json:"status"`
	NodeID string `json:"nodeID"`
}

// StorageNode 存储节点
type StorageNode struct {
	Name   string `json:"name"`
	Host   string `json:"host"`
	Status string `json:"status"`
	NodeID string `json:"nodeID"`
}

// GetXdbNetInfo
func (h *Handler) GetXdbNetInfo() (*NetInfo, error) {
	// 获取缓存的namespace信息
	totalNsNum := 0
	nsFilesData, _ := cache.GetNamespaceFilesMap("data", true)
	if nsFilesData != nil {
		totalNsNum += len(nsFilesData)
	}
	nsFilesModel, _ := cache.GetNamespaceFilesMap("model", true)
	if nsFilesModel != nil {
		totalNsNum += len(nsFilesModel)
	}

	info, err := cache.GetXDBSysHealth()
	if err != nil {
		return nil, err
	}
	return &NetInfo{
		SysHealth:       info.SysHealth,
		FilesHealthRate: info.FilesHealthRate,
		NodeHealthRate:  info.NodeHealthRate,
		NodeNum:         info.NodeNum,
		GreenNodeNum:    info.GreenNodeNum,
		YellowNodeNum:   info.YellowNodeNum,
		RedNodeNum:      info.RedNodeNum,
		NsNum:           totalNsNum,
		FileNum:         info.FileNum,
		FileExpiredNum:  info.FileExpiredNum,
		GreenFileNum:    info.GreenFileNum,
		YellowFileNum:   info.YellowFileNum,
		RedFileNum:      info.RedFileNum,
	}, nil
}

// GetXdbNodeInfo
func (h *Handler) GetXdbNodeInfo() (*NodeInfo, error) {
	var nodeInfo NodeInfo
	xdbClient := xdb.GetXDBClient(config.GetXDBConfig())
	storageNode, err := xdbClient.StorageNodeList()
	if err != nil {
		return nil, err
	}
	for _, node := range storageNode {
		storageNode := &StorageNode{
			Name:   node.Name,
			Host:   node.Address,
			NodeID: string(node.ID),
		}
		if node.Online {
			storageNode.Status = "Online"
		} else {
			storageNode.Status = "Offline"
		}
		nodeInfo.StorageNodeList = append(nodeInfo.StorageNodeList, storageNode)
	}
	xdbConf := config.GetXDBConfig()
	nodeInfo.DataNodeList = append(nodeInfo.DataNodeList, &DataNode{
		Name:   xdbConf.Name,
		Host:   xdbConf.Host,
		NodeID: xdbConf.NodeID,
		Status: "Online",
	})

	return &nodeInfo, nil
}

func (h *Handler) ReplicaLimit() (int64, error) {
	nodeInfo, err := h.GetXdbNodeInfo()
	if err != nil {
		return 0, codeerror.NewErrorByCode(codeerror.ErrCodeInternal, err.Error())
	}

	maxReplica := 0
	for _, node := range nodeInfo.StorageNodeList {
		if node.Status == "Online" {
			maxReplica++
		}
	}
	return int64(maxReplica), nil
}
