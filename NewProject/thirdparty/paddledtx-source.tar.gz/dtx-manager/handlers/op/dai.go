// Package op 平台运维管理逻辑实现
package op

import (
	"baidu/blockchain/dtx-manager/handlers/user"
	"baidu/blockchain/dtx-manager/models"
	"baidu/blockchain/dtx-manager/pkg/cache"
	"baidu/blockchain/dtx-manager/pkg/dai"
	"baidu/blockchain/dtx-manager/pkg/logger"
	"encoding/hex"
	"time"

	pbTask "github.com/PaddlePaddle/PaddleDTX/dai/protos/task"
)

// DaiNode Dai节点信息
type DaiNode struct {
	Name         string `json:"name"`
	Host         string `json:"host"`
	GrpcHost     string `json:"grpcHost"`
	Status       string `json:"status"`
	NodeID       string `json:"nodeID"`
	Health       string `json:"health"`
	RegisterTime int64  `json:"registerTime"`
}

// DaiNet
type DaiNet struct {
	Health float64    `json:"health"`
	Nodes  []*DaiNode `json:"nodes"`
}

// TaskInfo 任务概览信息
type TaskInfo struct {
	TotalTask    int64   `json:"totalTasks"`
	WaitingTasks int64   `json:"waitingTasks"`
	RunningTasks int64   `json:"runningTasks"`
	FailedTasks  int64   `json:"failedTasks"`
	SuccessTasks int64   `json:"successTasks"`
	Health       float64 `json:"health"`
}

// GetDaiNetInfo
func (h *Handler) GetDaiNetInfo() (*DaiNet, error) {
	var ret DaiNet

	cli := dai.GetDaiClient()
	nodeList, err := cache.GetExecutorList()
	if err != nil {
		return &ret, err
	}
	// 获取所有机构
	orgInfoList, err := cache.GetOrgInfoList()

	// 获取用户信息中的orgid 当前组织
	handler := user.NewHandler(h.RequestID)
	selfInfo := handler.GetOrgInfo()
	logger.Debugf("GetDaiNetInfo 审核未通过 ===== ")
	cntGreen := 0
	if orgInfo := cache.GetOrgInfoByID(string(selfInfo.OrgID)); orgInfo != nil {
		logger.Debugf("GetDaiNetInfo 审核未通过 ===== %v", orgInfo)
		// 审核未通过
		if orgInfo.Apply == 0 {
			logger.Debugf("GetDaiNetInfo 审核未通过 ===== ")
			for _, v := range nodeList {
				if v.OrgID == orgInfo.ID {
					logger.Debugf("GetDaiNetInfo 审核未通过 %s %s ===== ", v.OrgID, orgInfo.ID)
					d := &DaiNode{
						Name:         v.Name,
						Host:         v.HttpAddress,
						GrpcHost:     v.Address,
						NodeID:       hex.EncodeToString(v.ID),
						RegisterTime: v.RegTime / 1000000000,
					}
					if v.Online {
						d.Status = "Online"
					} else {
						d.Status = "Offline"
					}

					opt1 := &pbTask.GetExecutorNodeHealthRequest{
						Id:          v.ID,
						CurrentTime: time.Now().UnixNano(),
					}
					health, err := cli.GetExecutorNodeHealth(opt1)
					if err == nil {
						d.Health = health
						if health == "Green" {
							cntGreen++
						}
					}
					ret.Nodes = append(ret.Nodes, d)
					logger.Debug("GetDaiNetInfo 审核未通过 %v ===== ", ret)
				}
			}
		} else {
			for _, info := range orgInfoList {
				if info.Apply == 1 {
					for _, v := range nodeList {
						if info.ID == v.OrgID {
							d := &DaiNode{
								Name:         v.Name,
								Host:         v.HttpAddress,
								GrpcHost:     v.Address,
								NodeID:       hex.EncodeToString(v.ID),
								RegisterTime: v.RegTime / 1000000000,
							}
							if v.Online {
								d.Status = "Online"
							} else {
								d.Status = "Offline"
							}

							opt1 := &pbTask.GetExecutorNodeHealthRequest{
								Id:          v.ID,
								CurrentTime: time.Now().UnixNano(),
							}
							health, err := cli.GetExecutorNodeHealth(opt1)
							if err == nil {
								d.Health = health
								if health == "Green" {
									cntGreen++
								}
							}
							ret.Nodes = append(ret.Nodes, d)
						}
					}
				}
			}
		}
	}
	ret.Health = float64(cntGreen) / float64(len(nodeList))

	return &ret, nil
}

// GetDaiTaskInfo 汇总统计链上任务数量, 不包含编辑中未发布任务
func (h *Handler) GetDaiTaskInfo() (*TaskInfo, error) {
	cnt_map, err := models.CountTasksByStatus()
	if err != nil {
		return nil, err
	}

	task_info := TaskInfo{}
	for k, cnt := range cnt_map {
		if k == models.TaskStatusPublished {
			task_info.WaitingTasks = cnt
		} else if k == models.TaskStatusRunning {
			task_info.RunningTasks = cnt
		} else if k == models.TaskStatusFailed {
			task_info.FailedTasks = cnt
		} else if k == models.TaskStatusFinished {
			task_info.SuccessTasks = cnt
		} else {
			continue
		}
		task_info.TotalTask += cnt
	}
	if task_info.TotalTask != 0 {
		task_info.Health = float64(task_info.SuccessTasks) / float64(task_info.TotalTask)
	}

	return &task_info, nil
}
