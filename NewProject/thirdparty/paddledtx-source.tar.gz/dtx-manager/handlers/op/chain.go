// Package op 平台运维管理逻辑实现
package op

import "baidu/blockchain/dtx-manager/config"

type Handler struct {
	RequestID string
}

// NewHandler
func NewHandler(requestId string) Handler {
	return Handler{
		RequestID: requestId,
	}
}

// GetBlockchainNode
func (h *Handler) GetBlockchainNode() *RespChainNode {
	if config.GetChainType() == "fabric" {
		fabricConf := config.GetFabricConf()
		node := &ChainNode{
			Name:   fabricConf.OrgName,
			Host:   fabricConf.ChainAddr,
			Status: "Running",
		}

		return &RespChainNode{
			Mnemonic:     "",
			ContractName: fabricConf.DtxChaincode,
			NodeList:     []ChainNode{*node},
		}
	} else {
		xchainConf := config.GetXchainConf()

		node := &ChainNode{
			Name:   xchainConf.ChainName,
			Host:   xchainConf.ChainAddress,
			Status: "Running",
		}
		return &RespChainNode{
			Mnemonic:     xchainConf.Mnemonic,
			ContractName: xchainConf.DtxContractName,
			NodeList:     []ChainNode{*node},
		}
	}
}
