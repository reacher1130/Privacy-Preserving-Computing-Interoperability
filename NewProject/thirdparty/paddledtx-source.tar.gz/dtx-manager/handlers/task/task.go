// Package task 任务管理模块逻辑实现
package task

import (
	"encoding/hex"
	"encoding/json"
	"fmt"
	"strings"
	"time"

	"baidu/blockchain/dtx-manager/config"
	"baidu/blockchain/dtx-manager/models"
	"baidu/blockchain/dtx-manager/pkg/blockchain"
	"baidu/blockchain/dtx-manager/pkg/cache"
	"baidu/blockchain/dtx-manager/pkg/codeerror"
	"baidu/blockchain/dtx-manager/pkg/dai"
	"baidu/blockchain/dtx-manager/pkg/logger"

	"github.com/PaddlePaddle/PaddleDTX/crypto/core/ecdsa"
	"github.com/PaddlePaddle/PaddleDTX/dai/crypto/vl/common/csv"
	dai_common "github.com/PaddlePaddle/PaddleDTX/dai/protos/common"
	"github.com/PaddlePaddle/PaddleDTX/dai/protos/task"
)

type Handler struct {
	RequestID string
}

// dai.DataForTask子集
type DataForTask struct {
	Executor    string      `json:"executor,omitempty"`
	DataID      string      `json:"dataID,omitempty"`
	PsiLabel    string      `json:"psiLabel,omitempty"`
	FeatureEngs interface{} `json:"featureEngs,omitempty"`
}

// L1 任务参数, dai_task.FLTask子集
type TaskParams struct {
	TaskName    string                 `json:"name,omitempty"`
	Description string                 `json:"description,omitempty"`
	DataSets    []*DataForTask         `json:"dataSets,omitempty"`
	AlgoParam   *dai_common.TaskParams `json:"algoParam,omitempty"`
}

func NewHandler(requestId string) Handler {
	return Handler{
		RequestID: requestId,
	}
}

// CreateTask 创建任务
func (h *Handler) CreateTask(newtask *models.Task) error {
	// 1.check taskname is already existed
	task, err := models.QueryTaskByName(newtask.TaskName)
	if err != nil && !models.IsNoRowFoundError(err) {
		return codeerror.NewErrorByCode(codeerror.ErrQueryFailed, err.Error())
	}
	if task != nil {
		return codeerror.NewErrorByCode(codeerror.ErrTaskExisted)
	}

	// 2.check tasktype
	if newtask.TaskType != "train" && newtask.TaskType != "predict" && newtask.TaskType != "psi" {
		return codeerror.NewErrorByCode(codeerror.ErrTaskTypeError)
	}
	// 3.check taskparams if have
	if newtask.TaskParams != "" && newtask.TaskParams != "{}" {
		// 2.1.parse taskparams
		pub_opts, err := ParsePublishOptionsFromParamsStr(newtask.TaskName, newtask.TaskParams)
		if err != nil {
			logger.Errorf("parse taskparams failed, err: %v", err)
			return codeerror.NewErrorByCode(codeerror.ErrTaskParamError)
		}

		// 2.2.check taskparams
		client, err := dai.GetRequesterClient()
		if err != nil {
			logger.Errorf("GetRequesterClient failed, err: %v", err)
			return codeerror.NewErrorByCode(codeerror.ErrCodeInternal, err.Error())
		}
		if _, _, err = client.CheckPublishTaskOptions(pub_opts); err != nil {
			logger.Errorf("check taskparams failed, err: %v", err)
			return err
		}

		// 2.3.fill taskParams by default values
		filledParams, err := fillTaskParamsByDefault(newtask.TaskParams)
		if err != nil {
			logger.Errorf("fill task params failed, err: %v", err)
			return codeerror.NewErrorByCode(codeerror.ErrTaskParamError, err.Error())
		}
		newtask.TaskParams = filledParams
	}

	// 4.insert into db
	id, err := models.InsertTask(newtask)
	if err != nil {
		return err
	} else {
		newtask.ID = uint64(id)
	}

	return nil
}

// CloneTask 克隆任务
func (h *Handler) CloneTask(id uint64, create_by string) (*models.Task, error) {
	// 1.query task
	task, err := models.QueryTask(id)
	if err != nil {
		return nil, err
	}
	if task == nil {
		return nil, codeerror.NewErrorByCode(codeerror.ErrTaskNotExisted)
	}

	// 2.update origin task.updatetime, for ordering
	time_now := time.Now()
	task.UpdateTime = time_now
	models.UpdateTaskStatus(task)

	// 3.modify task
	new_taskname := fmt.Sprintf("%s_copy%d", task.TaskName, time.Now().Unix())
	// 3.1.check taskname is already existed
	new_task, err := models.QueryTaskByName(new_taskname)
	if err != nil && !models.IsNoRowFoundError(err) {
		return nil, err
	}
	if new_task != nil {
		return nil, codeerror.NewErrorByCode(codeerror.ErrTaskExisted)
	}

	task.ID = 0
	task.TaskID = ""
	task.ErrMsg = ""
	task.TaskStatus = models.TaskStatusPreparing
	task.CreateBy = create_by
	task.TaskName = new_taskname
	task.CreateTime = time_now
	task.UpdateTime = time_now

	// 4.insert into db
	_, err = models.InsertTask(task)
	if err != nil {
		return nil, err
	}

	return task, nil
}

// DeleteTask 删除任务
func (h *Handler) DeleteTask(id uint64) error {
	// try delete
	task := &models.Task{
		ID: id,
	}

	_, err := models.DeleteTask(task)
	return err
}

// ParsePublishOptionsFromParamsStr 函数从paramsStr中解析出 PublishOptions 对象
func ParsePublishOptionsFromParamsStr(taskname, paramsStr string) (dai.PublishOptions, error) {

	obj_taskparams := TaskParams{}
	err := json.Unmarshal([]byte(paramsStr), &obj_taskparams)
	if err != nil {
		logger.Errorf("parse params str failed, err: %s", err.Error())
		return dai.PublishOptions{}, err
	}
	if len(obj_taskparams.DataSets) < 2 {
		logger.Errorf("parse params str failed, dataSets size error")
		return dai.PublishOptions{}, err
	}

	// 处理为pubopts
	pub_opts := dai.PublishOptions{
		PrivateKey:  config.GetPrivateKey(),
		Files:       obj_taskparams.DataSets[0].DataID + "," + obj_taskparams.DataSets[1].DataID,
		Executors:   obj_taskparams.DataSets[0].Executor + "," + obj_taskparams.DataSets[1].Executor,
		PSILabels:   obj_taskparams.DataSets[0].PsiLabel + "," + obj_taskparams.DataSets[1].PsiLabel,
		Description: obj_taskparams.Description,
		TaskName:    taskname,
		AlgoParam:   *obj_taskparams.AlgoParam,
	}

	for _, data_set := range obj_taskparams.DataSets {
		feateng, _ := json.Marshal(data_set.FeatureEngs)
		pub_opts.FeatEngs = append(pub_opts.FeatEngs, feateng)
	}

	return pub_opts, nil
}

// UpdateTask 更新任务参数
func (h *Handler) UpdateTask(newtask *models.Task) error {
	// 0.check taskname is already existed
	task, err := models.QueryTaskByName(newtask.TaskName)
	if err != nil && !models.IsNoRowFoundError(err) {
		return codeerror.NewErrorByCode(codeerror.ErrQueryFailed, err.Error())
	}
	if task != nil && task.ID != newtask.ID {
		return codeerror.NewErrorByCode(codeerror.ErrTaskExisted)
	}

	// 1.parse taskparams
	pub_opts, err := ParsePublishOptionsFromParamsStr(newtask.TaskName, newtask.TaskParams)
	if err != nil {
		logger.Errorf("parse taskparams failed, err: %v", err)
		return codeerror.NewErrorByCode(codeerror.ErrTaskParamError, err.Error())
	}

	// 2.check taskparams
	client, err := dai.GetRequesterClient()
	if err != nil {
		logger.Errorf("GetRequesterClient failed, err: %v", err)
		return codeerror.NewErrorByCode(codeerror.ErrCodeInternal, err.Error())
	}
	if _, _, err = client.CheckPublishTaskOptions(pub_opts); err != nil {
		logger.Errorf("check taskparams failed, err: %v", err)
		return err
	}

	// 3.fill taskParams by default values
	filledParams, err := fillTaskParamsByDefault(newtask.TaskParams)
	if err != nil {
		logger.Errorf("fill task params failed, err: %v", err)
		return codeerror.NewErrorByCode(codeerror.ErrTaskParamError, err.Error())
	}
	newtask.TaskParams = filledParams

	// 4.update into db
	_, err = models.UpdateTask(newtask)
	if err != nil {
		logger.Errorf("update task failed, err: %v", err)
	}
	return err
}

// QueryTask 查询任务详情
func (h *Handler) QueryTask(id uint64) (*models.Task, error) {
	if id <= 0 {
		return nil, codeerror.NewErrorByCode(codeerror.ErrTaskNotExisted)
	}

	task, err := models.QueryTask(id)
	if err != nil && !models.IsNoRowFoundError(err) {
		return nil, err
	}
	if task == nil {
		return nil, codeerror.NewErrorByCode(codeerror.ErrTaskNotExisted)
	}

	// 若是已发布或是已启动状态的任务, 查询链上信息, 同步最新任务状态
	if task.TaskStatus == models.TaskStatusPublished || task.TaskStatus == models.TaskStatusRunning {
		err := h.SyncTaskStatus(task)
		if err != nil {
			logger.Errorf("SyncTaskStatus failed, err: %v", err)
		}
	}

	return task, nil
}

// QueryTask 基于任务名称查询ID
func (h *Handler) QueryIDByName(name string) (uint64, error) {
	if name == "" {
		return 0, codeerror.NewErrorByCode(codeerror.ErrTaskParamError)
	}

	task, err := models.QueryTaskByName(name)
	if err != nil && !models.IsNoRowFoundError(err) {
		return 0, err
	}
	if task != nil {
		return task.ID, nil
	}
	return 0, nil
}

// ListTask 查询任务列表
func (h *Handler) ListTasks(opts *models.TaskQueryOpts) ([]*models.Task, int64, error) {
	tasks, total, err := models.ListTasks(opts)
	if err != nil {
		return nil, 0, err
	}
	// 同步任务状态信息
	go h.SyncAllTaskStatus()

	return tasks, total, nil
}

// SyncAllTaskStatus 查询链上任务状态, 更新到数据库.
func (h *Handler) SyncAllTaskStatus() error {
	// // 查询链上任务状态, 更新到数据库.
	// // 任务发布-> 	(Confirming, Ready)  任务启动-> (ToProcess, Processing)  ||  任务结束-> (Finished  || Failed, Stopped, Rejected)
	// //                    待启动      						计算中 			 |				 	已完成 | 计算失败

	// 之前状态为计算中和发布后未启动的任务
	opts := &models.TaskQueryOpts{
		StatusIn: []int{models.TaskStatusRunning, models.TaskStatusPublished},
	}
	tasks, _, err := models.ListTasks(opts)
	if err != nil {
		logger.Errorf("QueryTasksByStatus failed, err: %v", err)
		return err
	}
	for _, task := range tasks {
		err := h.SyncTaskStatus(task)
		if err != nil {
			logger.Errorf("SyncTaskStatus failed, err: %v", err)
			continue
		}
	}
	logger.Infof("SyncAllTaskStatus finished with %d tasks checked", len(tasks))

	return nil
}

// SyncTaskStatus 同步并更新任务入库
func (h *Handler) SyncTaskStatus(task *models.Task) error {
	defer func() {
		if r := recover(); r != nil {
			logger.Errorf(`SyncTaskStatus failed, err: %v`, r)
		}
	}()

	if task.TaskStatus != models.TaskStatusPublished && task.TaskStatus != models.TaskStatusRunning {
		return nil
	}
	cli, err := dai.GetRequesterClient()
	if err != nil {
		logger.Errorf("GetRequesterClient failed, err: %v", err)
		return err
	}
	chain_task, err := cli.GetTaskById(task.TaskID)
	if err != nil || chain_task == nil {
		logger.Errorf("GetTaskById failed, err: %v", err)
		return err
	}
	logger.Infof("SyncTaskStatus: taskID: %s, status: %s", task.TaskID, chain_task.Status)
	// 更新任务入库
	if chain_task.Status == "Finished" {
		task.TaskStatus = models.TaskStatusFinished
		task.UpdateTime = time.Now()
		models.UpdateTaskStatus(task)
	} else if chain_task.Status == "Failed" || chain_task.Status == "Stopped" || chain_task.Status == "Rejected" {
		task.TaskStatus = models.TaskStatusFailed
		task.ErrMsg = strings.Replace(chain_task.ErrMessage, "\\u0026", "&", -1)
		task.UpdateTime = time.Now()
		models.UpdateTaskStatus(task)
	}
	return nil
}

// PublishTask 发布任务
func (h *Handler) PublishTask(id uint64) (string, error) {
	// 1.query task
	task, err := models.QueryTask(id)
	if err != nil && !models.IsNoRowFoundError(err) {
		logger.Errorf("query task failed, err: %v", err)
		return "", err
	}
	if task == nil {
		return "", codeerror.NewErrorByCode(codeerror.ErrTaskNotExisted)
	}
	if task.TaskStatus != models.TaskStatusPreparing {
		return "", codeerror.NewErrorByCode(codeerror.ErrTaskPublished)
	}

	// 2.parse taskParams
	pub_opts, err := ParsePublishOptionsFromParamsStr(task.TaskName, task.TaskParams)
	if err != nil {
		logger.Errorf("parse taskparams failed, err: %v", err)
		return "", err
	}

	// 3.try publish and get taskid
	cli, err := dai.GetRequesterClient()
	if err != nil {
		logger.Errorf("GetRequesterClient failed, err: %v", err)
		return "", err
	}
	task.TaskID, err = cli.Publish(pub_opts)
	if err != nil {
		logger.Errorf("publish task failed, err: %v", err)
		return "", err
	}

	// 4.update task into db
	task.TaskStatus = models.TaskStatusPublished
	task.UpdateTime = time.Now()
	_, err = models.UpdateTaskStatus(task)
	if err != nil {
		logger.Errorf("update task failed, err: %v", err)
	}
	return task.TaskID, err
}

// StartTask 启动任务
func (h *Handler) StartTask(id uint64) error {
	// 1.query task
	task, err := models.QueryTask(id)
	if err != nil && !models.IsNoRowFoundError(err) {
		logger.Errorf("query task failed, err: %v", err)
		return err
	}
	if task == nil {
		return codeerror.NewErrorByCode(codeerror.ErrTaskNotExisted)
	}
	if task.TaskStatus != models.TaskStatusPublished {
		return codeerror.NewErrorByCode(codeerror.ErrTaskNotPublished)
	}

	// 2.try start task
	cli, err := dai.GetRequesterClient()
	if err != nil {
		logger.Errorf("GetRequesterClient failed, err: %v", err)
		return err
	}
	err = cli.StartTask(config.GetPrivateKey(), task.TaskID)
	if err != nil {
		logger.Errorf("start task failed, err: %v", err)
		return codeerror.NewErrorByCode(codeerror.ErrTaskConfirming)
	}

	// 3.update task into db
	task.TaskStatus = models.TaskStatusRunning
	task.UpdateTime = time.Now()
	_, err = models.UpdateTaskStatus(task)
	if err != nil {
		logger.Errorf("update task failed, err: %v", err)
	}
	return err
}

// QueryEvalResult 查询评估结果
func (h *Handler) QueryEvalResult(id uint64) (*task.EvaluationResponse, error) {
	res := &task.EvaluationResponse{}
	// 1.query task
	task, err := models.QueryTask(id)
	if err != nil && !models.IsNoRowFoundError(err) {
		logger.Errorf("query task failed, err: %v", err)
		return res, err
	}
	if task == nil {
		return res, codeerror.NewErrorByCode(codeerror.ErrTaskNotExisted)
	}
	if task.TaskStatus == models.TaskStatusFailed {
		return res, codeerror.NewErrorByCode(codeerror.ErrTaskStatusError, "task already failed")
	}
	if task.TaskStatus != models.TaskStatusFinished {
		return res, codeerror.NewErrorByCode(codeerror.ErrTaskStatusError, "task not finished")
	}

	// 2.judge whether task has eval result
	pub_opts, err := ParsePublishOptionsFromParamsStr(task.TaskName, task.TaskParams)
	if err != nil {
		logger.Errorf("parse taskparams failed, err: %v", err)
		return res, codeerror.NewErrorByCode(codeerror.ErrTaskParamError)
	}

	if (pub_opts.AlgoParam.EvalParams == nil || !pub_opts.AlgoParam.EvalParams.Enable) && (pub_opts.AlgoParam.LivalParams == nil || !pub_opts.AlgoParam.LivalParams.Enable) {
		return res, nil
	}

	// 3.try query eval result
	cli, err := dai.GetRequesterClient()
	if err != nil {
		logger.Errorf("GetRequesterClient failed, err: %v", err)
		return res, err
	}
	_, res, _, err = cli.GetEvalMetricsById(config.GetPrivateKey(), task.TaskID)
	if err != nil {
		logger.Errorf("QueryEvalResult failed, err: %v", err)
		return res, err
	}
	return res, nil
}

// QueryPredResult 下载预测结果
func (h *Handler) QueryResult(id uint64) ([]byte, string, error) {
	// 1.query task
	task, err := models.QueryTask(id)
	if err != nil && !models.IsNoRowFoundError(err) {
		logger.Errorf("query task failed, err: %v", err)
		return []byte{}, "", err
	}
	if task == nil {
		return []byte{}, "", codeerror.NewErrorByCode(codeerror.ErrTaskNotExisted)
	}
	if task.TaskStatus == models.TaskStatusFailed {
		return []byte{}, "", codeerror.NewErrorByCode(codeerror.ErrTaskStatusError, "task already failed")
	}
	if task.TaskStatus != models.TaskStatusFinished {
		return []byte{}, "", codeerror.NewErrorByCode(codeerror.ErrTaskStatusError, "task not finished")
	}

	// 2 swich tasktype
	switch task.TaskType {
	case "predict":
		cli, err := dai.GetRequesterClient()
		if err != nil {
			logger.Errorf("GetRequesterClient failed, err: %v", err)
			return []byte{}, "", err
		}
		rowsData, err := cli.GetPredictResult(config.GetPrivateKey(), task.TaskID)
		if err != nil {
			logger.Errorf("GetPredictResult failed, err: %v", err)
			return []byte{}, "", err
		}

		var rows [][]string
		if err := json.Unmarshal(rowsData, &rows); err != nil {
			return []byte{}, "", codeerror.NewErrorByCode(codeerror.ErrInternalServer, "json unmarshal error")
		}
		// convert to csv bytes
		fileData, err := csv.ConvertRowsToBytes(rows)
		if err != nil {
			return []byte{}, "", codeerror.NewErrorByCode(codeerror.ErrInternalServer, "Convert Rows To CSV Bytes failed")
		}

		filename := fmt.Sprintf("%s.csv", task.TaskName)
		return fileData, filename, nil
	case "psi":
		logger.Info("get psi result begin")
		cli, err := dai.GetRequesterClient()
		if err != nil {
			logger.Errorf("GetRequesterClient failed, err: %v", err)
			return []byte{}, "", err
		}
		rowsData, err := cli.GetPsiResult(config.GetPrivateKey(), task.TaskID)
		if err != nil {
			logger.Errorf("GetPsiResult failed, err: %v", err)
			return []byte{}, "", err
		}

		//var rows [][]string
		//if err := json.Unmarshal(rowsData, &rows); err != nil {
		//	return []byte{}, "", codeerror.NewErrorByCode(codeerror.ErrInternalServer, "json unmarshal error")
		//}
		//// convert to csv bytes
		//fileData, err := csv.ConvertRowsToBytes(rows)
		//if err != nil {
		//	return []byte{}, "", codeerror.NewErrorByCode(codeerror.ErrInternalServer, "Convert Rows To CSV Bytes failed")
		//}

		filename := fmt.Sprintf("%s.csv", task.TaskName)
		return rowsData, filename, nil
	default:
		return []byte{}, "", fmt.Errorf("task type not supported")
	}
	//return nil, "", fmt.Errorf("task type not supported")
}

// GetTaskExecutors 返回任务执行器列表
func (h *Handler) GetTaskExecutors(resourceID string) ([]string, error) {
	res := make([]string, 0)

	// 获取文件信息, 得到机构公钥
	cli, err := blockchain.GetBlockchainClient()
	if err != nil {
		return nil, err
	}
	dataFile, err := cli.GetCatalogFileDetailByID(resourceID)
	if err != nil {
		return nil, codeerror.NewErrorByCode(codeerror.ErrResourceNotExisted, "get catalog file failed")
	}
	owner := hex.EncodeToString(dataFile.Owner)

	// 查询机构信息
	pubKey, _ := ecdsa.DecodePublicKeyFromString(owner)
	org_info, err := cli.QueryOrgInfoByPK(string(pubKey[:]))
	if err != nil {
		return nil, err
	}

	// 获取所有的执行器
	exeList, err := cache.GetExecutorList()
	if err != nil {
		logger.Errorf("GetExecutorList failed, err: %v", err)
		return nil, err
	}
	// 获取对应机构的所有的执行器
	for _, exenode := range exeList {
		if exenode.OrgID == org_info.ID {
			res = append(res, exenode.Name)
		}
	}

	return res, nil
}

// QueryTaskLog 获取计算日志
func (h *Handler) QueryTaskLog(id uint64) (string, error) {
	// 1.query task
	task, err := models.QueryTask(id)
	if err != nil && !models.IsNoRowFoundError(err) {
		logger.Errorf("query task failed, err: %v", err)
		return "", err
	}
	if task == nil {
		return "", codeerror.NewErrorByCode(codeerror.ErrTaskNotExisted)
	}

	// 2.try query task log
	cli, err := dai.GetRequesterClient()
	if err != nil {
		logger.Errorf("GetRequesterClient failed, err: %v", err)
		return "", err
	}
	logData, err := cli.GetTaskLog(task.TaskID)
	if err != nil {
		logger.Errorf("GetTaskLog failed, err: %v", err)
		return "", err
	}

	return string(logData), nil
}

func fillTaskParamsByDefault(paramStr string) (res string, err error) {
	defer func() {
		if r := recover(); r != nil {
			err = fmt.Errorf("fillTaskParamsByDefault error: %v", r)
		}
	}()

	if len(paramStr) == 0 {
		return "", nil
	}

	taskParams := TaskParams{}
	if err := json.Unmarshal([]byte(paramStr), &taskParams); err != nil {
		return "", err
	}
	filledParams := dai.FillParamsByDefault(taskParams.AlgoParam)
	taskParams.AlgoParam = filledParams
	newParams, _ := json.Marshal(taskParams)

	return string(newParams), nil
}

func JudgeTaskEvaluable(paramStr string) bool {
	defer func() {
		if r := recover(); r != nil {
			logger.Warnf("JudgeTaskEvaluable error: %v", r)
		}
	}()

	if len(paramStr) == 0 {
		return false
	}

	taskParams := TaskParams{}
	if err := json.Unmarshal([]byte(paramStr), &taskParams); err != nil {
		return false
	}

	params := taskParams.AlgoParam
	if params != nil && params.TaskType == dai_common.TaskType_LEARN {
		if params.EvalParams != nil && params.EvalParams.Enable {
			return true
		} else if params.LivalParams != nil && params.LivalParams.Enable {
			return true
		}
		return false
	}
	return false
}
