// Package data 数据资源管理模块
package data

import (
	bc "baidu/blockchain/dtx-manager/blockchain"
	"baidu/blockchain/dtx-manager/config"
	"baidu/blockchain/dtx-manager/handlers/catalog"
	"baidu/blockchain/dtx-manager/models"
	"baidu/blockchain/dtx-manager/pkg/blockchain"
	"baidu/blockchain/dtx-manager/pkg/codeerror"
	"baidu/blockchain/dtx-manager/pkg/common"
	"baidu/blockchain/dtx-manager/pkg/format"
	"baidu/blockchain/dtx-manager/pkg/logger"
	"baidu/blockchain/dtx-manager/pkg/uuid"
	"baidu/blockchain/dtx-manager/pkg/xdb"
	"bufio"
	"bytes"
	"crypto/md5"
	"encoding/csv"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"os"
	"path/filepath"
	"strings"
	"time"

	util "github.com/PaddlePaddle/PaddleDTX/xdb/pkgs/strings"

	"github.com/PaddlePaddle/PaddleDTX/crypto/core/aes"
	"github.com/PaddlePaddle/PaddleDTX/crypto/core/ecdsa"
	"github.com/PaddlePaddle/PaddleDTX/crypto/core/machine_learning/feature_engineering"
	"github.com/xuperchain/crypto/core/hash"
)

// Handler
type Handler struct {
	RequestID string
}

// NewHandler
func NewHandler(requestId string) Handler {
	return Handler{
		RequestID: requestId,
	}
}

// Create
func (h *Handler) Create(dataResource *models.DataResource) (uint64, string, error) {
	// 查重名
	cli, err := blockchain.GetBlockchainClient()
	if err != nil {
		return 0, "", err
	}
	if _, err := cli.GetCatalogFileDetailByFileName(bc.CatalogFileTypeOfData, dataResource.Namespace, dataResource.ResourceName); err == nil {
		return 0, "", codeerror.NewError(codeerror.ErrCodeAlreadyExists, "duplicate name")
	}

	// 解析中状态
	dataResource.Status = models.StatusParsing
	if _, err := models.InsertDataResource(dataResource); err != nil {
		return 0, "", err
	}

	// 如果保存在本地 则生成uuid
	if dataResource.StorageType == 1 {
		dataResource.ResourceID = uuid.GenUUID()
	}

	// 异步解析及存储
	go h.ParseDataAndSave(dataResource)

	return dataResource.ID, dataResource.ResourceID, nil
}

// ParseDataAndSave
func (h *Handler) ParseDataAndSave(dataResource *models.DataResource) error {
	err := h.ParseData(dataResource)
	if err != nil {
		dataResource.Status = models.StatusParsingFailed
		models.UpdateDataSource(dataResource)
		logger.Error("ParseDataAndSave ParseData error:", err)
		return err
	}
	err = h.SaveData(dataResource)
	if err != nil {
		dataResource.Status = models.StatusStoredFaild
		models.UpdateDataSource(dataResource)
		logger.Error("ParseDataAndSave SaveData error:", err)
	}
	return err
}

// ParseDataAndUpdate 链上更新
func (h *Handler) ParseDataAndUpdate(dataResource *models.DataResource) error {
	err := h.ParseData(dataResource)
	if err != nil {
		logger.Error("ParseDataAndUpdate ParseData error:", err)
		// 状态改为更新失败
		dataResource.Status = models.StatusUpdateFailed
		_, err = models.UpdateDataSource(dataResource)
		return err
	}
	err = h.UpdataData(dataResource)
	if err != nil {
		logger.Error("ParseDataAndUpdate UpdataData error:", err)
		// 状态改为更新失败
		dataResource.Status = models.StatusUpdateFailed
		_, err = models.UpdateDataSource(dataResource)
		return err
	}
	err = h.UpdatePublish(dataResource)
	if err != nil {
		logger.Error("ParseDataAndUpdate UpdatePublish error:", err)
		// 状态改为更新失败
		dataResource.Status = models.StatusUpdateFailed
		_, err = models.UpdateDataSource(dataResource)
		return err
	}
	// 更新成功后状态改为已发布
	dataResource.Status = models.StatusPublished
	_, err = models.UpdateDataSource(dataResource)
	logger.Error("UpdateDataSource error:", err)
	return err
}

// UpdatePublish
func (h *Handler) UpdatePublish(dataResource *models.DataResource) error {
	cli, err := blockchain.GetBlockchainClient()
	if err != nil {
		return err
	}
	file, err := cli.GetCatalogFileDetailByID(dataResource.ResourceID)
	if err != nil {
		logger.Infof("dataResource %v not exist,", dataResource.ResourceID, err)
		return nil
	}

	// 2.更新发布的数据
	metaInfoDetail, err := h.MergeMetaAndDataInfo(dataResource.MetaInfo, dataResource.DataInfo)
	if err != nil {
		return err
	}
	metaInfo, _ := json.Marshal(metaInfoDetail)
	priKey, err := ecdsa.DecodePrivateKeyFromString(config.GetPrivateKey())
	if err != nil {
		return err
	}

	k := md5.New().Sum([]byte(config.SecretKey + dataResource.ResourceID))[0:32]
	encryptExt, err := aes.EncryptUsingAESGCM(aes.AESKey{
		Key:   k,
		Nonce: k[0:12],
	}, metaInfo, nil)
	if err != nil {
		logger.Infof("encrypt failed, err: %v", err)
		return err
	}

	opt := &bc.UpdateCatalogFileOptions{
		FileID:        file.FileID,
		NewExpireTime: dataResource.ExpireTime.UnixNano(),
		NewVersion:    dataResource.Version,
		NewLength:     uint64(dataResource.Size),
		NewNumber:     int64(dataResource.Number),
		// NewMerkleRoot:
		NewExt:      encryptExt,
		CurrentTime: time.Now().UnixNano(),
	}
	str, err := util.GetSigMessage(opt)
	if err != nil {
		return err
	}
	sign, err := ecdsa.Sign(priKey, hash.HashUsingSha256([]byte(str)))
	if err != nil {
		return err
	}
	opt.Signature = sign[:]
	err = cli.UpdateCatalogFileByID(opt)
	return err
}

// UpdateData
func (h *Handler) UpdataData(dataResource *models.DataResource) (err error) {
	defer func() {
		if r := recover(); r != nil {
			err = fmt.Errorf("UpdataData error, panic: %v", r)
		}
	}()

	if dataResource.StorageType == 0 {
		return h.saveToXDB(dataResource)
	} else {
		return h.saveToLocal(dataResource)
	}
}

// SaveData
func (h *Handler) SaveData(dataResource *models.DataResource) (err error) {
	defer func() {
		if r := recover(); r != nil {
			err = fmt.Errorf("SaveData error, panic: %v", r)
		}
	}()

	// 保存数据文件
	if dataResource.StorageType == 0 {
		return h.saveToXDB(dataResource)
	} else {
		return h.saveToLocal(dataResource)
	}
}

// ParseData
func (h *Handler) ParseData(dataResource *models.DataResource) (err error) {
	defer func() {
		if r := recover(); r != nil {
			err = fmt.Errorf("ParseData error, panic: %v", r)
		}
	}()

	var metaInfo []*models.MetaInfo
	dataInfo := make(map[string]*models.DataStats)

	// 统计信息输入
	var fileRows [][]string
	var features []string

	dataTemp := dataResource.FileTempPath + "_v2"
	metaF, err := os.Open(dataResource.MetaTempPath)
	if err != nil {
		return err
	}
	defer metaF.Close()
	dataF, err := os.Open(dataResource.FileTempPath)
	if err != nil {
		return err
	}
	defer dataF.Close()

	featureHasStr := make(map[string]bool)
	var metaFormat []*format.MetaFormat
	metaReader := bufio.NewReader(metaF)
	for {
		line, _, err := metaReader.ReadLine()
		if err == io.EOF {
			break
		}
		meta := format.ParFromatDefineStr(string(line))
		// 特征必须指定类型
		if len(meta.Type) == 0 {
			return fmt.Errorf("meta data error, data type is empty")
		}
		if strings.ToLower(meta.Type) == "string" {
			featureHasStr[meta.Name] = true
		}
		metaFormat = append(metaFormat, meta)
		metaInfo = append(metaInfo, &models.MetaInfo{
			Name:        meta.Name,
			Type:        meta.Type,
			Description: meta.Description,
		})
		features = append(features, meta.Name)
	}
	// fileRows = append(fileRows, features)

	// 格式化数据 并写入临时文件
	dataNewFile, err := os.Create(dataTemp)
	if err != nil {
		return err
	}
	defer dataNewFile.Close()
	w := bufio.NewWriter(dataNewFile)
	dataReader := bufio.NewReader(dataF)
	firstLine, _, _ := dataReader.ReadLine()
	firstLineStr := strings.TrimSpace(string(firstLine))
	featureNames := strings.Split(firstLineStr, ",")
	// 文件和meta都为空的情况, 可以传递过来 [""]
	if len(featureNames) == 0 || len(features) == 0 {
		return fmt.Errorf("meta data error, feature is empty")
	}
	// 比对meta和样本文件的特征是否匹配
	if len(features) != len(featureNames) {
		return fmt.Errorf("meta and sample file not match")
	}
	for i := 0; i < len(features); i++ {
		if !common.ContainsStr(featureNames, features[i]) {
			return fmt.Errorf("meta and sample file not match")
		}
	}

	fileRows = append(fileRows, featureNames)
	for {
		line, _, err := dataReader.ReadLine()
		if err == io.EOF {
			break
		}
		l := format.FormatDataStr(string(line), metaFormat)
		w.WriteString(l)
		w.Flush()
		fileRows = append(fileRows, format.ReadFormatLine(l))
	}

	if len(fileRows) == 0 {
		return fmt.Errorf("file data empty, no fileRows.\r")
	}

	// 调用dai统计文件信息
	for _, item := range features {
		static, _ := feature_engineering.FeatureStatistics(fileRows, item, featureHasStr[item])
		dataInfo[item] = &models.DataStats{
			Mean:   fmt.Sprintf("%f", static.Mean),
			Mode:   strings.Join(static.Mode, ","),
			Median: fmt.Sprintf("%f", static.Median),
			Max:    fmt.Sprintf("%f", static.Maximum),
			Min:    fmt.Sprintf("%f", static.Minimum),
		}
	}

	// 格式化的文件作为上传xdb的文件
	//	dataResource.FileTempPath = dataTemp
	metaBytes, _ := json.Marshal(metaInfo)
	dataBytes, _ := json.Marshal(dataInfo)
	dataResource.MetaInfo = string(metaBytes)
	dataResource.DataInfo = string(dataBytes)
	dataResource.Number = len(fileRows) - 1
	_, err = models.UpdateDataSource(dataResource)
	return err
}

// saveToXDB 上传文件或更新文件到xdb
func (h *Handler) saveToXDB(dataResource *models.DataResource) error {
	file, err := os.Open(dataResource.FileTempPath)
	if err != nil {
		return err
	}
	fi, _ := file.Stat()
	dataResource.Size = int(fi.Size())

	dataResource.Status = models.StatusStoring
	models.UpdateDataSource(dataResource)

	xdbConfig := config.GetXDBConfig()
	xdbClient := xdb.GetXDBClient(xdbConfig)
	// 存储成功过的数据资源才有ResourceID
	if dataResource.ResourceID == "" {
		dataResource.ResourceID, err = xdbClient.WriteFile(xdbConfig.NameSpace, dataResource.ResourceName, dataResource.Version, dataResource.FileTempPath, dataResource.ExpireTime.UnixNano(), dataResource.Description,
			dataResource.MetaInfo)
		if err != nil {
			logger.Errorf("requestID: %v write file failed, err: %v", h.RequestID, err)
			return err
		}
	} else {
		dataResource.ResourceID, err = xdbClient.UpdateFile(dataResource.ResourceID, dataResource.FileTempPath, dataResource.ExpireTime.UnixNano(), dataResource.Description,
			dataResource.MetaInfo)
		if err != nil {
			logger.Errorf("requestID: %v update file failed, err: %v", h.RequestID, err)
			return err
		}
	}
	logger.Infof("requestID: %v updateXDB, originID:%v, newID:%v", h.RequestID, dataResource.ResourceID, dataResource.ResourceID)

	dataResource.Status = models.StatusStored
	_, err = models.UpdateDataSource(dataResource)
	return err
}

// saveToLocal
func (h *Handler) saveToLocal(dataResource *models.DataResource) error {
	file, err := ioutil.ReadFile(dataResource.FileTempPath)
	if err != nil {
		return err
	}
	dataResource.Size = len(file)

	dataResource.Status = models.StatusStoring
	models.UpdateDataSource(dataResource)

	// 保存到特定目录，区分ns, resourceID上层已生成并返回, 不用重复生成
	newPath := filepath.Join(config.DataLocalPath, dataResource.Namespace)
	if _, err := os.Stat(newPath); err != nil {
		if err := os.MkdirAll(newPath, 0777); err != nil {
			return err
		}
	}
	newPath = filepath.Join(newPath, dataResource.ResourceID)
	if err := ioutil.WriteFile(newPath, file, 0666); err != nil {
		dataResource.Status = models.StatusStoredFaild
		_, upErr := models.UpdateDataSource(dataResource)
		if upErr != nil {
			return codeerror.NewError(codeerror.ErrCodeInternal, "failed to write file: %v, update db: %v", err, upErr)
		}
		return err
	}

	dataResource.Status = models.StatusStored
	_, err = models.UpdateDataSource(dataResource)
	return err
}

// GetList
func (h *Handler) GetList(opts *models.ResourceQueryOpts) ([]*models.DataResource, int64, error) {
	// 更新所有过期记录的状态列
	obj := &models.DataResource{}
	if _, err := models.UpdateExpiredStatus(obj.TableName()); err != nil {
		logger.Errorf("UpdateExpiredStatus failed, err: %v", err)
	}

	resources, total, err := models.GetDataResourcesList(opts)
	return resources, total, err
}

// Detail
func (h *Handler) Detail(resourceID string, id int64) (*models.DataResource, error) {
	var data *models.DataResource
	var err error
	if id > 0 {
		data, err = models.QueryDataSourceByID(id)
	} else {
		data, err = models.QueryDataSourceByResourceID(resourceID)
	}
	return data, err
}

// MergeMetaAndDataInfo
func (h *Handler) MergeMetaAndDataInfo(metaInfo, dataInfo string) ([]*models.FieldInfo, error) {
	var metaArr []*models.MetaInfo
	var dataArr map[string]*models.DataStats
	err := json.Unmarshal([]byte(metaInfo), &metaArr)
	if err != nil {
		return nil, err
	}
	err = json.Unmarshal([]byte(dataInfo), &dataArr)
	if err != nil {
		return nil, err
	}
	ret := []*models.FieldInfo{}
	for _, item := range metaArr {
		if d, ok := dataArr[item.Name]; ok {
			ret = append(ret, &models.FieldInfo{
				MetaInfo: item,
				Stat:     *d,
			})
		}

	}
	return ret, nil
}

// Publish
func (h *Handler) Publish(id int64) error {
	data, err := models.QueryDataSourceByID(id)
	if err != nil {
		return err
	}
	if data.Status != models.StatusStored {
		return codeerror.NewErrorByCode(codeerror.ErrResourceStatus)
	}

	metaInfoDetail, err := h.MergeMetaAndDataInfo(data.MetaInfo, data.DataInfo)
	if err != nil {
		return err
	}
	metaInfo, _ := json.Marshal(metaInfoDetail)

	// 发布到区块链上
	cli, err := blockchain.GetBlockchainClient()
	if err != nil {
		return err
	}
	pubKey, err := ecdsa.DecodePublicKeyFromString(config.GetPublicKey())
	if err != nil {
		return err
	}
	priKey, err := ecdsa.DecodePrivateKeyFromString(config.GetPrivateKey())
	if err != nil {
		return err
	}

	k := md5.New().Sum([]byte(config.SecretKey + data.ResourceID))[0:32]
	encryptExt, err := aes.EncryptUsingAESGCM(aes.AESKey{
		Key:   k,
		Nonce: k[0:12],
	}, metaInfo, nil)
	if err != nil {
		logger.Infof("encrypt failed, err: %v", err)
		return err
	}

	opt := &bc.PublishFileToCatalogOptions{
		File: bc.CatalogFile{
			FileID:      data.ResourceID,
			Type:        "data",
			StorageType: models.GetStorageType(data.StorageType),
			Name:        data.ResourceName,
			Version:     data.Version,
			Description: data.Description,
			Namespace:   data.Namespace,
			// MerkleRoot
			Status:      "online", //发布默认为online状态
			Owner:       pubKey[:],
			OwnerName:   config.GetOrgName(),
			Length:      uint64(data.Size),
			PublishTime: time.Now().UnixNano(),
			ExpireTime:  data.ExpireTime.UnixNano(),
			Number:      int64(data.Number),
			Ext:         encryptExt,
		},

		Signature: nil,
	}
	str, err := util.GetSigMessage(opt)
	if err != nil {
		return err
	}
	sign, err := ecdsa.Sign(priKey, hash.HashUsingSha256([]byte(str)))
	if err != nil {
		return err
	}
	opt.Signature = sign[:]
	txid, err := cli.PublishFileToCatalog(opt)
	if err != nil {
		return err
	}

	// 更新数据库状态
	data.Status = models.StatusPublished
	data.TxID = txid
	_, err = models.UpdateDataSource(data, "status", "tx_id")
	if err != nil {
		return err
	}
	return nil
}

// Update
func (h *Handler) Update(id int64, expireTime int64, filePath, fileVersion, metaPath string) error {
	data, err := models.QueryDataSourceByID(id)
	if err != nil {
		return err
	}
	// 解析中, 存储中, 已下线的状态, 不支持更新
	if data.Status == models.StatusOffline || data.Status == models.StatusParsing || data.Status == models.StatusStoring {
		return codeerror.NewErrorByCode(codeerror.ErrResourceStatus)
	}
	// 文件更新需校验特征列，需包含之前的特征
	if err := checkUpdateFileMeta(data.MetaInfo, metaPath); err != nil {
		return err
	}

	if len(fileVersion) != 0 {
		data.Version = fileVersion
	}
	if expireTime != 0 {
		data.ExpireTime = time.Unix(expireTime, 0)
	}
	data.FileTempPath = filePath
	data.MetaTempPath = metaPath
	_, err = models.UpdateDataSource(data)

	// 文件资源处理包括, 分为发布后的更新和发布前的更新
	if data.Status == models.StatusPublished || data.Status == models.StatusUpdateFailed {
		go h.ParseDataAndUpdate(data)
	} else {
		go h.ParseDataAndSave(data)
	}

	return err
}

// UpdateMate
func (h *Handler) UpdateMeta(id int64, metaInfo []*models.MetaInfo) error {
	data, err := models.QueryDataSourceByID(id)
	if err != nil {
		return err
	}

	// 校验meta中的特征数量
	var originMetaInfo []*models.MetaInfo
	err = json.Unmarshal([]byte(data.MetaInfo), &originMetaInfo)
	if err != nil {
		return err
	}
	if len(originMetaInfo) != len(metaInfo) {
		return codeerror.NewErrorByCode(codeerror.ErrParam, "metaInfo")
	}

	// 解析统计信息并更新
	dataInfo := make(map[string]*models.DataStats)
	if err := json.Unmarshal([]byte(data.DataInfo), &dataInfo); err != nil {
		return err
	}

	for i := 0; i < len(metaInfo); i++ {
		if metaInfo[i].Type == originMetaInfo[i].Type {
			continue
		}
		feature := metaInfo[i].Name
		isString := false
		if strings.ToLower(metaInfo[i].Type) == "string" {
			isString = true
		}

		// 读取文件内容并转成fileRows
		fileContent, err := getFileContentByID(data)
		if err != nil {
			return err
		}
		r := csv.NewReader(bytes.NewReader(fileContent))
		fileRows, err := r.ReadAll()
		if err != nil {
			return err
		}

		// 计算新的统计数据
		static, _ := feature_engineering.FeatureStatistics(fileRows, feature, isString)
		dataInfo[feature] = &models.DataStats{
			Mean:   fmt.Sprintf("%f", static.Mean),
			Mode:   strings.Join(static.Mode, ","),
			Median: fmt.Sprintf("%f", static.Median),
			Max:    fmt.Sprintf("%f", static.Maximum),
			Min:    fmt.Sprintf("%f", static.Minimum),
		}
	}

	meta, _ := json.Marshal(metaInfo)
	data.MetaInfo = string(meta)
	dataBytes, _ := json.Marshal(dataInfo)
	data.DataInfo = string(dataBytes)
	_, err = models.UpdateDataSource(data, "meta_info", "data_info")
	return err
}

// Delete
func (h *Handler) Delete(id int64) error {
	data, err := models.QueryDataSourceByID(id)
	if err != nil {
		return err
	}

	// local文件删除
	if data.StorageType == 1 {
		filePath := filepath.Join(config.DataLocalPath, data.Namespace, data.ResourceID)
		if _, err := os.Stat(filePath); err == nil {
			if err := os.Remove(filePath); err != nil {
				logger.Error("delete file[%s] error:", filePath, err)
				return err
			}
		}
	}

	// xdb删除 @todo xdb暂时先不删除
	// xdbClient := xdb.GetXDBClient(config.GetXDBConfig())
	// err = xdbClient.Delete(resourceID)
	// if err != nil {
	// 	return err
	// }

	// 数据库删除
	_, err = models.DeleteDataSourceByID(id)
	return err
}

// Online
func (h *Handler) Online(id int64) error {
	data, err := models.QueryDataSourceByID(id)
	if err != nil {
		return err
	}
	// 调用区块链
	cli, err := blockchain.GetBlockchainClient()
	if err != nil {
		return err
	}
	priKey, err := ecdsa.DecodePrivateKeyFromString(config.GetPrivateKey())
	if err != nil {
		return err
	}
	pubKey, err := ecdsa.DecodePublicKeyFromString(config.GetPublicKey())
	if err != nil {
		return err
	}
	opt := &bc.OnlineCatalogFileOpt{
		FileID:    data.ResourceID,
		Pubkey:    pubKey[:],
		Signature: nil,
	}
	str, err := util.GetSigMessage(opt)
	if err != nil {
		return err
	}
	sign, err := ecdsa.Sign(priKey, hash.HashUsingSha256([]byte(str)))
	if err != nil {
		return err
	}
	opt.Signature = sign[:]
	err = cli.OnlineCatalogFile(opt)
	if err != nil {
		return err
	}

	// 更新数据库
	data.Status = models.StatusPublished
	_, err = models.UpdateDataSource(data, "status")
	return err
}

// Offline
func (h *Handler) Offline(id int64) error {
	data, err := models.QueryDataSourceByID(id)
	if err != nil {
		return err
	}

	// 调用区块链
	err = catalog.ResourceOffline(data.ResourceID)
	if err != nil {
		return err
	}

	// 更新数据库
	data.Status = models.StatusOffline
	_, err = models.UpdateDataSource(data, "status")
	return err
}

func (h *Handler) ReadFile(data *models.DataResource, fileType string) ([]byte, string, error) {
	// 0.校验
	if fileType != "data" && fileType != "meta" {
		return []byte{}, "", codeerror.NewErrorByCode(codeerror.ErrParam, "type")
	}

	// 1.确定文件地址
	filePath := ""
	respName := ""
	if fileType == "data" {
		filePath = data.FileTempPath
		respName = data.ResourceName + ".csv"
	} else {
		filePath = data.MetaTempPath
		respName = data.ResourceName + ".meta"
	}

	// 2.read file and return bytes
	fileData, err := ioutil.ReadFile(filePath)
	if err != nil {
		logger.Errorf("read file failed, err: %v", err)
		return []byte{}, "", codeerror.NewErrorByCode(codeerror.ErrResourceNotExisted)
	}

	return fileData, respName, nil
}

// 从local或xdb读文件内容
func getFileContentByID(data *models.DataResource) ([]byte, error) {
	// 从xdb读
	if data.StorageType == 0 {
		xdbClient := xdb.GetXDBClient(config.GetXDBConfig())
		return xdbClient.ReadFileByID(data.ResourceID)
	}

	// 从local读
	filePath := filepath.Join(config.DataLocalPath, data.Namespace, data.ResourceID)
	return ioutil.ReadFile(filePath)
}

// 文件更新时，校验特征列是否包含之前的特征
func checkUpdateFileMeta(metaInfo, newMetaPath string) error {
	var meta []*models.MetaInfo
	if err := json.Unmarshal([]byte(metaInfo), &meta); err != nil {
		return codeerror.NewError(codeerror.ErrCodeInternal, "failed to unmarshal metaInfo[%s]", metaInfo)
	}

	// 读取最新meta信息
	newMeta, err := readMetaInfoFromFile(newMetaPath)
	if err != nil {
		return codeerror.NewError(codeerror.ErrCodeInternal, "failed to read metaInfo by path[%s]", newMetaPath)
	}

	// 更新的样本特征数不能减少
	if len(newMeta) < len(meta) {
		return codeerror.NewErrorByCode(codeerror.ErrMetaFeatsCheck)
	}
	// 更新的特征必须包含之前的特征
	newFeatures := make(map[string]bool)
	for i := 0; i < len(newMeta); i++ {
		newFeatures[newMeta[i].Name] = true
	}
	for i := 0; i < len(meta); i++ {
		if !newFeatures[meta[i].Name] {
			return codeerror.NewErrorByCode(codeerror.ErrMetaFeatsCheck)
		}
	}

	return nil
}

// 从meta文件中读取并解析出meta信息
func readMetaInfoFromFile(metaTmpPath string) ([]*models.MetaInfo, error) {
	metaF, err := os.Open(metaTmpPath)
	if err != nil {
		return nil, err
	}
	defer metaF.Close()

	var metaInfo []*models.MetaInfo
	metaReader := bufio.NewReader(metaF)
	for {
		line, _, err := metaReader.ReadLine()
		if err == io.EOF {
			break
		}
		meta := format.ParFromatDefineStr(string(line))
		// 特征必须指定类型
		if len(meta.Type) == 0 {
			return nil, fmt.Errorf("meta data error, data type is empty")
		}

		metaInfo = append(metaInfo, &models.MetaInfo{
			Name:        meta.Name,
			Type:        meta.Type,
			Description: meta.Description,
		})
	}
	return metaInfo, nil
}
