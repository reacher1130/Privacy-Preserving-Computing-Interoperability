// Package user 平台用户模块逻辑实现
package user

import (
	"crypto/md5"
	"encoding/base64"
	"strings"
	"time"

	beego "github.com/beego/beego/v2/server/web"
	"github.com/xuperchain/xuper-sdk-go/account"

	"baidu/blockchain/dtx-manager/models"
	"baidu/blockchain/dtx-manager/pkg/codeerror"
	"baidu/blockchain/dtx-manager/pkg/common"
)

const (
	ErrUserExisted   = "UserExisted"
	ErrUserNotFound  = "UserNotFound"
	ErrLoginCode     = "ErrorLoginCode"
	ErrWrongPassword = "WrongPassword"
	ErrNotAdmin      = "NotAdmin"
)

type Handler struct {
	RequestID string
}

// UserInfo
type UserInfo struct {
	Role       string `json:"role",omitempty`
	UserName   string `json:"username",omitempty`
	Mnemonic   string `json:"mnemonic",omitempty`
	PrivateKey string `json:"privateKey",omitempty`
	Address    string `json:"address",omitempty`
	CreateTime string `json:"createTime",omitempty`
}

// OrgInfo
type OrgInfo struct {
	OrgID     string `json:"orgId",omitempty`
	OrgName   string `json:"orgName",omitempty`
	OrgDID    string `json:"orgDID",omitempty`
	OrgPubKey string `json:"orgPubKey",omitempty`
}

const DefaultPassword = "670b14728ad9902aecba32e22fa4f6bd" // md5(000000)

func NewHandler(requestId string) Handler {
	return Handler{
		RequestID: requestId,
	}
}

// CreateUser 创建用户,并返回用户区块链地址
func (h *Handler) CreateUser(username string, password string) (*UserInfo, error) {
	// 1.check username is already existed
	user, err := models.QueryUserByUserName(username)
	if err != nil && !models.IsNoRowFoundError(err) {
		return nil, err
	}
	if user != nil {
		return nil, codeerror.NewErrorByCode(codeerror.ErrUserExisted)
	}

	// 2.create blockchain account
	acc, err := account.CreateAccount(1, 1)
	if err != nil {
		return nil, err
	}

	// 3.insert into db
	user = &models.User{
		Address:    acc.Address,
		PrivateKey: acc.PrivateKey,
		Mnemonic:   acc.Mnemonic,
		UserName:   username,
		Password:   password,
		CreateTime: time.Now(),
	}

	_, err = models.InsertUser(user)
	if err != nil {
		return nil, err
	}

	return &UserInfo{
		UserName:   username,
		Mnemonic:   acc.Mnemonic,
		PrivateKey: acc.PrivateKey,
		Address:    acc.Address,
		CreateTime: common.FormatTimeStamp(user.CreateTime),
	}, nil
}

// GetUserWithPwd 校验用户密码后获取用户信息
func (h *Handler) GetUserWithPwd(username string, password string) (*UserInfo, error) {
	// 1.check username is already existed
	user, err := models.QueryUserByUserName(username)
	if err != nil {
		if models.IsNoRowFoundError(err) {
			return nil, codeerror.NewErrorByCode(codeerror.ErrParam, "username")
		}
		return nil, err
	}

	// 2.check pwd
	salt := user.Salt
	mdh := md5.New()
	mdh.Write([]byte(password + salt))
	realPwd := base64.StdEncoding.EncodeToString(mdh.Sum(nil))
	if strings.Compare(user.Password, realPwd) != 0 {
		return nil, codeerror.NewErrorByCode(codeerror.ErrParam, "password")
	}

	return &UserInfo{
		UserName:   username,
		Role:       user.RoleName,
		Mnemonic:   user.Mnemonic,
		PrivateKey: user.PrivateKey,
		Address:    user.Address,
		CreateTime: common.FormatTimeStamp(user.CreateTime),
	}, nil
}

// ResetUserPwd 重置用户密码
func (h *Handler) ResetUserPwd(username string, oldpwd, newpwd string) (*UserInfo, error) {
	// 1.check username is already existed
	user, err := models.QueryUserByUserName(username)
	if err != nil {
		if models.IsNoRowFoundError(err) {
			return nil, codeerror.NewErrorByCode(codeerror.ErrCodeParam)
		}
		return nil, err
	}

	// 2.check pwd
	salt := user.Salt
	mdh := md5.New()
	mdh.Write([]byte(oldpwd + salt))
	realPwd := base64.StdEncoding.EncodeToString(mdh.Sum(nil))
	if strings.Compare(user.Password, realPwd) != 0 {
		return nil, codeerror.NewErrorByCode(codeerror.ErrWrongPassword)
	}

	retUser := &UserInfo{
		Address:    user.Address,
		PrivateKey: user.PrivateKey,
		Mnemonic:   user.Mnemonic,
		UserName:   username,
	}

	// 3.set new pwd
	user.Password = newpwd
	_, err = models.UpdateUser(user)
	if err != nil {
		return nil, err
	}
	return retUser, nil
}

// ClearUserPwd 给用户设置默认的密码
func (h *Handler) ClearUserPwd(username string) (bool, error) {
	// 1.check username is already existed
	user, err := models.QueryUserByUserName(username)
	if err != nil {
		if models.IsNoRowFoundError(err) {
			return false, codeerror.NewErrorByCode(codeerror.ErrUserNotExisted)
		}
		return false, err
	}

	// 2.set new pwd
	user.Password = DefaultPassword
	_, err = models.UpdateUser(user)
	if err != nil {
		return false, err
	}
	return true, nil
}

// GetUserInfo
func (h *Handler) GetUserInfo(address string) (*UserInfo, error) {
	user, err := models.QueryUserByAddress(address)
	if err != nil {
		return nil, codeerror.NewErrorByCode(codeerror.ErrUserNotExisted)
	}

	retUser := &UserInfo{
		Role:       user.RoleName,
		Address:    user.Address,
		PrivateKey: user.PrivateKey,
		Mnemonic:   user.Mnemonic,
		UserName:   user.UserName,
		CreateTime: common.FormatTimeStamp(user.CreateTime),
	}
	return retUser, nil
}

// GetOrgInfo
func (h *Handler) GetOrgInfo() *OrgInfo {
	orgInfo, _ := beego.AppConfig.GetSection("orginfo")
	return &OrgInfo{
		OrgID:     orgInfo["id"],
		OrgName:   orgInfo["name"],
		OrgDID:    orgInfo["did"],
		OrgPubKey: orgInfo["pubkey"],
	}
}
