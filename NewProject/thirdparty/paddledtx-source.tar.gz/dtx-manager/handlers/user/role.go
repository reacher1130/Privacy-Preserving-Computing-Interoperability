// Package user 平台用户模块逻辑实现
package user

import (
	"baidu/blockchain/dtx-manager/models"
	"baidu/blockchain/dtx-manager/pkg/codeerror"
	"encoding/json"
)

type RoleAuth struct {
	RoleName   string           `json:"rolename"`
	CreateTime int64            `json:"createTime"`
	Authority  models.Authority `json:"authority"`
}

type BindInfo struct {
	UserName   string `json:"username"`
	RoleName   string `json:"rolename"`
	BindTime   int64  `json:"bindTime"`
	CreateTime int64  `json:"createTime"`
}

// CreateRole 创建
func (h *Handler) CreateRole(rolename string, authority string, userAddress string) error {
	if !json.Valid([]byte(authority)) {
		return codeerror.NewErrorByCode(codeerror.ErrParam, "authority")
	}
	_, err := models.InsertRole(&models.Role{
		RoleName:          rolename,
		Authority:         authority,
		LastUpdateAddress: userAddress,
	})

	return err
}

// ModifyRole 更新
func (h *Handler) ModifyRole(rolename string, authority string, userAddress string) error {
	if !json.Valid([]byte(authority)) {
		return codeerror.NewErrorByCode(codeerror.ErrParam, "authority")
	}
	_, err := models.UpdateRole(&models.Role{
		RoleName:          rolename,
		Authority:         authority,
		LastUpdateAddress: userAddress,
	})
	return err
}

// ListRoles 列表
func (h *Handler) ListRoles() ([]*RoleAuth, error) {
	roles, err := models.ListRoles()
	if err != nil {
		return nil, err
	}
	ret := make([]*RoleAuth, 0, len(roles))
	if len(roles) != 0 {
		for _, v := range roles {
			var authority models.Authority
			json.Unmarshal([]byte(v.Authority), &authority)
			ret = append(ret, &RoleAuth{
				RoleName:   v.RoleName,
				CreateTime: v.CreateTime.Unix(),
				Authority:  authority,
			})
		}
		return ret, nil
	}
	return ret, nil
}

// QueryRole 查询
func (h *Handler) QueryRole(roleName string) (*models.Authority, error) {
	role, err := models.QueryRole(roleName)
	if err != nil {
		return nil, err
	}
	var authority models.Authority
	json.Unmarshal([]byte(role.Authority), &authority)
	return &authority, err
}

// DeleteRole 删除
func (h *Handler) DeleteRole(roleName string) (int64, error) {
	// 判断是否有绑定用户
	bindList, err := models.ListUserRole(roleName)
	if err != nil {
		return 0, err
	}
	if len(bindList) > 0 {
		return 0, codeerror.NewErrorByCode(codeerror.ErrRoleHasBinds)
	}

	// 执行角色删除
	id, err := models.DeleteRole(roleName)
	if err != nil {
		return 0, err
	}
	return id, nil
}

// Bind 给用户绑定权限
func (h *Handler) Bind(username string, rolename string) error {
	return models.Bind(username, rolename)
}

// BindList 绑定列表
func (h *Handler) BindList() ([]*models.UserBindInfo, error) {
	return models.ListUserRole("")
}
