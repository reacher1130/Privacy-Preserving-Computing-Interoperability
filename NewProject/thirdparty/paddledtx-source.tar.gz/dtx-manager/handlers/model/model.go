package model

import (
	bc "baidu/blockchain/dtx-manager/blockchain"
	"baidu/blockchain/dtx-manager/config"
	"baidu/blockchain/dtx-manager/handlers/catalog"
	"baidu/blockchain/dtx-manager/models"
	"baidu/blockchain/dtx-manager/pkg/blockchain"
	"baidu/blockchain/dtx-manager/pkg/cache"
	"baidu/blockchain/dtx-manager/pkg/codeerror"
	"baidu/blockchain/dtx-manager/pkg/common"
	"baidu/blockchain/dtx-manager/pkg/dai"
	"baidu/blockchain/dtx-manager/pkg/logger"
	"baidu/blockchain/dtx-manager/pkg/xdb"
	"encoding/hex"
	"os"
	"time"

	"github.com/PaddlePaddle/PaddleDTX/crypto/core/ecdsa"
	util "github.com/PaddlePaddle/PaddleDTX/xdb/pkgs/strings"
	"github.com/xuperchain/crypto/core/hash"
)

// Handler
type Handler struct {
	RequestID string
}

// NewHandler
func NewHandler(requestId string) Handler {
	return Handler{
		RequestID: requestId,
	}
}

// Create
func (h *Handler) Create(modelResource *models.ModelResource) (string, error) {
	// 查重名
	cli, err := blockchain.GetBlockchainClient()
	if err != nil {
		return "", err
	}
	if _, err := cli.GetCatalogFileDetailByFileName(bc.CatalogFileTypeOfModel, modelResource.Namespace, modelResource.ResourceName); err == nil {
		return "", codeerror.NewError(codeerror.ErrCodeAlreadyExists, "duplicate name")
	}

	// 写库
	modelResource.Status = models.StatusParsing
	if _, err := models.InsertModelResource(modelResource); err != nil {
		return "", err
	}

	// // 调用xdb存储 无需存xdb
	// err = h.saveToXDB(modelResource)
	// if err != nil {
	// 	return "", err
	// }
	modelResource.ResourceID = modelResource.TaskID
	modelResource.Status = models.StatusStored
	models.UpdateModelSource(modelResource)

	return modelResource.ResourceID, err
}

// saveToXDB 上传文件到xdb
func (h *Handler) saveToXDB(modelResource *models.ModelResource) error {
	// @todo 找到模型文件 并上传到xdb
	path := ""

	file, err := os.Open(path)
	if err != nil {
		return err
	}
	fi, _ := file.Stat()
	modelResource.Size = int(fi.Size())

	xdbClient := xdb.GetXDBClient(config.GetXDBConfig())
	resourceID, err := xdbClient.WriteFile(modelResource.Namespace, modelResource.ResourceName, "", path, modelResource.ExpireTime.UnixNano(), modelResource.Description,
		"")
	if err != nil {
		logger.Error("requestID: %v write file failed, err: %v", h.RequestID, err)
		return err
	}

	modelResource.ResourceID = resourceID
	modelResource.Status = models.StatusStored
	models.UpdateModelSource(modelResource)
	return nil
}

// GetList
func (h *Handler) GetList(opts *models.ResourceQueryOpts) ([]*models.ModelResource, int64, error) {
	// 更新所有过期记录的状态列
	obj := &models.ModelResource{}
	if _, err := models.UpdateExpiredStatus(obj.TableName()); err != nil {
		logger.Errorf("UpdateExpiredStatus failed, err: %v", err)
	}

	resources, total, err := models.GetModelResourcesList(opts)

	// 校验模型资源是否已被下线
	for i := 0; i < len(resources); i++ {
		if resources[i].Status == models.StatusPublished && resources[i].ExpireTime.Unix() > time.Now().Unix() {
			cli, err := blockchain.GetBlockchainClient()
			if err != nil {
				logger.Error("failed to GetBlockchainClient: err: %v", err)
				continue
			}
			resource, err := cli.GetCatalogFileDetailByID(resources[i].ResourceID)
			if err != nil {
				logger.Error("failed to GetCatalogFileDetailByID[%s]: err: %v", resources[i].ResourceID, err)
				continue
			}
			if resource.Status == bc.CatalogFileOfflelineStatus {
				resources[i].Status = models.StatusOffline
				if _, err = models.UpdateModelSource(resources[i], "status"); err != nil {
					logger.Error("failed to UpdateModelSource[%s]: err: %v", resources[i].ResourceID, err)
				}
			}

		}
	}

	return resources, total, err
}

// Detail
func (h *Handler) Detail(resourceID string) (*models.ModelResource, error) {
	model, err := models.QueryModelSourceByResourceID(resourceID)
	if err != nil {
		return nil, err
	}

	if model.Status == models.StatusPublished && model.ExpireTime.Unix() > time.Now().Unix() {
		cli, err := blockchain.GetBlockchainClient()
		if err != nil {
			logger.Error("failed to GetBlockchainClient: err: %v", err)
			return model, nil
		}
		resource, err := cli.GetCatalogFileDetailByID(model.ResourceID)
		if err != nil {
			logger.Error("failed to GetCatalogFileDetailByID[%s]: err: %v", model.ResourceID, err)
			return model, nil
		}
		if resource.Status == bc.CatalogFileOfflelineStatus {
			model.Status = models.StatusOffline
			if _, err = models.UpdateModelSource(model, "status"); err != nil {
				logger.Error("failed to UpdateModelSource[%s]: err: %v", model.ResourceID, err)
			}
		}

	}
	return model, err
}

// Publish
func (h *Handler) Publish(resourceID string) error {
	model, err := models.QueryModelSourceByResourceID(resourceID)
	if err != nil {
		return err
	}
	if model.Status != models.StatusStored {
		return codeerror.NewErrorByCode(codeerror.ErrResourceStatus)
	}

	// 发布到区块链上
	cli, err := blockchain.GetBlockchainClient()
	if err != nil {
		return err
	}
	pubKey, err := ecdsa.DecodePublicKeyFromString(config.GetPublicKey())
	if err != nil {
		return err
	}
	priKey, err := ecdsa.DecodePrivateKeyFromString(config.GetPrivateKey())
	if err != nil {
		return err
	}
	partnerName, err := getPartnerName(model.TaskID)
	if err != nil {
		return err
	}
	opt := &bc.PublishFileToCatalogOptions{
		File: bc.CatalogFile{
			FileID:      model.ResourceID,
			TaskID:      model.TaskID,
			Type:        "model",
			StorageType: models.GetStorageType(model.StorageType),
			Name:        model.ResourceName,
			// Version
			Description: model.Description,
			Namespace:   model.Namespace,
			// MerkleRoot
			Status:      "online", //发布默认为online状态
			Owner:       pubKey[:],
			OwnerName:   config.GetOrgName(),
			PartnerName: partnerName,
			// Length
			PublishTime: time.Now().UnixNano(),
			ExpireTime:  model.ExpireTime.UnixNano(),
			Number:      1, // 标签只有1个
		},
		Signature: nil,
	}
	str, err := util.GetSigMessage(opt)
	if err != nil {
		return err
	}
	sign, err := ecdsa.Sign(priKey, hash.HashUsingSha256([]byte(str)))
	if err != nil {
		return err
	}
	opt.Signature = sign[:]
	txid, err := cli.PublishFileToCatalog(opt)
	if err != nil {
		return err
	}

	// 更新数据库状态
	model.Status = models.StatusPublished
	model.TxID = txid
	_, err = models.UpdateModelSource(model, "status", "tx_id")
	if err != nil {
		return err
	}
	return nil
}

// Delete 删除创建的模型资源，已发布的不支持删除
func (h *Handler) Delete(resourceID string) error {
	model, err := models.QueryModelSourceByResourceID(resourceID)
	if err != nil {
		return err
	}
	if model.Status == models.StatusPublished {
		return codeerror.NewError(codeerror.ErrCodeParam, "cannot delete published model")
	}

	//cli, err := blockchain.GetBlockchainClient()
	//if err != nil {
	//	return err
	//}
	//priKey, err := ecdsa.DecodePrivateKeyFromString(config.GetPrivateKey())
	//if err != nil {
	//	return err
	//}
	//pubKey, err := ecdsa.DecodePublicKeyFromString(config.GetPublicKey())
	//if err != nil {
	//	return err
	//}
	//opt := &bc.OfflineCatalogFileOpt{
	//	FileID:    resourceID,
	//	Pubkey:    pubKey[:],
	//	Signature: nil,
	//}
	//str, err := util.GetSigMessage(opt)
	//if err != nil {
	//	return err
	//}
	//sign, err := ecdsa.Sign(priKey, hash.HashUsingSha256([]byte(str)))
	//if err != nil {
	//	return err
	//}
	//opt.Signature = sign[:]
	//err = cli.OfflineCatalogFile(opt)
	//if err != nil {
	//	return err
	//}

	// xdb删除
	//xdbClient := xdb.GetXDBClient(config.GetXDBConfig())
	//err = xdbClient.Delete(resourceID)
	//if err != nil {
	//	return err
	//}

	_, err = models.DeleteModelSourceByResourceID(resourceID)
	return err
}

// Online
func (h *Handler) Online(resourceID string) error {
	model, err := models.QueryModelSourceByResourceID(resourceID)
	if err != nil {
		return err
	}

	// 调用区块链
	cli, err := blockchain.GetBlockchainClient()
	if err != nil {
		return err
	}
	priKey, err := ecdsa.DecodePrivateKeyFromString(config.GetPrivateKey())
	if err != nil {
		return err
	}
	pubKey, err := ecdsa.DecodePublicKeyFromString(config.GetPublicKey())
	if err != nil {
		return err
	}
	opt := &bc.OnlineCatalogFileOpt{
		FileID:    resourceID,
		Pubkey:    pubKey[:],
		Signature: nil,
	}
	str, err := util.GetSigMessage(opt)
	if err != nil {
		return err
	}
	sign, err := ecdsa.Sign(priKey, hash.HashUsingSha256([]byte(str)))
	if err != nil {
		return err
	}
	opt.Signature = sign[:]
	err = cli.OnlineCatalogFile(opt)
	if err != nil {
		return err
	}

	// 更新数据库
	model.Status = models.StatusPublished
	_, err = models.UpdateModelSource(model, "status")
	return err
}

// Offline，训练任务参与方均可对模型资源下线
func (h *Handler) Offline(resourceID string) error {
	// 调用区块链
	err := catalog.ResourceOffline(resourceID)
	if err != nil {
		return codeerror.NewErrorByCode(codeerror.ErrCodeInternal, "offline resource error")
	}

	// 更新数据库
	resource, err := cache.GetCatalogFileDetail("model", resourceID)
	if resource == nil {
		return codeerror.NewErrorByCode(codeerror.ErrResourceNotExisted, err.Error())
	}

	if resource.OwnerName == config.GetOrgName() {
		model, _ := models.QueryModelSourceByResourceID(resourceID)
		// 若有本地记录, 更新数据库
		if model != nil {
			model.Status = models.StatusOffline
			if _, err = models.UpdateModelSource(model, "status"); err != nil {
				return codeerror.NewErrorByCode(codeerror.ErrInternalServer, err.Error())
			}
		}
	}
	return nil
}

// ModelTaskList 模型关联任务ID列表, 过滤已经新增过的活动状态的model-task
func (h *Handler) ModelTaskIDList() ([]string, error) {
	opts := &models.TaskQueryOpts{
		Status:   models.TaskStatusFinished,
		TaskType: "train",
	}
	tasks, _, err := models.ListTasks(opts)
	if err != nil {
		return []string{}, err
	}

	// 过滤已经新增过的活动状态的model-task
	modelOpts := &models.ResourceQueryOpts{
		Status:    -1,
		StatusNot: models.StatusOffline,
	}
	activeModels, _, err := models.GetModelResourcesList(modelOpts)
	activeModelIDs := make([]string, 0)
	for _, model := range activeModels {
		activeModelIDs = append(activeModelIDs, model.TaskID)
	}

	taskidList := make([]string, 0)
	for _, v := range tasks {
		if !common.ContainsStr(activeModelIDs, v.TaskID) {
			taskidList = append(taskidList, v.TaskID)
		}
	}
	return taskidList, err
}

// 查询协作方机构名称
func getPartnerName(taskID string) (string, error) {
	reqCli, err := dai.GetRequesterClient()
	if err != nil {
		return "", err
	}
	ownOrgID := config.GetOrgID()

	task, err := reqCli.GetTaskById(taskID)
	if err != nil {
		return "", err
	}

	for i := 0; i < len(task.DataSets); i++ {
		node, err := reqCli.GetExecutorNodeByID(hex.EncodeToString(task.DataSets[i].Executor))
		if err != nil {
			logger.Errorf("GetExecutorNodeByID failed, err: %v", err)
			return "", err
		}
		orgInfo := cache.GetOrgInfoByID(node.OrgID)
		if err != nil {
			logger.Errorf("QueryOrgInfo failed, err: %v", err)
			return "", err
		}
		if orgInfo.ID != ownOrgID {
			return orgInfo.Name, nil
		}
	}
	return "", codeerror.NewError(codeerror.ErrCodeInternal, "failed to find partner orgName")
}
