// Package 目录链实现, 包括资源空间和资源授权
package catalog

import (
	bc "baidu/blockchain/dtx-manager/blockchain"
	"baidu/blockchain/dtx-manager/config"
	"baidu/blockchain/dtx-manager/handlers/user"
	"baidu/blockchain/dtx-manager/models"
	"baidu/blockchain/dtx-manager/pkg/blockchain"
	"baidu/blockchain/dtx-manager/pkg/cache"
	"baidu/blockchain/dtx-manager/pkg/codeerror"
	"baidu/blockchain/dtx-manager/pkg/dai"
	"baidu/blockchain/dtx-manager/pkg/logger"
	"bytes"
	"crypto/md5"
	"encoding/hex"
	"encoding/json"
	"strings"
	"time"

	"github.com/PaddlePaddle/PaddleDTX/crypto/core/aes"
	"github.com/PaddlePaddle/PaddleDTX/crypto/core/ecdsa"
	"github.com/PaddlePaddle/PaddleDTX/crypto/core/ecies"
	util "github.com/PaddlePaddle/PaddleDTX/xdb/pkgs/strings"
	"github.com/xuperchain/crypto/core/hash"
)

type Handler struct {
	RequestID string
}

type CreateRequest struct {
	Name        string `json:"name"`
	Replica     int    `json:"replica"`
	Description string `json:"description"`
}

type FileInfo struct {
	FileName string `json:"fileName"`
	FileID   string `json:"fileID"`
}

type ResourceDetail struct {
	Name        string              `json:"name"`
	Owner       string              `json:"owner"`
	OrgName     string              `json:"orgName"`
	TaskID      string              `json:"taskID"`
	FileID      string              `json:"fileID"`
	TotalNumber int                 `json:"totalNumber"`
	Features    []string            `json:"features"`
	Size        int                 `json:"size"`
	Description string              `json:"description"`
	MetaInfo    []*models.FieldInfo `json:"metaInfo"`
	ExpireTime  int                 `json:"expireTime"`
	PublishTime int                 `json:"publishTime"`
	FromOwn     bool                `json:"fromOwn"`
	Partner     string              `json:"partner"`
}

type OrgResourceStat struct {
	OrgName        string  `json:"orgName"`
	OrgID          string  `json:"orgID"`
	CountNamespace int     `json:"countNamespace"`
	CountResource  int     `json:"countResource"`
	CountExecutor  int     `json:"countExecutor"`
	HoldingRation  float32 `json:"holdingRation"`
}

type AllOrgResourceStat struct {
	TotalNamespace int                `json:"totalNamespace"`
	TotalResource  int                `json:"totalResource"`
	TotalOrgs      int                `json:"totalOrgs"`
	TotalExes      int                `json:"totalExes"`
	List           []*OrgResourceStat `json:"list"`
}

// NewHandler
func NewHandler(requestId string) Handler {
	return Handler{
		RequestID: requestId,
	}
}

// AddNS
func (h *Handler) AddNS(dataType string, req CreateRequest) (err error) {
	// 先基于缓存判断是否已经存在
	nsFilesMap, err := cache.GetNamespaceFilesMap(dataType, true)
	if err == nil {
		if _, ok := nsFilesMap[req.Name]; ok {
			return codeerror.NewErrorByCode(codeerror.ErrNamespaceExisted)
		}
	}

	// 整理链上交互的error信息
	defer func() {
		if err != nil {
			if strings.Contains(err.Error(), "duplicated catalog namespace") {
				err = codeerror.NewErrorByCode(codeerror.ErrNamespaceExisted)
			} else {
				err = codeerror.NewErrorByCode(codeerror.ErrInternalServer, err)
			}
		}
	}()

	cli, err := blockchain.GetBlockchainClient()
	if err != nil {
		return err
	}

	pubKey, err := ecdsa.DecodePublicKeyFromString(config.GetPublicKey())
	if err != nil {
		return err
	}
	priKey, err := ecdsa.DecodePrivateKeyFromString(config.GetPrivateKey())
	if err != nil {
		return err
	}
	opt := &bc.AddCatalogNsOptions{
		Namespace: bc.CatalogNamespace{
			Name:        req.Name,
			Description: req.Description,
			Owner:       pubKey[:],
			Type:        dataType,
			CreateTime:  time.Now().UnixNano(),
		},
		Signature: nil,
	}
	str, err := util.GetSigMessage(opt)
	if err != nil {
		return err
	}
	sign, err := ecdsa.Sign(priKey, hash.HashUsingSha256([]byte(str)))
	if err != nil {
		return err
	}

	opt.Signature = sign[:]
	err = cli.AddCatalogNamespace(opt)
	return err
}

// ListNsName
func (h *Handler) ListNsName(dataType string) ([]string, error) {
	cli, err := blockchain.GetBlockchainClient()
	if err != nil {
		return nil, err
	}
	// 获取所有机构
	orgInfoList, err := cache.GetOrgInfoList()

	// 获取用户信息中的orgid
	handler := user.NewHandler(h.RequestID)
	selfInfo := handler.GetOrgInfo()
	// 当前组织机构
	info, err := cli.QueryOrgInfo(selfInfo.OrgID)
	if err != nil {
		return nil, err
	}

	// pubKey, _ := ecdsa.DecodePublicKeyFromString(config.GetPublicKey())
	data, err := cli.ListCatalogNs(&bc.ListCatalogNsOptions{
		// Owner: pubKey[:],
		Type: dataType,
	})
	if err != nil {
		return nil, err
	}

	ret := []string{}
	// 当前节点未审核
	if info.Apply == 0 {
		// 只筛选当前节点的ns

		for _, item := range data {
			// 比较是否是当前节点
			if len(item.Name) != 0 && bytes.Equal(item.Owner[:], info.Pubkey) {
				ret = append(ret, item.Name)
			}
		}
	} else {
		for _, orgInfo := range orgInfoList {
			if orgInfo.Apply == 1 {
				for _, item := range data {
					// 比较是否是当前节点
					if len(item.Name) != 0 && bytes.Equal(item.Owner[:], orgInfo.Pubkey) {
						ret = append(ret, item.Name)
					}
				}
			}
		}
	}

	// NS列表应该可以展示所有机构的NS, 不需要有公钥过滤
	// pubKey, _ := ecdsa.DecodePublicKeyFromString(config.GetPublicKey())
	//data, err := cli.ListCatalogNs(&bc.ListCatalogNsOptions{
	//	// Owner: pubKey[:],
	//	Type: dataType,
	//})
	//if err != nil {
	//	return nil, err
	//}
	//
	//ret := []string{}
	//for _, item := range data {
	//	if len(item.Name) != 0 {
	//		ret = append(ret, item.Name)
	//	}
	//}
	return ret, nil
}

// ListNs
func (h *Handler) ListNs(dataType string, orgName string) (map[string][]*FileInfo, error) {
	res := make(map[string][]*FileInfo)
	filesMap, err := cache.GetNamespaceFilesMap(dataType, false)
	for ns, fils := range filesMap {
		res[ns] = make([]*FileInfo, 0)
		for _, file := range fils {
			if orgName == "" || file.PartnerName == orgName || file.OwnerName == orgName {
				res[ns] = append(res[ns], &FileInfo{
					FileName: file.Name,
					FileID:   file.FileID})
			}
		}
	}
	return res, err
}

// ListOrgStat
func (h *Handler) ListOrgStat(dataType string) (*AllOrgResourceStat, error) {
	cli, err := blockchain.GetBlockchainClient()
	if err != nil {
		return nil, err
	}
	// 获取所有机构
	orgInfoList, err := cache.GetOrgInfoList()
	// 获取各机构计算节点数量
	ret := map[string]*OrgResourceStat{}
	exeList, err := cache.GetExecutorList()

	if err != nil {
		logger.Error("GetExecutorList failed:", err)
	}
	// 遍历ns, ns-file, 计算各机构的ns数量, ns-file数量
	data, err := cli.ListCatalogNs(&bc.ListCatalogNsOptions{
		Type: dataType,
	})
	if err != nil {
		return nil, err
	}

	cntAllFiles := 0
	nsFilesMap, err := cache.GetNamespaceFilesMap(dataType, true)
	if err != nil {
		return nil, err
	}

	// 获取用户信息中的orgid
	handler := user.NewHandler(h.RequestID)
	selfInfo := handler.GetOrgInfo()
	if orgInfo := cache.GetOrgInfoByID(selfInfo.OrgID); orgInfo != nil {
		if orgInfo.Apply == 0 {
			logger.Debugf("ListOrgStat GetExecutorList ======== ")
			// 获取各机构计算节点数量
			if err != nil {
				logger.Error("GetExecutorList failed:", err)
			} else {
				for _, exenode := range exeList {
					logger.Debugf("ListOrgStat GetExecutorList %s %s", orgInfo.ID, exenode.OrgID)
					if exenode.OrgID == orgInfo.ID {
						if _, ok := ret[exenode.OrgID]; !ok {
							ret[exenode.OrgID] = &OrgResourceStat{
								OrgID:         exenode.OrgID,
								CountExecutor: 0,
							}
							ret[exenode.OrgID].CountExecutor++
						}
					}
					//logger.Info()
					//ret[exenode.OrgID].CountExecutor++
				}
			}

			// 遍历ns, ns-file, 计算各机构的ns数量, ns-file数量
			//data, err := cli.ListCatalogNs(&bc.ListCatalogNsOptions{
			//	Type: dataType,
			//})
			//if err != nil {
			//	return nil, err
			//}
			//
			//cntAllFiles := 0
			//nsFilesMap, err := cache.GetNamespaceFilesMap(dataType, true)
			//if err != nil {
			//	return nil, err
			//}

			for _, item := range data {
				if string(item.Owner[:]) == string(orgInfo.Pubkey) {
					orgInfo := cache.GetOrgInfoByPK(string(item.Owner[:]))
					if orgInfo == nil {
						continue
					}
					if _, ok := ret[orgInfo.ID]; !ok {
						continue
					}
					ret[orgInfo.ID].CountNamespace++

					files, ok := nsFilesMap[item.Name]
					if !ok {
						logger.Errorf("get namespace files of [%s] failed.", item.Name)
						continue
					}
					// 模型资源要考虑发起方和参与方
					for _, file := range files {
						if orgInfo := cache.GetOrgInfoByPK(string(file.Owner[:])); orgInfo != nil {
							ret[orgInfo.ID].CountResource++
							cntAllFiles++
						}
						if orgInfo := cache.GetOrgInfoByName(file.PartnerName); orgInfo != nil {
							ret[orgInfo.ID].CountResource++
						}
					}
					break
				}
			}
			//
			//allStat := &AllOrgResourceStat{
			//	TotalNamespace: len(nsFilesMap),
			//	TotalResource:  cntAllFiles,
			//	List:           make([]*OrgResourceStat, 0),
			//}
			//for orgID, stat := range ret {
			//	if orgInfo := cache.GetOrgInfoByID(string(orgID)); orgInfo != nil {
			//		stat.OrgName = orgInfo.Name
			//		if cntAllFiles == 0 {
			//			stat.HoldingRation = 0
			//		} else {
			//			stat.HoldingRation = float32(stat.CountResource) / float32(cntAllFiles)
			//		}
			//		allStat.List = append(allStat.List, stat)
			//		allStat.TotalOrgs += 1
			//		allStat.TotalExes += stat.CountExecutor
			//	}
			//}
			// 当前节点审核通过
		} else {
			// 筛选审核通过的机构
			for _, orgInfo := range orgInfoList {
				if orgInfo.Apply == 1 {
					// 机构计算节点数量
					for _, exenode := range exeList {
						if exenode.OrgID == orgInfo.ID {
							if _, ok := ret[exenode.OrgID]; !ok {
								ret[exenode.OrgID] = &OrgResourceStat{
									OrgID:         exenode.OrgID,
									CountExecutor: 0,
								}
								ret[exenode.OrgID].CountExecutor++
							}
							//ret[exenode.OrgID].CountExecutor++
						}
					}
					if ret[orgInfo.ID] == nil {
						ret[orgInfo.ID] = &OrgResourceStat{
							OrgID:         orgInfo.ID,
							CountExecutor: 0,
						}
					}

					for _, item := range data {
						// 如果公钥一致
						if string(item.Owner[:]) == string(orgInfo.Pubkey) {
							ret[orgInfo.ID].CountNamespace++
							files, ok := nsFilesMap[item.Name]
							if !ok {
								logger.Errorf("get namespace files of [%s] failed.", item.Name)
								continue
							}
							// 模型资源要考虑发起方和参与方
							for _, file := range files {
								if orgInfo := cache.GetOrgInfoByPK(string(file.Owner[:])); orgInfo != nil {
									ret[orgInfo.ID].CountResource++
									cntAllFiles++
								}
								if orgInfo := cache.GetOrgInfoByName(file.PartnerName); orgInfo != nil {
									ret[orgInfo.ID].CountResource++
								}
							}
						}

						//orgInfo := cache.GetOrgInfoByPK(string(item.Owner[:]))
						//if orgInfo == nil {
						//	continue
						//}
						//if _, ok := ret[orgInfo.ID]; !ok {
						//	continue
						//}
						//ret[orgInfo.ID].CountNamespace++

						files, ok := nsFilesMap[item.Name]
						if !ok {
							logger.Errorf("get namespace files of [%s] failed.", item.Name)
							continue
						}
						// 模型资源要考虑发起方和参与方
						for _, file := range files {
							if orgInfo := cache.GetOrgInfoByPK(string(file.Owner[:])); orgInfo != nil {
								ret[orgInfo.ID].CountResource++
								cntAllFiles++
							}
							if orgInfo := cache.GetOrgInfoByName(file.PartnerName); orgInfo != nil {
								ret[orgInfo.ID].CountResource++
							}
						}
					}
				}
			}
		}
	}
	allStat := &AllOrgResourceStat{
		TotalNamespace: len(nsFilesMap),
		TotalResource:  cntAllFiles,
		List:           make([]*OrgResourceStat, 0),
	}
	for orgID, stat := range ret {
		if orgInfo := cache.GetOrgInfoByID(string(orgID)); orgInfo != nil {
			stat.OrgName = orgInfo.Name
			if cntAllFiles == 0 {
				stat.HoldingRation = 0
			} else {
				stat.HoldingRation = float32(stat.CountResource) / float32(cntAllFiles)
			}
			allStat.List = append(allStat.List, stat)
			allStat.TotalOrgs += 1
			allStat.TotalExes += stat.CountExecutor
		}
	}

	return allStat, nil
}

// ResourceDetail
func (h *Handler) ResourceDetail(dataType, resourceID string) (*ResourceDetail, error) {
	cli, err := blockchain.GetBlockchainClient()
	if err != nil {
		return nil, err
	}
	dataFile, err := cli.GetCatalogFileDetailByID(resourceID)
	if err != nil {
		return nil, err
	}
	owner := hex.EncodeToString(dataFile.Owner)

	var metaInfo []*models.FieldInfo
	ret := &ResourceDetail{
		Name:        dataFile.Name,
		Owner:       owner,
		FileID:      dataFile.FileID,
		TaskID:      dataFile.TaskID,
		Size:        int(dataFile.Length),
		Description: dataFile.Description,
		TotalNumber: int(dataFile.Number),
		ExpireTime:  int(time.UnixMicro(dataFile.ExpireTime / 1000).Unix()),
		PublishTime: int(time.UnixMicro(dataFile.PublishTime / 1000).Unix()),
		MetaInfo:    []*models.FieldInfo{},
		Features:    []string{},
		OrgName:     dataFile.OwnerName,
		Partner:     dataFile.PartnerName,
	}

	if len(ret.OrgName) == 0 {
		// 查询机构信息, 若存在则添加到ResourceDetail中
		pubKey, _ := ecdsa.DecodePublicKeyFromString(owner)
		orgInfo, _ := cli.QueryOrgInfoByPK(string(pubKey[:]))
		if orgInfo != nil {
			ret.OrgName = orgInfo.Name
		} else {
			logger.Warnf("query orgInfo by %s failed.", owner)
		}
	}

	// 对于模型信息，加上协同方组织名称
	if dataType == bc.CatalogFileTypeOfModel && len(ret.Partner) == 0 {
		reqCli, err := dai.GetRequesterClient()
		if err != nil {
			logger.Errorf("GetRequesterClient failed, err: %v", err)
			return nil, err
		}
		task, err := reqCli.GetTaskById(ret.TaskID)
		if err != nil {
			logger.Errorf("GetTaskById failed, err: %v", err)
			return nil, err
		}
		for i := 0; i < len(task.DataSets); i++ {
			node, err := reqCli.GetExecutorNodeByID(hex.EncodeToString(task.DataSets[i].Executor))
			if err != nil {
				logger.Errorf("GetExecutorNodeByID failed, err: %v", err)
				return nil, err
			}
			org, err := cli.QueryOrgInfo(node.OrgID)
			if err != nil {
				logger.Errorf("QueryOrgInfo failed, err: %v", err)
				return nil, err
			}
			if len(ret.OrgName) != 0 && ret.OrgName != org.Name {
				ret.Partner = org.Name
				break
			}
		}
	}
	// 模型参与者也是模型的所有者
	// if dataType == bc.CatalogFileTypeOfModel && ret.Partner == config.GetOrgName() {
	// 	ret.FromOwn = true
	// }

	features := make(map[string]string)
	// 解密
	if owner == config.GetPublicKey() {
		// 文件所有者是自己
		ret.FromOwn = true
		// metaInfoBytes := aes.AesDecryptECB(string(dataFile.Ext), md5.New().Sum([]byte(config.SecretKey+dataFile.FileID)))
		k := md5.New().Sum([]byte(config.SecretKey + dataFile.FileID))[0:32]
		metaInfoBytes, err := aes.DecryptUsingAESGCM(aes.AESKey{
			Key:   k,
			Nonce: k[0:12],
		}, dataFile.Ext, nil)
		if err == nil {
			for _, v := range metaInfo {
				features[v.Name] = v.Name
			}
			json.Unmarshal(metaInfoBytes, &metaInfo)
			ret.MetaInfo = metaInfo
		} else {
			logger.Infof("decrypt ext error %v", err)
		}
	} else {
		// 文件所有者是其他, 查询授权
		pubKey, _ := ecdsa.DecodePublicKeyFromString(config.GetPublicKey())
		priKey, _ := ecdsa.DecodePrivateKeyFromString(config.GetPrivateKey())
		ownerKey, _ := ecdsa.DecodePublicKeyFromString(owner)
		opt := &bc.ListCatalogFileAuthOptions{
			Applier:    pubKey[:],
			Authorizer: ownerKey[:],
			FileID:     dataFile.FileID,
			DataType:   dataFile.Type,
			Status:     bc.CatalogFileAuthApproved,
			TimeNow:    time.Now().UnixNano(), // 加上此行, 只返回未过期记录
		}
		authList, err := cli.ListCatalogFileAuth(opt)
		if err == nil {
			var key []byte
			for _, item := range authList.List {
				if item.Status != bc.CatalogFileAuthApproved {
					break
				}
				if item.Type == bc.CatalogFileAuthLook {
					ecdsakey := ecdsa.ParsePrivateKey(priKey)
					key, _ = ecies.Decrypt(&ecdsakey, item.AuthKey)
				}
				if item.Type == bc.CatalogFileAuthUse {
					if dataType == bc.CatalogFileTypeOfModel {
						ret.FromOwn = true
					}
					for _, v := range item.Features {
						features[v] = v
					}
				}
			}
			if key != nil {
				// metaInfoBytes := aes.AesDecryptECB(string(dataFile.Ext), key)
				metaInfoBytes, err := aes.DecryptUsingAESGCM(aes.AESKey{
					Key:   key,
					Nonce: key[0:12],
				}, dataFile.Ext, nil)
				if err == nil {
					json.Unmarshal(metaInfoBytes, &metaInfo)
					ret.MetaInfo = metaInfo
				} else {
					logger.Infof("decrypt ext error %v", err)
				}
			}
		}
	}

	for k, _ := range features {
		ret.Features = append(ret.Features, k)
	}

	return ret, err
}

func ResourceOffline(resourceID string) error {
	cli, err := blockchain.GetBlockchainClient()
	if err != nil {
		return err
	}
	priKey, err := ecdsa.DecodePrivateKeyFromString(config.GetPrivateKey())
	if err != nil {
		return err
	}
	pubKey, err := ecdsa.DecodePublicKeyFromString(config.GetPublicKey())
	if err != nil {
		return err
	}
	opt := &bc.OfflineCatalogFileOpt{
		FileID:    resourceID,
		Pubkey:    pubKey[:],
		Signature: nil,
	}
	str, err := util.GetSigMessage(opt)
	if err != nil {
		return err
	}
	sign, err := ecdsa.Sign(priKey, hash.HashUsingSha256([]byte(str)))
	if err != nil {
		return err
	}
	opt.Signature = sign[:]

	return cli.OfflineCatalogFile(opt)
}
