package catalog

import (
	bc "baidu/blockchain/dtx-manager/blockchain"
	"baidu/blockchain/dtx-manager/config"
	"baidu/blockchain/dtx-manager/pkg/blockchain"
	"baidu/blockchain/dtx-manager/pkg/cache"
	"baidu/blockchain/dtx-manager/pkg/codeerror"
	"baidu/blockchain/dtx-manager/pkg/uuid"
	"crypto/md5"
	"encoding/hex"
	"time"

	"github.com/PaddlePaddle/PaddleDTX/crypto/core/ecdsa"
	"github.com/PaddlePaddle/PaddleDTX/crypto/core/ecies"
	util "github.com/PaddlePaddle/PaddleDTX/xdb/pkgs/strings"
	"github.com/cloudflare/cfssl/log"
	"github.com/xuperchain/crypto/core/hash"
)

const (
	AuthLook = "look"
	AuthUse  = "use"
)

// Application
type Application struct {
	AuthID       string `json:"authID"`
	ResourceID   string `json:"resourceID"`
	Name         string `json:"name"`
	CreateTime   int64  `json:"createTime"`
	ExpireTime   int64  `json:"expireTime"`
	Status       string `json:"status"`
	RejectReason string `json:"rejectReason"`
}

type AuthDetail struct {
	AuthID         string   `json:"authID"`
	ResourceID     string   `json:"resourceID"`
	ResourceName   string   `json:"resourceName"`
	Description    string   `json:"description"`
	CreateTime     int64    `json:"createTime"`
	ExpireTime     int64    `json:"expireTime"`
	Status         string   `json:"status"`
	RejectReason   string   `json:"rejectReason"`
	AuthType       string   `json:"authType"`
	Applier        string   `json:"applier"`
	ApplierDID     string   `json:"applierDID"`
	ApplierName    string   `json:"applierName"`
	Authorizer     string   `json:"authorizer"`
	AuthorizerName string   `json:"authorizerName"`
	AuthorizerDID  string   `json:"authorizerDID"`
	Features       []string `json:"features"`
	ApprovalTime   int64    `json:"approvalTime"`
}

type AuthAbstract struct {
	AuthID       string `json:"authID"`
	AuthType     string `json:"authType"`
	ResourceID   string `json:"resourceID"`
	ResourceName string `json:"resourceName"`
	CreateTime   int64  `json:"createTime"`
	ExpireTime   int64  `json:"expireTime"`
	Status       string `json:"status"`
	RejectReason string `json:"rejectReason"`
}

// Apply
func (h *Handler) Apply(resourceID string, authType string, dataType string, keys []string) (string, error) {
	// 申请数据资源使用权时，限特征列表不能为空
	if dataType == bc.CatalogFileTypeOfData && authType == bc.CatalogFileAuthUse && len(keys) == 0 {
		return "", codeerror.NewErrorByCode(codeerror.ErrParam, "keys")
	}

	pubKey, err := ecdsa.DecodePublicKeyFromString(config.GetPublicKey())
	if err != nil {
		return "", err
	}
	priKey, err := ecdsa.DecodePrivateKeyFromString(config.GetPrivateKey())
	if err != nil {
		return "", err
	}

	id := uuid.GenUUID()

	cli, err := blockchain.GetBlockchainClient()
	if err != nil {
		return "", err
	}

	// 查询资源是否有申请中记录, 若有则直接返回
	query_opt := &bc.ListCatalogFileAuthOptions{
		Applier:  pubKey[:],
		FileID:   resourceID,
		DataType: dataType,
		Status:   bc.CatalogFileAuthUnapproved,
		TimeNow:  time.Now().UnixNano(), // 加上此行, 只返回未过期记录
	}
	authList, err := cli.ListCatalogFileAuth(query_opt)
	if err == nil && len(authList.List) > 0 {
		// 只要存在审批中记录, 直接返回错误: 已在申请中
		return authList.List[0].ID, codeerror.NewErrorByCode(codeerror.ErrReqInProgress)
	}

	// 查资源所有者
	fileData, err := cli.GetCatalogFileDetailByID(resourceID)
	if err != nil {
		return "", err
	}
	if dataType != fileData.Type {
		return "", codeerror.NewErrorByCode(codeerror.ErrParam, "dataType")
	}
	if hex.EncodeToString(fileData.Owner) == config.GetPublicKey() {
		return "", codeerror.NewErrorByCode(codeerror.ErrParam, "apply for own resource")
	}

	// 向所有者申请授权
	opt := &bc.PublishCatalogFileAuthOptions{
		FileAuthApplication: bc.CatalogFileAuthApplication{
			ID:         id,
			FileID:     resourceID,
			Name:       fileData.Name,
			DataType:   dataType,
			Type:       authType,
			Applier:    pubKey[:],
			CreateTime: time.Now().UnixNano(),
			Authorizer: fileData.Owner,
			TaskID:     fileData.TaskID,
			Features:   keys,
		},
		Signature: nil,
	}
	str, err := util.GetSigMessage(opt)
	if err != nil {
		return "", err
	}
	sign, err := ecdsa.Sign(priKey, hash.HashUsingSha256([]byte(str)))
	if err != nil {
		return "", err
	}

	opt.Signature = sign[:]
	err = cli.PublishCatalogFileAuth(opt)
	if err != nil {
		return "", err
	}
	return id, nil
}

// ApplicationApprove
func (h *Handler) ApplicationApprove(authID string, expireTime time.Time) error {
	priKey, err := ecdsa.DecodePrivateKeyFromString(config.GetPrivateKey())
	if err != nil {
		return err
	}
	cli, err := blockchain.GetBlockchainClient()
	if err != nil {
		return err
	}
	// 查询授权申请的公钥
	auth, err := cli.GetCatalogFileAuthDetailByID(authID)
	if err != nil {
		return err
	}
	var ecdsakey ecdsa.PublicKey
	copy(ecdsakey[:], auth.Applier)
	ecdsaPub, err := ecdsa.ParsePublicKey(ecdsakey)
	if err != nil {
		return err
	}

	// 使用公钥加密对称密钥 authKey
	k := md5.New().Sum([]byte(config.SecretKey + auth.FileID))[0:32]
	key, err := ecies.Encrypt(&ecdsaPub, k)
	if err != nil {
		return err
	}

	// 授权过期时间, 不能超过资源原本过期时间
	cfile, _ := cache.GetCatalogFileDetail(auth.DataType, auth.FileID)
	if expireTime.UnixNano() > cfile.ExpireTime {
		expireTime = time.Unix(0, cfile.ExpireTime)
	}

	opt := &bc.ConfirmCatalogFileAuthOptions{
		ID:          authID,
		AuthKey:     key,
		CurrentTime: time.Now().UnixNano(),
		ExpireTime:  expireTime.UnixNano(),
	}
	str, err := util.GetSigMessage(opt)
	if err != nil {
		return err
	}
	sign, err := ecdsa.Sign(priKey, hash.HashUsingSha256([]byte(str)))
	if err != nil {
		return err
	}
	opt.Signature = sign[:]
	err = cli.ConfirmCatalogFileAuth(opt)
	if err != nil {
		return err
	}

	return nil
}

// ApplicationReject
func (h *Handler) ApplicationReject(authID, rejectReason string) error {
	priKey, err := ecdsa.DecodePrivateKeyFromString(config.GetPrivateKey())
	if err != nil {
		return err
	}
	cli, err := blockchain.GetBlockchainClient()
	if err != nil {
		return err
	}
	opt := &bc.RejectCatalogFileAuthOptions{
		ID:           authID,
		CurrentTime:  time.Now().UnixNano(),
		RejectReason: rejectReason,
	}
	str, err := util.GetSigMessage(opt)
	if err != nil {
		return err
	}
	sign, err := ecdsa.Sign(priKey, hash.HashUsingSha256([]byte(str)))
	if err != nil {
		return err
	}
	opt.Signature = sign[:]
	err = cli.RejectCatalogFileAuth(opt)
	if err != nil {
		return err
	}

	return nil
}

// ApplicationList
func (h *Handler) ApplicationList(reqType, dataType, dataStatus, authType, authStatus string, pageNo, pageSize int) ([]*AuthAbstract, int, error) {
	pubKey, err := ecdsa.DecodePublicKeyFromString(config.GetPublicKey())
	if err != nil {
		return nil, 0, err
	}

	opt := &bc.ListCatalogFileAuthOptions{
		DataType:   dataType,
		DataStatus: dataStatus,
		AuthType:   authType,
		Status:     authStatus,
		PageNo:     int64(pageNo),
		PageSize:   int64(pageSize),
		TimeNow:    time.Now().UnixNano(), // 加上此行, 只返回未过期记录
	}
	if reqType == "apply" {
		opt.Applier = pubKey[:]
	} else {
		opt.Authorizer = pubKey[:]
	}

	cli, err := blockchain.GetBlockchainClient()
	if err != nil {
		return nil, 0, err
	}
	data, err := cli.ListCatalogFileAuth(opt)
	if err != nil {
		return nil, 0, err
	}

	res := []*AuthAbstract{}
	for _, v := range data.List {
		item := &AuthAbstract{
			AuthID:       v.ID,
			AuthType:     v.Type,
			ResourceID:   v.FileID,
			ResourceName: v.Name,
			CreateTime:   time.UnixMicro(v.CreateTime / 1000).Unix(),
			ExpireTime:   time.UnixMicro(v.ExpireTime / 1000).Unix(),
			Status:       v.Status,
			RejectReason: v.RejectReason,
		}
		res = append(res, item)
	}
	return res, int(data.Total), err
}

// ApplicationDetail
func (h *Handler) ApplicationDetail(dataType, authID string) (*AuthDetail, error) {
	cli, err := blockchain.GetBlockchainClient()
	if err != nil {
		return nil, err
	}
	data, err := cli.GetCatalogFileAuthDetailByID(authID)
	if err != nil {
		return nil, err
	}

	ret := &AuthDetail{
		AuthID:       authID,
		ResourceID:   data.FileID,
		ResourceName: data.Name,
		Description:  data.Description,
		CreateTime:   time.UnixMicro(data.CreateTime / 1000).Unix(),
		ExpireTime:   time.UnixMicro(data.ExpireTime / 1000).Unix(),
		Status:       data.Status,
		RejectReason: data.RejectReason,
		AuthType:     data.Type,
		Applier:      hex.EncodeToString(data.Applier),
		Authorizer:   hex.EncodeToString(data.Authorizer),
		Features:     data.Features,
		ApprovalTime: time.UnixMicro(data.ApprovalTime / 1000).Unix(),
	}

	// 授权方机构信息
	author := hex.EncodeToString(data.Authorizer)
	authorPubKey, _ := ecdsa.DecodePublicKeyFromString(author)
	autherOrgInfo, err := cli.QueryOrgInfoByPK(string(authorPubKey[:]))
	if err != nil {
		log.Errorf("QueryOrgInfoByPK failed on author %s: %v", author, err)
	}
	if autherOrgInfo != nil {
		ret.AuthorizerName = autherOrgInfo.Name
		ret.AuthorizerDID = autherOrgInfo.DID
	}

	// 申请方机构信息
	applier := hex.EncodeToString(data.Applier)
	applierPubKey, _ := ecdsa.DecodePublicKeyFromString(applier)
	applierOrgInfo, err := cli.QueryOrgInfoByPK(string(applierPubKey[:]))
	if err != nil {
		log.Errorf("QueryOrgInfoByPK failed on applier %s: %v", applier, err)
	}
	if applierOrgInfo != nil {
		ret.ApplierName = applierOrgInfo.Name
		ret.ApplierDID = applierOrgInfo.DID
	}

	return ret, nil
}

func (h *Handler) ListApprovedUseApplies(dataType string, pageNo, pageSize int) ([]*bc.CatalogFile, int, error) {

	resources, total, err := h.ApplicationList("apply", dataType, "online", "Use", "Approved", pageNo, pageSize)
	if err != nil {
		return nil, 0, err
	}

	// 基于资源ID, 获取缓存文件信息
	retList := make([]*bc.CatalogFile, 0)
	ridMap := make(map[string]string)
	for _, v := range resources {
		if _, ok := ridMap[v.ResourceID]; ok {
			// 重复过滤
			continue
		}
		ridMap[v.ResourceID] = v.ResourceID

		cfile, _ := cache.GetCatalogFileDetail(dataType, v.ResourceID)
		if cfile == nil {
			// 若资源获取失败, 大部分为旧数据已过期, 暂时使用授权信息填充, 预期以后不再有这样情况
			log.Errorf("catalog file not found for resource: %v", v.ResourceID)
			cfile = &bc.CatalogFile{
				FileID:      v.ResourceID,
				Name:        v.ResourceName,
				PublishTime: v.CreateTime * 1000000000,
				ExpireTime:  v.ExpireTime * 1000000000,
				Description: "",
				Version:     "",
				Namespace:   "",
				Status:      "offline",
			}
		}
		retList = append(retList, cfile)
	}

	return retList, total, nil
}
