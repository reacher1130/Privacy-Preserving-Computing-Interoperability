// Package algorithm 算法管理模块逻辑实现, 此模块无需入库, 因此无对应的model
package algorithm

import (
	"baidu/blockchain/dtx-manager/pkg/codeerror"
	"baidu/blockchain/dtx-manager/pkg/logger"
	"io/ioutil"
)

const (
	AlgoTypeFL  = "fl"
	AlgoTypeMPC = "mpc"
	AlgoTypeFE  = "feateng"
)

type Handler struct {
	RequestID string
}

// 算法管理-算法结构
type Algorithm struct {
	Name        string `json:"name"`
	Version     string `json:"version"`
	File        string `json:"file"`
	StorageType string `json:"storage"`
	Description string `json:"desc"`
	Hash        string `json:"hash"`
	Type        string `json:"type"`
}

// 算法列表基本固定, 写成map结构存储.
var Algorithms = []Algorithm{
	{
		Name:        "Multivariate-Linear-Regression",
		Version:     "1.0",
		File:        "multivariate-linear@v1.0.zip",
		StorageType: "local",
		Description: "基于同态的多元线性回归算法系",
		Hash:        "1358382d62ea6590471f3da832ca1c10254320a39e280b1f8fcfeb85efefcd77",
		Type:        AlgoTypeFL,
	}, {
		Name:        "Multivariate-Logistic-Regression",
		Version:     "1.0",
		File:        "multivariate-logistic@v1.0.zip",
		StorageType: "local",
		Description: "基于同态的多变量逻辑回归算法",
		Hash:        "898b14a6299d580ac2f2a4bc4c781d76fecf7089d64707ddc38e8cbf2cdcb935",
		Type:        AlgoTypeFL,
	}, {
		Name:        "Decision-Tree",
		Version:     "1.0",
		File:        "decision-tree@v1.0.zip",
		StorageType: "local",
		Description: "基于CART的分类决策树算法",
		Hash:        "08c79f72088bdafb230f47843b36fe89697b60c8c42cdf30626b9cd182a28c28",
		Type:        AlgoTypeFL,
	}, {
		Name:        "BaseOT",
		Version:     "1.0",
		File:        "OT@v1.0.zip",
		StorageType: "local",
		Description: "不经意传输协议",
		Hash:        "eba01d0c83aa9e50fbeea29c9267fc27efe4e925300138abb30dfe182b773e33",
		Type:        AlgoTypeMPC,
	}, {
		Name:        "ECDH-PSI",
		Version:     "1.0",
		File:        "PSI@v1.0.zip",
		StorageType: "local",
		Description: "基于ECDH的隐私求交算法",
		Hash:        "23b4c1a8ca0dd3bfd3735833e861a484384d925465021df595207dc56e887232",
		Type:        AlgoTypeMPC,
	}, {
		Name:        "PHE-Paillier",
		Version:     "1.0",
		File:        "PHE@v1.0.zip",
		StorageType: "local",
		Description: "基于Paillier的加法同态算法",
		Hash:        "7822a75ec4b39af49b99f8c99857a8bdabf74446631d87c71658949eb5a63f38",
		Type:        AlgoTypeMPC,
	}, {
		Name:        "Equal-Width-Binning",
		Version:     "1.0",
		File:        "EqWidthBin@v1.0.zip",
		StorageType: "local",
		Description: "特征工程-等距分箱工具",
		Hash:        "3fc2fb92d97a2f1903b407f68992de2aae385cc87ec9b6ad41bc01924e2bbbad",
		Type:        AlgoTypeFE,
	}, {
		Name:        "Equal-Frequency-Binning",
		Version:     "1.0",
		File:        "EqFreqBin@v1.0.zip",
		StorageType: "local",
		Description: "特征工程-等频分箱工具",
		Hash:        "668c5ca3db40425d703fdf184eb00db084f71f0874515d45fdb27bdea02fb067",
		Type:        AlgoTypeFE,
	}, {
		Name:        "Feature-Selection",
		Version:     "1.0",
		File:        "FeatSelect@v1.0.zip",
		StorageType: "local",
		Description: "特征工程-特征选择工具",
		Hash:        "244ce8ec5f7af222070e614a065126cc6b08d96dce7d40eceba2fea6584d370a",
		Type:        AlgoTypeFE,
	}, {
		Name:        "Missing-Value-Fill",
		Version:     "1.0",
		File:        "MissingValue@v1.0.zip",
		StorageType: "local",
		Description: "特征工程-缺失值处理工具",
		Hash:        "80ce537d15dedab217c0ed379a2c1d06f3b93abdc49fbe722c20a8cd5e5966ff",
		Type:        AlgoTypeFE,
	}, {
		Name:        "Interval-Replacement",
		Version:     "1.0",
		File:        "IntervalRep@v1.0.zip",
		StorageType: "local",
		Description: "特征工程-指定区间值替换工具",
		Hash:        "8bf52c43ff78cfc4cd7cd3892719219029984fada103d43b9a05e1538d74ecdf",
		Type:        AlgoTypeFE,
	}, {
		Name:        "Feature-Statistics",
		Version:     "1.0",
		File:        "FeatStats@v1.0.zip",
		StorageType: "local",
		Description: "特征工程-特征统计分析工具",
		Hash:        "bc168e2c4648c887d48fbf1dda14631e7ca4a679a33780e7d255c9d55482afb4",
		Type:        AlgoTypeFE,
	},
}

func NewHandler(requestId string) Handler {
	return Handler{
		RequestID: requestId,
	}
}

// ListAlgorithms 查询算法列表
func (h *Handler) ListAlgorithms() ([]Algorithm, int, error) {
	return Algorithms, len(Algorithms), nil
}

// QueryAlgorithm 查询算法详情
func (h *Handler) QueryAlgorithm(name, version string) (Algorithm, error) {
	for _, a := range Algorithms {
		if a.Name != name {
			continue
		}
		if a.Version != version {
			return Algorithm{}, codeerror.NewErrorByCode(codeerror.ErrAlgoNotExisted, "version not match")
		} else {
			return a, nil
		}
	}
	return Algorithm{}, codeerror.NewErrorByCode(codeerror.ErrAlgoNotExisted)
}

// QueryPredResult 下载算法
func (h *Handler) DownloadAlgorithm(name, version string) ([]byte, string, error) {
	// 1.query Algorithm
	algo, err := h.QueryAlgorithm(name, version)
	if err != nil {
		return []byte{}, "", err
	}

	// 2.read file and return bytes
	file_path := "./static/algorithms/" + algo.File
	filedata, err := ioutil.ReadFile(file_path)
	if err != nil {
		logger.Errorf("read file failed, err: %v", err)
		return []byte{}, "", err
	}

	return filedata, algo.File, nil
}
