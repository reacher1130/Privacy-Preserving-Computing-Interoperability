// Package baas 实现用户baas登录功能
package baas

import (
	"encoding/json"

	"baidu/blockchain/dtx-manager/config"
	"baidu/blockchain/dtx-manager/pkg/codeerror"
	"baidu/blockchain/dtx-manager/pkg/httpclient"
)

const ConnectTimeoutMSec = 3000
const ReadTimeoutMSec = 15000

type Handler struct {
	RequestID string
}

// baas登录所需的body
type BaasLoginReq struct {
	Username string `json:"username"`
	Password string `json:"password"`
	Code     string `json:"code"`
}

// baas登录成功后响应体body，只解析关键字段
type BaasLoginResp struct {
	Token    string `json:"token"`
	UserName string `json:"username"`
	UserRole string `json:"userrole"`
}

func NewHandler(requestId string) Handler {
	return Handler{
		RequestID: requestId,
	}
}

// GetBaasToken 获取登录token
func (h *Handler) GetBaasToken() (string, error) {
	// 0. 初始化配置
	user, pwd, urlLogin, urlGetcode := config.GetBaasUserConf()

	// 1. 获取验证码
	resp, err := httpclient.Get(urlGetcode, nil, ConnectTimeoutMSec, ReadTimeoutMSec)
	if err != nil {
		return "", err
	}

	// 2. 登录并解析出token。固定的用户名密码
	body := BaasLoginReq{
		Username: user,
		Password: pwd,
		Code:     string(resp.Body)[1:5], //去掉前后的""
	}
	s, _ := json.Marshal(body)
	header := make(map[string]string)
	header["Content-Type"] = "application/json;charset=UTF-8"
	resp2, err := httpclient.Post(urlLogin, header, ConnectTimeoutMSec, ReadTimeoutMSec, string(s))
	if err != nil {
		return "", err
	}

	// 3. 解析responseBody获取token
	var baasResp BaasLoginResp
	if err := json.Unmarshal(resp2.Body, &baasResp); err != nil {
		return "", nil
	}

	// 如果获取失败，则解析错误日志
	if len(baasResp.Token) == 0 {
		type baasErrRespBody struct {
			Status  int    `json:"status"`
			Code    int    `json:"code"`
			Message string `json:"message"`
		}
		var b baasErrRespBody
		json.Unmarshal(resp2.Body, &b)
		return "", codeerror.NewErrorByCode(codeerror.ErrBaaSGetToken, b.Message)
	}

	return baasResp.Token, nil
}

