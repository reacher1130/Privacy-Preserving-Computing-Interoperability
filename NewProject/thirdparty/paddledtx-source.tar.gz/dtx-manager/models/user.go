// Package models 平台用户model
package models

import (
	"crypto/md5"
	"encoding/base64"
	"errors"
	"time"

	"github.com/beego/beego/v2/client/orm"

	"baidu/blockchain/dtx-manager/pkg/aes"
	"baidu/blockchain/dtx-manager/pkg/codeerror"
	"baidu/blockchain/dtx-manager/pkg/uuid"
)

/*
CREATE TABLE `common_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `address` varchar(40) NOT NULL DEFAULT '' COMMENT '用户地址',
  `private_key` varchar(500) NOT NULL DEFAULT '' COMMENT '加密私钥',
//   `mnemonic` varchar(500) NOT NULL DEFAULT '' COMMENT '加密助记词',
  `username` varchar(40) NOT NULL DEFAULT '' COMMENT '用户名',
  `password` varchar(40) NOT NULL DEFAULT '' COMMENT '密码',
  `salt` varchar(40) NOT NULL DEFAULT '' COMMENT '密码的加盐',
  `role_name` varchar(40) NOT NULL DEFAULT 'default' COMMENT '角色名称',
  `bind_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '角色绑定时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uidx_address` (`address`),
  UNIQUE KEY `uidx_username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='用户表';
*/

// User 平台用户
type User struct {
	ID         uint64    `orm:"column(id);size(20);pk;auto;description(自增主键id)" json:"id"`
	Address    string    `orm:"column(address);type(varchar);size(40);unique;index;description(用户区块链地址)" json:"address"`
	PrivateKey string    `orm:"column(private_key);type(varchar);size(500);description(用户区块链私钥)" json:"privateKey"`
	Mnemonic   string    `orm:"column(mnemonic);type(varchar);size(500);description(用户区块链助记词)" json:"mnemonic"`
	UserName   string    `orm:"column(username);type(varchar);size(40);unique;index;description(用户名)" json:"userName"`
	Password   string    `orm:"column(password);type(varchar);size(40);description(用户密码哈希)" json:"password"`
	Salt       string    `orm:"column(salt);type(varchar);size(40);description(用户密码随机盐)" json:"slat"`
	RoleName   string    `orm:"column(role_name);type(varchar);default(default);size(40);description(用户角色)" json:"roleName"`
	BindTime   time.Time `orm:"column(bind_time);auto_now_add;type(datetime);description(角色绑定时间)" json:"bindTime"`
	CreateTime time.Time `orm:"column(create_time);auto_now_add;type(datetime);description(创建时间)" json:"createTime"`
	UpdateTime time.Time `orm:"column(update_time);auto_now;type(datetime);description(更新时间)" json:"updateTime"`
}

// UserBindInfo 用户角色绑定信息
type UserBindInfo struct {
	UserName   string `json:"username"`
	RoleName   string `json:"rolename"`
	BindTime   int64  `json:"bindTime"`
	CreateTime int64  `json:"createTime"`
}

const defaultRoleName = "default"

var adminUser = &User{
	UserName: "admin",
	RoleName: "admin",
	Password: "e10adc3949ba59abbe56e057f20f883e", // md5(123456)
}

func (*User) TableName() string {
	return "common_user"
}

// UserAesKeyPrefix 区块链账户aes加密私钥 前缀+salt
const UserAesKeyPrefix = "slyngg6tbg4s0ol"

// InsertUser 插入用户记录, 函数内部实现加密
func InsertUser(user *User) (int64, error) {
	salt := uuid.GenUUID()[0:7]
	h := md5.New()
	h.Write([]byte(user.Password + salt))

	if user.UserName != "admin" {
		user.RoleName = defaultRoleName
	}

	// 加密后重新赋值
	user.Salt = salt
	user.Password = base64.StdEncoding.EncodeToString(h.Sum(nil))
	aesKey := []byte(UserAesKeyPrefix + salt)
	user.Mnemonic = aes.AesEncryptECB([]byte(user.Mnemonic), aesKey)
	user.PrivateKey = aes.AesEncryptECB([]byte(user.PrivateKey), aesKey)

	return insert(user)
}

// UpdateUser 更新用户账户密码
func UpdateUser(user *User) (int64, error) {
	if user.Password == "" || user.PrivateKey == "" || user.Mnemonic == "" {
		return 0, errors.New("error user param")
	}
	salt := uuid.GenUUID()[0:7]
	h := md5.New()
	h.Write([]byte(user.Password + salt))

	// 加密后重新赋值
	user.Salt = salt
	user.Password = base64.StdEncoding.EncodeToString(h.Sum(nil))
	aesKey := []byte(UserAesKeyPrefix + salt)
	user.Mnemonic = aes.AesEncryptECB([]byte(user.Mnemonic), aesKey)
	user.PrivateKey = aes.AesEncryptECB([]byte(user.PrivateKey), aesKey)
	return update(user, "private_key", "mnemonic", "password", "salt")
}

// QueryUserByUserName
func QueryUserByUserName(userName string) (*User, error) {
	var user User
	err := queryOne(&user, WithUserName(userName))
	if err != nil {
		return nil, err
	}

	aesKey := []byte(UserAesKeyPrefix + user.Salt)
	user.Mnemonic = string(aes.AesDecryptECB(user.Mnemonic, aesKey))
	user.PrivateKey = string(aes.AesDecryptECB(user.PrivateKey, aesKey))
	return &user, nil
}

// QueryUserByAddress
func QueryUserByAddress(address string) (*User, error) {
	var user User
	err := queryOne(&user, WithAddress(address))
	if err != nil {
		return nil, codeerror.NewErrorByCode(codeerror.ErrUserNotExisted)
	}
	aesKey := []byte(UserAesKeyPrefix + user.Salt)
	user.Mnemonic = string(aes.AesDecryptECB(user.Mnemonic, aesKey))
	user.PrivateKey = string(aes.AesDecryptECB(user.PrivateKey, aesKey))
	return &user, nil
}

// ListUserRole
func ListUserRole(rolename string) ([]*UserBindInfo, error) {
	users := make([]User, 0)
	orderBy := WithOrder("create_time", "desc")
	var err error
	if rolename != "" {
		_, err = queryAll(new(User), &users, orderBy, WithRoleName(rolename))
	} else {
		_, err = queryAll(new(User), &users, orderBy)
	}
	if err != nil {
		return nil, err
	}

	ret := make([]*UserBindInfo, 0)
	for _, item := range users {
		ret = append(ret, &UserBindInfo{
			UserName:   item.UserName,
			RoleName:   item.RoleName,
			BindTime:   item.BindTime.Unix(),
			CreateTime: item.CreateTime.Unix(),
		})
	}
	return ret, nil
}

// WithUserName 查询条件username
func WithUserName(username string) QueryOption {
	return func(o orm.QuerySeter) orm.QuerySeter {
		return o.Filter("username", username)
	}
}

// WithAddress 查询条件address
func WithAddress(address string) QueryOption {
	return func(o orm.QuerySeter) orm.QuerySeter {
		return o.Filter("address", address)
	}
}
