// Package models 平台任务model
package models

import (
	"baidu/blockchain/dtx-manager/pkg/codeerror"
	"strings"
	"time"

	"github.com/beego/beego/v2/client/orm"
)

/*
CREATE TABLE `tasks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `task_name` varchar(100) NOT NULL DEFAULT '' COMMENT '任务名称',
  `task_id` varchar(100) DEFAULT '' COMMENT '任务id, 发布后为待计算生成task_id',
  `task_type` varchar(8) NOT NULL DEFAULT 'train' COMMENT '任务类型: train训练任务, predict预测任务',
  `task_params` text NOT NULL COMMENT '任务参数',
  `task_status` tinyint(3) NOT NULL DEFAULT '0' COMMENT '任务状态，0为编辑中，1为待计算，2为计算中，3为计算完成，4为计算失败',
  `canvas_info` varchar(200) DEFAULT '' COMMENT '任务画布坐标信息',
  `err_msg` varchar(500) DEFAULT '' COMMENT '任务失败信息',
  `description` varchar(500) NOT NULL DEFAULT '' COMMENT '任务描述',
  `create_by` varchar(40) NOT NULL COMMENT '创建者, username',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uidx_taskname` (`task_name`),
  UNIQUE KEY `uidx_taskid` (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='任务表'
*/

const (
	TaskStatusPreparing = 0 // 编辑中
	TaskStatusPublished = 1 // 待启动
	TaskStatusRunning   = 2 // 计算中
	TaskStatusFinished  = 3 // 已完成
	TaskStatusFailed    = 4 // 计算失败
)

// 任务管理
type Task struct {
	ID          uint64    `orm:"column(id);size(20);pk;auto;description(自增主键id)" json:"id"`
	TaskName    string    `orm:"column(task_name);size(100);unique;description(任务名称)" json:"name"`
	TaskID      string    `orm:"column(task_id);size(100);comment(任务id, 发布后为待计算生成task_id)" json:"taskID"`
	TaskType    string    `orm:"column(task_type);size(8);comment(任务类型: train训练任务, predict预测任务,psi 隐私求交)" json:"type"`
	TaskParams  string    `orm:"column(task_params);type(text);comment(任务参数)" json:"params"`
	TaskStatus  int8      `orm:"column(task_status);default(0);comment(任务状态，0为编辑中，1为待启动，2为计算中，3为已完成，4为计算失败)" json:"status"`
	ErrMsg      string    `orm:"column(err_msg);type(text);comment(任务失败信息)" json:"errMsg"`
	CanvasInfo  string    `orm:"column(canvas_info);type(text);comment(任务画布坐标信息)" json:"canvasInfo"`
	Description string    `orm:"column(description);size(500);comment(任务描述)" json:"desc"`
	CreateBy    string    `orm:"column(create_by);size(40);comment(创建者, useraddress)" json:"createBy"`
	CreateTime  time.Time `orm:"column(create_time);type(datetime);auto_now_add;comment(创建时间)" json:"createTime"`
	UpdateTime  time.Time `orm:"column(update_time);type(datetime);auto_now;comment(更新时间)" json:"updateTime"`
}

type TaskQueryOpts struct {
	Status    int       `json:"status"`   // 初始化此结构时需注意状态字段的零值
	StatusIn  []int     `json:"statusIn"` // 若此字段非空, 则优先使用该字段, 查询多个状态的记录
	Name      string    `json:"name"`
	TaskType  string    `json:"taskType"`
	StartTime time.Time `json:"startTime"`
	EndTime   time.Time `json:"endTime"`
	PageNo    int       `json:"pageNo"`
	PageSize  int       `json:"pageSize"`
	OrderBy   string    `json:"orderBy"`
}

func GenerateTaskQueryOptions(opts *TaskQueryOpts) QueryOption {
	return func(o orm.QuerySeter) orm.QuerySeter {
		if len(opts.StatusIn) > 0 {
			o = o.Filter("task_status__in", opts.StatusIn)
		} else if opts.Status >= 0 {
			o = o.Filter("task_status", opts.Status)
		}
		if opts.Name != "" {
			// 模糊匹配
			o = o.Filter("task_name__icontains", opts.Name)
		}

		if opts.TaskType == "train" || opts.TaskType == "predict" {
			o = o.Filter("task_type", opts.TaskType)
		}

		if !opts.StartTime.IsZero() {
			o = o.Filter("create_time__gt", opts.StartTime)
		}

		if !opts.EndTime.IsZero() {
			o = o.Filter("create_time__lt", opts.EndTime)
		}

		if opts.OrderBy == "" {
			o = o.OrderBy("-update_time")
		} else {
			o = o.OrderBy(opts.OrderBy)
		}

		pageStart := (opts.PageNo - 1) * opts.PageSize
		o = o.Limit(opts.PageSize, pageStart)

		return o
	}
}

func (*Task) TableName() string {
	return "tasks"
}

// InsertTask 新建任务
func InsertTask(task *Task) (int64, error) {
	id, err := insert(task)
	if err == nil {
		return id, err
	}
	if strings.Contains(err.Error(), "1062") {
		return id, codeerror.NewErrorByCode(codeerror.ErrTaskExisted)
	}
	return id, err
}

// UpdateTask 更新任务
func UpdateTask(task *Task) (int64, error) {
	var old Task
	queryOne(&old, WithTaskID(task.ID))
	if old.ID == 0 {
		return 0, codeerror.NewErrorByCode(codeerror.ErrTaskNotExisted)
	}

	// 发布后任务状态需要通过UpdateTaskStatus更改
	if old.TaskStatus != TaskStatusPreparing {
		return 0, codeerror.NewErrorByCode(codeerror.ErrTaskPublished)
	}

	if task.TaskName != "" {
		old.TaskName = task.TaskName
	}
	if task.TaskParams != "" {
		old.TaskParams = task.TaskParams
	}
	if task.CanvasInfo != "" {
		old.CanvasInfo = task.CanvasInfo
	}
	if task.Description != "" {
		old.Description = task.Description
	}
	old.UpdateTime = task.UpdateTime
	return update(&old)
}

// UpdateTaskStatus 专注更新任务状态和链上ID
func UpdateTaskStatus(task *Task) (int64, error) {
	var old Task
	queryOne(&old, WithTaskID(task.ID))
	if old.ID == 0 {
		return 0, codeerror.NewErrorByCode(codeerror.ErrTaskNotExisted)
	}

	if task.TaskID != "" {
		old.TaskID = task.TaskID
	}
	if task.ErrMsg != "" {
		old.ErrMsg = task.ErrMsg
	}
	old.TaskStatus = task.TaskStatus
	old.UpdateTime = task.UpdateTime
	return update(&old)
}

// DeleteTask 新建任务
func DeleteTask(task *Task) (int64, error) {
	var old Task
	queryOne(&old, WithTaskID(task.ID))
	if old.ID == 0 {
		return 0, codeerror.NewErrorByCode(codeerror.ErrTaskNotExisted)
	}

	if old.TaskStatus != TaskStatusPreparing {
		return 0, codeerror.NewErrorByCode(codeerror.ErrTaskPublished)
	}

	return delete(&old)
}

// QueryTask
func QueryTask(id uint64) (*Task, error) {
	var task Task
	err := queryOne(&task, WithTaskID(id))
	if err != nil {
		return nil, err
	}
	if task.ID == 0 {
		return nil, codeerror.NewErrorByCode(codeerror.ErrTaskNotExisted)
	}
	return &task, nil
}

// ListTasks 任务列表
func ListTasks(opts *TaskQueryOpts) ([]*Task, int64, error) {
	tasks := make([]*Task, 0)
	options := GenerateTaskQueryOptions(opts)

	total_cnt, _ := count(new(Task), options)
	_, err := queryAll(new(Task), &tasks, options)
	return tasks, total_cnt, err
}

// QueryTaskByName
func QueryTaskByName(taskname string) (*Task, error) {
	var task Task
	err := queryOne(&task, WithTaskName(taskname))
	if err != nil {
		return nil, codeerror.NewErrorByCode(codeerror.ErrTaskNotExisted)
	}
	return &task, nil
}

// CountTasksByStatus
func CountTasksByStatus() (cnt_map map[int]int64, err error) {
	var fields []int
	var counts []int64

	o := orm.NewOrm()
	countQuery := "SELECT task_status, COUNT(*) as cnt FROM tasks GROUP BY task_status"
	_, err = o.Raw(countQuery).QueryRows(&fields, &counts)
	if err != nil {
		return nil, err
	}
	cnt_map = make(map[int]int64)
	for idx, v := range fields {
		cnt_map[v] = counts[idx]
	}

	return cnt_map, err
}

// WithTaskName 查询条件task_name
func WithTaskName(taskname string) QueryOption {
	return func(o orm.QuerySeter) orm.QuerySeter {
		return o.Filter("task_name", taskname)
	}
}

// WithTaskID 查询条件自增id
func WithTaskID(id uint64) QueryOption {
	return func(o orm.QuerySeter) orm.QuerySeter {
		return o.Filter("id", id)
	}
}
