// Package models 平台用户model
package models

import (
	"baidu/blockchain/dtx-manager/pkg/codeerror"
	"strings"
	"time"

	"github.com/beego/beego/v2/client/orm"
)

/*
CREATE TABLE `data_file_resource` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `resource_id` varchar(40) NOT NULL DEFAULT '' COMMENT '资源id',
  `resource_name` varchar(100) NOT NULL DEFAULT '' COMMENT '资源名称',
  `file_temp_path` varchar(100) NOT NULL DEFAULT '' COMMENT '资源文件临时路径',
  `meta_temp_path` varchar(100) NOT NULL DEFAULT '' COMMENT '解析文件临时路径',
  `version` varchar(40) NOT NULL DEFAULT '' COMMENT '数据版本',
  `namespace` varchar(40) NOT NULL DEFAULT '' COMMENT '资源空间',
  `storage_type` tinyint(3) NOT NULL DEFAULT '0' COMMENT '0:xdb 1:本地文件',
  `resource_path` varchar(100) NOT NULL DEFAULT '' COMMENT '资源文件最终存储寻址路径',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `number` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '样本数量',
  `status` tinyint(3) NOT NULL DEFAULT '0' COMMENT '资源状态 0:解析中, 1:存储中, 2:已存储, 3:已发布, 4:解析失败, 5:存储失败, 6:已下线',
  `tx_id` varchar(150) NOT NULL DEFAULT '' COMMENT '存证交易hash',
  `meta_info` text NOT NULL COMMENT '特征列详情',
  `data_info` text NOT NULL COMMENT '文件数据详情(文件大小、样本数、列数等)',
  `merkle_root` varchar(1000) NOT NULL DEFAULT '' COMMENT '数据文件梅克尔树根',
  `description` varchar(500) NOT NULL DEFAULT '' COMMENT '描述',
  `expire_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '过期时间',
  `public_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '发布时间; 发布到目录链的时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `uidx_resource_id` (`resource_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='数据资源表';
*/

// 数据文件资源
type DataResource struct {
	ID           uint64    `orm:"column(id);size(20);pk;auto;description(自增主键id)" json:"id"`
	ResourceID   string    `orm:"column(resource_id);null;type(varchar);size(40);index;description(资源id)" json:"resourceID"`
	ResourceName string    `orm:"column(resource_name);type(varchar);size(100);description(资源名称)" json:"resourceName"`
	FileTempPath string    `orm:"column(file_temp_path);type(varchar);size(100);description(资源文件临时路径)" json:"fileTempPath"`
	MetaTempPath string    `orm:"column(meta_temp_path);type(varchar);size(100);description(资源文件临时路径)" json:"metaTempPath"`
	Version      string    `orm:"column(version);type(varchar);size(40);description(数据版本)" json:"version"`
	Namespace    string    `orm:"column(namespace);type(varchar);size(40);description(资源空间)" json:"namespace"`
	StorageType  int       `orm:"column(storage_type);type(integer);default(0);description(存储类型 0:xdb 1:本地文件)" json:"storageType"`
	ResourcePath string    `orm:"column(resource_path);type(varchar);size(100);description(资源文件最终存储寻址路径)" json:"resourcePath"`
	Size         int       `orm:"column(size);type(integer);default(0);description(数据文件的大小)" json:"size"`
	Number       int       `orm:"column(number);type(integer);default(0);description(样本数)" json:"number"`
	Status       int       `orm:"column(status);type(integer);default(0);description(资源状态 0:解析中, 1:存储中, 2:已存储, 3:已发布, 4:解析失败, 5:存储失败, 6:已下线, 7:更新失败, 9:已过期)" json:"status"`
	TxID         string    `orm:"column(tx_id);type(varchar);size(150);description(存证交易hash)" json:"txID"`
	MetaInfo     string    `orm:"column(meta_info);type(text);description(特征列详情)" json:"metaInfo"`
	DataInfo     string    `orm:"column(data_info);type(text);description(特征列详情)" json:"dataInfo"`
	MerkleRoot   string    `orm:"column(merkle_root);type(varchar);size(1000);description(梅克尔树根)" json:"merkleRoot"`
	Description  string    `orm:"column(description);type(varchar);size(500);description(描述)" json:"description"`
	ExpireTime   time.Time `orm:"column(expire_time);type(datetime);description(过期时间)" json:"expireTime"`
	PublicTime   time.Time `orm:"column(public_time);null;type(datetime);description(发布时间 发布到目录链的时间)" json:"publicTime"`
	CreateTime   time.Time `orm:"column(create_time);auto_now_add;type(datetime);description(创建时间)" json:"createTime"`
	UpdateTime   time.Time `orm:"column(update_time);auto_now;type(datetime);description(更新时间)" json:"updateTime"`
}

const (
	StatusParsing       = iota //初始化, 解析中
	StatusStoring              //存储中
	StatusStored               //已存储/新增
	StatusPublished            //已发布
	StatusParsingFailed        //解析失败
	StatusStoredFaild          //存储失败
	StatusOffline              //已下线
	StatusUpdateFailed         //更新失败
	StatusPreserved            //预留状态
	StatusExpired              //已过期
)

type MetaInfo struct {
	Name        string `json:"name"`
	Type        string `json:"type"`
	Description string `json:"description"`
}

type DataStats struct {
	Mean   string `json:"mean"`
	Mode   string `json:"mode"`
	Median string `json:"median"`
	Max    string `json:"max"`
	Min    string `json:"min"`
}

// FieldInfo
type FieldInfo struct {
	*MetaInfo
	Stat DataStats `json:"dataInfo"`
}

type ResourceQueryOpts struct {
	PageNo    int       `json:"pageNo"`
	PageSize  int       `json:"pageSize"`
	Namespace string    `json:"namespace"`
	Status    int       `json:"status"`
	StartTime time.Time `json:"startTime"`
	EndTime   time.Time `json:"endTime"`
	OrderBy   string    `json:"orderBy"`
	StatusNot int       `json:"statusNot"` // Status未配置时查看此项, 排除部分状态
}

func GenerateResourceQueryOptions(opts *ResourceQueryOpts) QueryOption {
	return func(o orm.QuerySeter) orm.QuerySeter {
		if opts.Namespace != "" {
			o = o.Filter("namespace", opts.Namespace)
		}

		if opts.Status >= 0 {
			o = o.Filter("status", opts.Status)
		} else if opts.StatusNot >= 0 {
			o = o.Exclude("status", opts.StatusNot)
		}

		if !opts.StartTime.IsZero() {
			o = o.Filter("create_time__gt", opts.StartTime)
		}

		if !opts.EndTime.IsZero() {
			o = o.Filter("create_time__lt", opts.EndTime)
		}

		o = o.OrderBy("-id")

		pageStart := (opts.PageNo - 1) * opts.PageSize
		o = o.Limit(opts.PageSize, pageStart)

		return o
	}
}

func (*DataResource) TableName() string {
	return "data_file_resource"
}

// InsertDataResource
func InsertDataResource(data *DataResource) (int64, error) {
	data.CreateTime = time.Now()
	data.UpdateTime = time.Now()
	id, err := insert(data)
	if err == nil {
		return id, err
	}
	if strings.Contains(err.Error(), "1062") {
		return id, codeerror.NewErrorByCode(codeerror.ErrDataExist)
	}
	return id, err
}

// GetDataResourcesList
func GetDataResourcesList(opts *ResourceQueryOpts) ([]*DataResource, int64, error) {
	dataList := make([]*DataResource, 0)

	queries := GenerateResourceQueryOptions(opts)

	total, _ := count(new(DataResource), queries)
	_, err := queryAll(new(DataResource), &dataList, queries)
	if err != nil {
		return nil, 0, err
	}
	return dataList, total, nil
}

// QueryDataSourceByID
func QueryDataSourceByID(id int64) (*DataResource, error) {
	var data DataResource
	err := queryOne(&data, WithID(int64(id)))
	return &data, err
}

// QueryDataSourceByResourceID
func QueryDataSourceByResourceID(resourceID string) (*DataResource, error) {
	var data DataResource
	err := queryOne(&data, WithResourceID(resourceID))
	if err != nil && strings.Contains(err.Error(), "no row found") {
		return nil, codeerror.NewErrorByCode(codeerror.ErrResourceNotExisted)
	}
	return &data, err
}

// UpdateDataSource
func UpdateDataSource(data *DataResource, cols ...string) (int64, error) {
	return update(data, cols...)
}

// DeleteDataSourceByID
func DeleteDataSourceByID(id int64) (int64, error) {
	var data DataResource
	err := queryOne(&data, WithID(id))
	if err != nil && strings.Contains(err.Error(), "no row found") {
		return 0, codeerror.NewErrorByCode(codeerror.ErrResourceNotExisted)
	}
	return delete(&data)
}

// DeleteDataSourceByResourceID
func DeleteDataSourceByResourceID(resourceID string) (int64, error) {
	var data DataResource
	err := queryOne(&data, WithResourceID(resourceID))
	if err != nil && strings.Contains(err.Error(), "no row found") {
		return 0, codeerror.NewErrorByCode(codeerror.ErrResourceNotExisted)
	}
	return delete(&data)
}

// WithResourceID
func WithResourceID(resourceID string) QueryOption {
	return func(o orm.QuerySeter) orm.QuerySeter {
		return o.Filter("resource_id", resourceID)
	}
}
