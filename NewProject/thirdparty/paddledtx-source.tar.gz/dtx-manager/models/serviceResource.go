// Package models 平台用户model
package models

import (
	"baidu/blockchain/dtx-manager/blockchain"
	"baidu/blockchain/dtx-manager/pkg/codeerror"
	"strings"
	"time"

	"github.com/beego/beego/v2/client/orm"
)

/*
CREATE TABLE `model_service_resource` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `resource_id` varchar(40) NOT NULL DEFAULT '' COMMENT '资源id',
  `resource_name` varchar(100) NOT NULL DEFAULT '' COMMENT '资源名称',
  `task_id` varchar(40) NOT NULL DEFAULT '' COMMENT '任务id',
  `namespace` varchar(40) NOT NULL DEFAULT '' COMMENT '资源空间',
  `storage_type` tinyint(3) NOT NULL DEFAULT '0' COMMENT '0:xdb 1:本地文件',
  `resource_path` varchar(100) NOT NULL DEFAULT '' COMMENT '服务模型文件最终存储寻址路径',
  `status` tinyint(3) NOT NULL DEFAULT '2' COMMENT '资源状态 2:已新增, 3:已发布, 6:已下线',
//   `part_num` tinyint(3) NOT NULL DEFAULT '2' COMMENT '模型构成的份数',
  `tx_id` varchar(150) NOT NULL DEFAULT '' COMMENT '存证交易hash',
  `description` varchar(500) NOT NULL DEFAULT '' COMMENT '描述',
  `expire_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '过期时间',
  `public_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '发布时间; 发布到目录链的时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uidx_resource_id` (`resource_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='数据资源表';
*/

// 模型资源
type ModelResource struct {
	ID           uint64    `orm:"column(id);size(20);pk;auto;description(自增主键id)" json:"id"`
	ResourceID   string    `orm:"column(resource_id);type(varchar);size(40);unique;index;description(资源id)" json:"resourceID"`
	ResourceName string    `orm:"column(resource_name);type(varchar);size(100);description(资源名称)" json:"resourceName"`
	TaskID       string    `orm:"column(task_id);type(varchar);size(100);unique;description(任务id)" json:"taskID"`
	Namespace    string    `orm:"column(namespace);type(varchar);size(40);description(资源空间)" json:"namespace"`
	StorageType  int       `orm:"column(storage_type);type(integer);default(0);description(存储类型 0:xdb 1:本地文件)" json:"storageType"`
	AlgoType     int       `orm:"column(algo_type);type(integer);default(0);description(算法类型 0为线性回归, 1为逻辑回归, 3为分类决策树)" json:"algoType"`
	ResourcePath string    `orm:"column(resource_path);type(varchar);size(100);description(资源文件最终存储寻址路径)" json:"resourcePath"`
	Size         int       `orm:"column(size);type(integer);default(0);description(数据文件的大小)" json:"size"`
	Status       int       `orm:"column(status);type(integer);default(2);description(资源状态 2:已新增, 3:已发布, 6:已下线 9:已过期)" json:"status"`
	TxID         string    `orm:"column(tx_id);type(varchar);size(150);description(存证交易hash)" json:"txID"`
	Description  string    `orm:"column(description);type(varchar);size(500);description(描述)" json:"description"`
	ExpireTime   time.Time `orm:"column(expire_time);auto_now_add;type(datetime);description(过期时间)" json:"expireTime"`
	PublicTime   time.Time `orm:"column(public_time);auto_now_add;type(datetime);description(发布时间 发布到目录链的时间)" json:"publicTime"`
	CreateTime   time.Time `orm:"column(create_time);auto_now_add;type(datetime);description(创建时间)" json:"createTime"`
	UpdateTime   time.Time `orm:"column(update_time);auto_now;type(datetime);description(更新时间)" json:"updateTime"`
}

func (*ModelResource) TableName() string {
	return "model_service_resource"
}

// InsertModelResource
func InsertModelResource(model *ModelResource) (int64, error) {
	model.CreateTime = time.Now()
	model.UpdateTime = time.Now()
	id, err := insert(model)
	if err == nil {
		return id, err
	}
	if strings.Contains(err.Error(), "1062") {
		return id, codeerror.NewErrorByCode(codeerror.ErrDataExist, "taskID existed")
	}
	return id, err
}

// GetModelResourcesList
func GetModelResourcesList(opts *ResourceQueryOpts) ([]*ModelResource, int64, error) {
	modelList := make([]*ModelResource, 0)

	queries := GenerateResourceQueryOptions(opts)
	total, _ := count(new(ModelResource), queries)
	_, err := queryAll(new(ModelResource), &modelList, queries)
	if err != nil {
		return nil, 0, err
	}
	return modelList, total, nil
}

// WithStatus 查询条件status
func WithStatus(status int8) QueryOption {
	return func(o orm.QuerySeter) orm.QuerySeter {
		return o.Filter("status", status)
	}
}

// QueryModelSourceByResourceID
func QueryModelSourceByResourceID(resourceID string) (*ModelResource, error) {
	var model ModelResource
	err := queryOne(&model, WithResourceID(resourceID))
	if err != nil && strings.Contains(err.Error(), "no row found") {
		return nil, codeerror.NewErrorByCode(codeerror.ErrResourceNotExisted)
	}
	return &model, err
}

// UpdateModelSource
func UpdateModelSource(model *ModelResource, cols ...string) (int64, error) {
	return update(model, cols...)
}

// DeleteModelSourceByResourceID
func DeleteModelSourceByResourceID(resourceID string) (int64, error) {
	var model ModelResource
	err := queryOne(&model, WithResourceID(resourceID))
	if err != nil && strings.Contains(err.Error(), "no row found") {
		return 0, codeerror.NewErrorByCode(codeerror.ErrResourceNotExisted)
	}
	return delete(&model)
}

func GetStorageType(storageType int) string {
	if storageType == 0 {
		return blockchain.StorageTypeXdb
	} else {
		return blockchain.StorageTypeLocal
	}
}
