// Package models 平台用户model
package models

import (
	"baidu/blockchain/dtx-manager/pkg/codeerror"
	"strings"
	"time"

	"github.com/beego/beego/v2/client/orm"
)

/*
CREATE TABLE `common_role` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `role_name` varchar(40) NOT NULL DEFAULT '' COMMENT '角色名称',
  `authority` text NOT NULL COMMENT '角色权限',
  `last_update_address` varchar(40) NOT NULL DEFAULT '' COMMENT '最后修改角色的用户地址',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uidx_role_name` (`role_name`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='角色表';
*/

// Role 权限角色
type Role struct {
	ID                uint64    `orm:"column(id);size(20);pk;auto;description(自增主键id)" json:"id"`
	RoleName          string    `orm:"column(role_name);type(varchar);size(40);unique;index;description(角色名称)" json:"roleName"`
	Authority         string    `orm:"column(authority);type(text);description(角色对应的权限)" json:"authority"`
	LastUpdateAddress string    `orm:"column(last_update_address);type(varchar);size(40);description(最后更新的用户地址)" json:"lastUpdateAddress"`
	CreateTime        time.Time `orm:"column(create_time);auto_now_add;type(datetime);description(创建时间)" json:"createTime"`
	UpdateTime        time.Time `orm:"column(update_time);auto_now;type(datetime);description(更新时间)" json:"updateTime"`
}

func (*Role) TableName() string {
	return "common_role"
}

var defaultRole = &Role{
	RoleName:  "default",
	Authority: defaultAuth,
}

var adminRole = &Role{
	RoleName:  "admin",
	Authority: adminAuth,
}

// InsertRole 新建角色
func InsertRole(role *Role) (int64, error) {
	role.CreateTime = time.Now()
	role.UpdateTime = time.Now()
	id, err := insert(role)
	if err == nil {
		return id, err
	}
	if strings.Contains(err.Error(), "1062") {
		return id, codeerror.NewErrorByCode(codeerror.ErrRoleExisted)
	}
	return id, err
}

// UpdateRole 更新角色
func UpdateRole(role *Role) (int64, error) {
	var old Role
	queryOne(&old, WithRoleName(role.RoleName))
	if old.ID == 0 {
		return 0, codeerror.NewErrorByCode(codeerror.ErrRoleNotExisted)
	}

	old.Authority = role.Authority
	old.RoleName = role.RoleName
	old.LastUpdateAddress = role.LastUpdateAddress
	old.UpdateTime = time.Now()
	return update(&old)
}

// ListRoles 所有角色列表
func ListRoles() ([]Role, error) {
	roles := make([]Role, 0)
	orderBy := WithOrder("create_time", "desc")
	_, err := queryAll(new(Role), &roles, orderBy)
	return roles, err
}

// Bind 修改用户的角色
func Bind(username string, rolename string) error {
	var user User
	queryOne(&user, WithUserName(username))
	if user.ID == 0 {
		return codeerror.NewErrorByCode(codeerror.ErrUserNotExisted)
	}
	var role Role
	queryOne(&role, WithRoleName(rolename))
	if role.ID == 0 {
		return codeerror.NewErrorByCode(codeerror.ErrRoleNotExisted)
	}
	user.UpdateTime = time.Now()
	user.RoleName = rolename
	user.BindTime = user.UpdateTime
	_, err := update(&user)
	return err
}

// QueryRole
func QueryRole(rolename string) (*Role, error) {
	var role Role
	queryOne(&role, WithRoleName(rolename))
	if role.ID == 0 {
		return nil, codeerror.NewErrorByCode(codeerror.ErrRoleNotExisted)
	}
	return &role, nil
}

// DeleteRole
func DeleteRole(rolename string) (int64, error) {
	var old Role
	queryOne(&old, WithRoleName(rolename))
	if old.ID == 0 {
		return 0, codeerror.NewErrorByCode(codeerror.ErrRoleNotExisted)
	}
	return delete(&old)
}

// WithRoleName 查询条件role_name
func WithRoleName(rolename string) QueryOption {
	return func(o orm.QuerySeter) orm.QuerySeter {
		return o.Filter("role_name", rolename)
	}
}
