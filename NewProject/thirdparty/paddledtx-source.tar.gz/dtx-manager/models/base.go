// Package models 数据库操作封装
package models

import (
	"database/sql"
	"fmt"
	"strings"
	"time"

	"github.com/beego/beego/v2/client/orm"
	_ "github.com/go-sql-driver/mysql"

	"baidu/blockchain/dtx-manager/config"
	"baidu/blockchain/dtx-manager/pkg/logger"

	"github.com/xuperchain/xuper-sdk-go/account"
)

// QueryOption
type QueryOption func(orm.QuerySeter) orm.QuerySeter

// InitDB初始化数据库日志等级、连接数据库、创建不存在的数据表
func InitDB() {
	setDBLogLevel()
	registerDB()
	registerModels()
	createTables()
	initData()
}

// 设置数据库日志级别
func setDBLogLevel() {
	orm.Debug = config.OrmDebug
}

// 连接数据库
func registerDB() {
	dbUser := config.DBUser
	dbPassword := config.DBPassword
	dbHost := config.DBHost
	dbPort := config.DBPort
	dbName := config.DBName
	maxIdle := config.MaxIdle
	maxConn := config.MaxConn

	logger.Info("Start to connect mysql, dbUser: ", dbUser, " dbHost: ", dbHost, " dbPort: ", dbPort, " dbName:", dbName)
	dataSource := fmt.Sprintf("%v:%v@tcp(%v:%v)/%v?charset=utf8&loc=Local&parseTime=true", dbUser, dbPassword, dbHost, dbPort, dbName)

	if err := orm.RegisterDataBase("default", "mysql", dataSource,
		orm.MaxIdleConnections(maxIdle), orm.MaxOpenConnections(maxConn)); err != nil {
		panic("Failed to connect mysql")
	}
}

// 注册models
func registerModels() {
	orm.RegisterModel(
		new(User),
		new(Role),
		new(DataResource),
		new(ModelResource),
		new(Task),
	)
}

// 是否自动创建tables
func createTables() {
	if config.RunSyncdb {
		if err := orm.RunSyncdb("default", false, true); err != nil {
			logger.Error("Create table failed: %v", err)
		}
	}
}

// 初始化数据, default, admin角色, 以及admin账户
func initData() {
	orm.NewOrm().ReadOrCreate(defaultRole, "role_name")
	orm.NewOrm().ReadOrCreate(adminRole, "role_name")

	// judge if admin user exist
	if user, _ := QueryUserByUserName(adminUser.UserName); user != nil {
		return
	}
	// init admin user
	// create blockchain account and update user info
	acc, err := account.CreateAccount(1, 1)
	if err != nil {
		panic(err)
	} else {
		adminUser.Address = acc.Address
		adminUser.PrivateKey = acc.PrivateKey
		adminUser.Mnemonic = acc.Mnemonic
		adminUser.CreateTime = time.Now()
	}

	// try insert into db
	_, err = InsertUser(adminUser)
	if err != nil {
		panic(err)
	}
}

// update可以更新orm对象
//
//	参数：
//	updateObject 传入orm更新对象
//	cols 需要更新的字段
func update(updateObject interface{}, cols ...string) (int64, error) {
	o := orm.NewOrm()
	id, err := o.Update(updateObject, cols...)
	if err != nil {
		return id, err
	}
	return id, nil
}

// insert可以插入orm对象
//
//	参数：
//	insertObject 传入orm插入对象，因为传入地址，所以id自动更新
func insert(insertObject interface{}) (int64, error) {
	o := orm.NewOrm()
	id, err := o.Insert(insertObject)
	if err != nil {
		return id, err
	}
	return id, nil
}

func insertMulti(count int, insertObject interface{}) (int64, error) {
	num, err := orm.NewOrm().InsertMulti(count, insertObject)
	if err != nil {
		return 0, err
	}

	return num, nil
}

// delete可以删除orm对象
//
//	参数：
//		deleteObject 主要使用主键
func delete(deleteObject interface{}) (int64, error) {
	o := orm.NewOrm()
	id, err := o.Delete(deleteObject)
	if err != nil {
		return id, err
	}
	return id, nil
}

// queryOne可以查询一个orm对象
//
//	参数：
//	queryObject 传入orm查询对象，因为传入地址，所以直接返回
//	opts 查询参数
func queryOne(queryObject interface{}, opts ...QueryOption) error {
	querySeter, err := getQuerySeter(queryObject)
	if err != nil {
		return err
	}

	for _, opt := range opts {
		querySeter = opt(querySeter)
	}

	return querySeter.One(queryObject)
}

// queryRows通过mysql语句查询多条
//
//	参数：
//	queryObject 传入orm查询对象，因为传入地址，所以直接返回
//	opts 查询参数
func queryRows(container interface{}, query string, args ...interface{}) (int64, error) {
	var count int64
	var err error

	o := orm.NewOrm()
	querySeter := o.Raw(query, args...)

	if count, err = querySeter.QueryRows(container); err != nil {
		return count, err
	}
	return count, nil
}

// QueryAll可以查询多个orm对象
//
//	参数：
//	queryObject 传入orm查询对象，用于识别类型
//	container 对象地址数组，用于返回多个
//	opts 查询参数
func queryAll(queryObject interface{}, container interface{}, opts ...QueryOption) (int64, error) {
	var count int64
	var err error
	querySeter, err := getQuerySeter(queryObject)
	if err != nil {
		return count, err
	}

	for _, opt := range opts {
		querySeter = opt(querySeter)
	}

	if count, err = querySeter.All(container); err != nil {
		return count, err
	}
	return count, nil
}

// count可以查询多个orm对象
//
//	参数：
//	queryObject 传入orm查询对象，用于识别类型
//	opts 查询参数
func count(queryObject interface{}, opts ...QueryOption) (int64, error) {
	var count int64
	var err error
	querySeter, err := getQuerySeter(queryObject)
	if err != nil {
		return count, err
	}

	for _, opt := range opts {
		querySeter = opt(querySeter)
	}

	if count, err = querySeter.Count(); err != nil {
		return count, err
	}
	return count, nil
}

func getQuerySeter(queryObject interface{}) (orm.QuerySeter, error) {
	o := orm.NewOrm()
	return o.QueryTable(queryObject), nil
}

func IsNoRowFoundError(err error) bool {
	if err == nil {
		return false
	}

	if strings.Contains(err.Error(), "no row found") {
		return true
	}
	if strings.Contains(err.Error(), "not exist") {
		return true
	}

	return false
}

func BeginTransaction() (orm.TxOrmer, error) {
	o := orm.NewOrm()
	return o.Begin()
}

func EndTransaction(tx orm.TxOrmer, err error) {
	if err != nil {
		// error happens, roll back
		tx.Rollback()
	} else {
		// no error, commit
		tx.Commit()
	}
}

func WithPage(page int, perPage int) QueryOption {
	return func(o orm.QuerySeter) orm.QuerySeter {
		// 假设前端从1开始
		pageNo := (page - 1) * perPage
		return o.Limit(perPage, pageNo)
	}
}

func WithID(id int64) QueryOption {
	return func(o orm.QuerySeter) orm.QuerySeter {
		return o.Filter("id", id)
	}
}

func WithOrder(orderby string, order string) QueryOption {
	return func(o orm.QuerySeter) orm.QuerySeter {
		if strings.ToLower(order) == "desc" {
			orderby = "-" + orderby
		}
		return o.OrderBy(orderby)
	}
}

func UpdateExpiredStatus(tablename string) (sql.Result, error) {
	o := orm.NewOrm()
	rawSeter := o.Raw(fmt.Sprintf("UPDATE %s SET `status` = %d WHERE Now() >= `expire_time` ", tablename, StatusExpired))
	return rawSeter.Exec()
}
