// Package models 平台用户model
package models

const (
	AuthRead  = "01"
	AuthWrite = "10"
	AuthAll   = "11"
)

type Authority struct {
	Permission string `json:"permission"`
	Data       string `json:"data"`
	Service    string `json:"service"`
	Task       string `json:"task"`
	Algorithm  string `json:"algorithm"`
	OP         string `json:"op"`
}

// AuthGroupInverse 需要权限的接口及对应的权限
var AuthGroupInverse map[string]string = map[string]string{
	// permission
	"permission/role/modify": AuthAll,
	"permission/role/create": AuthAll,
	"permission/role/bind":   AuthAll,
	// "permission/role/list":   AuthAll,
	// "permission/role/get":    AuthAll,
	"permission/bind/list": AuthAll,

	// user
	// "user/login":    AuthAll,
	// "user/register": AuthAll,
	// "user/clearpwd": AuthAll,
	// "user/resetpwd": AuthAll,
	// "user/info":     AuthAll,

	// op
	"op/blockchain/netInfo": AuthRead,
	"op/xdb/netInfo":        AuthRead,
	"op/xdb/nodeInfo":       AuthRead,
	"op/dai/taskInfo":       AuthRead,
	"op/dai/netInfo":        AuthRead,

	// data
	"data/fileupload":     AuthAll,
	"data/create":         AuthAll,
	"data/list":           AuthRead,
	"data/detail":         AuthRead,
	"data/publish":        AuthAll,
	"data/update":         AuthAll,
	"data/meta/update":    AuthAll,
	"data/delete":         AuthAll,
	"data/online":         AuthAll,
	"data/offline":        AuthAll,
	"data/list/published": AuthRead,
	"data/list/approved":  AuthRead,

	// model
	"model/create":         AuthAll,
	"model/list":           AuthRead,
	"model/detail":         AuthRead,
	"model/publish":        AuthAll,
	"model/delete":         AuthAll,
	"model/online":         AuthAll,
	"model/offline":        AuthAll,
	"model/tasklist":       AuthRead,
	"model/usable":         AuthRead,
	"model/list/published": AuthRead,
	"model/list/approved":  AuthRead,

	// namespace resource
	"data/ns/add":              AuthAll,
	"data/ns/list":             AuthRead,
	"data/ns/simplelist":       AuthRead,
	"data/ns/resource/detail":  AuthRead,
	"data/ns/orgStat":          AuthRead,
	"model/ns/add":             AuthAll,
	"model/ns/list":            AuthRead,
	"model/ns/simplelist":      AuthRead,
	"model/ns/resource/detail": AuthRead,
	"model/ns/orgStat":         AuthRead,

	// namespace auth
	"data/auth/apply":    AuthAll,
	"data/auth/operate":  AuthAll,
	"data/auth/list":     AuthRead,
	"data/auth/detail":   AuthRead,
	"model/auth/apply":   AuthAll,
	"model/auth/operate": AuthAll,
	"model/auth/list":    AuthRead,
	"model/auth/detail":  AuthRead,

	// task
	"task/create":          AuthAll,
	"task/clone":           AuthAll,
	"task/delete":          AuthAll,
	"task/update":          AuthAll,
	"task/list":            AuthRead,
	"task/detail":          AuthRead,
	"task/exists":          AuthRead,
	"task/publish":         AuthAll,
	"task/executors":       AuthRead,
	"task/start":           AuthAll,
	"task/eval/res":        AuthRead,
	"task/result/download": AuthRead,

	// algorithm
	"algo/list":     AuthRead,
	"algo/detail":   AuthRead,
	"algo/download": AuthRead,
}

func GetAuthByPath(path string) string {
	return AuthGroupInverse[path]
}

var adminAuth = `{"permission":"11","data":"11","service":"11","task":"11","algorithm":"11","op":"11","user":"11"}`
var defaultAuth = `{"permission":"00","data":"00","service":"00","task":"00","algorithm":"00","op":"00"}`
