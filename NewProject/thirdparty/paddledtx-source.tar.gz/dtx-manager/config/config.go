// Package config 全局配置
package config

import (
	"baidu/blockchain/dtx-manager/pkg/xdb"
	"errors"

	"github.com/beego/beego/v2/core/logs"
	beego "github.com/beego/beego/v2/server/web"
	"github.com/spf13/viper"
)

var (
	// mysql
	DBUser     = beego.AppConfig.DefaultString("dbUser", "root")
	DBPassword = beego.AppConfig.DefaultString("dbPassword", "root@xchain123")
	DBHost     = beego.AppConfig.DefaultString("dbHost", "mysql")
	DBPort     = beego.AppConfig.DefaultString("dbPort", "3306")
	DBName     = beego.AppConfig.DefaultString("dbName", "baas")
	MaxIdle    = beego.AppConfig.DefaultInt("maxIdle", 30)
	MaxConn    = beego.AppConfig.DefaultInt("maxConn", 30)
	OrmDebug   = beego.AppConfig.DefaultBool("ormDebug", false)
	RunSyncdb  = beego.AppConfig.DefaultBool("runSyncdb", true)

	SecretKey = beego.AppConfig.DefaultString("secretKey", "")

	DataLocalPath = beego.AppConfig.DefaultString("localPath", "")

	// blockahin
	blockchainConfig = beego.AppConfig.DefaultString("blockchainConfig", "conf/blockchain.toml")

	// log
	LogLevel = beego.AppConfig.DefaultInt("logLevel", logs.LevelInfo)
	LogPath  = beego.AppConfig.DefaultString("logPath", "./log")
)

type BlockchainConf struct {
	Type   string
	Xchain *XchainConf
	Fabric *FabricConf
}

// xchain 配置
type XchainConf struct {
	Mnemonic            string
	DtxContractName     string
	ManagerContractName string
	ContractAccount     string
	ChainAddress        string
	ChainName           string
}

// fabric配置
type FabricConf struct {
	ConfigFile       string
	ChannelID        string
	DtxChaincode     string
	ManagerChaincode string
	UserName         string
	OrgName          string
	ChainAddr        string
}

var (
	chainType  string
	xchainConf *XchainConf
	fabricConf *FabricConf
)

func InitBlockchainConfig() error {
	v := viper.New()
	v.SetConfigFile(blockchainConfig)
	if err := v.ReadInConfig(); err != nil {
		return err
	}
	var err error
	var chainconf BlockchainConf
	err = v.Sub("blockchain").Unmarshal(&chainconf)
	if err != nil {
		return err
	}
	chainType = chainconf.Type
	if chainType == "fabric" {
		fabricConf = chainconf.Fabric
	} else if chainType == "xchain" {
		xchainConf = chainconf.Xchain
	} else {
		return errors.New("unSupported blockchain Type")
	}
	return err
}

// GetXchainConf
func GetXchainConf() *XchainConf {
	return xchainConf
}

// GetFabricConf
func GetFabricConf() *FabricConf {
	return fabricConf
}

// GetChainType
func GetChainType() string {
	return chainType
}

func GetConfPath() string {
	return blockchainConfig
}

func GetPrivateKey() string {
	orginfo, _ := beego.AppConfig.GetSection("orginfo")
	return orginfo["prikey"]
}

func GetPublicKey() string {
	orginfo, _ := beego.AppConfig.GetSection("orginfo")
	return orginfo["pubkey"]
}

func GetOrgID() string {
	orginfo, _ := beego.AppConfig.GetSection("orginfo")
	return orginfo["id"]
}

func GetOrgName() string {
	orginfo, _ := beego.AppConfig.GetSection("orginfo")
	return orginfo["name"]
}

func GetXDBConfig() *xdb.XDBConfig {
	xdbinfo, _ := beego.AppConfig.GetSection("xdb")
	return &xdb.XDBConfig{
		Name:       xdbinfo["name"],
		Host:       xdbinfo["host"],
		NodeID:     xdbinfo["nodeid"],
		PrivateKey: xdbinfo["privatekey"],
		NameSpace:  xdbinfo["namespace"],
	}
}

// baas username+password
func GetBaasUserConf() (string, string, string, string) {
	baasInfo, _ := beego.AppConfig.GetSection("baas")
	return baasInfo["username"], baasInfo["password"], baasInfo["urlLogin"], baasInfo["urlGetcode"]
}
