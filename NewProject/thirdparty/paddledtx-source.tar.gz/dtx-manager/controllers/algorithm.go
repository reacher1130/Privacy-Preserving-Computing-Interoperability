// Package controllers 算法管理模块接口实现
package controllers

import (
	"baidu/blockchain/dtx-manager/handlers/algorithm"
	"baidu/blockchain/dtx-manager/pkg/logger"
)

type AlgoController struct {
	BaseController
}

type ReqAlgoDownload struct {
	AlgoName    string `json:"name" valid:"Required"`
	AlgoVersion string `json:"version" valid:"Required"`
}

type ResAlgoList struct {
	Total int                   `json:"total"`
	List  []algorithm.Algorithm `json:"list"`
}

// @Title 算法列表
// @Description 算法列表
// @router /algo/list [get]
func (u *AlgoController) List() {

	handler := algorithm.NewHandler(u.RequestID)
	algos, cnt, err := handler.ListAlgorithms()
	if err != nil {
		logger.Error("RequestID: %s, list algos failed, error: %s", u.RequestID, err.Error())
		u.ServeJSONWithError(err)
	}

	res := &ResAlgoList{
		Total: cnt,
		List:  algos,
	}
	u.ServeData(res)
}

// @Title 算法详情
// @Description 查询算法详情
// @router /algo/detail [get]
func (u *AlgoController) Detail() {
	algo_name := u.MustString("name")
	algo_version := u.MustString("version")

	handler := algorithm.NewHandler(u.RequestID)
	algo, err := handler.QueryAlgorithm(algo_name, algo_version)
	if err != nil {
		logger.Error("RequestID: %s, query algo failed, error: %s", u.RequestID, err.Error())
		u.ServeJSONWithError(err)
	}
	u.ServeData(algo)
}

// @Title 下载算法
// @Description 下载算法
// @router /algo/download [get]
func (u *AlgoController) Download() {
	algo_name := u.MustString("name")
	algo_version := u.MustString("version")

	handler := algorithm.NewHandler(u.RequestID)
	resp_bytes, file_name, err := handler.DownloadAlgorithm(algo_name, algo_version)
	if err != nil {
		logger.Error("RequestID: %s, algorithm download failed, error: %s", u.RequestID, err.Error())
		u.Abort("404")
	}

	u.ServeDownloadFile(file_name, resp_bytes)

}
