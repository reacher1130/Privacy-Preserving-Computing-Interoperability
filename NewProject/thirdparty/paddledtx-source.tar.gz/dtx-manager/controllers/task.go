// Package controllers 任务管理模块接口实现
package controllers

import (
	"baidu/blockchain/dtx-manager/handlers/task"
	"baidu/blockchain/dtx-manager/models"
	"baidu/blockchain/dtx-manager/pkg/logger"
	"encoding/json"
	"time"
)

type TaskController struct {
	BaseController
}

// ReqTaskCreate
type ReqTaskCreate struct {
	Taskname    string          `json:"name" valid:"Required"`
	TaskType    string          `json:"type" valid:"Required"`
	TaskParams  task.TaskParams `json:"params,omitempty"`
	CanvasInfo  string          `json:"canvasInfo" valid:"Required"`
	Description string          `json:"desc,omitempty"`
}

type ReqTaskUpdate struct {
	ID          uint64          `json:"id" valid:"Required"`
	Taskname    string          `json:"name" valid:"Required"`
	TaskParams  task.TaskParams `json:"params" valid:"Required"`
	CanvasInfo  string          `json:"canvasInfo" valid:"Required"`
	Description string          `json:"desc,omitempty"`
}

type ReqTaskOperate struct {
	ID uint64 `json:"id" valid:"Required"`
}

type ResTask struct {
	ID          uint64 `json:"id"`
	TaskName    string `json:"name"`
	TaskID      string `json:"taskID"`
	TaskType    string `json:"type"`
	TaskParams  string `json:"params"`
	TaskStatus  int8   `json:"status"`
	ErrMsg      string `json:"errMsg"`
	CanvasInfo  string `json:"canvasInfo"`
	Description string `json:"desc"`
	Evaluable   bool   `json:"evaluable"`
	CreateBy    string `json:"createBy"`
	CreatorName string `json:"creatorName"`
	CreateTime  int64  `json:"createTime"`
	UpdateTime  int64  `json:"updateTime"`
}

type ResTaskList struct {
	Total int64      `json:"total"`
	List  []*ResTask `json:"list"`
}

// @Title 新增任务
// @Description 新建计算任务
// @router /task/create [post]
func (u *TaskController) Create() {
	var req ReqTaskCreate
	u.bindAndCheck(&req)

	handler := task.NewHandler(u.RequestID)

	taskParamsBytes, _ := json.Marshal(req.TaskParams)
	newtask := models.Task{
		TaskName:    req.Taskname,
		TaskType:    req.TaskType,
		TaskParams:  string(taskParamsBytes),
		CanvasInfo:  req.CanvasInfo,
		Description: req.Description,
		CreateBy:    u.UserAddress,
		CreateTime:  time.Now(),
		UpdateTime:  time.Now(),
	}
	err := handler.CreateTask(&newtask)
	if err != nil {
		logger.Error("RequestID: %s, create task failed, error: %s", u.RequestID, err.Error())
		u.ServeJSONWithError(err)
	}
	resTask := getResponseTask(&newtask)
	u.ServeData(resTask)
}

// @Title 任务复制
// @Description 复制计算任务
// @router /task/clone [post]
func (u *TaskController) Clone() {
	var req ReqTaskOperate
	u.bindAndCheck(&req)

	handler := task.NewHandler(u.RequestID)
	task, err := handler.CloneTask(req.ID, u.UserAddress)
	if err != nil {
		logger.Error("RequestID: %s, clone task failed, error: %s", u.RequestID, err.Error())
		u.ServeJSONWithError(err)
	}
	resTask := getResponseTask(task)
	u.ServeData(resTask)
}

func getResponseTask(mtask *models.Task) ResTask {
	resTask := ResTask{
		ID:          mtask.ID,
		TaskName:    mtask.TaskName,
		TaskID:      mtask.TaskID,
		TaskType:    mtask.TaskType,
		TaskParams:  mtask.TaskParams,
		TaskStatus:  mtask.TaskStatus,
		ErrMsg:      mtask.ErrMsg,
		CanvasInfo:  mtask.CanvasInfo,
		Description: mtask.Description,
		CreateBy:    mtask.CreateBy,
		CreateTime:  mtask.CreateTime.Unix(),
		UpdateTime:  mtask.UpdateTime.Unix(),
	}

	// 是否可评估JudgeTaskEvaluable
	resTask.Evaluable = task.JudgeTaskEvaluable(mtask.TaskParams)
	// 获取创建者的张慧名称
	user, err := models.QueryUserByAddress(mtask.CreateBy)
	if err != nil {
		logger.Error("query user failed, error: %s", err.Error())
	} else {
		resTask.CreatorName = user.UserName
	}

	return resTask
}

// @Title 任务详情
// @Description 查询任务详情
// @router /task/detail [get]
func (u *TaskController) Detail() {
	id := u.MustInt("id")

	handler := task.NewHandler(u.RequestID)
	task, err := handler.QueryTask(uint64(id))
	if err != nil {
		logger.Error("RequestID: %s, query task failed, error: %s", u.RequestID, err.Error())
		u.ServeJSONWithError(err)
	}
	resTask := getResponseTask(task)
	u.ServeData(resTask)
}

// @Title 任务名称是否存在
// @Description 任务名称是否存在
// @router /task/exists [get]
func (u *TaskController) Exists() {
	name := u.MustString("name")
	handler := task.NewHandler(u.RequestID)
	id, err := handler.QueryIDByName(name)
	if err != nil {
		u.ServeJSONWithError(err)
	}
	u.ServeData(id)
}

// @Title 删除任务
// @Description 删除编辑中的任务, 发布后不可删除
// @router /task/create [post]
func (u *TaskController) Delete() {
	var req ReqTaskOperate
	u.bindAndCheck(&req)

	handler := task.NewHandler(u.RequestID)
	err := handler.DeleteTask(req.ID)
	if err != nil {
		logger.Error("RequestID: %s, delete task failed, error: %s", u.RequestID, err.Error())
		u.ServeJSONWithError(err)
	}

	var s struct{}
	u.ServeData(s)
}

// @Title 更新任务
// @Description 更新任务
// @router /task/update [post]
func (u *TaskController) Update() {
	var req ReqTaskUpdate
	u.bindAndCheck(&req)

	handler := task.NewHandler(u.RequestID)
	taskParamsBytes, _ := json.Marshal(req.TaskParams)
	newtask := models.Task{
		ID:          req.ID,
		TaskName:    req.Taskname,
		TaskParams:  string(taskParamsBytes),
		CanvasInfo:  req.CanvasInfo,
		Description: req.Description,
		UpdateTime:  time.Now(),
	}
	err := handler.UpdateTask(&newtask)
	if err != nil {
		logger.Error("RequestID: %s, update task failed, error: %s", u.RequestID, err.Error())
		u.ServeJSONWithError(err)
	}

	var s struct{}
	u.ServeData(s)
}

// @Title 任务列表
// @Description 任务列表
// @router /task/list [get]
func (u *TaskController) List() {
	opts := &models.TaskQueryOpts{
		PageNo:   u.MustInt("pageNo"),
		PageSize: u.MustInt("pageSize"),
		OrderBy:  "-update_time",
	}
	opts.Status, _ = u.GetInt("status", -1)
	opts.Name = u.GetString("name", "")
	timeStart, _ := u.GetInt64("startTime", 0)
	if timeStart > 0 {
		opts.StartTime = time.Unix(timeStart, 0)
	}
	timeEnd, _ := u.GetInt64("endTime", 0)
	if timeEnd > 0 {
		opts.EndTime = time.Unix(timeEnd, 0)
	}

	handler := task.NewHandler(u.RequestID)
	tasks, cnt, err := handler.ListTasks(opts)
	if err != nil {
		logger.Error("RequestID: %s, list tasks failed, error: %s", u.RequestID, err.Error())
		u.ServeJSONWithError(err)
	}

	res := &ResTaskList{
		Total: cnt,
		List:  make([]*ResTask, 0),
	}
	for _, task := range tasks {
		resTask := getResponseTask(task)
		res.List = append(res.List, &resTask)
	}
	u.ServeData(res)
}

// @Title 发布任务
// @Description 发布任务
// @router /task/publish [post]
func (u *TaskController) Publish() {
	var req ReqTaskOperate
	u.bindAndCheck(&req)

	handler := task.NewHandler(u.RequestID)
	taskid, err := handler.PublishTask(req.ID)
	if err != nil {
		logger.Error("RequestID: %s, task publish failed, error: %s", u.RequestID, err.Error())
		u.ServeJSONWithError(err)
	}

	res := struct{ taskID string }{taskid}
	u.ServeData(res)
}

// @Title 启动任务
// @Description 启动任务
// @router /task/start [post]
func (u *TaskController) Start() {
	var req ReqTaskOperate
	u.bindAndCheck(&req)

	handler := task.NewHandler(u.RequestID)
	err := handler.StartTask(req.ID)
	if err != nil {
		logger.Error("RequestID: %s, task start failed, error: %s", u.RequestID, err.Error())
		u.ServeJSONWithError(err)
	}

	res := struct{}{}
	u.ServeData(res)
}

// @Title 查询评估结果
// @Description 查询评估结果
// @router /task/eval/res [get]
func (u *TaskController) QueryEvalResult() {
	id := u.MustInt("id")

	handler := task.NewHandler(u.RequestID)
	res, err := handler.QueryEvalResult(uint64(id))
	if err != nil {
		logger.Error("RequestID: %s, query evalution result failed, error: %s", u.RequestID, err.Error())
		u.ServeJSONWithError(err)
	}

	u.ServeData(res)
}

// @Title 下载预测结果
// @Description 下载预测结果
// @router /task/result/download [get]
func (u *TaskController) DownloadResult() {
	id := u.MustInt("id")

	handler := task.NewHandler(u.RequestID)
	respBytes, filename, err := handler.QueryResult(uint64(id))
	if err != nil {
		logger.Error("RequestID: %s, download prediction result failed, error: %s", u.RequestID, err.Error())
		u.Abort("404")
	}

	u.ServeDownloadFile(filename, respBytes)
}

// @Title 可用计算节点列表
// @Description
// @router GetTaskExecutors [get]
func (u *TaskController) GetTaskExecutors() {
	id := u.MustString("resourceID")
	h := task.NewHandler(u.RequestID)
	res, err := h.GetTaskExecutors(id)
	if err != nil {
		u.ServeJSONWithError(err)
	} else {
		u.ServeData(res)
	}
}

func (u *TaskController) GetTaskLog() {
	id := u.MustInt("id")
	h := task.NewHandler(u.RequestID)
	res, err := h.QueryTaskLog(uint64(id))
	if err != nil {
		u.ServeJSONWithError(err)
	} else {
		u.ServeData(res)
	}
}
