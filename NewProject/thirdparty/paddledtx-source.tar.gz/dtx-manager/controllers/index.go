package controllers

type ConsoleController struct {
	BaseController
}

// @Title Get
// @Description 主页接口
// @router / [get]
func (c *ConsoleController) Get() {
	c.TplName = "index.html"

	c.EnableRender = true
	_ = c.Render()
}
