// Package controllers 资源模块接口实现
package controllers

import (
	"baidu/blockchain/dtx-manager/handlers/catalog"
	"baidu/blockchain/dtx-manager/handlers/data"
	"baidu/blockchain/dtx-manager/models"
	"baidu/blockchain/dtx-manager/pkg/cache"
	"baidu/blockchain/dtx-manager/pkg/codeerror"
	"crypto/md5"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"time"
)

type DataController struct {
	BaseController
}

// IDReq
type IDReq struct {
	ID int64 `json:"id" valid:"Min(1)"`
}

// ResourceIDReq
type ResourceIDReq struct {
	ResourceID string `json:"resourceID" valid:"Required"`
}

// DataReq
type DataReq struct {
	Name        string `json:"name" valid:"Required"`
	ExpireTime  int64  `json:"expireTime"`
	FilePath    string `json:"filePath"`
	FileVersion string `json:"fileVersion"`
	MetaPath    string `json:"metaPath"`
	Namespace   string `json:"namespace" valid:"Required"`
	StorageType int    `json:"storageType" valid:"Range(0, 1)"`
	Description string `json:"description" valid:"Required"`
}

// DataSimpleResp
type DataSimpleResp struct {
	ID           uint64 `json:"id"`
	ResourceID   string `json:"resourceID"`
	ResourceName string `json:"resourceName"`
	Description  string `json:"description"`
	Version      string `json:"version"`
	Namespace    string `json:"namespace"`
	Status       int    `json:"status"`
	TxID         string `json:"tx_id"`
	CreateTime   int64  `json:"createTime"`
	UpdateTime   int64  `json:"updateTime"`
	ExpireTime   int64  `json:"expireTime"`
}

// DataUpdateReq
type DataUpdateReq struct {
	ID          int64  `json:"id" valid:"Min(1)"`
	ExpireTime  int64  `json:"expireTime"`
	FilePath    string `json:"filePath" valid:"Required"`
	FileVersion string `json:"fileVersion" valid:"Required"`
	MetaPath    string `json:"metaPath" valid:"Required"`
}

// MetaInfoReq
type MetaInfoReq struct {
	ID       int64              `json:"id" valid:"Min(1)"`
	MetaInfo []*models.MetaInfo `json:"metaInfo"`
}

// DataResp
type DataResp struct {
	ID           uint64              `json:"id"`
	ResourceID   string              `json:"resourceID"`
	ResourceName string              `json:"resourceName"`
	Description  string              `json:"description"`
	Version      string              `json:"version"`
	Namespace    string              `json:"namespace"`
	StorageType  int                 `json:"storageType"`
	Status       int                 `json:"status"`
	TxID         string              `json:"tx_id"`
	CreateTime   int64               `json:"createTime"`
	ExpireTime   int64               `json:"expireTime"`
	MetaInfo     []*models.FieldInfo `json:"metaInfo"`
}

// @Title 新建数据资源
// @Description
// @router create [post]
func (d *DataController) Create() {
	var req DataReq
	d.bindAndCheck(&req)

	if req.ExpireTime != 0 && req.ExpireTime < time.Now().Unix() {
		d.ServeJSONWithError(codeerror.NewErrorByCode(codeerror.ErrParam, "expireTime"))
	}

	// 防刷
	reqByte, _ := json.Marshal(req)
	sum := md5.Sum(reqByte)
	md5Key := hex.EncodeToString(sum[:])
	if _, ok := cache.GetCache().Get(md5Key); ok {
		d.ServeJSONWithError(codeerror.NewErrorByCode(codeerror.ErrDuplicateReq))
	}
	cache.GetCache().SetEx(md5Key, true, 5)

	// 若过期时间未设置, 则缺省时间每次不同, md5Key也会变化; 所以缺省时间设置放在重复校验之后
	if req.ExpireTime == 0 {
		req.ExpireTime = time.Now().Add(time.Hour * 24 * 365 * 5).Unix()
	}

	h := data.NewHandler(d.RequestID)
	id, resourceID, err := h.Create(&models.DataResource{
		ResourceName: req.Name,
		ExpireTime:   time.Unix(req.ExpireTime, 0),
		FileTempPath: req.FilePath,
		MetaTempPath: req.MetaPath,
		Version:      req.FileVersion,
		Namespace:    req.Namespace,
		StorageType:  req.StorageType,
		Description:  req.Description,
		MetaInfo:     "[]",
		DataInfo:     "{}",
	})
	if err != nil {
		d.ServeJSONWithError(err)
	}
	ret := map[string]interface{}{
		"id": id,
	}
	if resourceID != "" {
		ret["resourceID"] = resourceID
	}
	d.ServeData(ret)
}

// @Title
// @Description
// @router list [get]
func (d *DataController) GetList() {
	// 整理输入参数
	opts := &models.ResourceQueryOpts{
		OrderBy: "id",
	}
	opts.PageNo, _ = d.GetInt("pageNo", 1)
	opts.PageSize, _ = d.GetInt("pageSize", 20)
	opts.Namespace = d.GetString("namespace", "")
	opts.Status, _ = d.GetInt("status", -1)

	timeStart, _ := d.GetInt64("startTime", 0)
	if timeStart > 0 {
		opts.StartTime = time.Unix(timeStart, 0)
	}
	timeEnd, _ := d.GetInt64("endTime", 0)
	if timeEnd > 0 {
		opts.EndTime = time.Unix(timeEnd, 0)
	}

	h := data.NewHandler(d.RequestID)
	list, total, err := h.GetList(opts)
	if err != nil {
		d.ServeJSONWithError(err)
	}

	retList := make([]*DataSimpleResp, len(list))
	for i, v := range list {
		retList[i] = &DataSimpleResp{
			ID:           v.ID,
			ResourceID:   v.ResourceID,
			ResourceName: v.ResourceName,
			Description:  v.Description,
			Version:      v.Version,
			Namespace:    v.Namespace,
			Status:       v.Status,
			TxID:         v.TxID,
			CreateTime:   v.CreateTime.Unix(),
			UpdateTime:   v.UpdateTime.Unix(),
			ExpireTime:   v.ExpireTime.Unix(),
		}
	}

	d.ServeData(map[string]interface{}{
		"total": total,
		"list":  retList,
	})
}

// @Title 文件上传
// @Description
// @router fileupload [post]
func (d *DataController) FileUpload() {
	fileName := d.Ctx.Request.Form.Get("fileName")
	if fileName == "" {
		d.ServeJSONWithError(codeerror.NewErrorByCode(codeerror.ErrParam, "fileName"))
	}
	file, _, err := d.Ctx.Request.FormFile("file")
	if err != nil {
		d.Ctx.Output.SetStatus(InternalServerError)
		d.ServeJSONWithError(err)
	}
	defer file.Close()

	// 创建文件夹
	filePath := "./upload/" + d.UserAddress + "/"
	err = os.MkdirAll(filePath, 0777)
	if err != nil {
		d.Ctx.Output.SetStatus(InternalServerError)
		d.ServeJSONWithError(err)
	}

	fileName = fmt.Sprintf("%s.%d", fileName, time.Now().Unix())
	fName := filePath + fileName
	// 写临时文件
	f, err := os.OpenFile(fName, os.O_WRONLY|os.O_CREATE, 0666) // test目录放在 GOPATH 目录下
	if err != nil {
		d.Ctx.Output.SetStatus(InternalServerError)
		d.ServeJSONWithError(err)
		return
	}
	defer f.Close()
	_, err = io.Copy(f, file)
	if err != nil {
		d.Ctx.Output.SetStatus(InternalServerError)
		d.ServeJSONWithError(err)
		return
	}

	d.ServeData(map[string]string{
		"filePath": fName,
	})
}

// @Title 数据资源下载
// @Description
// @router download [get]
func (d *DataController) FileDownload() {
	id := d.MustInt64("id")
	fileType := d.MustString("type")

	h := data.NewHandler(d.RequestID)
	detail, err := h.Detail("", id)
	if err != nil {
		d.Abort("404")
	}

	fileBytes, fileName, err := h.ReadFile(detail, fileType)
	if err != nil {
		d.Abort("404")
	}
	d.ServeDownloadFile(fileName, fileBytes)

}

// @Title 数据资源详情
// @Description
// @router detail [get]
func (d *DataController) Detail() {
	id, _ := d.GetInt64("id", 0)
	resourceID := d.GetString("resourceID", "")

	h := data.NewHandler(d.RequestID)
	detail, err := h.Detail(resourceID, id)
	if err != nil {
		d.ServeJSONWithError(err)
	}

	var metaInfo []models.FieldInfo
	err = json.Unmarshal([]byte(detail.MetaInfo), &metaInfo)
	if err != nil {
		metaInfo = []models.FieldInfo{}
	}

	meta, err := h.MergeMetaAndDataInfo(detail.MetaInfo, detail.DataInfo)
	if err != nil {
		d.ServeJSONWithError(err)
	}

	ret := &DataResp{
		ID:           detail.ID,
		ResourceID:   detail.ResourceID,
		ResourceName: detail.ResourceName,
		Description:  detail.Description,
		Version:      detail.Version,
		Namespace:    detail.Namespace,
		StorageType:  detail.StorageType,
		Status:       detail.Status,
		TxID:         detail.TxID,
		CreateTime:   detail.CreateTime.Unix(),
		ExpireTime:   detail.ExpireTime.Unix(),
		MetaInfo:     meta,
	}

	d.ServeData(ret)
}

// @Title 发布数据资源
// @Description
// @router publish [post]
func (d *DataController) Publish() {
	var req IDReq
	d.bindAndCheck(&req)

	h := data.NewHandler(d.RequestID)
	err := h.Publish(req.ID)
	if err != nil {
		d.ServeJSONWithError(err)
	}
}

// @Title 数据资源更新
// @Description
// @router update [post]
func (d *DataController) Update() {
	var req DataUpdateReq
	d.bindAndCheck(&req)

	if req.ExpireTime != 0 && req.ExpireTime < time.Now().Unix() {
		d.ServeJSONWithError(codeerror.NewErrorByCode(codeerror.ErrParam, "expireTime"))
	}

	// 防刷
	reqByte, _ := json.Marshal(req)
	sum := md5.Sum(reqByte)
	md5Key := hex.EncodeToString(sum[:])
	if _, ok := cache.GetCache().Get(md5Key); ok {
		d.ServeJSONWithError(codeerror.NewErrorByCode(codeerror.ErrDuplicateReq))
	}
	cache.GetCache().SetEx(md5Key, true, 5)

	h := data.NewHandler(d.RequestID)
	err := h.Update(req.ID, req.ExpireTime, req.FilePath, req.FileVersion, req.MetaPath)
	if err != nil {
		d.ServeJSONWithError(err)
	}
}

// @Title 数据资源meta信息更新
// @Description
// @router meta/update [post]
func (d *DataController) MetaUpdate() {
	var req MetaInfoReq
	d.bindAndCheck(&req)

	h := data.NewHandler(d.RequestID)
	err := h.UpdateMeta(req.ID, req.MetaInfo)
	if err != nil {
		d.ServeJSONWithError(err)
	}
}

// @Title 数据资源删除
// @Description
// @router delete [post]
func (d *DataController) Delete() {
	var req IDReq
	d.bindAndCheck(&req)

	h := data.NewHandler(d.RequestID)
	err := h.Delete(req.ID)
	if err != nil {
		d.ServeJSONWithError(err)
	}
}

// @Title 数据资源上线
// @Description
// @router online [post]
func (d *DataController) Online() {
	var req IDReq
	d.bindAndCheck(&req)
	h := data.NewHandler(d.RequestID)
	err := h.Online(req.ID)
	if err != nil {
		d.ServeJSONWithError(err)
	}
}

// @Title 数据资源下线
// @Description
// @router offline [post]
func (d *DataController) Offline() {
	var req IDReq
	d.bindAndCheck(&req)
	h := data.NewHandler(d.RequestID)
	err := h.Offline(req.ID)
	if err != nil {
		d.ServeJSONWithError(err)
	}
}

// @Title
// @Description 可用数据列表: 已发布列表
// @router list/published [get]
func (d *DataController) ListPublished() {
	pageNo, _ := d.GetInt("pageNo", 1)
	pageSize, _ := d.GetInt("pageSize", 20)

	// 本机构已发布模型列表
	h := data.NewHandler(d.RequestID)
	opts := &models.ResourceQueryOpts{
		PageNo:   pageNo,
		PageSize: pageSize,
		Status:   models.StatusPublished,
	}
	list, total, err := h.GetList(opts)
	if err != nil {
		d.ServeJSONWithError(err)
	}

	retList := make([]*DataResp, len(list))
	for i, v := range list {
		retList[i] = &DataResp{
			ID:           v.ID,
			ResourceID:   v.ResourceID,
			ResourceName: v.ResourceName,
			Description:  v.Description,
			Version:      v.Version,
			Namespace:    v.Namespace,
			StorageType:  v.StorageType,
			Status:       v.Status,
			TxID:         v.TxID,
			CreateTime:   v.CreateTime.Unix(),
			ExpireTime:   v.ExpireTime.Unix(),
		}
	}

	d.ServeData(map[string]interface{}{
		"total": total,
		"list":  retList,
	})
}

// @Title
// @Description 可用数据列表: 申请通过列表
// @router list/appoved [get]
func (d *DataController) ListApproved() {
	pageNo, _ := d.GetInt("pageNo", 1)
	pageSize, _ := d.GetInt("pageSize", 20)
	// 申请通过模型列表
	c := catalog.NewHandler(d.RequestID)
	resources, total, err := c.ListApprovedUseApplies("data", pageNo, pageSize)
	if err != nil {
		d.ServeJSONWithError(err)
	}

	// 基于缓存文件信息, 补充缺失字段
	retList := make([]*DataResp, len(resources))
	for i, v := range resources {
		retList[i] = &DataResp{
			ResourceID:   v.FileID,
			ResourceName: v.Name,
			Description:  v.Description,
			Version:      v.Version,
			Namespace:    v.Namespace,
			CreateTime:   v.PublishTime / 1000000000,
			ExpireTime:   v.ExpireTime / 1000000000,
			Status:       models.StatusPublished,
		}
	}

	d.ServeData(map[string]interface{}{
		"total": total,
		"list":  retList,
	})
}
