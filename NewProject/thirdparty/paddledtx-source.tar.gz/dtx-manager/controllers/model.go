// Package controllers 资源模块接口实现
package controllers

import (
	"baidu/blockchain/dtx-manager/handlers/catalog"
	"baidu/blockchain/dtx-manager/handlers/model"
	"baidu/blockchain/dtx-manager/models"
	"baidu/blockchain/dtx-manager/pkg/cache"
	"baidu/blockchain/dtx-manager/pkg/codeerror"
	"crypto/md5"
	"encoding/hex"
	"encoding/json"
	"time"
)

type ModelController struct {
	BaseController
}

// ModelReq
type ModelReq struct {
	Name        string `json:"name"`
	ExpireTime  int64  `json:"expireTime"`
	Namespace   string `json:"namespace" valid:"Required"`
	StorageType int    `json:"storageType" valid:"Range(0, 1)"`
	TaskID      string `json:"taskId"`
	ModelName   string `json:"modelName"`
	Description string `json:"description" valid:"Required"`
}

// ModelResp
type ModelResp struct {
	ID           uint64 `json:"id"`
	TaskID       string `json:"taskID"`
	ResourceID   string `json:"resourceID"`
	ResourceName string `json:"resourceName"`
	Description  string `json:"description"`
	Version      string `json:"version"`
	Namespace    string `json:"namespace"`
	StorageType  int    `json:"storageType"`
	AlgoType     int    `json:"algoType"`
	Status       int    `json:"status"`
	TxID         string `json:"tx_id"`
	CreateTime   int64  `json:"createTime"`
	ExpireTime   int64  `json:"expireTime"`
}

// @Title
// @Description
// @router create [post]
func (d *ModelController) Create() {
	var req ModelReq
	d.bindAndCheck(&req)

	if req.ExpireTime != 0 && req.ExpireTime < time.Now().Unix() {
		d.ServeJSONWithError(codeerror.NewErrorByCode(codeerror.ErrParam, "expireTime"))
	}

	// 缓存去重
	reqByte, _ := json.Marshal(req)
	sum := md5.Sum(reqByte)
	md5Key := hex.EncodeToString(sum[:])
	if _, ok := cache.GetCache().Get(md5Key); ok {
		d.ServeJSONWithError(codeerror.NewErrorByCode(codeerror.ErrDuplicateReq))
	}
	cache.GetCache().SetEx(md5Key, true, 5)

	// 若过期时间未设置, 则缺省时间每次不同, md5Key也会变化; 所以缺省时间设置放在重复校验之后
	if req.ExpireTime == 0 {
		req.ExpireTime = time.Now().Add(time.Hour * 24 * 365 * 20).Unix()
	}

	// 新增模型时, 算法类型必须确认有效
	algoType := cache.GetTaskAlgoType(req.TaskID)
	if algoType < 0 {
		d.ServeJSONWithError(codeerror.NewErrorByCode(codeerror.ErrAlgoNotExisted))
	}

	h := model.NewHandler(d.RequestID)
	resourceID, err := h.Create(&models.ModelResource{
		ResourceID:   req.TaskID,
		ResourceName: req.ModelName,
		TaskID:       req.TaskID,
		ExpireTime:   time.Unix(req.ExpireTime, 0),
		Namespace:    req.Namespace,
		StorageType:  req.StorageType,
		AlgoType:     algoType,
		Description:  req.Description,
	})
	if err != nil {
		d.ServeJSONWithError(err)
	}
	d.ServeData(map[string]string{
		"resourceID": resourceID,
	})
}

// @Title
// @Description
// @router list [get]
func (d *ModelController) GetList() {
	// 整理输入参数
	opts := &models.ResourceQueryOpts{}
	opts.PageNo, _ = d.GetInt("pageNo", 1)
	opts.PageSize, _ = d.GetInt("pageSize", 20)
	opts.Namespace = d.GetString("namespace", "")
	opts.Status, _ = d.GetInt("status", -1)

	timeStart, _ := d.GetInt64("startTime", 0)
	if timeStart > 0 {
		opts.StartTime = time.Unix(timeStart, 0)
	}
	timeEnd, _ := d.GetInt64("endTime", 0)
	if timeEnd > 0 {
		opts.EndTime = time.Unix(timeEnd, 0)
	}

	h := model.NewHandler(d.RequestID)
	list, total, err := h.GetList(opts)
	if err != nil {
		d.ServeJSONWithError(err)
	}

	retList := make([]*ModelResp, len(list))
	for i, v := range list {
		// 0921新增字段, 库中老数据未写入, 此处统一查询一次
		v.AlgoType = cache.GetTaskAlgoType(v.TaskID)

		retList[i] = &ModelResp{
			ID:           v.ID,
			TaskID:       v.TaskID,
			ResourceID:   v.ResourceID,
			ResourceName: v.ResourceName,
			Description:  v.Description,
			// Version:     v.Version,
			Namespace:   v.Namespace,
			StorageType: v.StorageType,
			AlgoType:    v.AlgoType,
			Status:      v.Status,
			TxID:        v.TxID,
			CreateTime:  v.CreateTime.Unix(),
			ExpireTime:  v.ExpireTime.Unix(),
		}
	}

	d.ServeData(map[string]interface{}{
		"total": total,
		"list":  retList,
	})
}

// @Title
// @Description
// @router detail [get]
func (d *ModelController) Detail() {
	resourceID := d.GetString("resourceID", "")
	if resourceID == "" {
		d.ServeJSONWithError(codeerror.NewErrorByCode(codeerror.ErrParam, "resourceID"))
	}

	h := model.NewHandler(d.RequestID)
	detail, err := h.Detail(resourceID)
	if err != nil {
		d.ServeJSONWithError(err)
	}

	// 0921新增字段, 库中老数据未写入, 此处统一查询一次
	detail.AlgoType = cache.GetTaskAlgoType(detail.TaskID)

	res := &ModelResp{
		ID:           detail.ID,
		TaskID:       detail.TaskID,
		ResourceID:   detail.ResourceID,
		ResourceName: detail.ResourceName,
		Description:  detail.Description,
		// Version:     detail.Version,
		Namespace:   detail.Namespace,
		StorageType: detail.StorageType,
		AlgoType:    detail.AlgoType,
		Status:      detail.Status,
		TxID:        detail.TxID,
		CreateTime:  detail.CreateTime.Unix(),
		ExpireTime:  detail.ExpireTime.Unix(),
	}

	d.ServeData(res)
}

// @Title
// @Description
// @router publish [post]
func (d *ModelController) Publish() {
	var req ResourceIDReq
	d.bindAndCheck(&req)

	h := model.NewHandler(d.RequestID)
	err := h.Publish(req.ResourceID)
	if err != nil {
		d.ServeJSONWithError(err)
	}
}

// @Title
// @Description
// @router delete [post]
func (d *ModelController) Delete() {
	var req ResourceIDReq
	d.bindAndCheck(&req)

	h := model.NewHandler(d.RequestID)
	err := h.Delete(req.ResourceID)
	if err != nil {
		d.ServeJSONWithError(err)
	}
}

// @Title
// @Description
// @router online [post]
func (d *ModelController) Online() {
	var req ResourceIDReq
	d.bindAndCheck(&req)
	h := model.NewHandler(d.RequestID)
	err := h.Online(req.ResourceID)
	if err != nil {
		d.ServeJSONWithError(err)
	}
}

// @Title
// @Description
// @router offline [post]
func (d *ModelController) Offline() {
	var req ResourceIDReq
	d.bindAndCheck(&req)
	h := model.NewHandler(d.RequestID)
	err := h.Offline(req.ResourceID)
	if err != nil {
		d.ServeJSONWithError(err)
	}
}

// @Title
// @Description
// @router tasklist [get]
func (d *ModelController) TaskList() {
	h := model.NewHandler(d.RequestID)
	taskid_list, err := h.ModelTaskIDList()
	if err != nil {
		d.ServeJSONWithError(err)
	} else {
		d.ServeData(taskid_list)
	}
}

// @Title
// @Description 预测任务可用模型列表: 发布模型列表 + 申请通过模型列表
// @router usable [get]
func (d *ModelController) Usable() {
	// 本机构已发布模型列表
	h := model.NewHandler(d.RequestID)
	opts := &models.ResourceQueryOpts{
		Status: models.StatusPublished,
	}
	models, _, err := h.GetList(opts)
	if err != nil {
		d.ServeJSONWithError(err)
	}

	idList := make([]string, 0)
	for _, v := range models {
		idList = append(idList, v.ResourceID)
	}

	// 申请通过模型列表
	c := catalog.NewHandler(d.RequestID)
	resources, _, err := c.ApplicationList("apply", "model", "online", "Use", "Approved", 0, 0)
	if err != nil {
		d.ServeJSONWithError(err)
	}

	for _, catalogResource := range resources {
		if catalogResource.Status == "Approved" && time.Now().Unix() < catalogResource.ExpireTime {
			idList = append(idList, catalogResource.ResourceID)
		}
	}
	d.ServeData(idList)
}

// @Title
// @Description 预测任务可用模型列表: 发布模型列表
// @router list/published [get]
func (d *ModelController) ListPublished() {
	pageNo, _ := d.GetInt("pageNo", 1)
	pageSize, _ := d.GetInt("pageSize", 20)

	// 本机构已发布模型列表
	h := model.NewHandler(d.RequestID)
	opts := &models.ResourceQueryOpts{
		PageNo:   pageNo,
		PageSize: pageSize,
		Status:   models.StatusPublished,
	}
	models, total, err := h.GetList(opts)
	if err != nil {
		d.ServeJSONWithError(err)
	}

	retList := make([]*ModelResp, len(models))
	for i, v := range models {
		// 0921新增字段, 库中老数据未写入, 此处统一查询一次
		v.AlgoType = cache.GetTaskAlgoType(v.TaskID)

		retList[i] = &ModelResp{
			ID:           v.ID,
			TaskID:       v.TaskID,
			ResourceID:   v.ResourceID,
			ResourceName: v.ResourceName,
			Description:  v.Description,
			Namespace:    v.Namespace,
			StorageType:  v.StorageType,
			AlgoType:     v.AlgoType,
			Status:       v.Status,
			CreateTime:   v.CreateTime.Unix(),
			ExpireTime:   v.ExpireTime.Unix(),
		}
	}

	d.ServeData(map[string]interface{}{
		"total": total,
		"list":  retList,
	})
}

// @Title
// @Description 预测任务可用模型列表: 申请通过模型列表
// @router list/appoved [get]
func (d *ModelController) ListApproved() {
	pageNo, _ := d.GetInt("pageNo", 1)
	pageSize, _ := d.GetInt("pageSize", 20)
	// 申请通过模型列表
	c := catalog.NewHandler(d.RequestID)
	resources, total, err := c.ListApprovedUseApplies("model", pageNo, pageSize)
	if err != nil {
		d.ServeJSONWithError(err)
	}

	// 基于缓存文件信息, 补充缺失字段
	retList := make([]*ModelResp, len(resources))
	for i, v := range resources {
		algoType := cache.GetTaskAlgoType(v.TaskID)
		retList[i] = &ModelResp{
			TaskID:       v.TaskID,
			ResourceID:   v.FileID,
			ResourceName: v.Name,
			Description:  v.Description,
			Version:      v.Version,
			Namespace:    v.Namespace,
			CreateTime:   v.PublishTime / 1000000000,
			ExpireTime:   v.ExpireTime / 1000000000,
			Status:       models.StatusPublished,
			AlgoType:     algoType,
		}
	}

	d.ServeData(map[string]interface{}{
		"total": total,
		"list":  retList,
	})
}
