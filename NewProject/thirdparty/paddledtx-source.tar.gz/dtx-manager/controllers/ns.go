// Package controllers 命名空间接口实现
package controllers

import (
	"baidu/blockchain/dtx-manager/handlers/catalog"
	"baidu/blockchain/dtx-manager/handlers/op"
	"baidu/blockchain/dtx-manager/pkg/codeerror"
)

// NameSpaceController
type NameSpaceController struct {
	BaseController
}

// @Title
// @Description
// @router add [post]
func (ns *NameSpaceController) AddNamespace() {
	dataType := ns.Ctx.Input.Param(":dataType")
	if dataType != "data" && dataType != "model" {
		ns.ServeJSONWithError(codeerror.NewErrorByCode(codeerror.ErrDataTypeNotExisted))
	}

	var req catalog.CreateRequest
	ns.bindAndCheck(&req)
	if len(req.Name) == 0 {
		ns.ServeJSONWithError(codeerror.NewErrorByCode(codeerror.ErrParam, "name"))
	}

	// replica为定值, 暂不需要校验
	// o := op.NewHandler(ns.RequestID)
	// limit, err := o.ReplicaLimit()
	// if err != nil {
	// 	ns.ServeJSONWithError(codeerror.NewErrorByCode(codeerror.ErrCodeInternal, err.Error()))
	// }
	// if req.Replica > int(limit) {
	// 	errMsg := fmt.Sprintf("replica should not greater than storage node count[%d]", limit)
	// 	ns.ServeJSONWithError(codeerror.NewErrorByCode(codeerror.ErrReplicaOversized, errMsg))
	// }

	h := catalog.NewHandler(ns.RequestID)
	err := h.AddNS(dataType, req)
	if err != nil {
		ns.ServeJSONWithError(err)
	}
}

// @Title
// @Description
// @router replicaLimit [get]
func (ns *NameSpaceController) ReplicaLimit() {
	o := op.NewHandler(ns.RequestID)
	limit, err := o.ReplicaLimit()
	if err != nil {
		ns.ServeJSONWithError(err)
	}
	ns.ServeData(limit)
}

// @Title
// @Description
// @router list [get]
func (ns *NameSpaceController) List() {
	dataType := ns.Ctx.Input.Param(":dataType")
	if dataType != "data" && dataType != "model" {
		ns.ServeJSONWithError(codeerror.NewErrorByCode(codeerror.ErrDataTypeNotExisted))
	}
	orgName := ns.GetString("orgName", "")

	h := catalog.NewHandler(ns.RequestID)
	data, err := h.ListNs(dataType, orgName)
	if err != nil {
		ns.ServeJSONWithError(err)
	}
	ns.ServeData(data)
}

// @Title
// @Description
// @router list [get]
func (ns *NameSpaceController) Simplelist() {
	dataType := ns.Ctx.Input.Param(":dataType")
	if dataType != "data" && dataType != "model" {
		ns.ServeJSONWithError(codeerror.NewErrorByCode(codeerror.ErrDataTypeNotExisted))
	}
	h := catalog.NewHandler(ns.RequestID)
	data, err := h.ListNsName(dataType)
	if err != nil {
		ns.ServeJSONWithError(err)
	}
	ns.ServeData(data)
}

// @Title
// @Description
// @router resource/detail [get]
func (ns *NameSpaceController) ResourceDetail() {
	dataType := ns.Ctx.Input.Param(":dataType")
	resourceID := ns.GetString("resourceID", "")

	h := catalog.NewHandler(ns.RequestID)
	data, err := h.ResourceDetail(dataType, resourceID)
	if err != nil {
		ns.ServeJSONWithError(err)
	}
	ns.ServeData(data)
}

// @Title
// @Description
// @router orgStat [get]
func (ns *NameSpaceController) OrgStat() {
	dataType := ns.Ctx.Input.Param(":dataType")

	h := catalog.NewHandler(ns.RequestID)
	data, err := h.ListOrgStat(dataType)
	if err != nil {
		ns.ServeJSONWithError(err)
	}
	ns.ServeData(data)
}
