// Package controllers 资源权限模块接口实现
package controllers

import (
	"baidu/blockchain/dtx-manager/handlers/catalog"
	"baidu/blockchain/dtx-manager/pkg/cache"
	"baidu/blockchain/dtx-manager/pkg/codeerror"
	"crypto/md5"
	"encoding/hex"
	"encoding/json"
	"time"
)

type ResourceAuthController struct {
	BaseController
}

// ResourceApplyReq
type ResourceApplyReq struct {
	ResourceID string   `json:"resourceID" valid:"Required;"`
	AuthType   string   `json:"authType" valid:"Required;Match(Look|Use)"`
	Keys       []string `json:"keys"`
}

// ApplyOperaitonReq
type ApplyOperationReq struct {
	AuthID     string `json:"authID" valid:"Required;"`
	Status     string `json:"status" valid:"Required;Match(pass|reject)"`
	Reason     string `json:"reason"`
	ExpireTime int64  `json:"expireTime"`
}

// @Title
// @Description
// @router apply [post]
func (r *ResourceAuthController) Apply() {
	dataType := r.Ctx.Input.Param(":dataType")
	if dataType != "data" && dataType != "model" {
		r.ServeJSONWithError(codeerror.NewErrorByCode(codeerror.ErrDataTypeNotExisted))
	}
	var req ResourceApplyReq
	r.bindAndCheck(&req)

	// 防刷
	reqByte, _ := json.Marshal(req)
	sum := md5.Sum(reqByte)
	md5Key := hex.EncodeToString(sum[:])
	if _, ok := cache.GetCache().Get(md5Key); ok {
		r.ServeJSONWithError(codeerror.NewErrorByCode(codeerror.ErrDuplicateReq))
	}
	cache.GetCache().SetEx(md5Key, true, 60)

	h := catalog.NewHandler(r.RequestID)
	authID, err := h.Apply(req.ResourceID, req.AuthType, dataType, req.Keys)
	if err != nil {
		r.ServeJSONWithError(err)
	}
	r.ServeData(map[string]string{
		"authID": authID,
	})
}

// @Title
// @Description
// @router operate [post]
func (r *ResourceAuthController) Operate() {
	var req ApplyOperationReq
	r.bindAndCheck(&req)

	if req.ExpireTime != 0 && req.ExpireTime < time.Now().Unix() {
		r.ServeJSONWithError(codeerror.NewErrorByCode(codeerror.ErrParam, "expireTime"))
	}

	var err error
	h := catalog.NewHandler(r.RequestID)
	switch req.Status {
	case "pass":
		err = h.ApplicationApprove(req.AuthID, time.Unix(req.ExpireTime, 0))
	case "reject":
		err = h.ApplicationReject(req.AuthID, req.Reason)
	}
	if err != nil {
		r.ServeJSONWithError(err)
	}
}

// @Title
// @Description
// @router list [get]
func (r *ResourceAuthController) List() {
	dataType := r.Ctx.Input.Param(":dataType")
	reqType := r.GetString("type", "")
	pageNo, _ := r.GetInt("pageNo", 1)
	pageSize, _ := r.GetInt("pageSize", 20)

	if reqType != "apply" && reqType != "auth" {
		r.ServeJSONWithError(codeerror.NewErrorByCode(codeerror.ErrParam, "type"))
	}
	h := catalog.NewHandler(r.RequestID)
	data, cnt, err := h.ApplicationList(reqType, dataType, "", "", "", pageNo, pageSize)
	if err != nil {
		r.ServeJSONWithError(err)
	}

	res := map[string]interface{}{
		"total": cnt,
		"list":  data,
	}
	r.ServeData(res)
}

// @Title
// @Description
// @router detail [get]
func (r *ResourceAuthController) Detail() {
	dataType := r.Ctx.Input.Param(":dataType")

	authID := r.GetString("authID", "")
	if authID == "" {
		r.ServeJSONWithError(codeerror.NewErrorByCode(codeerror.ErrParam, "authID"))
	}
	h := catalog.NewHandler(r.RequestID)
	data, err := h.ApplicationDetail(dataType, authID)
	if err != nil {
		r.ServeJSONWithError(err)
	}
	r.ServeData(data)
}
