// Package controllers 平台用户模块接口实现
package controllers

import (
	"baidu/blockchain/dtx-manager/handlers/op"
	"baidu/blockchain/dtx-manager/pkg/codeerror"
	"baidu/blockchain/dtx-manager/pkg/logger"
	"bufio"
	"encoding/json"
	"fmt"
	"github.com/PaddlePaddle/PaddleDTX/crypto/core/ecdsa"
	"io/ioutil"
	"log"
	"os"
	"os/exec"
	"regexp"
	"strconv"
	"strings"
)

// OPController
type OPController struct {
	BaseController
}

// @Title
// @Description
// @router blockchain/netInfo [get]
func (o *OPController) ChainNetInfo() {
	h := op.NewHandler(o.RequestID)
	ret := h.GetBlockchainNode()
	o.ServeData(ret)
}

// @Title
// @Description
// @router xdb/netInfo [get]
func (o *OPController) XdbNetInfo() {
	h := op.NewHandler(o.RequestID)
	netInfo, err := h.GetXdbNetInfo()
	if err != nil {
		o.ServeJSONWithError(codeerror.NewErrorByCode(codeerror.ErrInternalServer, err))
	}
	o.ServeData(netInfo)
}

// @Title
// @Description
// @router xdb/nodeInfo [get]
func (o *OPController) XdbNodeInfo() {
	h := op.NewHandler(o.RequestID)
	nodeInfo, err := h.GetXdbNodeInfo()
	if err != nil {
		o.ServeJSONWithError(codeerror.NewErrorByCode(codeerror.ErrInternalServer, err))
	}
	o.ServeData(nodeInfo)
}

// @Title
// @Description
// @router dai/netInfo [get]
func (o *OPController) DaiNetInfo() {
	h := op.NewHandler(o.RequestID)
	netInfo, err := h.GetDaiNetInfo()
	if err != nil {
		o.ServeJSONWithError(codeerror.NewErrorByCode(codeerror.ErrInternalServer, err))
	}
	o.ServeData(netInfo)
}

// @Title
// @Description
// @router dai/taskInfo [get]
func (o *OPController) DaiTaskInfo() {
	h := op.NewHandler(o.RequestID)
	data, err := h.GetDaiTaskInfo()
	if err != nil {
		o.ServeJSONWithError(codeerror.NewErrorByCode(codeerror.ErrInternalServer, err))
	}
	o.ServeData(data)
}

type newExecutorNodeReq struct {
	ExecutorID      int    `json:"executorID"`
	ExecutorName    string `json:"executorName"`
	OrgID           int    `json:"orgID"`
	Replicas        int    `json:"replicas"`
	ContainerPort   int    `json:"containerPort"`
	PaddleFLAddress int    `json:"paddleFLAddress"`
	HttpPort        int    `json:"httpPort"`
	ManagerID       int    `json:"managerID"`
}

/*type NewExecutorNodeResp struct {
	ExecutorID int `json:"executorID"`
}*/

func (o *OPController) NewExecutorNode() {
	var req newExecutorNodeReq
	if err := json.Unmarshal(o.Ctx.Input.RequestBody, &req); err != nil {
		o.ServeJSONWithError(codeerror.NewError(ErrUnmarshal, err.Error()))
		return
	}

	// 打开模版文件
	filePath := "/home/chart/templates/executor/executor-node1.yaml" // 修改为实际的文件路径
	f, err := os.Open(filePath)
	if err != nil {
		log.Fatal("无法打开文件", err)
	}
	defer f.Close()

	// 创建新文件
	newFilePath := fmt.Sprintf("/home/chart/templates/executor/%s.yaml", req.ExecutorName) // 修改为实际的新文件路径
	newFile, err := os.Create(newFilePath)
	if err != nil {
		log.Fatal("无法创建新文件", err)
	}
	defer newFile.Close()

	prikey, pubkey, err := ecdsa.GenerateKeyPair()
	if err != nil {
		logger.Info("failed to GenerateKeyPair, err：%v\n", err)
		return
	}

	str1 := "---"
	symbolRegex := regexp.MustCompile(`]`)
	var firstchar string

	// 逐行读取原始文件并写入新文件
	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		lineText := scanner.Text() + "\n" // 添加换行符
		lineText1 := scanner.Text()
		var lineTextTmp []string
		if len(strings.TrimSpace(lineText1)) > 0 {
			lineTextTmp = strings.Split(lineText1, ":")
			firstchar = string(strings.TrimSpace(lineText1)[0])
			//log.Printf("aa3aa[%v]", lineTextTmp[1])
		}
		var lineTextTmp2 []string
		if len(strings.TrimSpace(lineText1)) > 0 {
			lineTextTmp2 = strings.Split(lineText1, "=")
			//log.Printf("aa3aa[%v]", lineTextTmp[1])
		}

		if len(strings.TrimSpace(lineText1)) == 64 {
			lineTextTmp[0] = fmt.Sprintf("    %s", prikey)
			lineTextTmp1 := fmt.Sprintf("%s\n", lineTextTmp[0])
			_, err = newFile.WriteString(lineTextTmp1)
			if err != nil {
				log.Println("写入新文件时发生错误", err)
			}
			continue
		}

		if len(strings.TrimSpace(lineText1)) == 128 {
			lineTextTmp[0] = fmt.Sprintf("    %s", pubkey)
			lineTextTmp1 := fmt.Sprintf("%s\n", lineTextTmp[0])
			_, err = newFile.WriteString(lineTextTmp1)
			if err != nil {
				log.Println("写入新文件时发生错误", err)
			}
			continue
		}

		//log.Printf("------aa13aa[%v][%v][%v]", lineText1, strings.TrimSpace(lineText1), len(strings.TrimSpace(lineText1)))
		if lineText1 != str1 && len(lineTextTmp) > 0 &&
			strings.TrimSpace(lineText1) != "image: \"{{ .Values.global.registry }}/{{ .Values.paddledtx_dai.image.repository }}:{{ .Values.paddledtx_dai.image.tag }}\"" &&
			strings.TrimSpace(lineText1) != "- ReadWriteOnce" && strings.TrimSpace(lineText1) != "config.toml: |-" && symbolRegex.MatchString(strings.TrimSpace(lineText1)) != true &&
			len(lineTextTmp2) != 2 && firstchar != "#" {

			//log.Printf("aa2aa [%v]\n", strings.TrimSpace(lineTextTmp[0]))

			if lineTextTmp[1] == " executor-node1" {
				lineTextTmp[1] = fmt.Sprintf(" executor-node%d", req.ExecutorID)
			}
			if lineTextTmp[1] == " executor-node1-svc" {
				lineTextTmp[1] = fmt.Sprintf(" executor-node%d-svc", req.ExecutorID)
			}
			if lineTextTmp[1] == " {{ .Values.paddledtx_dai.svc.nodePort1 }}" {
				lineTextTmp[1] = fmt.Sprintf(" {{ .Values.paddledtx_dai.svc.nodePort%d }}", req.ExecutorID)
			}
			if lineTextTmp[1] == " executor1" {
				lineTextTmp[1] = fmt.Sprintf(" executor%d", req.ExecutorID)
			}
			if strings.TrimSpace(lineTextTmp[0]) == "- containerPort" {
				lineTextTmp1 := strings.TrimSpace(lineTextTmp[1])
				containerPortTmp, _ := strconv.Atoi(lineTextTmp1)
				//log.Printf("---------------cccccc[%v]", lineTextTmp1)
				if containerPortTmp == 8511 {
					log.Printf("dddddd")
					lineTextTmp[1] = fmt.Sprintf(" %d", req.ContainerPort)
				}
			}
			if lineTextTmp[1] == " executor1-conf" {
				lineTextTmp[1] = fmt.Sprintf(" executor%d-conf", req.ExecutorID)
			}
			if lineTextTmp[1] == " executor1-keys" {
				lineTextTmp[1] = fmt.Sprintf(" executor%d-keys", req.ExecutorID)
			}
			if lineTextTmp[1] == " executor1-files" {
				lineTextTmp[1] = fmt.Sprintf(" executor%d-files", req.ExecutorID)
			}
			if lineTextTmp[1] == " executor1-ukey" {
				lineTextTmp[1] = fmt.Sprintf(" executor%d-ukey", req.ExecutorID)
			}
			if lineTextTmp[1] == " dai-executor1-pvc" {
				lineTextTmp[1] = fmt.Sprintf(" dai-executor%d-pvc", req.ExecutorID)
			}
			if strings.TrimSpace(lineTextTmp[1]) == "{{ .Values.global.pv.path_prefix }}{{ .Values.manager1.pv.localStore }}" {
				lineTextTmp[1] = fmt.Sprintf(" {{ .Values.global.pv.path_prefix }}{{ .Values.manager%d.pv.localStore }}", req.ManagerID)
				log.Printf("------aa14aa[%v][%v][%v]", lineText1, strings.TrimSpace(lineText1), len(strings.TrimSpace(lineText1)))
			}
			if strings.TrimSpace(lineTextTmp[1]) == "dai-executor1" {
				lineTextTmp[1] = fmt.Sprintf(" dai-executor%d", req.ExecutorID)
			}
			if strings.TrimSpace(lineTextTmp[1]) == "dai-executor1-pv" {
				lineTextTmp[1] = fmt.Sprintf(" dai-executor%d-pv", req.ExecutorID)
			}
			if strings.TrimSpace(lineTextTmp[1]) == "\"{{ .Values.global.pv.path_prefix }}{{ .Values.paddledtx_dai.pv.path }}/node1\"" {
				lineTextTmp[1] = fmt.Sprintf(" \"{{ .Values.global.pv.path_prefix }}{{ .Values.paddledtx_dai.pv.path }}/node%d\"", req.ExecutorID)
			}

			//log.Printf("aa4aa[%v]", lineTextTmp[1])
			lineTextTmp1 := fmt.Sprintf("%s:%s\n", lineTextTmp[0], lineTextTmp[1])
			_, err = newFile.WriteString(lineTextTmp1)
			if err != nil {
				log.Println("写入新文件时发生错误", err)
			}
		} else if len(lineTextTmp2) > 1 {
			if strings.TrimSpace(lineTextTmp2[0]) == "name" {
				lineTextTmp2[1] = fmt.Sprintf(" \"%s\"", req.ExecutorName)
			}
			if strings.TrimSpace(lineTextTmp2[0]) == "orgID" {
				lineTextTmp2[1] = fmt.Sprintf(" \"%d\"", req.OrgID)
			}
			if strings.TrimSpace(lineTextTmp2[0]) == "publicAddress" {
				lineTextTmp2[1] = fmt.Sprintf(" \"{{ .Values.paddledtx_dai.svc.nodeAddr }}:{{ .Values.paddledtx_dai.svc.nodePort%d }}\"", req.ExecutorID)
			}
			if strings.TrimSpace(lineTextTmp2[0]) == "paddleFLRole" {
				paddleFLRole := 1
				//log.Printf("---------------aa6aa[%v][%v]", lineTextTmp2, lineTextTmp2[1])
				lineTextTmp2[1] = fmt.Sprintf(" %d", paddleFLRole)
			}
			if strings.TrimSpace(lineTextTmp2[0]) == "paddleFLAddress" {
				lineTextTmp2[1] = fmt.Sprintf(" \"paddlefl-env%d:%d\"", req.ExecutorID, req.PaddleFLAddress)
			}
			if strings.TrimSpace(lineTextTmp2[0]) == "httpAddress" {
				lineTextTmp2[1] = fmt.Sprintf(" \"{{ .Values.global.dtx_exip }}:%d\"", req.HttpPort)
			}
			if strings.TrimSpace(lineTextTmp2[0]) == "httpPort" {
				lineTextTmp2[1] = fmt.Sprintf(" \":%d\"", req.HttpPort)
			}
			if strings.TrimSpace(lineTextTmp2[0]) == "host" {
				lineTextTmp2[1] = fmt.Sprintf(" \"http://dataowner-node%d-svc.dtx.svc:80\"", req.ExecutorID)
			}

			//log.Printf("aa5aa[%v]", lineTextTmp2[1])
			lineTextTmp2 := fmt.Sprintf("%s=%s\n", lineTextTmp2[0], lineTextTmp2[1])
			_, err = newFile.WriteString(lineTextTmp2)
			if err != nil {
				log.Println("写入新文件时发生错误", err)
			}
		} else {
			_, err = newFile.WriteString(lineText)
			if err != nil {
				log.Println("写入新文件时发生错误", err)
			}
		}
	}

	err = scanner.Err()
	if err != nil {
		log.Fatal("在读取文件过程中发生错误", err)
	}

	//新建对应的nfs目录

	//动态生效配置文件
	if err := HelmUpgrade("dtx", "/home/chart", "dtxns"); err != nil {
		o.ServeJSONWithError(codeerror.NewError(ErrHelmUpgrade, err.Error()))
		return
	}

	o.Ret.Data = "OK"
	o.Ret.Code = "0"
}

type newDataownerNodeReq struct {
	DataownerID   int    `json:"dataownerID"`
	DataownerName string `json:"dataownerName"`
	Replicas      int    `json:"replicas"`
}

func (o *OPController) NewDataownerNode() {
	var req newDataownerNodeReq
	if err := json.Unmarshal(o.Ctx.Input.RequestBody, &req); err != nil {
		o.ServeJSONWithError(codeerror.NewError(ErrUnmarshal, err.Error()))
		return
	}
	// 打开原始文件
	filePath := "/home/chart/templates/xdb/dataowner-node1.yaml" // 修改为实际的文件路径
	f, err := os.Open(filePath)
	if err != nil {
		log.Fatal("无法打开文件", err)
	}
	defer f.Close()

	// 创建新文件
	newFilePath := fmt.Sprintf("/home/chart/templates/xdb/%s.yaml", req.DataownerName)
	newFile, err := os.Create(newFilePath)
	if err != nil {
		log.Fatal("无法创建新文件", err)
	}
	defer newFile.Close()

	prikey, pubkey, err := ecdsa.GenerateKeyPair()
	if err != nil {
		logger.Info("failed to GenerateKeyPair, err：%v\n", err)
		return
	}

	str1 := "---"
	symbolRegex := regexp.MustCompile(`]`)
	var firstchar string

	// 逐行读取原始文件并写入新文件
	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		lineText := scanner.Text() + "\n" // 添加换行符FGetTaskById
		lineText1 := scanner.Text()
		var lineTextTmp []string
		if len(strings.TrimSpace(lineText1)) > 0 {
			lineTextTmp = strings.Split(lineText1, ":")
			firstchar = string(strings.TrimSpace(lineText1)[0])
			//log.Printf("aa3aa[%v]", lineTextTmp[1])
		}
		var lineTextTmp2 []string
		if len(strings.TrimSpace(lineText1)) > 0 {
			lineTextTmp2 = strings.Split(lineText1, "=")
			//log.Printf("aa3aa[%v]", lineTextTmp[1])
		}

		if len(strings.TrimSpace(lineText1)) == 64 {
			lineTextTmp[0] = fmt.Sprintf("    %s", prikey)
			lineTextTmp1 := fmt.Sprintf("%s\n", lineTextTmp[0])
			_, err = newFile.WriteString(lineTextTmp1)
			if err != nil {
				log.Println("写入新文件时发生错误", err)
			}
			continue
		}

		if len(strings.TrimSpace(lineText1)) == 128 {
			lineTextTmp[0] = fmt.Sprintf("    %s", pubkey)
			lineTextTmp1 := fmt.Sprintf("%s\n", lineTextTmp[0])
			_, err = newFile.WriteString(lineTextTmp1)
			if err != nil {
				log.Println("写入新文件时发生错误", err)
			}
			continue
		}

		//log.Printf("------aa1aa[%v][%v][%v]", lineText1, strings.TrimSpace(lineText1), len(strings.TrimSpace(lineText1)))
		if lineText1 != str1 && len(lineTextTmp) > 0 &&
			strings.TrimSpace(lineText1) != "image: \"{{ .Values.global.registry }}/{{ .Values.xdb_dataowner.image.repository }}:{{ .Values.xdb_dataowner.image.tag }}\"" &&
			strings.TrimSpace(lineText1) != "- ReadWriteOnce" && strings.TrimSpace(lineText1) != "config.toml: |-" && symbolRegex.MatchString(strings.TrimSpace(lineText1)) != true &&
			len(lineTextTmp2) != 2 && firstchar != "#" {

			//log.Printf("aa2aa [%v]\n", strings.TrimSpace(lineTextTmp[0]))

			if lineTextTmp[1] == " dataowner-node1-svc" {
				lineTextTmp[1] = fmt.Sprintf(" dataowner-node%d-svc", req.DataownerID)
			}
			if lineTextTmp[1] == " dataowner-node1" {
				lineTextTmp[1] = fmt.Sprintf(" dataowner-node%d", req.DataownerID)
			}
			if lineTextTmp[1] == " xdb-dataowner1-conf" {
				lineTextTmp[1] = fmt.Sprintf(" xdb-dataowner%d-conf", req.DataownerID)
			}
			if lineTextTmp[1] == " xdb-dataowner1-keys" {
				lineTextTmp[1] = fmt.Sprintf(" xdb-dataowner%d-keys", req.DataownerID)
			}
			if lineTextTmp[1] == " xdb-dataowner1-ukeys" {
				lineTextTmp[1] = fmt.Sprintf(" xdb-dataowner%d-ukeys", req.DataownerID)
			}
			if lineTextTmp[1] == " xdb-dataowner1-authkeys" {
				lineTextTmp[1] = fmt.Sprintf(" xdb-dataowner%d-authkeys", req.DataownerID)
			}
			if lineTextTmp[1] == " data1" {
				lineTextTmp[1] = fmt.Sprintf(" data%d", req.DataownerID)
			}
			if strings.TrimSpace(lineTextTmp[1]) == "xdb-dataowner1-pvc" {
				lineTextTmp[1] = fmt.Sprintf(" xdb-dataowner%d-pvc", req.DataownerID)
			}
			if strings.TrimSpace(lineTextTmp[1]) == "xdb-dataowner1" {
				lineTextTmp[1] = fmt.Sprintf(" xdb-dataowner%d", req.DataownerID)
			}
			if strings.TrimSpace(lineTextTmp[1]) == "xdb-dataowner1-pv" {
				lineTextTmp[1] = fmt.Sprintf(" xdb-dataowner%d-pv", req.DataownerID)
			}
			if strings.TrimSpace(lineTextTmp[1]) == "\"{{ .Values.global.pv.path_prefix }}{{ .Values.xdb_dataowner.pv.path }}/data1\"" {
				lineTextTmp[1] = fmt.Sprintf(" \"{{ .Values.global.pv.path_prefix }}{{ .Values.xdb_dataowner.pv.path }}/data%d\"", req.DataownerID)
			}

			//log.Printf("aa4aa[%v]", lineTextTmp[1])
			lineTextTmp1 := fmt.Sprintf("%s:%s\n", lineTextTmp[0], lineTextTmp[1])
			_, err = newFile.WriteString(lineTextTmp1)
			if err != nil {
				log.Println("写入新文件时发生错误", err)
			}
		} else if len(lineTextTmp2) > 1 {
			if strings.TrimSpace(lineTextTmp2[0]) == "name" {
				lineTextTmp2[1] = fmt.Sprintf(" \"%s\"", req.DataownerName)
			}
			if strings.TrimSpace(lineTextTmp2[0]) == "publicAddress" {
				lineTextTmp2[1] = fmt.Sprintf(" \"dataowner%d.node.com:80\"", req.DataownerID)
			}

			//log.Printf("aa5aa[%v]", lineTextTmp2[1])
			lineTextTmp2 := fmt.Sprintf("%s=%s\n", lineTextTmp2[0], lineTextTmp2[1])
			_, err = newFile.WriteString(lineTextTmp2)
			if err != nil {
				log.Println("写入新文件时发生错误", err)
			}
		} else {
			_, err = newFile.WriteString(lineText)
			if err != nil {
				log.Println("写入新文件时发生错误", err)
			}
		}
	}

	err = scanner.Err()
	if err != nil {
		log.Fatal("在读取文件过程中发生错误", err)
	}

	//动态生效配置文件
	if err := HelmUpgrade("dtx", "/home/chart", "dtxns"); err != nil {
		o.ServeJSONWithError(codeerror.NewError(ErrHelmUpgrade, err.Error()))
		return
	}

	o.Ret.Code = "0"
	o.Ret.Data = "ok"
}

type newStorageNodeReq struct {
	StorageID   int    `json:"storageID"`
	StorageName string `json:"storageName"`
	Replicas    int    `json:"replicas"`
}

func (o *OPController) NewStorageNode() {
	var req newStorageNodeReq
	if err := json.Unmarshal(o.Ctx.Input.RequestBody, &req); err != nil {
		o.ServeJSONWithError(codeerror.NewError(ErrUnmarshal, err.Error()))
		return
	}
	// 打开原始文件
	filePath := "/home/chart/templates/xdb/storage-node1.yaml" // 修改为实际的文件路径
	f, err := os.Open(filePath)
	if err != nil {
		log.Fatal("无法打开文件", err)
	}
	defer f.Close()

	// 创建新文件
	newFilePath := fmt.Sprintf("/home/chart/templates/xdb/%s.yaml", req.StorageName)
	newFile, err := os.Create(newFilePath)
	if err != nil {
		log.Fatal("无法创建新文件", err)
	}
	defer newFile.Close()

	prikey, pubkey, err := ecdsa.GenerateKeyPair()
	if err != nil {
		logger.Info("failed to GenerateKeyPair, err：%v\n", err)
		return
	}

	str1 := "---"
	symbolRegex := regexp.MustCompile(`]`)
	var firstchar string

	// 逐行读取原始文件并写入新文件
	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		lineText := scanner.Text() + "\n" // 添加换行符
		lineText1 := scanner.Text()
		var lineTextTmp []string
		if len(strings.TrimSpace(lineText1)) > 0 {
			lineTextTmp = strings.Split(lineText1, ":")
			firstchar = string(strings.TrimSpace(lineText1)[0])
			//log.Printf("aa3aa[%v]", lineTextTmp[1])
		}
		var lineTextTmp2 []string
		if len(strings.TrimSpace(lineText1)) > 0 {
			lineTextTmp2 = strings.Split(lineText1, "=")
			//log.Printf("aa3aa[%v]", lineTextTmp[1])
		}

		if len(strings.TrimSpace(lineText1)) == 64 {
			lineTextTmp[0] = fmt.Sprintf("    %s", prikey)
			lineTextTmp1 := fmt.Sprintf("%s\n", lineTextTmp[0])
			_, err = newFile.WriteString(lineTextTmp1)
			if err != nil {
				log.Println("写入新文件时发生错误", err)
			}
			continue
		}

		if len(strings.TrimSpace(lineText1)) == 128 {
			lineTextTmp[0] = fmt.Sprintf("    %s", pubkey)
			lineTextTmp1 := fmt.Sprintf("%s\n", lineTextTmp[0])
			_, err = newFile.WriteString(lineTextTmp1)
			if err != nil {
				log.Println("写入新文件时发生错误", err)
			}
			continue
		}

		//log.Printf("------aa1aa[%v][%v][%v]", lineText1, strings.TrimSpace(lineText1), len(strings.TrimSpace(lineText1)))
		if lineText1 != str1 && len(lineTextTmp) > 0 &&
			strings.TrimSpace(lineText1) != "image: \"{{ .Values.global.registry }}/{{ .Values.xdb_storage.image.repository }}:{{ .Values.xdb_storage.image.tag }}\"" &&
			strings.TrimSpace(lineText1) != "- ReadWriteOnce" && strings.TrimSpace(lineText1) != "config.toml: |-" && symbolRegex.MatchString(strings.TrimSpace(lineText1)) != true &&
			len(lineTextTmp2) != 2 && firstchar != "#" {

			//log.Printf("aa2aa [%v]\n", strings.TrimSpace(lineTextTmp[0]))

			if lineTextTmp[1] == " storage-node1-svc" {
				lineTextTmp[1] = fmt.Sprintf(" storage-node%d-svc", req.StorageID)
			}
			if lineTextTmp[1] == " storage-node1" {
				lineTextTmp[1] = fmt.Sprintf(" storage-node%d", req.StorageID)
			}
			if lineTextTmp[1] == " xdb-storage1-conf" {
				lineTextTmp[1] = fmt.Sprintf(" xdb-storage%d-conf", req.StorageID)
			}
			if lineTextTmp[1] == " xdb-storage1-keys" {
				lineTextTmp[1] = fmt.Sprintf(" xdb-storage%d-keys", req.StorageID)
			}
			if strings.TrimSpace(lineTextTmp[1]) == "storage1" {
				lineTextTmp[1] = fmt.Sprintf(" storage%d", req.StorageID)
			}
			if strings.TrimSpace(lineTextTmp[1]) == "xdb-storage1-pvc" {
				lineTextTmp[1] = fmt.Sprintf(" xdb-storage%d-pvc", req.StorageID)
			}
			if strings.TrimSpace(lineTextTmp[1]) == "xdb-storage1" {
				lineTextTmp[1] = fmt.Sprintf(" xdb-storage%d", req.StorageID)
			}
			if strings.TrimSpace(lineTextTmp[1]) == "xdb-storage1-pv" {
				lineTextTmp[1] = fmt.Sprintf(" xdb-storage%d-pv", req.StorageID)
			}
			if strings.TrimSpace(lineTextTmp[1]) == "\"{{ .Values.global.pv.path_prefix }}{{ .Values.xdb_storage.pv.path }}/storage1\"" {
				lineTextTmp[1] = fmt.Sprintf(" \"{{ .Values.global.pv.path_prefix }}{{ .Values.xdb_storage.pv.path }}/storage%d\"", req.StorageID)
			}

			//log.Printf("aa4aa[%v]", lineTextTmp[1])
			lineTextTmp1 := fmt.Sprintf("%s:%s\n", lineTextTmp[0], lineTextTmp[1])
			_, err = newFile.WriteString(lineTextTmp1)
			if err != nil {
				log.Println("写入新文件时发生错误", err)
			}
		} else if len(lineTextTmp2) > 1 {
			if strings.TrimSpace(lineTextTmp2[0]) == "name" {
				lineTextTmp2[1] = fmt.Sprintf(" \"%s\"", req.StorageName)
			}
			if strings.TrimSpace(lineTextTmp2[0]) == "publicAddress" {
				lineTextTmp2[1] = fmt.Sprintf(" \"storage-node%d-svc.{{ .Values.global.namespace }}.svc:80\"", req.StorageID)
			}

			//log.Printf("aa5aa[%v]", lineTextTmp2[1])
			lineTextTmp2 := fmt.Sprintf("%s=%s\n", lineTextTmp2[0], lineTextTmp2[1])
			_, err = newFile.WriteString(lineTextTmp2)
			if err != nil {
				log.Println("写入新文件时发生错误", err)
			}
		} else {
			_, err = newFile.WriteString(lineText)
			if err != nil {
				log.Println("写入新文件时发生错误", err)
			}
		}
	}

	err = scanner.Err()
	if err != nil {
		log.Fatal("在读取文件过程中发生错误", err)
	}

	//动态生效配置文件
	if err := HelmUpgrade("dtx", "/home/chart", "dtxns"); err != nil {
		o.ServeJSONWithError(codeerror.NewError(ErrHelmUpgrade, err.Error()))
		return
	}

	o.Ret.Code = "0"
	o.Ret.Data = "ok"
}

type modifyExecutorNodeReq struct {
	ExecutorName string `json:"executorName"`
	Replicas     int    `json:"replicas"`
}

func (o *OPController) ModifyExecutorNode() {
	var req modifyExecutorNodeReq
	if err := json.Unmarshal(o.Ctx.Input.RequestBody, &req); err != nil {
		o.ServeJSONWithError(codeerror.NewError(ErrUnmarshal, err.Error()))
		return
	}

	logger.Infof("aaaaaa4[%v][%v]", req.ExecutorName, req.Replicas)
	/*executorConf := ex.GetExecutorConf()
	logger.Infof("aaaaaa1-executor[%v]", executorConf.PublicAddress)*/

	// 打开原始文件
	//filePath := "/home/chart/templates/executor/executor-node" + strconv.Itoa(req.ExecutorID) + ".yaml"
	filePath := fmt.Sprintf("/home/chart/templates/executor/%s.yaml", req.ExecutorName)
	// 1. 读取原始文件内容
	contentBytes, err := ioutil.ReadFile(filePath)
	if err != nil {
		logger.Error("无法读取文件 %s: %v", filePath, err)
	}

	lines := []string{} // 存放每一行内容的切片
	for _, line := range strings.Split(string(contentBytes), "\n") {
		if strings.Contains(line, "replicas") {
			lineTmp := []byte("  replicas: " + strconv.Itoa(req.Replicas))
			line = string(lineTmp)
		}
		lines = append(lines, line)
	}

	newContentString := ""
	for _, line := range lines {
		newContentString += line + "\n"
	}

	// 5. 将新的内容写入到原始文件中
	err = ioutil.WriteFile(filePath, []byte(newContentString), 0644)
	if err != nil {
		logger.Error("无法写入文件 %s: %v", filePath, err)
	}

	//动态生效配置文件
	if err := HelmUpgrade("dtx", "/home/chart", "dtxns"); err != nil {
		o.ServeJSONWithError(codeerror.NewError(ErrHelmUpgrade, err.Error()))
		return
	}

	o.Ret.Code = "0"
	o.Ret.Data = "ok"
}

type modifyDataownerNodeReq struct {
	DataownerName string `json:"dataownerName"`
	Replicas      int    `json:"replicas"`
}

func (o *OPController) ModifyDataownerNode() {
	var req modifyDataownerNodeReq
	if err := json.Unmarshal(o.Ctx.Input.RequestBody, &req); err != nil {
		o.ServeJSONWithError(codeerror.NewError(ErrUnmarshal, err.Error()))
		return
	}

	filePath := fmt.Sprintf("/home/chart/templates/xdb/%s.yaml", req.DataownerName)
	//filePath := "/data/dtx/templates/xdb/dataowner-node" + strconv.Itoa(req.DataownerID) + ".yaml"
	// 1. 读取原始文件内容
	contentBytes, err := ioutil.ReadFile(filePath)
	if err != nil {
		logger.Error("无法读取文件 %s: %v", filePath, err)
	}

	lines := []string{} // 存放每一行内容的切片
	for _, line := range strings.Split(string(contentBytes), "\n") {
		if strings.Contains(line, "replicas") {
			lineTmp := []byte("  replicas: " + strconv.Itoa(req.Replicas))
			line = string(lineTmp)
		}
		lines = append(lines, line)
	}

	newContentString := ""
	for _, line := range lines {
		newContentString += line + "\n"
	}

	// 5. 将新的内容写入到原始文件中
	err = ioutil.WriteFile(filePath, []byte(newContentString), 0644)
	if err != nil {
		logger.Error("无法写入文件 %s: %v", filePath, err)
	}

	//动态生效配置文件
	if err := HelmUpgrade("dtx", "/home/chart", "dtxns"); err != nil {
		o.ServeJSONWithError(codeerror.NewError(ErrHelmUpgrade, err.Error()))
		return
	}

	o.Ret.Code = "0"
	o.Ret.Data = "ok"
}

type modifyStorageNodeReq struct {
	StorageName string `json:"storageName"`
	Replicas    int    `json:"replicas"`
}

func (o *OPController) ModifyStorageNode() {
	var req modifyStorageNodeReq
	if err := json.Unmarshal(o.Ctx.Input.RequestBody, &req); err != nil {
		o.ServeJSONWithError(codeerror.NewError(ErrUnmarshal, err.Error()))
		return
	}

	filePath := fmt.Sprintf("/home/chart/templates/xdb/%s.yaml", req.StorageName)
	// 1. 读取原始文件内容
	contentBytes, err := ioutil.ReadFile(filePath)
	if err != nil {
		logger.Error("无法读取文件 %s: %v", filePath, err)
	}

	lines := []string{} // 存放每一行内容的切片
	for _, line := range strings.Split(string(contentBytes), "\n") {
		if strings.Contains(line, "replicas") {
			lineTmp := []byte("  replicas: " + strconv.Itoa(req.Replicas))
			line = string(lineTmp)
		}
		lines = append(lines, line)
	}

	newContentString := ""
	for _, line := range lines {
		newContentString += line + "\n"
	}

	// 5. 将新的内容写入到原始文件中
	err = ioutil.WriteFile(filePath, []byte(newContentString), 0644)
	if err != nil {
		logger.Error("无法写入文件 %s: %v", filePath, err)
	}

	//动态生效配置文件
	if err := HelmUpgrade("dtx", "/home/chart", "dtxns"); err != nil {
		o.ServeJSONWithError(codeerror.NewError(ErrHelmUpgrade, err.Error()))
		return
	}

	o.Ret.Code = "0"
	o.Ret.Data = "ok"
}

type deleteExecutorNode struct {
	ExecutorName string `json:"executorName"`
}

func (o *OPController) DeleteExecutorNode() {
	var req deleteExecutorNode
	if err := json.Unmarshal(o.Ctx.Input.RequestBody, &req); err != nil {
		o.ServeJSONWithError(codeerror.NewError(ErrUnmarshal, err.Error()))
		return
	}

	file := fmt.Sprintf("/home/chart/templates/executor/%s.yaml", req.ExecutorName)
	if err := o.DeleteNodeFile(file); err != nil {
		o.ServeJSONWithError(codeerror.NewError(ErrDeleteNodeFile, err.Error()))
		return
	}

	//动态生效配置文件
	if err := HelmUpgrade("dtx", "/home/chart", "dtxns"); err != nil {
		o.ServeJSONWithError(codeerror.NewError(ErrDeleteNodeFile, err.Error()))
		return
	}

	o.Ret.Code = "0"
	o.Ret.Data = "ok"
}

type deleteDataownerNode struct {
	DataownerName string `json:"dataownerName"`
}

func (o *OPController) DeleteDataownerNode() {
	var req deleteDataownerNode
	if err := json.Unmarshal(o.Ctx.Input.RequestBody, &req); err != nil {
		o.ServeJSONWithError(codeerror.NewError(ErrUnmarshal, err.Error()))
		return
	}

	file := fmt.Sprintf("/home/chart/templates/xdb/%s.yaml", req.DataownerName)
	if err := o.DeleteNodeFile(file); err != nil {
		o.ServeJSONWithError(codeerror.NewError(ErrDeleteNodeFile, err.Error()))
		return
	}

	//动态生效配置文件
	if err := HelmUpgrade("dtx", "/home/chart", "dtxns"); err != nil {
		o.ServeJSONWithError(codeerror.NewError(ErrHelmUpgrade, err.Error()))
		return
	}

	o.Ret.Code = "0"
	o.Ret.Data = "ok"
}

type deleteStorageNodeReq struct {
	StorageName string `json:"storageName"`
}

func (o *OPController) DeleteStorageNode() {
	var req deleteStorageNodeReq
	if err := json.Unmarshal(o.Ctx.Input.RequestBody, &req); err != nil {
		o.ServeJSONWithError(codeerror.NewError(ErrUnmarshal, err.Error()))
		return
	}

	file := fmt.Sprintf("/home/chart/templates/xdb/%s.yaml", req.StorageName)
	if err := o.DeleteNodeFile(file); err != nil {
		o.ServeJSONWithError(codeerror.NewError(ErrDeleteNodeFile, err.Error()))
		return
	}
	//动态生效配置文件
	if err := HelmUpgrade("dtx", "/home/chart", "dtxns"); err != nil {
		o.ServeJSONWithError(codeerror.NewError(ErrHelmUpgrade, err.Error()))
		return
	}

	o.Ret.Code = "0"
	o.Ret.Data = "ok"
}

func HelmUpgrade(releaseName string, chartPath string, namespace string) error {

	cmdString := fmt.Sprintf("cd %s", chartPath)
	logger.Infof("aaaaaaq2[%v]", cmdString)
	cmd := exec.Command("bash", "-c", cmdString)
	output, err := cmd.CombinedOutput()
	if err != nil {
		logger.Error("%s\n%v", string(output), err)
		return err
	}
	logger.Infof("aaaaaaq2[%v]", cmdString)

	cmdString1 := fmt.Sprintf("/home/helm upgrade -n %s %s %s", namespace, releaseName, chartPath)
	logger.Infof("aaaaaaq[%v]", cmdString1)
	cmd1 := exec.Command("bash", "-c", cmdString1)
	output1, err1 := cmd1.CombinedOutput()
	if err != nil {
		logger.Error("%s\n%v", string(output1), err1)
		return err1
	}

	// 输出命令结果

	return nil
}

func (o *OPController) DeleteNodeFile(file string) error {
	cmdString := fmt.Sprintf("rm -f %s", file)
	cmd := exec.Command("bash", "-c", cmdString)
	output, err := cmd.CombinedOutput()
	if err != nil {
		logger.Error("%s\n%v", string(output), err)
		return err
	}

	//动态生效配置文件
	if err := HelmUpgrade("dtx", "/home/chart", "dtxns"); err != nil {
		o.ServeJSONWithError(codeerror.NewError(ErrDeleteNodeFile, err.Error()))
		return err
	}

	// 输出命令结果
	logger.Info(string(output))

	return nil
}
