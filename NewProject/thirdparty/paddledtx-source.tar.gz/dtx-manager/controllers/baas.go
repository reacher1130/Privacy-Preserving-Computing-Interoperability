// Package controllers 算法管理模块接口实现
package controllers

import (
	"baidu/blockchain/dtx-manager/handlers/baas"
	"baidu/blockchain/dtx-manager/pkg/logger"
)

type BaaSController struct {
	BaseController
}

type ResGetBaasToken struct {
	Token string `json:"token"`
}

// @Title 获取baas登录token
// @Description 获取baas登录token
// @router /baas/gettoken [get]
func (b *BaaSController) GetBaasToken() {
	handler := baas.NewHandler(b.RequestID)
	token, err := handler.GetBaasToken()
	if err != nil {
		logger.Error("RequestID: %s, get baas token failed, error: %s", b.RequestID, err.Error())
		b.ServeJSONWithError(err)
	}

	res := &ResGetBaasToken{
		Token: token,
	}
	b.ServeData(res)
}
