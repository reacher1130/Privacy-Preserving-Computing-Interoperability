// Package controllers 平台用户模块接口实现
package controllers

import (
	"encoding/base64"

	// ecies "github.com/ecies/go/v2"

	"github.com/xuperchain/xuper-sdk-go/crypto"

	"baidu/blockchain/dtx-manager/handlers/user"
	"baidu/blockchain/dtx-manager/pkg/codeerror"
	"baidu/blockchain/dtx-manager/pkg/logger"
)

type UserController struct {
	BaseController
}

// UserReq
type UserReq struct {
	Username    string `json:"username"`
	Password    string `json:"password,omitempty"`
	NewPassword string `json:"newpwd,omitempty"`
	PubKey      string `json:"pubkey,omitempty"`
}

// UserInfoResp
type UserInfoResp struct {
	user.UserInfo
	user.OrgInfo
}

// @Title
// @Description 用户账户密码登录
// @router /login [post]
func (u *UserController) Login() {
	var req UserReq
	u.bindAndCheck(&req)

	if req.PubKey != "" {
		_, err := crypto.GetCryptoClient().GetEcdsaPublicKeyFromJsonStr(req.PubKey)
		if err != nil {
			logger.Error("RequestId: %s, req pubkey is invalid, error: %s", u.RequestID, err.Error())
			u.ServeJSONWithError(err)
		}
	}

	handler := user.NewHandler(u.RequestID)
	user, err := handler.GetUserWithPwd(req.Username, req.Password)
	if err != nil {
		logger.Error("RequestID: %s, get user failed, error: %s", u.RequestID, err.Error())
		u.ServeJSONWithError(err)
	}
	user.PrivateKey = u.ConvertPriKeyToJS(user.PrivateKey)

	// 返回用户区块链账户加密
	if req.PubKey != "" {
		pubKeyGo := u.ConvertJSPubKeyToGo(req.PubKey)
		cli := crypto.GetCryptoClient()
		pubKey, _ := cli.GetEcdsaPublicKeyFromJsonStr(pubKeyGo)

		// encryptMnemonic, _ := ecies.Encrypt(pubKey, []byte(user.Mnemonic))
		// encryptPriKey, _ := ecies.Encrypt(pubKey, []byte(u.ConvertPriKeyToJS(user.PrivateKey)))
		encryptMnemonic, _ := cli.EncryptByEcdsaKey(pubKey, []byte(user.Mnemonic))
		encryptPriKey, _ := cli.EncryptByEcdsaKey(pubKey, []byte(u.ConvertPriKeyToJS(user.PrivateKey)))
		user.Mnemonic = base64.StdEncoding.EncodeToString(encryptMnemonic)
		user.PrivateKey = base64.StdEncoding.EncodeToString(encryptPriKey)
	} else {
		cli := crypto.GetCryptoClient()
		encryptPriKey, _ := cli.EncryptByAESKey(user.PrivateKey, req.Password)
		user.PrivateKey = base64.StdEncoding.EncodeToString([]byte(encryptPriKey))

		encryptMnemonic, _ := cli.EncryptByAESKey(user.Mnemonic, req.Password)
		user.Mnemonic = base64.StdEncoding.EncodeToString([]byte(encryptMnemonic))
	}

	u.ServeData(user)
}

// @Title
// @Description 用户账户密码注册
// @router /register [post]
func (u *UserController) Register() {
	var req UserReq
	u.bindAndCheck(&req)

	if req.PubKey != "" {
		req.PubKey = u.ConvertJSPubKeyToGo(req.PubKey)
		_, err := crypto.GetCryptoClient().GetEcdsaPublicKeyFromJsonStr(req.PubKey)
		if err != nil {
			logger.Error("RequestId: %s, req pubkey is invalid, error: %s", u.RequestID, err.Error())
			u.ServeJSONWithError(err)
		}
	}

	handler := user.NewHandler(u.RequestID)
	user, err := handler.CreateUser(req.Username, req.Password)
	if err != nil {
		logger.Error("RequestID: %s, create user failed, error: %s", u.RequestID, err.Error())
		u.ServeJSONWithError(err)
	}
	user.PrivateKey = u.ConvertPriKeyToJS(user.PrivateKey)

	// 返回用户区块链账户加密
	if req.PubKey != "" {
		cli := crypto.GetCryptoClient()
		pubKey, _ := cli.GetEcdsaPublicKeyFromJsonStr(req.PubKey)

		encryptMnemonic, _ := cli.EncryptByEcdsaKey(pubKey, []byte(user.Mnemonic))
		encryptPriKey, _ := cli.EncryptByEcdsaKey(pubKey, []byte(u.ConvertPriKeyToJS(user.PrivateKey)))
		// encryptMnemonic, _ := ecies.Encrypt(pubKey, []byte(user.Mnemonic))
		// encryptPriKey, _ := ecies.Encrypt(pubKey, []byte(u.ConvertPriKeyToJS(user.PrivateKey)))
		user.Mnemonic = base64.StdEncoding.EncodeToString(encryptMnemonic)
		user.PrivateKey = base64.StdEncoding.EncodeToString(encryptPriKey)
	} else {
		cli := crypto.GetCryptoClient()
		encryptPriKey, _ := cli.EncryptByAESKey(user.PrivateKey, req.Password)
		user.PrivateKey = base64.StdEncoding.EncodeToString([]byte(encryptPriKey))

		encryptMnemonic, _ := cli.EncryptByAESKey(user.Mnemonic, req.Password)
		user.Mnemonic = base64.StdEncoding.EncodeToString([]byte(encryptMnemonic))
	}
	u.ServeData(user)
}

// @Title
// @Description 管理员清空密码
// @router /clearpwd [post]
func (u *UserController) ClearPwd() {
	var req UserReq
	u.bindAndCheck(&req)

	//校验当前账户是admin
	// middlewares.Auth()
	// address := u.Ctx.Request.Header.Get("X-User-Address")
	// if address != models.GetMyBaaS().Address {
	// 	err := codeerror.NewError(user.ErrNotAdmin, "user is not admin")
	// 	logger.Error("RequestId: %s, clear user's password failed, error: %s", u.RequestID, err.Error())
	// 	u.ServeJsonWithError(err)
	// }

	handler := user.NewHandler(u.RequestID)
	_, err := handler.ClearUserPwd(req.Username)
	if err != nil {
		logger.Error("RequestID: %s, clear user's password failed, error: %s", u.RequestID, err.Error())
		u.ServeJSONWithError(err)
	}

	var s struct{}
	u.ServeData(s)
}

// @Title
// @Description 用户修改密码
// @router /resetpwd [post]
func (u *UserController) ResetPwd() {
	var req UserReq
	u.bindAndCheck(&req)

	handler := user.NewHandler(u.RequestID)
	_, err := handler.ResetUserPwd(req.Username, req.Password, req.NewPassword)
	if err != nil {
		logger.Error("RequestID: %s, reset user's password failed, error: %s", u.RequestID, err.Error())
		u.ServeJSONWithError(err)
	}

	var s struct{}
	u.ServeData(s)
}

// @Title
// @Description 用户信息
// @router /info [get]
func (u *UserController) GetInfo() {
	// 确认是登陆状态
	if u.UserAddress == "" {
		u.ServeJSONWithError(codeerror.NewErrorByCode(codeerror.ErrParam, "X-User-Pubkey"))
	}

	handler := user.NewHandler(u.RequestID)
	user, err := handler.GetUserInfo(u.UserAddress)
	if err != nil {
		u.ServeJSONWithError(codeerror.NewErrorByCode(codeerror.ErrUserNotExisted))
	}
	orgInfo := handler.GetOrgInfo()

	// 返回用户区块链账户加密
	cli := crypto.GetCryptoClient()
	pubKey, _ := cli.GetEcdsaPublicKeyFromJsonStr(u.UserPubkey)
	// encryptMnemonic, _ := ecies.Encrypt(pubKey, []byte(user.Mnemonic))
	// encryptPriKey, _ := ecies.Encrypt(pubKey, []byte(u.ConvertPriKeyToJS(user.PrivateKey)))
	encryptMnemonic, _ := cli.EncryptByEcdsaKey(pubKey, []byte(user.Mnemonic))
	encryptPriKey, _ := cli.EncryptByEcdsaKey(pubKey, []byte(u.ConvertPriKeyToJS(user.PrivateKey)))
	user.Mnemonic = base64.StdEncoding.EncodeToString(encryptMnemonic)
	user.PrivateKey = base64.StdEncoding.EncodeToString(encryptPriKey)

	ret := &UserInfoResp{
		OrgInfo:  *orgInfo,
		UserInfo: *user,
	}
	u.ServeData(ret)

}
