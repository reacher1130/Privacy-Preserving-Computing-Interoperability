package controllers

import (
	"encoding/json"
	"io/ioutil"
	"math/big"
	"mime"
	"strconv"
	"strings"

	"github.com/beego/beego/v2/core/validation"
	beego "github.com/beego/beego/v2/server/web"
	"github.com/xuperchain/crypto/client/service/xchain"

	"baidu/blockchain/dtx-manager/models"
	"baidu/blockchain/dtx-manager/pkg/auth"
	"baidu/blockchain/dtx-manager/pkg/codeerror"
	"baidu/blockchain/dtx-manager/pkg/logger"
	"baidu/blockchain/dtx-manager/pkg/uuid"
)

const PathPrefix = "/dtx/v1/"
const ExpireSecond = 6000000 // 接口时间戳过期时间, 为了debug方便暂时设大, 上线前修改

const (
	ErrorCode           = 400
	ForbiddenCode       = 403
	SuccessCode         = 200
	InternalServerError = 500

	RequestIDHeader  = "X-Request-Id"
	UserPubkeyHeader = "X-User-Pubkey"
	UserAgentHeader  = "User-Agent"
	Authorization    = "Authorization"
)

var (
	ErrInternalServer    = "InternalServerError"
	ErrInvalidHeader     = "InvalidHeaderError"
	ErrInvalidRequest    = "InvalidRequestError"
	ErrUnmarshal         = "UnmarshalError"
	ErrPermissionDeny    = "PermissionDenyError"
	ErrEmptyParameter    = "EmptyParameterError"
	ErrInvalidParameter  = "InvalidParameterError"
	ErrThirdServerFailed = "ThirdServerFailedError"
	ErrNotPassPortLogin  = "PassNotLoginError"
	ErrHelmUpgrade       = "HelmUpgradeFail"
	ErrDeleteNodeFile    = "DeleteNodeFileFail"
)

type NestPreparer interface {
	NestPrepare()
}

type ControllerRet struct {
	Code    string      `json:"code,omitempty"` // 语义返回码
	Message string      `json:"msg,omitempty"`  // 错误信息，否则 “ok”
	Data    interface{} `json:"data"`           // get结果数据，默认为空
}

type BaseController struct {
	beego.Controller

	RequestID   string // uuid v4,eg:dd030b9f-6cd1-4de7-8270-18a9089b9cd6
	UserAddress string // blockchain address,eg:nDpbnn3ayaBw1sR3jdGU5MpPnKcbppF6r
	UserPubkey  string // public key
	Host        string

	Ret *ControllerRet // response body
}

type PubKey struct {
	Curvname string `json:"Curvname"`
	X        string `json:"X"`
	Y        string `json:"Y"`
}

type PriKey struct {
	PubKey
	D string `json:"D"`
}

// Prepare runs before request function execution.
func (c *BaseController) Prepare() {
	// set requestId,new requestId if empty and set response header
	c.RequestID = c.getRequestID()

	logger.Infof("Request: %v", c.Ctx.Request)

	// prepare response
	c.Ret = &ControllerRet{
		Code:    "0",
		Message: "success",
		Data:    struct{}{},
	}

	// set userPubkey
	c.UserPubkey = c.getUserPubkey()

	// set userAddress
	xcc := new(xchain.XchainCryptoClient)
	pubKey, err := xcc.GetEcdsaPublicKeyFromJsonStr(c.UserPubkey)
	if err == nil {
		address, _ := xcc.GetAddressFromPublicKey(pubKey)
		c.UserAddress = address
		// 有address的用户 必须要校验签名正确性 下载相关接口暂不验证
		if !strings.Contains(c.Ctx.Request.URL.Path, "download") {
			if err := c.CheckSign(); err != nil {
				c.ServeJSONWithError(err)
			}
		}
	}

	// 返回设置
	c.Ctx.Output.Header(RequestIDHeader, c.RequestID) // 设置返回requestID 用于请求链路追踪
	c.Ctx.Output.SetStatus(SuccessCode)               // 返回的状态码统一用200，应用内部的错误在返回参数code中显示

	// 权限校验
	if !strings.Contains(c.Ctx.Request.URL.Path, "download") {
		if err := c.CheckAuthority(); err != nil {
			c.ServeJSONWithError(err)
		}
	}

	// call custom controller NestPreparer if current is not BaseController
	if app, ok := c.AppController.(NestPreparer); ok {
		app.NestPrepare()
	}
}

func (c *BaseController) CheckAuthority() error {

	// 查询接口需要的权限
	path := strings.TrimPrefix(c.Ctx.Request.URL.Path, PathPrefix)
	needAuth := models.GetAuthByPath(path)
	// 不需要权限
	if needAuth == "" {
		return nil
	}

	// 需要权限的接口也都需要登陆验签
	if c.UserAddress == "" {
		return codeerror.NewErrorByCode(codeerror.ErrSign)
	}

	pathParams := strings.Split(path, "/")
	authPrefix := pathParams[0]
	// 部分路由与标识字段不匹配
	if authPrefix == "model" {
		authPrefix = "service"
	}
	if authPrefix == "algo" {
		authPrefix = "algorithm"
	}

	// 查询用户拥有的权限
	user, err := models.QueryUserByAddress(c.UserAddress)
	if err != nil {
		return codeerror.NewErrorByCode(codeerror.ErrUserNotExisted)
	}
	role, err := models.QueryRole(user.RoleName)
	if err != nil {
		return codeerror.NewErrorByCode(codeerror.ErrRoleNotExisted)
	}
	var authority map[string]string
	json.Unmarshal([]byte(role.Authority), &authority)

	// 判断权限
	// 拥有的权限小于需要的权限; 将来权限升级判断条件再变更
	needAuthInt, _ := strconv.Atoi(needAuth)
	authHaveInt, _ := strconv.Atoi(authority[authPrefix])
	if authHaveInt-needAuthInt < 0 {
		return codeerror.NewErrorByCode(codeerror.ErrNoAuthority)
	}
	return nil
}

func (c *BaseController) CheckSign() error {
	// check sign
	xcc := new(xchain.XchainCryptoClient)
	pubKey, _ := xcc.GetEcdsaPublicKeyFromJsonStr(c.UserPubkey)
	authorization := c.Ctx.Request.Header.Get(Authorization)

	if c.Ctx.Request.Method == "POST" {
		ct, _, _ := mime.ParseMediaType(c.Ctx.Request.Header.Get("Content-Type"))
		switch ct {
		case "multipart/form-data":
			message := auth.GeneratePostFormBody(c.Ctx.Request)
			err := auth.VerifyAuthorization(pubKey, string(message), authorization, ExpireSecond)
			if err != nil {
				logger.Debugf("sign message: $%s$", message)
				return codeerror.NewErrorByCode(codeerror.ErrSign)
			}
		case "application/json":
			message, _ := ioutil.ReadAll(c.Ctx.Request.Body)
			err := auth.VerifyAuthorization(pubKey, string(message), authorization, ExpireSecond)
			if err != nil {
				logger.Debugf("sign message: $%s$", message)
				return codeerror.NewErrorByCode(codeerror.ErrSign)
			}
		default:
			return codeerror.NewError(codeerror.ErrSign, "unsupported content type")
		}
	} else if c.Ctx.Request.Method == "GET" {
		message := auth.GenerateGetRequestBody(c.Ctx.Request)
		err := auth.VerifyAuthorization(pubKey, string(message), authorization, ExpireSecond)
		if err != nil {
			logger.Debugf("sign message: $%s$", message)
			return codeerror.NewErrorByCode(codeerror.ErrSign)
		}
	}
	return nil
}

func (c *BaseController) getRequestID() string {
	requestID := c.Ctx.Request.Header.Get(RequestIDHeader)
	if !uuid.ValidUUID(requestID) {
		requestID = uuid.GenUUID()
	}
	return requestID
}

func (c *BaseController) getUserPubkey() string {
	pub := c.Ctx.Request.Header.Get(UserPubkeyHeader)
	return c.ConvertJSPubKeyToGo(pub)
}

func (c *BaseController) ConvertPubKeyToJS(pubkey string) string {
	if pubkey == "" {
		return ""
	}

	var pub struct {
		Cuvname string   `json:"Curvname"`
		X       *big.Int `json:"X"`
		Y       *big.Int `json:"Y"`
	}
	err := json.Unmarshal([]byte(pubkey), &pub)
	if err != nil {
		return ""
	}

	pubKeyJS := &PubKey{
		Curvname: pub.Cuvname,
		X:        pub.X.String(),
		Y:        pub.Y.String(),
	}
	ret, _ := json.Marshal(pubKeyJS)
	return string(ret)
}

func (c *BaseController) ConvertJSPubKeyToGo(pubkey string) string {
	if pubkey == "" {
		return ""
	}

	var pub PubKey
	err := json.Unmarshal([]byte(pubkey), &pub)
	if err != nil {
		return ""
	}
	x, _ := big.NewInt(0).SetString(pub.X, 10)
	y, _ := big.NewInt(0).SetString(pub.Y, 10)
	pubKeyGo := struct {
		Cuvname string   `json:"Curvname"`
		X       *big.Int `json:"X"`
		Y       *big.Int `json:"Y"`
	}{
		Cuvname: pub.Curvname,
		X:       x,
		Y:       y,
	}
	ret, _ := json.Marshal(pubKeyGo)
	return string(ret)
}

func (c *BaseController) ConvertPriKeyToJS(prikey string) string {
	if prikey == "" {
		return ""
	}

	var pri struct {
		Cuvname string   `json:"Curvname"`
		X       *big.Int `json:"X"`
		Y       *big.Int `json:"Y"`
		D       *big.Int `json:"D"`
	}
	err := json.Unmarshal([]byte(prikey), &pri)
	if err != nil {
		return ""
	}

	// pri.Curve.Params().Name = string(pri.Curve.Params().Name)
	priKeyJS := &PriKey{
		PubKey: PubKey{
			Curvname: pri.Cuvname,
			X:        pri.X.String(),
			Y:        pri.Y.String(),
		},
		D: pri.D.String(),
	}
	ret, _ := json.Marshal(priKeyJS)
	return string(ret)
}

// bindAndCheck bind RequestBody with request and check request.
func (c *BaseController) bindAndCheck(request interface{}) {
	if err := json.Unmarshal(c.Ctx.Input.RequestBody, request); err != nil {
		c.ServeJSONWithError(codeerror.NewError(ErrUnmarshal, err.Error()))
		return
	}

	validator := validation.Validation{}
	b, err := validator.Valid(request)
	if err != nil {
		c.ServeJSONWithError(codeerror.NewError(ErrInvalidRequest, err.Error()))
		return
	}

	if !b {
		c.ServeJSONWithError(codeerror.NewError(ErrInvalidRequest, "ValidRequest fail"))
		return
	}
}

// MustString must return param not empty, or break conn with ErrInvalidRequestFieldError
func (c *BaseController) MustString(key string) string {
	value := c.GetString(key)
	if len(value) == 0 {
		c.ServeJSONWithError(codeerror.NewError(ErrInvalidRequest, key+" is empty"))
	}
	return value
}

// MustInt must return param not empty, or break conn with ErrInvalidRequestFieldError
func (c *BaseController) MustInt(key string) int {
	value, err := c.GetInt(key)
	if err != nil {
		c.ServeJSONWithError(codeerror.NewError(ErrInvalidRequest, key+" is not int type"))
	}
	return value
}

// MustInt64 must return param not empty, or break conn with ErrInvalidRequestFieldError
func (c *BaseController) MustInt64(key string) int64 {
	value, err := c.GetInt64(key)
	if err != nil {
		logger.Error("MustInt64 error=", err)
		c.ServeJSONWithError(codeerror.NewError(ErrInvalidRequest, key+" is not int64 type"))
	}
	return value
}

func (c *BaseController) GetIntPointer(key string, def ...*int) (*int, error) {
	valueStr := c.Ctx.Input.Query(key)
	if len(valueStr) == 0 && len(def) > 0 {
		return def[0], nil
	}

	valueInt, err := strconv.Atoi(valueStr)
	if err != nil {
		return nil, err
	}

	return &valueInt, nil
}

// Finish runs after request function execution
func (c *BaseController) Finish() {
	c.Data["json"] = c.Ret
	retStr, _ := json.Marshal(c.Ret)
	logger.Debug("Response:", string(retStr), "RetCode:", c.Ctx.Output.Status)
	c.ServeJSON()
}

// ServeData sends a json response
func (c *BaseController) ServeData(data interface{}) {
	c.Ret.Data = data
}

// ServeJsonWithError sends a json response with error
func (c *BaseController) ServeJSONWithError(err error) {
	codeErr := codeerror.Decode(err)
	c.Ret.Code = codeErr.Code
	c.Ret.Message = codeErr.Message
	c.Data["json"] = c.Ret
	retStr, _ := json.Marshal(c.Ret)
	logger.Debug("Response:", string(retStr), "RetCode:", c.Ctx.Output.Status)
	c.ServeJSON()
	// abort
	c.StopRun()
}

// ServeDownloadFile provides file download
func (c *BaseController) ServeDownloadFile(filename string, data []byte) {

	// 设置响应头
	c.Ctx.ResponseWriter.Header().Set("Content-Disposition", "attachment; filename="+filename)
	c.Ctx.ResponseWriter.Header().Set("Content-Type", "application/octet-stream")
	// 返回文件数据
	c.Ctx.ResponseWriter.Write(data)
	// abort
	c.StopRun()
}
