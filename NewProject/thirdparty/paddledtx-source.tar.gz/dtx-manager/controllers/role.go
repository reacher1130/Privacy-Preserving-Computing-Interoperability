// Package controllers 平台用户模块接口实现
package controllers

import (
	"baidu/blockchain/dtx-manager/handlers/user"
	"baidu/blockchain/dtx-manager/pkg/codeerror"
)

type RoleController struct {
	BaseController
}

// RoleReq
type RoleReq struct {
	Username  string `json:"username,omitempty"`
	Rolename  string `json:"rolename,omitempty"`
	Authority string `json:"authority,omitempty"`
}

// @Title
// @Description
// @router role/create [post]
func (c *RoleController) Create() {
	var req RoleReq
	c.bindAndCheck(&req)
	if len(req.Rolename) == 0 || len(req.Rolename) > 20 {
		c.ServeJSONWithError(codeerror.NewErrorByCode(codeerror.ErrLengthInvalid, "should be length of 1-20"))
	}

	h := user.NewHandler(c.RequestID)
	err := h.CreateRole(req.Rolename, req.Authority, c.UserAddress)
	if err != nil {
		c.ServeJSONWithError(err)
		return
	}
}

// @Title
// @Description
// @router role/get [get]
func (c *RoleController) Query() {
	roleName := c.GetString("rolename", "")
	if roleName == "" {
		c.ServeJSONWithError(codeerror.NewErrorByCode(codeerror.ErrParam, "rolename"))
	}

	h := user.NewHandler(c.RequestID)
	data, err := h.QueryRole(roleName)
	if err != nil {
		c.ServeJSONWithError(err)
		return
	}
	c.ServeData(data)
}

// @Title
// @Description
// @router role/delete [get]
func (c *RoleController) Delete() {
	roleName := c.GetString("rolename", "")
	if roleName == "" {
		c.ServeJSONWithError(codeerror.NewErrorByCode(codeerror.ErrParam, "rolename"))
	}

	h := user.NewHandler(c.RequestID)
	_, err := h.DeleteRole(roleName)
	if err != nil {
		c.ServeJSONWithError(err)
		return
	}

	var res struct{}
	c.ServeData(res)
}

// @Title
// @Description
// @router bind/list [get]
func (c *RoleController) BindList() {
	h := user.NewHandler(c.RequestID)
	data, err := h.BindList()
	if err != nil {
		c.ServeJSONWithError(err)
		return
	}
	c.ServeData(data)
}

// @Title
// @Description
// @router role/modify [post]
func (c *RoleController) Modify() {
	var req RoleReq
	c.bindAndCheck(&req)

	h := user.NewHandler(c.RequestID)
	err := h.ModifyRole(req.Rolename, req.Authority, c.UserAddress)
	if err != nil {
		c.ServeJSONWithError(err)
		return
	}
}

// @Title
// @Description 列表展示全部角色
// @router role/list [get]
func (c *RoleController) List() {
	h := user.NewHandler(c.RequestID)
	ret, err := h.ListRoles()
	if err != nil {
		c.ServeJSONWithError(err)
		return
	}
	c.ServeData(ret)
}

// @Title
// @Description 用户绑定角色
// @router role/bind [post]
func (c *RoleController) Bind() {
	var req RoleReq
	c.bindAndCheck(&req)

	h := user.NewHandler(c.RequestID)
	err := h.Bind(req.Username, req.Rolename)
	if err != nil {
		c.ServeJSONWithError(err)
	}
}
