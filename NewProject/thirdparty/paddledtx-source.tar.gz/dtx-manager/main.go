package main

import (
	bc "baidu/blockchain/dtx-manager/blockchain"
	"baidu/blockchain/dtx-manager/config"
	"baidu/blockchain/dtx-manager/models"
	"baidu/blockchain/dtx-manager/pkg/blockchain"
	"baidu/blockchain/dtx-manager/pkg/cache"
	"baidu/blockchain/dtx-manager/pkg/logger"
	_ "baidu/blockchain/dtx-manager/routers"
	"strings"

	"github.com/PaddlePaddle/PaddleDTX/crypto/core/ecdsa"
	util "github.com/PaddlePaddle/PaddleDTX/xdb/pkgs/strings"
	beego "github.com/beego/beego/v2/server/web"
	_ "github.com/go-sql-driver/mysql"
	"github.com/xuperchain/crypto/core/hash"
)

func init() {
	logger.InitLogger()
	models.InitDB()
	config.InitBlockchainConfig()
	registerOrg()
	// 部分链上数据获取很慢, 提前加载到缓存并周期性更新
	cache.InitCacheData()
}

func registerOrg() {
	cli, err := blockchain.GetBlockchainClient()
	if err != nil {
		panic(err)
	}
	orgInfo, _ := beego.AppConfig.GetSection("orginfo")

	org, err := cli.QueryOrgInfo(orgInfo["id"])
	if org != nil {
		return
	} else if !strings.Contains(err.Error(), "not found") {
		panic(err)
	}
	pubKey, err := ecdsa.DecodePublicKeyFromString(config.GetPublicKey())
	if err != nil {
		panic(err)
	}
	priKey, err := ecdsa.DecodePrivateKeyFromString(config.GetPrivateKey())
	if err != nil {
		panic(err)
	}
	org = &bc.OrgInfo{
		ID:     orgInfo["id"],
		Name:   orgInfo["name"],
		DID:    orgInfo["did"],
		Pubkey: pubKey[:],
	}
	str, err := util.GetSigMessage(org)
	if err != nil {
		panic(err)
	}
	sign, err := ecdsa.Sign(priKey, hash.HashUsingSha256([]byte(str)))
	if err != nil {
		panic(err)
	}
	org.Signature = sign[:]
	err = cli.SetOrgInfo(org)
	if err != nil {
		panic(err)
	}
}

func main() {
	beego.Run()
}
