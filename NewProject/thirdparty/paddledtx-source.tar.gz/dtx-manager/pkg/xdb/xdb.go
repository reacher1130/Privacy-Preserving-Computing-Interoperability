package xdb

import (
	"baidu/blockchain/dtx-manager/pkg/httpclient"
	"context"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"os"
	"strings"
	"time"

	xdb_bc "github.com/PaddlePaddle/PaddleDTX/xdb/blockchain"
	xdb_cli "github.com/PaddlePaddle/PaddleDTX/xdb/client/http"
)

type XDBConfig struct {
	Name       string
	Host       string
	NodeID     string
	PrivateKey string
	NameSpace  string
}

type XDBClient struct {
	// engine.Blockchain
	XDBHost    string
	Owner      string
	PrivateKey string
}

var xdbClient *XDBClient

const ConnectTimeoutMSec = 5000
const ReadTimeoutMSec = 30000

// GetBlockchainClient get blockchain client
func GetXDBClient(conf *XDBConfig) *XDBClient {
	// 实例为空，重新初始化客户端
	if xdbClient != nil {
		return xdbClient
	}
	return &XDBClient{
		XDBHost:    conf.Host,
		Owner:      conf.NodeID,
		PrivateKey: conf.PrivateKey,
	}
}

// StorageNodeList 存储节点列表
func (x *XDBClient) StorageNodeList() ([]xdb_bc.Node, error) {
	url := fmt.Sprintf("http://%s/v1/node/list", x.XDBHost)

	resp, err := httpclient.Get(url, nil, ConnectTimeoutMSec, ReadTimeoutMSec)
	if err != nil {
		return nil, err
	}
	var ret struct {
		Code string        `json:"code"`
		Msg  string        `json:"message"`
		Data []xdb_bc.Node `json:"data"`
	}
	err = json.Unmarshal(resp.Body, &ret)
	if ret.Code != "0" {
		return ret.Data, fmt.Errorf("xdb get node list error, code: %s, msg: %s", ret.Code, ret.Msg)
	}
	return ret.Data, nil
}

// SysHealth xdb概览
func (x *XDBClient) SysHealth() (*xdb_bc.FileSysHealth, error) {
	url := fmt.Sprintf("http://%s/v1/file/getsyshealth", x.XDBHost)

	resp, err := httpclient.Get(url, nil, ConnectTimeoutMSec, ReadTimeoutMSec)
	if err != nil {
		return nil, err
	}
	var ret struct {
		Code string                `json:"code"`
		Msg  string                `json:"message"`
		Data *xdb_bc.FileSysHealth `json:"data"`
	}
	err = json.Unmarshal(resp.Body, &ret)
	if err != nil {
		return nil, err
	}
	if ret.Code != "0" {
		return ret.Data, fmt.Errorf("xdb get syshealth error, code: %s, msg: %s", ret.Code, ret.Msg)
	}
	return ret.Data, nil
}

// WriteFile 将文件上传到xdb
func (x *XDBClient) WriteFile(ns, fileName, fileVersion, filePath string, expireNanoTime int64, desc, ext string) (string, error) {
	opt := xdb_cli.WriteOptions{
		PrivateKey:  x.PrivateKey,
		Namespace:   ns,
		FileName:    combineNameAndVersion(fileName, fileVersion),
		ExpireTime:  expireNanoTime,
		Description: desc,
		Extra:       ext,
	}

	f, err := os.OpenFile(filePath, os.O_RDONLY, 0600)
	if err != nil {
		return "", err
	}
	defer f.Close()

	client, err := xdb_cli.New("http://" + x.XDBHost)
	if err != nil {
		return "", err
	}
	resp, err := client.Write(context.Background(), f, opt)
	if err != nil {
		return "", err
	}
	return resp.FileID, nil
}

// ReadFileByID 将文件从xdb读出
func (x *XDBClient) ReadFileByID(fileID string) ([]byte, error) {
	opt := xdb_cli.ReadOptions{
		PrivateKey: x.PrivateKey,
		FileID:     fileID,
	}

	client, err := xdb_cli.New("http://" + x.XDBHost)
	if err != nil {
		return nil, err
	}
	reader, err := client.Read(context.Background(), opt)
	if err != nil {
		return nil, err
	}
	defer reader.Close()

	res, err := ioutil.ReadAll(reader)
	if err != nil {
		return nil, err
	}
	return res, nil
}

// UpdateFile 更新文件
func (x *XDBClient) UpdateFile(fileID, filePath string, expireNanoTime int64, desc, ext string) (string, error) {
	opt := xdb_cli.UpdateOptions{
		PrivateKey:  x.PrivateKey,
		FileID:      fileID,
		ExpireTime:  expireNanoTime,
		Description: desc,
		Extra:       ext,
	}
	f, err := os.OpenFile(filePath, os.O_RDONLY, 0600)
	if err != nil {
		return "", err
	}
	defer f.Close()

	client, err := xdb_cli.New("http://" + x.XDBHost)
	if err != nil {
		return "", err
	}

	resp, err := client.Update(context.Background(), f, opt)
	if err != nil {
		return "", err
	}
	return resp.FileID, nil
}

// Delete
func (x *XDBClient) Delete(fileID string) error {
	client, err := xdb_cli.New("http://" + x.XDBHost)
	if err != nil {
		return err
	}
	err = client.UpdateExpTimeByID(context.Background(), fileID, x.PrivateKey, time.Now().UnixNano())
	return err
}

func combineNameAndVersion(fileName, fileVersion string) string {
	return fileName + ":" + fileVersion
}

func seperateName(name string) (fileName, fileVesion string) {
	strs := strings.Split(name, ":")
	if len(strs) == 2 {
		return strs[0], strs[1]
	} else {
		return strs[0], ""
	}
}
