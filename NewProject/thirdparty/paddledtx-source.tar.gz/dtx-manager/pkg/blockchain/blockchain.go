// Package blockchain 区块链交互相关包
package blockchain

import (
	"baidu/blockchain/dtx-manager/blockchain"
	"baidu/blockchain/dtx-manager/blockchain/fabric"
	"baidu/blockchain/dtx-manager/blockchain/xchain"
	"baidu/blockchain/dtx-manager/config"
)

type Blockchain interface {
	// 目录链资源空间及文件资源管理接口
	AddCatalogNamespace(opt *blockchain.AddCatalogNsOptions) error
	ListCatalogNs(opt *blockchain.ListCatalogNsOptions) (blockchain.CatalogNsList, error)
	PublishFileToCatalog(opt *blockchain.PublishFileToCatalogOptions) (string, error)
	ListCatalogFiles(opt *blockchain.ListCatalogFilesOptions) (blockchain.CatalogFileList, error)
	GetCatalogFileDetailByFileName(dataType, namespace, name string) (blockchain.CatalogFile, error)
	GetCatalogFileDetailByID(id string) (blockchain.CatalogFile, error)
	OfflineCatalogFile(opt *blockchain.OfflineCatalogFileOpt) error
	OnlineCatalogFile(opt *blockchain.OnlineCatalogFileOpt) error
	UpdateCatalogFileByID(opt *blockchain.UpdateCatalogFileOptions) error

	// 目录链下资源文件权限接口
	PublishCatalogFileAuth(opt *blockchain.PublishCatalogFileAuthOptions) error
	ConfirmCatalogFileAuth(opt *blockchain.ConfirmCatalogFileAuthOptions) error
	RejectCatalogFileAuth(opt *blockchain.RejectCatalogFileAuthOptions) error
	RecycleCatalogFileAuth(opt *blockchain.RecycleCatalogFileAuthOptions) error
	ListCatalogFileAuth(opt *blockchain.ListCatalogFileAuthOptions) (blockchain.CatalogFileAuthList, error)
	GetCatalogFileAuthDetailByID(authID string) (blockchain.CatalogFileAuthApplication, error)

	// org
	SetOrgInfo(opt *blockchain.OrgInfo) error
	QueryOrgInfo(id string) (*blockchain.OrgInfo, error)
	QueryOrgInfoByPK(pubkey string) (*blockchain.OrgInfo, error)
	ListOrgInfo() ([]*blockchain.OrgInfo, error)
}

var blockchainClient Blockchain

// GetBlockchainClient get blockchain client
func GetBlockchainClient() (Blockchain, error) {
	var err error
	// 实例为空，重新初始化客户端
	if blockchainClient == nil {
		blockchainClient, err = NewBlockChain()
	}
	return blockchainClient, err
}

func NewBlockChain() (Blockchain, error) {
	if config.GetChainType() == "fabric" {
		return fabric.New(config.GetFabricConf())
	} else {
		return xchain.New(config.GetXchainConf())
	}
}
