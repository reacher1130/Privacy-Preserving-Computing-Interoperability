package format

import (
	"strings"
)

type MetaFormat struct {
	Name        string
	Type        string
	Description string
	Handler     string
}

func ParFromatDefineStr(str string) *MetaFormat {
	var metaFormat MetaFormat
	strs := strings.Split(str, ",")
	if len(str) >= 1 {
		metaFormat.Name = strs[0]
	}
	if len(strs) >= 2 {
		metaFormat.Type = strs[1]
	}
	if len(strs) >= 3 {
		metaFormat.Description = strs[2]
	}
	if len(strs) >= 4 {
		metaFormat.Handler = strs[3]
	}
	return &metaFormat
}

func FormatDataStr(data string, format []*MetaFormat) string {
	datas := strings.Split(data, ",")
	dataStr := make([]string, len(datas))
	for i := 0; i < len(datas); i++ {
		// @todo 按行处理
		// format[i].Handler
		dataStr[i] = datas[i]
	}
	return strings.Join(dataStr, ",")
}

func ReadFormatLine(data string) []string {
	datas := strings.Split(data, ",")
	return datas
}
