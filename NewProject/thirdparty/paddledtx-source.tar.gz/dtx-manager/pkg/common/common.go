// Package common 一些通用的基础方法，无法具体分类可以放在这里
package common

import (
	"regexp"
	"time"
	"unicode"
	"unicode/utf8"
)

// ParseMobileSource parses mobile source from user agent of request.
func ParseMobileSource(userAgent string) string {
	mobileRe, _ := regexp.Compile("(?i:Mobile|iPod|iPhone|Android|Opera Mini|BlackBerry|webOS|UCWEB|Blazer|PSP|Windows Phone)")
	return mobileRe.FindString(userAgent)
}

// FormatTimeStamp
func FormatTimeStamp(t time.Time) string {
	return t.Format("2006-01-02 15:04:05")
}

// ParseLocalTime parses as local time.
func ParseLocalTime(timeStr string) (time.Time, error) {
	return time.ParseInLocation("2006-01-02 15:04:05", timeStr, time.Local)
}

// RemoveString returns a new slice without target
func RemoveString(strs []string, target string) []string {
	var result []string
	for _, s := range strs {
		if s != target {
			result = append(result, s)
		}
	}
	return result
}

// CheckInputName [2-16]中英文数字 return bool
func CheckInputName(name string) bool {
	strlen := utf8.RuneCountInString(name)
	if strlen < 2 || strlen > 16 {
		return false
	}
	//判断不是中文,英文,数字以外的字符为false
	for _, v := range name {
		if unicode.Is(unicode.Han, v) || unicode.IsLetter(v) || unicode.IsNumber(v) {
			continue
		}
		return false
	}
	return true
}

// 辅助函数，检查切片中是否包含某个元素
func ContainsStr(slice []string, item string) bool {
	for _, val := range slice {
		if val == item {
			return true
		}
	}
	return false
}
