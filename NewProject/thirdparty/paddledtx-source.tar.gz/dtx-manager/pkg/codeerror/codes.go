package codeerror

// error code list
const (
	ErrCodeConnection = "10001" // connection failed

	ErrCodeInternal  = "20001" // internal error
	ErrCodeConfig    = "20002" // encoding error
	ErrCodeParam     = "20003" // parameter error
	ErrCodeNotFound  = "20004" // target not found
	ErrCodeEncoding  = "20005" // encoding error
	ErrCodeUnmarshal = "20006" // unmarshal error

	ErrCodeNotAuthorized = "20008" // not authorized
	ErrCodeAlreadyExists = "20009" // duplicate item
	ErrCodeBadSignature  = "20010" // signature verification failed
	ErrCodeCrypto        = "20011" // cryptography computation error
	ErrCodeExpired       = "20012" // target expired

	ErrCodeReadBlockchain  = "30001" // errors occurred when reading data from blockchain
	ErrCodeWriteBlockchain = "30002" // errors occurred when writing data to blockchain
	ErrCodeAlreadyUpdate   = "30003" // duplicate updating error
)

// err code for dtx manager
const (
	// common error code
	ErrParam          = "ParamsErr"
	ErrSign           = "SignErr"
	ErrQueryFailed    = "QueryFailedErr"
	ErrDataExist      = "ExistedDataErr"
	ErrInternalServer = "InternalError"
	ErrDuplicateReq   = "DuplicateErr"
	ErrReqInProgress  = "ReqInProcessErr"
	ErrLengthInvalid  = "LengthInvalidErr"
	ErrMetaFeatsCheck = "MetaFeaturesCheckErr"

	// user error code
	ErrUserExisted    = "UserExisted"
	ErrUserNotExisted = "UserNotExisted"
	ErrLogin          = "ErrorLogin"
	ErrWrongPassword  = "WrongPassword"
	ErrNotAdmin       = "NotAdmin"

	// role error code
	ErrRoleExisted    = "RoleExisted"
	ErrRoleNotExisted = "RoleNotExisted"
	ErrRoleHasBinds   = "RoleHasBinds"
	ErrNoAuthority    = "NoAuthority"

	// resource
	ErrResourceStatus     = "StatusErr"
	ErrResourceNotExisted = "ResourceNotExisted"
	ErrDataTypeNotExisted = "DataTypeNotExisted"
	ErrNamespaceExisted   = "NamespaceExisted"
	ErrReplicaOversized   = "ReplicaOversized"

	// task error code
	ErrTaskExisted      = "TaskExisted"
	ErrTaskNotExisted   = "TaskNotExisted"
	ErrTaskTypeError    = "TaskTypeError"
	ErrTaskParamError   = "TaskParamError"
	ErrTaskPublished    = "TaskPublished"
	ErrTaskNotPublished = "TaskNotPublished"
	ErrTaskConfirming   = "TaskConfirming"
	ErrTaskStatusError  = "TaskStatusError"

	// Algorithm
	ErrAlgoNotExisted = "AlgorithmNotExisted"

	// Task params error
	ErrTaskParamsEmptyModelID            = "EmptyModelResourceID"          // 预测任务缺少模型ID
	ErrTaskParamsEmptyTrainParams        = "EmptyTrainParamsForTrainTask"  // 训练任务缺少训练参数配置
	ErrTaskParamsEmptyPsiParams          = "EmptyTrainParamsForPsiTask"    // 训练任务缺少psi参数配置
	ErrTaskParamsEmptyLabel              = "EmptyLabelForTrainTask"        // 训练任务缺少标签特征
	ErrTaskParamsEmptyLabelName          = "EmptyLabelNameForLogicTrain"   // 逻辑回归训练任务缺少目标值
	ErrTaskParamsNotEnoughData           = "NotEnoughDataResourceNum"      // 数据集数量不足
	ErrTaskParamsDuplicateData           = "DuplicateDataResourceIDs"      // 数据集重复
	ErrTaskParamsDataAndExeNotMatch      = "DataAndExeNodeNumNotMatch"     // 数据集和计算节点数量不匹配
	ErrTaskParamsDuplicateExe            = "DuplicateExecutorNodes"        // 计算节点重复
	ErrTaskParamsEmptyPsiLabel           = "EmptyPsiLabel"                 // psi特征名称为空
	ErrTaskParamsPsiLabelAndDataNotMatch = "PsiLabelAndDataNumberNotMatch" // psi特征数和数据集数量不匹配
	ErrTaskParamsFeatEngAndDataNotMatch  = "FeatEngAndDataNumberNotMatch"  // 特征工程配置和数据集数量不匹配
	ErrTaskParamsPsiLabelNotExist        = "PsiLabelNotExist"              // psi特征名称不存在
	ErrTaskParamsDuplicateLabel          = "DataContainDuplicateLabels"    // 数据集包含重复标签特征
	ErrTaskParamsParseFeatEngFailed      = "ParseFeatureEngFailed"         // 特征工程参数解析失败
	ErrTaskParamsCheckFeatEngFailed      = "CheckFeatureEngFailed"         // 特征工程校验失败
	ErrTaskParamsLabelNotExist           = "LabelNotExistForTrainTask"     // 标签特征不存在
	ErrTaskParamsExeNodeNotOnline        = "ExecutorNodeNotOnline"         // 计算节点已下线

	ErrBaaSGetToken = "GetBaasTokenFailed"
)

var CodeMsgMap = map[string]string{
	ErrParam:          "param '%v' is wrong",
	ErrSign:           "sign is wrong",
	ErrDataExist:      "data is existed",
	ErrQueryFailed:    "query failed",
	ErrInternalServer: "internal server error: %v",
	ErrLengthInvalid:  "length is invalid",
	ErrDuplicateReq:   "duplicate requeset",
	ErrReqInProgress:  "request in process, please try again later",
	ErrMetaFeatsCheck: "new meta should include original features",

	ErrUserExisted:    "user is existed",
	ErrUserNotExisted: "user is not existed",
	ErrLogin:          "login failed,please check username and password",
	ErrWrongPassword:  "password is wrong",
	ErrNotAdmin:       "user is not admin",

	ErrRoleExisted:    "role is existed",
	ErrRoleNotExisted: "role is not existed",
	ErrRoleHasBinds:   "role has binds and cannot be deleted",
	ErrNoAuthority:    "user has no authority",

	ErrResourceStatus:     "resource's status is wrong",
	ErrResourceNotExisted: "resource is not existed",
	ErrDataTypeNotExisted: "data type is not existed",
	ErrNamespaceExisted:   " namespace is existed",
	ErrReplicaOversized:   "replica is oversized",

	ErrTaskExisted:      "task is existed",
	ErrTaskNotExisted:   "task is not existed",
	ErrTaskTypeError:    "task type error, should be train or predict",
	ErrTaskParamError:   "task param error, parse failed",
	ErrTaskPublished:    "task published, cannot be modified",
	ErrTaskNotPublished: "task not published, cannot start or query result",
	ErrTaskConfirming:   "task confirming by peers, please try again later",
	ErrTaskStatusError:  "task status error",

	ErrAlgoNotExisted: "algorithm is not existed",
}
