package codeerror

import (
	"encoding/json"
	"fmt"
	"regexp"
	"strings"

	xdb_error "github.com/PaddlePaddle/PaddleDTX/xdb/errorx"
	"github.com/hyperledger/fabric-sdk-go/pkg/common/errors/multi"
	"github.com/hyperledger/fabric-sdk-go/pkg/common/errors/status"
	"github.com/pkg/errors"
)

// Error impls Error() and captures code,message and original error.
type Error struct {
	Code    string
	Message string
	Errord  error // 保存内部错误信息
}

// Error error required.
func (err Error) Error() string {
	return fmt.Sprintf("Err - code: %s, message: %s, error: %v", err.Code, err.Message, err.Errord)
}

// New create a implement of Error.
// Ignore the code if err is Error.
func New(err error, code string, message string, params ...interface{}) error {
	if len(params) != 0 {
		message = fmt.Sprintf(message, params...)
	}

	// ignore code,return lower code.
	if IsError(err) {
		return WithMessage(err, message)
	}

	return &Error{
		Code:    code,
		Message: message,
		Errord:  err,
	}
}

// NewError create a implement of Error.
func NewError(code string, message string, params ...interface{}) error {
	return New(nil, code, message, params...)
}

func NewErrorByCode(code string, col ...interface{}) error {
	errMsg := ""
	if msg, ok := CodeMsgMap[code]; ok {
		errMsg = msg
	} else {
		errMsg = "internal error"
	}

	// col优化处理, 字符串, error
	if len(col) > 0 {
		newMsg := ""
		if colErr, ok := col[0].(*Error); ok {
			newMsg = colErr.Message
		} else if colStr, ok := col[0].(string); ok {
			if _, msg, ok := TryParseFromString(colStr); ok {
				newMsg = msg
			} else {
				newMsg = colStr
			}
		}

		if newMsg == "" {
			errMsg = fmt.Sprintf(errMsg, col...)
		} else if strings.Contains(errMsg, "%v") || strings.Contains(errMsg, "%s") {
			errMsg = fmt.Sprintf(errMsg, newMsg)
		} else {
			errMsg = fmt.Sprintf("%s: %s", errMsg, newMsg)
		}
	}

	return NewError(code, errMsg)
}

// IsError return true if err is Error or *Error.
func IsError(err error) bool {
	switch err.(type) {
	case *Error:
		return true
	case Error:
		return true
	default:
		return false
	}
}

// WithMessage wraps errors.WithMessage
func WithMessage(err error, message string) error {
	if IsError(err) {
		e := Decode(err)
		e.Errord = errors.WithMessage(e.Errord, e.Message)
		e.Message = message

		return e
	}
	return errors.WithMessage(err, message)

}

// WithMessagef wraps errors.WithMessagef
func WithMessagef(err error, format string, args ...interface{}) error {
	if IsError(err) {
		e := Decode(err)
		e.Errord = errors.WithMessage(e.Errord, e.Message)
		e.Message = fmt.Sprintf(format, args...)

		return e
	}
	return errors.WithMessagef(err, format, args...)

}

// Decode decodes err to Error.
func Decode(err error) *Error {
	if err == nil {
		return &Error{}
	}

	switch typed := err.(type) {
	case *Error:
		return typed
	case Error:
		return &typed
	default:
		return HandleInternalError(err)
	}
}

// HandleInternalError handles errors that come from internal code.
func HandleInternalError(err error) (Err *Error) {
	defer func() {
		if r := recover(); r != nil {
			Err = &Error{
				Code:    ErrCodeInternal,
				Message: err.Error(),
				Errord:  err,
			}
		}
	}()

	// 尝试提取最内层的原始错误
	for {
		causeErr := errors.Cause(err)

		// 尝试将错误转换为 multi.Errors 类型
		multiErr, ok := causeErr.(multi.Errors)
		if ok {
			// 如果转换成功，获取其中的最后一个错误
			lastErr := multiErr[len(multiErr)-1]
			// 继续递归处理最后一个错误
			err = lastErr
		} else {
			if causeErr != err {
				// 如果错误有包装，不是最内层错误, 继续循环
				err = causeErr
			} else {
				break
			}
		}
	}

	Err = &Error{
		Code:    ErrCodeInternal,
		Message: err.Error(),
		Errord:  err,
	}

	// 专门处理fabric-sdk-go/pkg/common/errors
	if fabError, ok := err.(*status.Status); ok {
		code, msg, ok := TryParseFromString(fabError.Message)
		if ok {
			Err.Code = code
			Err.Message = msg
		} else {
			Err.Message = fabError.Message
		}
	} else if xdbError, ok := err.(*xdb_error.Error); ok {
		code, msg, ok := TryParseFromString(xdbError.Message)
		if ok {
			Err.Code = code
			Err.Message = msg
		} else {
			Err.Code = xdbError.Code
			Err.Message = xdbError.Message
		}
	} else {
		code, msg, ok := TryParseFromString(err.Error())
		if ok {
			Err.Code = code
			Err.Message = msg
		}
	}
	return
}

// TryParseFromString 将error信息解析位code, message 格式
func TryParseFromString(s string) (code, message string, success bool) {
	var e Error
	if nerr := json.Unmarshal([]byte(s), &e); nerr == nil && e.Code != "0" {
		return e.Code, e.Message, true
	}

	// try parse string use regexp
	// example:  "Err - code: 20004, message: CatalogFile not found: , error: <nil>"
	lastIndex := strings.LastIndex(s, "Err - code:")
	if lastIndex > 0 {
		re := regexp.MustCompile(`Err - code:\s(\w+),\smessage:\s(.+), error:`)
		matches := re.FindStringSubmatch(s[lastIndex:])
		if len(matches) >= 3 {
			if strings.HasSuffix(matches[2], ": ") {
				message = matches[2][:(len(matches[2]) - 2)]
			} else {
				message = matches[2]
			}
			return matches[1], message, true
		}
	}
	return ErrCodeInternal, s, false
}

func Internal(err error, format string, args ...interface{}) error {
	if err != nil {
		return New(err, ErrCodeInternal, format, args...)
	}
	return NewError(ErrCodeInternal, format, args...)
}
