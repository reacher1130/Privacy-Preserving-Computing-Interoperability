package logger

import (
	"fmt"
	"os"

	"github.com/beego/beego/v2/core/logs"
	beego "github.com/beego/beego/v2/server/web"

	"baidu/blockchain/dtx-manager/config"
)

func InitLogger() {
	beego.BConfig.Log.FileLineNum = true
	logLevel := config.LogLevel
	logPath := config.LogPath
	if err := os.MkdirAll(logPath, 0755); err != nil {
		panic(err)
	}

	logSet := fmt.Sprintf(`{"filename":"%s/project.log", "level":%d,"daily":true, "maxdays":30, "separate":["critical", "error", "debug", "warning"], "perm":"666", "rotateperm":"444"}`,
		logPath, logLevel)
	if err := logs.SetLogger(logs.AdapterMultiFile, logSet); err != nil {
		panic(err)
	}
	// error日志彩色打印
	logs.SetLogger(logs.AdapterConsole, `{"level":3,"color":true}`)

	logs.SetLevel(logLevel)

	// 设置日志打印格式 —— 时间 日志级别([I]) [文件全路径:行数] 消息
	f := &logs.PatternLogFormatter{
		Pattern:    "%w %t [%F:%n] %m",
		WhenFormat: "2006-01-02 15:04:05.000",
	}
	logs.RegisterFormatter("pattern", f)
	if err := logs.SetGlobalFormatter("pattern"); err != nil {
		panic(err)
	}

	logs.EnableFuncCallDepth(true)
	logs.SetLogFuncCallDepth(5)
}

func Error(errMsg interface{}, v ...interface{}) {
	logs.Error(errMsg, v...)
}

func Errorf(format string, args ...interface{}) {
	logs.Error(format, args...)
}

func Warn(warnMsg interface{}, v ...interface{}) {
	logs.Warn(warnMsg, v...)
}

func Warnf(format string, args ...interface{}) {
	logs.Warn(format, args...)
}

func Info(infoMsg interface{}, v ...interface{}) {
	logs.Info(infoMsg, v...)
}

func Infof(format string, args ...interface{}) {
	logs.Info(format, args...)
}

func Debug(debugMsg interface{}, v ...interface{}) {
	logs.Debug(debugMsg, v...)
}

func Debugf(format string, args ...interface{}) {
	logs.Debug(format, args...)
}
