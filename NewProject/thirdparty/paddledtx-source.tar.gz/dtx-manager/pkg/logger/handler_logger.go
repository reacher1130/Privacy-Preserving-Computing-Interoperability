package logger

import (
	"fmt"
)

type HandlerLogger struct {
	requestID string
}

func NewHandlerLogger(requestID string) HandlerLogger {
	return HandlerLogger{requestID}
}

func (h HandlerLogger) Error(errMsg interface{}, v ...interface{}) {
	Error(fmt.Sprintf("RequestID: %s, %v", h.requestID, errMsg), v...)
}

func (h HandlerLogger) Errorf(format string, args ...interface{}) {
	Error(fmt.Sprintf("RequestID: %s, %v", h.requestID, format), args...)
}

func (h HandlerLogger) Warn(warnMsg interface{}, v ...interface{}) {
	Warn(fmt.Sprintf("RequestID: %s, %v", h.requestID, warnMsg), v...)
}

func (h HandlerLogger) Warnf(format string, args ...interface{}) {
	Warn(fmt.Sprintf("RequestID: %s, %v", h.requestID, format), args...)
}

func (h HandlerLogger) Info(infoMsg interface{}, v ...interface{}) {
	Info(fmt.Sprintf("RequestID: %s, %v", h.requestID, infoMsg), v...)
}

func (h HandlerLogger) Infof(format string, args ...interface{}) {
	Info(fmt.Sprintf("RequestID: %s, %v", h.requestID, format), args...)
}

func (h HandlerLogger) Debug(debugMsg interface{}, v ...interface{}) {
	Debug(fmt.Sprintf("RequestID: %s, %v", h.requestID, debugMsg), v...)
}

func (h HandlerLogger) Debugf(format string, args ...interface{}) {
	Debug(fmt.Sprintf("RequestID: %s, %v", h.requestID, format), args...)
}
