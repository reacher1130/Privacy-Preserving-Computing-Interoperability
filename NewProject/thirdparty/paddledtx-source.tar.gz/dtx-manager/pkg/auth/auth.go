package auth

import (
	"crypto/ecdsa"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"net/http"
	"net/url"
	"sort"
	"strconv"
	"strings"
	"time"

	"baidu/blockchain/dtx-manager/pkg/logger"

	new_ecdsa "github.com/PaddlePaddle/PaddleDTX/crypto/core/ecdsa"
	"github.com/pkg/errors"
	"github.com/xuperchain/crypto/client/service/xchain"
)

// CreateAuthorization returns auth-v1 format authorization.
// sign = hex(ecdsaSign(sha256(message), privateKey))
// Authorization: auth-v1/{timestamp}/{sign}
func CreateAuthorization(privateKey *ecdsa.PrivateKey, message string) (string, error) {
	// sign
	timestamp := time.Now().Unix()
	h := sha256.New()
	h.Write([]byte(message + strconv.FormatInt(timestamp, 10)))
	fmt.Println(message + strconv.FormatInt(timestamp, 10))
	hashResult := h.Sum(nil)
	sign, err := Sign(privateKey, hashResult)
	if err != nil {
		return "", err
	}
	authorization := fmt.Sprintf("auth-v1/%d/%s", timestamp, hex.EncodeToString(sign))
	return authorization, nil
}

// VerifyAuthorization verifies authorization.
func VerifyAuthorization(publicKey *ecdsa.PublicKey, message, authorization string, expireSecond int64) error {
	timeStamp, sign, err := SplitAuthorization(authorization)
	logger.Debugf("authorization(%s), message(%s), err(%v)", authorization, message, err)
	if err != nil {
		return err
	}

	// 校验过期时间
	if expireSecond > 0 {
		if time.Now().Unix()-timeStamp > expireSecond {
			return errors.New("request expired")
		}
	}

	// check sign
	signBytes, err := new_ecdsa.DecodeSignatureFromString(sign)
	if err != nil {
		return err
	}
	h := sha256.New()
	h.Write([]byte(message + strconv.FormatInt(timeStamp, 10)))
	hashResult := h.Sum(nil)

	newPublicKey := new_ecdsa.MarshalPublicKey(publicKey)
	err = new_ecdsa.Verify(newPublicKey, []byte(hashResult), signBytes)
	logger.Debugf("hashResult(%v), err(%v)", hashResult, err)
	if err != nil {
		return err
	}
	return nil
}

// SplitAuthorization
func SplitAuthorization(authorization string) (timeStamp int64, sign string, err error) {
	fragments := strings.Split(authorization, "/")
	if len(fragments) != 3 || fragments[0] != "auth-v1" {
		return 0, "", errors.New("incorrect authorization format")
	}
	timeStampStr := fragments[1]
	timeStamp, err = strconv.ParseInt(timeStampStr, 10, 64)
	if err != nil {
		return 0, "", err
	}
	sign = fragments[2]
	return timeStamp, sign, err
}

// GenerateGetRequestBody
func GenerateGetRequestBody(req *http.Request) string {
	params := SplitQuery(req.URL.Query())
	sort.Strings(params)
	message := strings.Join(params, "")
	return message
}

func GeneratePostFormBody(req *http.Request) string {
	params := SplitQuery(req.PostForm)
	sort.Strings(params)
	message := strings.Join(params, "")
	return message
}

// SplitRawQuery splits raw query
func SplitQuery(values url.Values) []string {
	params := make([]string, 0)
	for k, vs := range values {
		q := k + "="
		if len(vs) > 0 {
			q += vs[0]
		}
		params = append(params, q)
	}
	return params
}

// Sign signs message.
func Sign(privateKey *ecdsa.PrivateKey, message []byte) ([]byte, error) {
	xcc := new(xchain.XchainCryptoClient)
	return xcc.SignECDSA(privateKey, message)
}

// PublicKeyAddressMatch matches public key and address.
func PublicKeyAddressMatch(publicKey *ecdsa.PublicKey, address string) error {
	xcc := new(xchain.XchainCryptoClient)

	chkResult, _ := xcc.VerifyAddressUsingPublicKey(address, publicKey)
	if !chkResult {
		return errors.New("public key and address not match")
	}
	return nil
}
