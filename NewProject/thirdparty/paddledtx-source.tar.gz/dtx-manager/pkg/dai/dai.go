// Package 与dai交互相关代码,目前通过区块链进行交互
package dai

import (
	"baidu/blockchain/dtx-manager/config"
	"fmt"

	"github.com/PaddlePaddle/PaddleDTX/dai/blockchain"
	"github.com/PaddlePaddle/PaddleDTX/dai/executor/handler"

	"github.com/PaddlePaddle/PaddleDTX/dai/blockchain/fabric"
	"github.com/PaddlePaddle/PaddleDTX/dai/blockchain/xchain"
	daiconf "github.com/PaddlePaddle/PaddleDTX/dai/config"
)

type DaiClient struct {
	handler.Blockchain
}

var daiClient *DaiClient

func GetDaiClient() *DaiClient {
	if daiClient == nil {
		if config.GetChainType() == "fabric" {
			conf := config.GetFabricConf()
			fabricCli, err := fabric.New(&daiconf.FabricConf{
				ConfigFile:       conf.ConfigFile,
				ChannelID:        conf.ChannelID,
				DtxChaincode:     conf.DtxChaincode,
				ManagerChaincode: conf.ManagerChaincode,
				UserName:         conf.UserName,
				OrgName:          conf.OrgName,
			})
			if err != nil {
				fmt.Println(err)
				return nil
			}
			daiClient = &DaiClient{
				fabricCli,
			}
		} else {
			conf := config.GetXchainConf()
			fmt.Println(conf)
			xchainCli, _ := xchain.New(&daiconf.XchainConf{
				Mnemonic:            conf.Mnemonic,
				DtxContractName:     conf.DtxContractName,
				ManagerContractName: conf.ManagerContractName,
				ContractAccount:     conf.ContractAccount,
				ChainAddress:        conf.ChainAddress,
				ChainName:           conf.ChainName,
			})
			daiClient = &DaiClient{
				xchainCli,
			}
		}
	}
	return daiClient
}

// ListExecutorNodes
func (c *DaiClient) ListExecutorNodes() (blockchain.ExecutorNodes, error) {
	return c.Blockchain.ListExecutorNodes()
}
