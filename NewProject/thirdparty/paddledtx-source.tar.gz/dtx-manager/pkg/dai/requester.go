package dai

import (
	"baidu/blockchain/dtx-manager/pkg/logger"
	"bytes"
	"context"
	"crypto/md5"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"reflect"
	"strings"
	"time"

	"github.com/PaddlePaddle/PaddleDTX/crypto/core/aes"
	"github.com/PaddlePaddle/PaddleDTX/crypto/core/ecdsa"
	"github.com/PaddlePaddle/PaddleDTX/crypto/core/ecies"
	"github.com/PaddlePaddle/PaddleDTX/crypto/core/hash"
	daiblockchain "github.com/PaddlePaddle/PaddleDTX/dai/blockchain"
	"github.com/PaddlePaddle/PaddleDTX/dai/blockchain/fabric"
	"github.com/PaddlePaddle/PaddleDTX/dai/blockchain/xchain"
	daiconf "github.com/PaddlePaddle/PaddleDTX/dai/config"
	"github.com/PaddlePaddle/PaddleDTX/dai/crypto/vl/feat_eng"
	pbCom "github.com/PaddlePaddle/PaddleDTX/dai/protos/common"
	pbTask "github.com/PaddlePaddle/PaddleDTX/dai/protos/task"
	xdbchain "github.com/PaddlePaddle/PaddleDTX/xdb/blockchain"
	util "github.com/PaddlePaddle/PaddleDTX/xdb/pkgs/strings"
	"github.com/golang/protobuf/proto"
	"github.com/google/uuid"
	"google.golang.org/grpc"

	dtxmb "baidu/blockchain/dtx-manager/blockchain"
	"baidu/blockchain/dtx-manager/config"
	"baidu/blockchain/dtx-manager/models"
	errorx "baidu/blockchain/dtx-manager/pkg/codeerror"
)

// Blockchain defines some contract methods
type Blockchain interface {
	// executor operation
	GetExecutorNodeByID(id string) (daiblockchain.ExecutorNode, error)
	GetExecutorNodeByName(name string) (daiblockchain.ExecutorNode, error)
	ListExecutorNodes() (daiblockchain.ExecutorNodes, error)
	GetExecutorNodeHealth(opt daiblockchain.GetExecutorNodeHealthOpts) (string, error)

	// task operation
	ListTask(opt *daiblockchain.ListFLTaskOptions) (daiblockchain.FLTasks, error)
	PublishTask(opt *daiblockchain.PublishFLTaskOptions) error
	StartTask(opt *daiblockchain.StartFLTaskOptions) error
	GetTaskById(id string) (daiblockchain.FLTask, error)

	// file operation
	GetFileByID(id string) (xdbchain.File, error)
	ListFileAuthApplications(opt *xdbchain.ListFileAuthOptions) (xdbchain.FileAuthApplications, error)
	GetAuthApplicationByID(authID string) (xdbchain.FileAuthApplication, error)

	// catalog operation
	GetCatalogFileDetailByID(id string) (dtxmb.CatalogFile, error)
	ListCatalogFileAuth(opt *dtxmb.ListCatalogFileAuthOptions) (dtxmb.CatalogFileAuthList, error)
}

// PublishOptions define parameters used to publishing a task
type PublishOptions struct {
	PrivateKey  string           // requester private key
	Files       string           // file list with "," as delimiter, used for training or prediction
	Executors   string           // executor nodes with "," as delimiter, used for executing a training or prediction task
	TaskName    string           // task name, not unique for one requester
	AlgoParam   pbCom.TaskParams // parameters required for training or prediction
	PSILabels   string           // ID feature name list with "," as delimiter, used for PSI
	Description string           // task description
	FeatEngs    [][]byte         // json encoding of feature engineering methods
}

// RequesterClient requester client, used to publish task and retrieve task result
type RequesterClient struct {
	chainClient Blockchain
}

var requesterClient *RequesterClient

func GetRequesterClient() (*RequesterClient, error) {
	if requesterClient != nil {
		return requesterClient, nil
	}

	if config.GetChainType() == "fabric" {
		conf := config.GetFabricConf()
		fabricCli, err := fabric.New(&daiconf.FabricConf{
			ConfigFile:       conf.ConfigFile,
			ChannelID:        conf.ChannelID,
			DtxChaincode:     conf.DtxChaincode,
			ManagerChaincode: conf.ManagerChaincode,
			UserName:         conf.UserName,
			OrgName:          conf.OrgName,
		})
		if err != nil {
			return nil, err
		}
		requesterClient = &RequesterClient{fabricCli}
	} else {
		conf := config.GetXchainConf()
		xchainCli, err := xchain.New(&daiconf.XchainConf{
			Mnemonic:            conf.Mnemonic,
			DtxContractName:     conf.DtxContractName,
			ManagerContractName: conf.ManagerContractName,
			ContractAccount:     conf.ContractAccount,
			ChainAddress:        conf.ChainAddress,
			ChainName:           conf.ChainName,
		})
		if err != nil {
			return nil, err
		}
		requesterClient = &RequesterClient{xchainCli}
	}
	return requesterClient, nil
}

// CheckPublishTaskOptions checks params for publishing task
// return dataForTask to be published on chain and taskID corresponding to modelID(only for predict tasks)
func (c *RequesterClient) CheckPublishTaskOptions(opt PublishOptions) ([]*pbTask.DataForTask, string, error) {
	sk, err := ecdsa.DecodePrivateKeyFromString(opt.PrivateKey)
	if err != nil {
		return nil, "", errorx.New(err, errorx.ErrCodeInternal, "failed to DecodePrivateKeyFromString")
	}
	pk := ecdsa.PublicKeyFromPrivateKey(sk)

	if opt.TaskName == "" {
		return nil, "", errorx.NewError(errorx.ErrCodeParam, "taskName can not be empty")
	}
	// 1. check taskID for predict task
	taskID := ""
	if opt.AlgoParam.TaskType == pbCom.TaskType_PREDICT {
		if opt.AlgoParam.ModelTaskID == "" {
			return nil, "", errorx.NewError(errorx.ErrTaskParamsEmptyModelID, "modelTaskID can not empty for predict task")
		}
		// check model auth
		if id, err := c.checkModelAuth(opt.AlgoParam.ModelTaskID, pk[:]); err != nil {
			return nil, "", errorx.NewError(errorx.ErrCodeParam, "model auth check failed: %v", err)
		} else {
			taskID = id
		}
	} else if opt.AlgoParam.TaskType == pbCom.TaskType_LEARN {
		if opt.AlgoParam.TrainParams == nil {
			return nil, "", errorx.NewError(errorx.ErrTaskParamsEmptyTrainParams, "algoParam.trainParams should not empty for train task")
		}
		if opt.AlgoParam.TrainParams.Label == "" {
			return nil, "", errorx.NewError(errorx.ErrTaskParamsEmptyLabel, "label can not empty for train task")
		}
		if opt.AlgoParam.Algo == pbCom.Algorithm_LOGIC_REGRESSION_VL && opt.AlgoParam.TrainParams.LabelName == "" {
			return nil, "", errorx.NewError(errorx.ErrTaskParamsEmptyLabelName, "labelName can not be empty for logistic-vl")
		}
	} else if opt.AlgoParam.TaskType == pbCom.TaskType_PSI {
		if opt.AlgoParam.PsiParams == nil {
			return nil, "", errorx.NewError(errorx.ErrTaskParamsEmptyPsiParams, "algoParam.trainParams should not empty for psi task")
		}
	}

	// 2. check data sets number and executor nodes number, at least two parties
	fileIDs := strings.Split(strings.TrimSpace(opt.Files), ",")
	executors := strings.Split(strings.TrimSpace(opt.Executors), ",")
	if len(fileIDs) < 2 {
		return nil, "", errorx.NewError(errorx.ErrTaskParamsNotEnoughData, "not enough data set numbers, got: %d", len(fileIDs))
	}
	if util.IsContainDuplicateItems(fileIDs) {
		return nil, "", errorx.NewError(errorx.ErrTaskParamsDuplicateData, "sample file IDs cannot be the same")
	}
	// the number of files and the number of nodes must be the same
	// when task is executed, the executor node take the sample file with the same index position
	if len(fileIDs) != len(executors) {
		return nil, "", errorx.NewError(errorx.ErrTaskParamsDataAndExeNotMatch, "sample files num not match executor nodes num, got: %d", len(executors))
	}
	if util.IsContainDuplicateItems(executors) {
		return nil, "", errorx.NewError(errorx.ErrTaskParamsDuplicateExe, "executor node names cannot be the same")
	}

	// 3. check if algorithm exists
	psiLabels := strings.Split(strings.TrimSpace(opt.PSILabels), ",")
	if _, ok := daiblockchain.VlAlgorithmListValue[opt.AlgoParam.Algo]; ok {
		if opt.PSILabels == "" {
			return nil, "", errorx.NewError(errorx.ErrTaskParamsEmptyPsiLabel, "PSILabel cannot be empty for vertical train task")
		}
		if len(fileIDs) != len(psiLabels) {
			return nil, "", errorx.NewError(errorx.ErrTaskParamsPsiLabelAndDataNotMatch, "sample file num not match psi label num")
		}
	}

	// 4. feature engineering config either 0 or dataIDs length
	if len(opt.FeatEngs) != 0 && len(opt.FeatEngs) != len(fileIDs) {
		return nil, "", errorx.NewError(errorx.ErrTaskParamsFeatEngAndDataNotMatch, "feature engineering files not 0 or not match files num")
	}

	// 5. check if dataset and specified label exist
	var dataSets []*pbTask.DataForTask
	var isTagPart bool
	isLabelExist := 0
	for index, fileID := range fileIDs {
		file, err := c.chainClient.GetCatalogFileDetailByID(fileID)
		if err != nil {
			return nil, "", err
		}

		fileExtra, err := c.getCatalogFileExt(file)
		if err != nil {
			return nil, "", errorx.NewError(errorx.ErrCodeInternal, "failed to get file extra info: %v", err)
		}
		fileFeatures := make([]string, 0, len(fileExtra))
		for _, meta := range fileExtra {
			fileFeatures = append(fileFeatures, meta.Name)
		}
		// check if psiLabel exists in feature list
		if !util.IsContain(fileFeatures, psiLabels[index]) {
			return nil, "", errorx.NewError(errorx.ErrTaskParamsPsiLabelNotExist, "features of file does not contain psiLabel")
		}

		// check if label exists in one of the datasets
		if opt.AlgoParam.TaskType == pbCom.TaskType_LEARN && util.IsContain(fileFeatures, opt.AlgoParam.TrainParams.Label) {
			isLabelExist += 1
			isTagPart = true
		}
		// only one party is allowed to have label
		if isLabelExist > 1 {
			return nil, "", errorx.NewError(errorx.ErrTaskParamsDuplicateLabel, "invalid fileIDs, only one sample file is allowed to have label")
		}

		// get executor address
		executorNode, err := c.chainClient.GetExecutorNodeByName(executors[index])
		if err != nil {
			return nil, "", errorx.New(err, errorx.ErrCodeReadBlockchain, "failed to get executor node by node name")
		}

		// get feature engineering methods
		var featureEngineering []*pbCom.FeatureEngineering
		if len(opt.FeatEngs) != 0 {
			featureEngineering, err = feat_eng.ParseFeatEngs(opt.FeatEngs[index])
			if err != nil {
				return nil, "", errorx.New(err, errorx.ErrTaskParamsParseFeatEngFailed, "failed to ParseFeatEngs")
			}
			if err := feat_eng.CheckFeatEngs(featureEngineering); err != nil {
				return nil, "", errorx.New(err, errorx.ErrTaskParamsCheckFeatEngFailed, "CheckFeatEngs failed")
			}
		}

		dataSets = append(dataSets, &pbTask.DataForTask{
			Owner:       file.Owner,
			Executor:    executorNode.ID,
			PsiLabel:    psiLabels[index],
			DataID:      fileID,
			Address:     executorNode.Address,
			IsTagPart:   isTagPart,
			FeatureEngs: featureEngineering,
		})
	}
	if opt.AlgoParam.TaskType == pbCom.TaskType_LEARN && isLabelExist < 1 {
		return nil, "", errorx.NewError(errorx.ErrTaskParamsLabelNotExist, "invalid label, dataSets label doest not exist")
	}

	// 6. check executor node online and health status
	for i := 0; i < len(executors); i++ {
		node, err := c.chainClient.GetExecutorNodeByName(executors[i])
		if err != nil {
			return nil, "", errorx.NewError(errorx.ErrCodeReadBlockchain, "failed to get executor node: %v", err)
		}
		if !node.Online {
			return nil, "", errorx.NewError(errorx.ErrTaskParamsExeNodeNotOnline, "executor node not online: %s", executors[i])
		}

		//opt1 := &pbTask.GetExecutorNodeHealthRequest{
		//	Id:          node.ID,
		//	CurrentTime: time.Now().UnixNano(),
		//}
		//health, err := c.chainClient.GetExecutorNodeHealth(opt1)
		//if err != nil {
		//	return nil, "", errorx.NewError(errorx.ErrCodeParam, "failed to get executor node health: %v", err)
		//}
		//if health == utilNode.ExecutorNodeHealthBad {
		//	return nil, "", errorx.NewError(errorx.ErrCodeParam, "executor node health not satisfied: %s", executors[i])
		//}
	}

	// 7. check if requester has authority to use data and model
	for i := 0; i < len(dataSets); i++ {
		// 如果不是自己的文件，则检查授权状况
		if !reflect.DeepEqual(pk[:], dataSets[i].Owner) {
			listOpt := &dtxmb.ListCatalogFileAuthOptions{
				Applier:  pk[:],
				FileID:   dataSets[i].DataID,
				DataType: dtxmb.CatalogFileTypeOfData,
				Status:   dtxmb.CatalogFileAuthApproved,
			}
			auths, err := c.chainClient.ListCatalogFileAuth(listOpt)
			if err != nil {
				return nil, "", errorx.New(err, errorx.ErrCodeReadBlockchain, "failed to ListCatalogFileAuth")
			}
			if len(auths.List) == 0 {
				return nil, "", errorx.NewError(errorx.ErrCodeNotAuthorized, "not authorized to use file: %s", dataSets[i])
			}
			if auths.List[0].ExpireTime < time.Now().UnixNano() {
				return nil, "", errorx.NewError(errorx.ErrCodeNotAuthorized, "file auth already expired")
			}
		}
	}

	return dataSets, taskID, nil
}

// Publish publishes a task, returns taskID
func (c *RequesterClient) Publish(opt PublishOptions) (taskId string, err error) {
	pubkey, privkey, err := checkUserPrivateKey(opt.PrivateKey)
	if err != nil {
		return taskId, err
	}
	dataSets, trainTaskID, err := c.CheckPublishTaskOptions(opt)
	if err != nil {
		return taskId, err
	}

	task := pbTask.FLTask{
		Name:        opt.TaskName,
		Description: opt.Description,
		Requester:   pubkey[:],
		AlgoParam:   &opt.AlgoParam,
		PublishTime: time.Now().UnixNano(),
		DataSets:    dataSets,
	}
	task.AlgoParam.ModelTaskID = trainTaskID
	// check usage auth of datasets, use only authorized features
	newSets, err := c.filterAuthedFeatures(dataSets, pubkey[:])
	if err != nil {
		return taskId, err
	}
	task.DataSets = newSets

	// generate a uuid as taskId
	taskUuid, err := uuid.NewRandom()
	if err != nil {
		return taskId, errorx.Internal(err, "failed to get uuid")
	}
	task.TaskID = taskUuid.String()

	pubTask, err := proto.Marshal(&task)
	if err != nil {
		return taskId, errorx.New(err, errorx.ErrCodeInternal, "failed to marshal fl task")
	}
	sig, err := ecdsa.Sign(privkey, hash.HashUsingSha256(pubTask))
	if err != nil {
		return taskId, errorx.New(err, errorx.ErrCodeInternal, "failed to sign fl task")
	}
	pubOpt := &daiblockchain.PublishFLTaskOptions{
		FLTask:    pubTask,
		Signature: sig[:],
	}

	if err := c.chainClient.PublishTask(pubOpt); err != nil {
		return taskId, err
	}
	return task.TaskID, nil
}

// GetTaskById gets task by taskID
func (c *RequesterClient) GetTaskById(id string) (t daiblockchain.FLTask, err error) {
	t, err = c.chainClient.GetTaskById(id)
	if err != nil {
		return t, err
	}
	return t, nil
}

// ListTask lists tasks by requester or executor's public key hex string
// support listing tasks a requester published or tasks an executor involved
// status is task status to search
// only task published after "start" before "end" will be listed
// limit is the maximum number of tasks to response
func (c *RequesterClient) ListTask(rPubkeyStr, ePubkeyStr, status string, start, end,
	limit int64) (tasks daiblockchain.FLTasks, err error) {
	rPubkey, err := hex.DecodeString(rPubkeyStr)
	if err != nil {
		return tasks, errorx.New(err, errorx.ErrCodeInternal, "failed to decode requester public key")
	}
	ePubkey, err := hex.DecodeString(ePubkeyStr)
	if err != nil {
		return tasks, errorx.New(err, errorx.ErrCodeInternal, "failed to decode executor public key")
	}
	tasks, err = c.chainClient.ListTask(&daiblockchain.ListFLTaskOptions{
		PubKey:     rPubkey[:],
		ExecPubKey: ePubkey[:],
		TimeStart:  start,
		TimeEnd:    end,
		Status:     status,
		Limit:      limit,
	})
	return
}

// StartTask starts task by taskID, only task with 'Ready' status can be started
func (c *RequesterClient) StartTask(privateKey, id string) (err error) {
	_, privkey, err := checkUserPrivateKey(privateKey)
	if err != nil {
		return err
	}
	sParams := daiblockchain.StartFLTaskOptions{TaskID: id}
	msg, err := util.GetSigMessage(sParams)
	if err != nil {
		return errorx.Internal(err, "failed to get the message to sign for start task")
	}
	sig, err := ecdsa.Sign(privkey, hash.HashUsingSha256([]byte(msg)))
	if err != nil {
		return errorx.New(err, errorx.ErrCodeInternal, "failed to sign fl task")
	}
	sParams.Signature = sig[:]
	err = c.chainClient.StartTask(&sParams)
	return err
}

// GetPredictResult gets predict result by taskID
func (c *RequesterClient) GetPsiResult(privateKey, taskID string) (out []byte, err error) {
	pubkey, privkey, err := checkUserPrivateKey(privateKey)
	if err != nil {
		return nil, err
	}

	// get prediction task
	task, err := c.chainClient.GetTaskById(taskID)
	if err != nil {
		return nil, err
	}
	// check task type
	if task.AlgoParam.TaskType != pbCom.TaskType_PSI {
		return nil, errorx.NewError(errorx.ErrCodeParam, "invalid task type, not a psi task")
	}
	//jsonString, err := json.Marshal(task)
	//if err != nil {
	//	fmt.Println("Error:", err)
	//	return nil, fmt.Errorf("task json Marshal err")
	//}
	//logger.Infof("获取到的链上任务信息是 %s", string(jsonString))
	//sk, err := ecdsa.DecodePrivateKeyFromString(config.GetPrivateKey())
	//if err != nil {
	//	logger.Errorf("get psi file -> GetPrivateKey err %s", err.Error())
	//	return nil, fmt.Errorf("get psi file -> GetPrivateKey err ")
	//}
	//pk := ecdsa.PublicKeyFromPrivateKey(sk)
	var executorHost string
	for _, dataset := range task.DataSets {
		if reflect.DeepEqual(pubkey[:], dataset.Owner) {
			executorHost = dataset.Address
			break
		}
	}
	logger.Infof("get psi file executorHost is %s ", executorHost)
	// connect to result owner
	conn, err := grpc.Dial(executorHost, grpc.WithInsecure())
	if err != nil {
		logger.Errorf("get psi file failed to connect to executor server: %v", err)
		return nil, errorx.NewError(errorx.ErrCodeInternal, "CAN_NOT_CONNECT_EXECUTOR_SERVER: %v", err)
	}
	defer conn.Close()
	taskClient := pbTask.NewTaskClient(conn)

	in := &pbTask.TaskRequest{
		PubKey: pubkey[:],
		TaskID: taskID,
	}

	// verify signature
	msg, err := util.GetSigMessage(in)
	if err != nil {
		return nil, errorx.Internal(err, "failed to get the message to sign for download psi result")
	}
	sig, err := ecdsa.Sign(privkey, hash.HashUsingSha256([]byte(msg)))
	if err != nil {
		return nil, errorx.New(err, errorx.ErrCodeInternal, "failed to sign predict task")
	}
	in.Signature = sig[:]

	// request data node to download psi file
	resp, err := taskClient.GetPsiResult(context.Background(), in)
	if err != nil {
		return nil, err
	}
	str := string(resp.Payload)
	// 去掉第一位字符 去掉最后一位字符
	str = str[1 : len(str)-1]
	resultByte := resp.Payload
	resultByte = resultByte[8 : len(resultByte)-8]
	result, err := base64.StdEncoding.DecodeString(str)
	if err != nil {
		logger.Infof("base64.StdEncoding.DecodeString 报错......")
		logger.Errorf(err.Error())
		return nil, err
	}
	//logger.Infof("返回结果是  " + string(result))
	return result, nil
}

// GetPredictResult gets predict result by taskID
func (c *RequesterClient) GetPredictResult(privateKey, taskID string) (out []byte, err error) {
	pubkey, privkey, err := checkUserPrivateKey(privateKey)
	if err != nil {
		return nil, err
	}

	// get prediction task
	task, err := c.chainClient.GetTaskById(taskID)
	if err != nil {
		return nil, err
	}
	// check task type
	if task.AlgoParam.TaskType != pbCom.TaskType_PREDICT {
		return nil, errorx.NewError(errorx.ErrCodeParam, "invalid task type, not a predict task")
	}
	// get training task
	modelTask, err := c.chainClient.GetTaskById(task.AlgoParam.ModelTaskID)
	if err != nil {
		return nil, err
	}
	var executorHost string
	for _, dataset := range modelTask.DataSets {
		if dataset.IsTagPart {
			executorHost = dataset.Address
			break
		}
	}

	// connect to result owner
	conn, err := grpc.Dial(executorHost, grpc.WithInsecure())
	if err != nil {
		return nil, errorx.NewError(errorx.ErrCodeInternal, "CAN_NOT_CONNECT_EXECUTOR_SERVER: %v", err)
	}
	defer conn.Close()
	taskClient := pbTask.NewTaskClient(conn)

	in := &pbTask.TaskRequest{
		PubKey: pubkey[:],
		TaskID: taskID,
	}

	// verify signature
	msg, err := util.GetSigMessage(in)
	if err != nil {
		return nil, errorx.Internal(err, "failed to get the message to sign for download prediction result")
	}
	sig, err := ecdsa.Sign(privkey, hash.HashUsingSha256([]byte(msg)))
	if err != nil {
		return nil, errorx.New(err, errorx.ErrCodeInternal, "failed to sign predict task")
	}
	in.Signature = sig[:]

	// request data node to download predict file
	resp, err := taskClient.GetPredictResult(context.Background(), in)
	if err != nil {
		return nil, err
	}

	return resp.Payload, nil
}

// GetEvalMetricsById gets learning task evaluation or live evaluation results by taskID
func (c *RequesterClient) GetEvalMetricsById(privateKey, taskID string) (t daiblockchain.FLTask, r *pbTask.EvaluationResponse,
	lr *pbTask.LiveEvaluationResponse, err error) {
	pubkey, privkey, err := checkUserPrivateKey(privateKey)
	if err != nil {
		return nil, nil, nil, err
	}

	// get learning task
	task, err := c.chainClient.GetTaskById(taskID)
	if err != nil {
		return nil, nil, nil, err
	}
	// check task type
	if task.AlgoParam.TaskType != pbCom.TaskType_LEARN {
		return nil, nil, nil, errorx.NewError(errorx.ErrCodeParam, "invalid task type, not a learning task")
	}
	// check task status
	if task.Status != daiblockchain.TaskFinished && task.Status != daiblockchain.TaskProcessing {
		return nil, nil, nil, errorx.NewError(errorx.ErrCodeParam, "the task status is not finished or processing")
	}
	// evaluation results can only be downloaded if the task has started static evaluation or live evaluation
	if task.AlgoParam.EvalParams == nil && task.AlgoParam.LivalParams == nil {
		return nil, nil, nil, errorx.NewError(errorx.ErrCodeParam, "the task didn't start evaluation or live evaluation")
	}
	var executorHost string
	for _, dataset := range task.DataSets {
		if dataset.IsTagPart {
			executorHost = dataset.Address
			break
		}
	}

	// connect to result owner
	conn, err := grpc.Dial(executorHost, grpc.WithInsecure())
	if err != nil {
		return nil, nil, nil, errorx.NewError(errorx.ErrCodeInternal, "CAN_NOT_CONNECT_EXECUTOR_SERVER: %v", err)
	}
	defer conn.Close()
	taskClient := pbTask.NewTaskClient(conn)

	in := &pbTask.TaskRequest{
		PubKey: pubkey[:],
		TaskID: taskID,
	}

	// verify signature
	msg, err := util.GetSigMessage(in)
	if err != nil {
		return nil, nil, nil, errorx.Internal(err, "failed to get the message to sign for download prediction result")
	}
	sig, err := ecdsa.Sign(privkey, hash.HashUsingSha256([]byte(msg)))
	if err != nil {
		return nil, nil, nil, errorx.New(err, errorx.ErrCodeInternal, "failed to sign predict task")
	}
	in.Signature = sig[:]

	// if task starts static evaluation
	if task.AlgoParam.EvalParams != nil && task.Status == daiblockchain.TaskFinished {
		r, err = taskClient.GetEvaluationResult(context.Background(), in)
		if err != nil {
			return nil, nil, nil, err
		}
	}
	// if task starts live evaluation
	if task.AlgoParam.LivalParams != nil {
		lr, err = taskClient.GetLiveEvaluationResult(context.Background(), in)
		if err != nil {
			return nil, nil, nil, err
		}
	}

	return task, r, lr, nil
}

// ListExecutorNodes list all executor nodes
func (c *RequesterClient) ListExecutorNodes() (nodes daiblockchain.ExecutorNodes, err error) {
	return c.chainClient.ListExecutorNodes()
}

// GetExecutorNodeByID get the executor node by nodeID, which is the public key of the node
func (c *RequesterClient) GetExecutorNodeByID(pubkeyStr string) (node daiblockchain.ExecutorNode, err error) {
	_, err = hex.DecodeString(pubkeyStr)
	if err != nil {
		return node, errorx.New(err, errorx.ErrCodeInternal, "failed to decode executor public key")
	}
	return c.chainClient.GetExecutorNodeByID(pubkeyStr)
}

// GetExecutorNodeByName get executor node by nodeName
func (c *RequesterClient) GetExecutorNodeByName(name string) (node daiblockchain.ExecutorNode, err error) {
	return c.chainClient.GetExecutorNodeByName(name)
}

// GetTaskLog gets train/predict task logs by taskID
func (c *RequesterClient) GetTaskLog(taskID string) (out []byte, err error) {
	// get task detail
	task, err := c.chainClient.GetTaskById(taskID)
	if err != nil {
		return nil, err
	}

	// find own executor node address
	var executorHost string
	for _, dataset := range task.DataSets {
		executor, err := c.chainClient.GetExecutorNodeByID(hex.EncodeToString(dataset.Executor))
		if err != nil {
			return nil, err
		}
		if executor.OrgID == config.GetOrgID() {
			executorHost = executor.Address
		}
	}
	if len(executorHost) == 0 {
		return nil, errorx.NewError(errorx.ErrCodeInternal, "did not find own executor node")
	}

	// connect to executor node
	conn, err := grpc.Dial(executorHost, grpc.WithInsecure())
	if err != nil {
		return nil, errorx.NewError(errorx.ErrCodeInternal, "CAN_NOT_CONNECT_EXECUTOR_SERVER: %v", err)
	}
	defer conn.Close()
	taskClient := pbTask.NewTaskClient(conn)

	in := &pbTask.GetTaskLogRequest{
		Id: taskID,
	}

	// request executor node to get task log
	resp, err := taskClient.GetTaskLog(context.Background(), in)
	if err != nil {
		return nil, err
	}

	return resp.Log, nil
}

// decrypt catalog file extra info
func (c *RequesterClient) getCatalogFileExt(dataFile dtxmb.CatalogFile) ([]*models.FieldInfo, error) {
	owner := hex.EncodeToString(dataFile.Owner)
	var metaInfo []*models.FieldInfo

	// 解密
	if owner == config.GetPublicKey() {
		// 文件所有者是自己
		k := md5.New().Sum([]byte(config.SecretKey + dataFile.FileID))[0:32]
		metaInfoBytes, err := aes.DecryptUsingAESGCM(aes.AESKey{
			Key:   k,
			Nonce: k[0:12],
		}, dataFile.Ext, nil)
		if err == nil {
			json.Unmarshal(metaInfoBytes, &metaInfo)
		} else {
			return nil, errorx.New(err, errorx.ErrCodeInternal, "decrypt own file ext error: %v")
		}
	} else {
		// 文件所有者是其他, 查询授权
		pubKey, _ := ecdsa.DecodePublicKeyFromString(config.GetPublicKey())
		priKey, _ := ecdsa.DecodePrivateKeyFromString(config.GetPrivateKey())
		ownerKey, _ := ecdsa.DecodePublicKeyFromString(owner)
		opt := &dtxmb.ListCatalogFileAuthOptions{
			Applier:    pubKey[:],
			Authorizer: ownerKey[:],
			FileID:     dataFile.FileID,
			DataType:   dataFile.Type,
			Status:     dtxmb.CatalogFileAuthApproved,
		}
		authList, err := c.chainClient.ListCatalogFileAuth(opt)
		if err == nil {
			var key []byte
			for _, item := range authList.List {
				ecdsakey := ecdsa.ParsePrivateKey(priKey)
				key, err = ecies.Decrypt(&ecdsakey, item.AuthKey)
				if err == nil {
					break
				}
			}
			if key != nil {
				metaInfoBytes, err := aes.DecryptUsingAESGCM(aes.AESKey{
					Key:   key,
					Nonce: key[0:12],
				}, dataFile.Ext, nil)
				if err == nil {
					json.Unmarshal(metaInfoBytes, &metaInfo)
				} else {
					return nil, errorx.New(err, errorx.ErrCodeInternal, "decrypt file ext error: %v")
				}
			}
		}
	}
	return metaInfo, nil
}

func (c *RequesterClient) checkModelAuth(modelID string, pk []byte) (string, error) {
	model, err := c.chainClient.GetCatalogFileDetailByID(modelID)
	if err != nil {
		return "", errorx.NewError(errorx.ErrCodeParam, "failed to get model: %v", err)
	}
	task, err := c.chainClient.GetTaskById(model.TaskID)
	if err != nil {
		return "", errorx.NewError(errorx.ErrCodeParam, "failed to get task[%s]: %v", model.TaskID, err)
	}

	// 如果发起方是训练任务参与方，则有权限发起预测任务
	myOrg := config.GetOrgID()
	for i := 0; i < len(task.DataSets); i++ {
		execA, err := c.chainClient.GetExecutorNodeByID(hex.EncodeToString(task.DataSets[i].Executor))
		if err != nil {
			return "", errorx.NewError(errorx.ErrCodeParam, "failed to get executor node: %v", err)
		}
		if myOrg == execA.OrgID {
			return task.TaskID, nil
		}
	}

	// 如果不是训练任务参与方，则校验模型资源权限
	listOpt := &dtxmb.ListCatalogFileAuthOptions{
		Applier:  pk,
		FileID:   modelID,
		DataType: dtxmb.CatalogFileTypeOfModel,
		Status:   dtxmb.CatalogFileAuthApproved,
	}
	auths, err := c.chainClient.ListCatalogFileAuth(listOpt)
	if err != nil {
		return "", errorx.New(err, errorx.ErrCodeInternal, "failed to ListCatalogFileAuth")
	}
	if len(auths.List) == 0 {
		return "", errorx.NewError(errorx.ErrCodeNotAuthorized, "not authorized to use model")
	}

	for i := 0; i < len(auths.List); i++ {
		if auths.List[i].ExpireTime > time.Now().UnixNano() {
			return task.TaskID, nil
		}
	}
	return "", errorx.NewError(errorx.ErrCodeNotAuthorized, "model authorization already expired")
}

func (c *RequesterClient) filterAuthedFeatures(dataSets []*pbTask.DataForTask, reqPubkey []byte) ([]*pbTask.DataForTask, error) {
	for i := 0; i < len(dataSets); i++ {
		fileResource, err := c.chainClient.GetCatalogFileDetailByID(dataSets[i].DataID)
		if err != nil {
			return nil, errorx.New(err, errorx.ErrCodeReadBlockchain, "failed to get file[%s] detail", dataSets[i].DataID)
		}
		// 如果是发布方的文件资源你，则不用做处理
		if bytes.Equal(fileResource.Owner, reqPubkey) {
			continue
		}

		// 如果不是发布方的资源，则需要获取授权的特征列表
		listOpt := &dtxmb.ListCatalogFileAuthOptions{
			Applier:  reqPubkey,
			FileID:   dataSets[i].DataID,
			DataType: dtxmb.CatalogFileTypeOfData,
			Status:   dtxmb.CatalogFileAuthApproved,
		}
		auths, err := c.chainClient.ListCatalogFileAuth(listOpt)
		if err != nil {
			return nil, errorx.New(err, errorx.ErrCodeInternal, "failed to ListCatalogFileAuth")
		}
		if len(auths.List) == 0 {
			return nil, errorx.New(err, errorx.ErrCodeInternal, "not authorized to use dataset[%s]", dataSets[i].DataID)
		}
		// 汇总所有授权使用的特征列表
		var authFeatures []string
		for j := 0; j < len(auths.List); j++ {
			if auths.List[j].Type == dtxmb.CatalogFileAuthUse && auths.List[j].ExpireTime > time.Now().UnixNano() {
				authFeatures = append(authFeatures, auths.List[j].Features...)
			}
		}
		// 新增featureSelect特征工程方法
		if len(authFeatures) > 0 {
			featEng := &pbCom.FeatureEngineering{
				FeatureEng: &pbCom.FeatureEngineering_FeatureSelect{
					FeatureSelect: &pbCom.FeatureSelect{
						Features: authFeatures,
					},
				},
			}
			dataSets[i].FeatureEngs = append(dataSets[i].FeatureEngs, featEng)
		}
	}

	return dataSets, nil
}

func FillParamsByDefault(params *pbCom.TaskParams) *pbCom.TaskParams {
	if params.TaskType == pbCom.TaskType_LEARN {
		if params.Algo == pbCom.Algorithm_LINEAR_REGRESSION_VL || params.Algo == pbCom.Algorithm_LOGIC_REGRESSION_VL {
			if params.TrainParams.RegMode != 0 && params.TrainParams.RegParam == 0 {
				params.TrainParams.RegParam = 0.1
			}
			if params.TrainParams.Alpha == 0 {
				params.TrainParams.Alpha = 0.1
			}
			if params.TrainParams.Amplitude == 0 {
				params.TrainParams.Amplitude = 0.0001
			}
			if params.TrainParams.Accuracy == 0 {
				params.TrainParams.Accuracy = 10
			}
		}
		if params.Algo == pbCom.Algorithm_DECISION_TREE_CLASS_VL {
			if params.TrainParams.RegParam == 0 {
				params.TrainParams.RegParam = 0.1
			}
			if params.TrainParams.StopCond == nil {
				params.TrainParams.StopCond = &pbCom.StopCond{
					SampleThreshold: 5,
					DepthThreshold:  15,
					GiniThreshold:   0.01,
				}
			} else {
				if params.TrainParams.StopCond.SampleThreshold == 0 {
					params.TrainParams.StopCond.SampleThreshold = 5
				}
				if params.TrainParams.StopCond.DepthThreshold == 0 {
					params.TrainParams.StopCond.DepthThreshold = 15
				}
				if params.TrainParams.StopCond.GiniThreshold == 0 {
					params.TrainParams.StopCond.GiniThreshold = 0.01
				}
			}
		}
		if params.EvalParams != nil && params.EvalParams.Enable {
			if params.EvalParams.EvalRule == pbCom.EvaluationRule_ErRandomSplit {
				if params.EvalParams.RandomSplit == nil || params.EvalParams.RandomSplit.PercentLO == 0 {
					params.EvalParams.RandomSplit = &pbCom.RandomSplit{
						PercentLO: 30,
					}
				}
			}
			if params.EvalParams.EvalRule == pbCom.EvaluationRule_ErCrossVal {
				if params.EvalParams.Cv == nil {
					params.EvalParams.Cv = &pbCom.CrossVal{
						Folds: 10,
					}
				} else if params.EvalParams.Cv.Folds == 0 {
					params.EvalParams.Cv.Folds = 10
				}
			}
		}
	}
	return params
}

// checkUserPrivateKey checks whether user public key is a valid ecc public key
func checkUserPrivateKey(privateKey string) (pubkey ecdsa.PublicKey, privkey ecdsa.PrivateKey, err error) {
	privkey, err = ecdsa.DecodePrivateKeyFromString(privateKey)
	if err != nil {
		return pubkey, privkey, err
	}
	pubkey = ecdsa.PublicKeyFromPrivateKey(privkey)
	return pubkey, privkey, nil
}
