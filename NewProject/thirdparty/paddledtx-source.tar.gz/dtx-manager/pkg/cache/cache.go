// 带优先级+有效期的LRU本地缓存
package cache

import (
	"container/list"
	"sync"
	"time"
)

type Cache struct {
	mu       sync.Mutex
	capacity int
	items    map[string]*list.Element
	queue    *list.List
}

type CacheItem struct {
	Key      string
	Value    interface{}
	ExpireAt time.Time
}

var cache *Cache

func GetCache() *Cache {
	if cache == nil {
		cache = &Cache{
			capacity: 100,
			items:    make(map[string]*list.Element),
			queue:    list.New(),
		}
	}
	return cache
}

func (c *Cache) SetEx(key string, value interface{}, timeoutSec int64) error {
	c.mu.Lock()
	defer c.mu.Unlock()

	// Check if the item already exists in the cache
	if elem, ok := c.items[key]; ok {
		c.queue.MoveToFront(elem) // Update priority
		elem.Value.(*CacheItem).Value = value
		elem.Value.(*CacheItem).ExpireAt = time.Now().Add(time.Duration(timeoutSec) * time.Second)
	} else {
		if c.queue.Len() >= c.capacity {
			// Evict the least recently used item if the cache is full
			oldestElem := c.queue.Back()
			if oldestElem != nil {
				delete(c.items, oldestElem.Value.(*CacheItem).Key)
				c.queue.Remove(oldestElem)
			}
		}

		expireAt := time.Now().Add(time.Duration(timeoutSec) * time.Second)
		newElem := c.queue.PushFront(&CacheItem{Key: key, Value: value, ExpireAt: expireAt})
		c.items[key] = newElem
	}

	return nil
}

func (c *Cache) Get(key string) (interface{}, bool) {
	c.mu.Lock()
	defer c.mu.Unlock()

	if elem, ok := c.items[key]; ok {
		if elem.Value.(*CacheItem).ExpireAt.After(time.Now()) {
			c.queue.MoveToFront(elem) // Update priority
			return elem.Value.(*CacheItem).Value, true
		}
		// Expired item, remove from cache
		delete(c.items, key)
		c.queue.Remove(elem)
	}

	return nil, false
}

// 获取某个键值对的更新时间
func (c *Cache) UpdateAt(key string, duration int64) int64 {
	if elem, ok := c.items[key]; ok {
		return elem.Value.(*CacheItem).ExpireAt.Unix() - duration
	}
	return 0
}
