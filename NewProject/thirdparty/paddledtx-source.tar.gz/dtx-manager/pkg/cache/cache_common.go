// 带优先级+有效期的LRU本地缓存
package cache

import (
	"baidu/blockchain/dtx-manager/blockchain"
	"baidu/blockchain/dtx-manager/config"
	pbc "baidu/blockchain/dtx-manager/pkg/blockchain"
	"baidu/blockchain/dtx-manager/pkg/dai"
	"baidu/blockchain/dtx-manager/pkg/logger"
	"baidu/blockchain/dtx-manager/pkg/xdb"
	"fmt"
	beego "github.com/beego/beego/v2/server/web"
	"sync"
	"time"

	dbc "github.com/PaddlePaddle/PaddleDTX/dai/blockchain"
	xbc "github.com/PaddlePaddle/PaddleDTX/xdb/blockchain"
)

const (
	cacheTTLDay          = 86400
	cacheTTLHour         = 3600
	cacheTTLMin          = 60
	cacheTTL5Min         = 300
	CacheOrgInfoList     = "Cache_OrgInfoList"
	CacheNsFilesMapData  = "Cache_NsFilesMapData"
	CacheNsFilesMapModel = "Cache_NsFilesMapModel"
	CacheExecutorList    = "Cache_ExecutorList"
	CacheTaskAlgoMap     = "Cache_TaskAlgoMap"
	CacheXDBSysHealth    = "Cache_XDBSysHealth"
)

// 系统初始化时, 提前加载部分链上数据, 而后周期性更新缓存
func InitCacheData() {

	// 启动定时任务，每隔一段时间检查缓存数据是否过期
	go func() {
		for {
			GetXDBSysHealth()
			GetNamespaceFilesMap("data", false)
			GetExecutorList()
			GetNamespaceFilesMap("model", false)

			logger.Info("Init cache data finished.")
			time.Sleep(5 * time.Minute)
		}
	}()
}

func GetXDBSysHealth() (*xbc.FileSysHealth, error) {
	if cacheInfo, ok := GetCache().Get(CacheXDBSysHealth); ok {
		if time.Now().Unix()-GetCache().UpdateAt(CacheXDBSysHealth, cacheTTLDay) > 5 {
			// 每次命中缓存后更新一次缓存, 同时为了减少短时间重复刷新, 操作时先更新一次时间戳
			GetCache().SetEx(CacheXDBSysHealth, cacheInfo, cacheTTLDay)
			go setXDBSysHealth(cacheTTLDay)
		}
		return cacheInfo.(*xbc.FileSysHealth), nil
	}
	return setXDBSysHealth(cacheTTLDay)
}

func setXDBSysHealth(duration int64) (*xbc.FileSysHealth, error) {
	xdbClient := xdb.GetXDBClient(config.GetXDBConfig())
	info, err := xdbClient.SysHealth()
	if err != nil {
		logger.Warnf("Get xdb system health failed, err: %s", err.Error())
		return nil, err
	}
	logger.Warnf("Get xdb system health finished.")

	GetCache().SetEx(CacheXDBSysHealth, info, duration)
	return info, nil
}

func GetTaskAlgoType(taskID string) int {
	var taskAlgoMap map[string]int
	if cacheInfo, ok := GetCache().Get(CacheTaskAlgoMap); ok {
		taskAlgoMap = cacheInfo.(map[string]int)
	} else {
		taskAlgoMap = make(map[string]int)
		GetCache().SetEx(CacheTaskAlgoMap, taskAlgoMap, cacheTTLHour*24)
	}

	if algoType, ok := taskAlgoMap[taskID]; ok {
		return algoType
	}

	// 未命中时, 进行链上任务查询
	reqCli, err := dai.GetRequesterClient()
	if err != nil {
		logger.Errorf("GetRequesterClient failed, err: %v", err)
		return -1
	}
	task, err := reqCli.GetTaskById(taskID)
	if err != nil {
		logger.Errorf("GetTaskById failed, err: %v", err)
		return -1
	}
	taskAlgoMap[taskID] = int(task.AlgoParam.Algo)

	return int(task.AlgoParam.Algo)
}

func GetCatalogFileDetail(dataType, id string) (*blockchain.CatalogFile, error) {
	mapNsFiles, err := GetNamespaceFilesMap(dataType, true)
	if err != nil {
		return nil, err
	}
	for _, cfiles := range mapNsFiles {
		for _, cfile := range cfiles {
			if cfile.FileID == id {
				return cfile, nil
			}
		}
	}

	// 缓存未命中时, 尝试线上查询一次
	cli, err := pbc.GetBlockchainClient()
	if err != nil {
		return nil, err
	}
	cfile, err := cli.GetCatalogFileDetailByID(id)
	// data model 可能类型对不上
	if err == nil {
		if cfile.Type == dataType {
			mapNsFiles[cfile.Namespace] = append(mapNsFiles[cfile.Namespace], &cfile)
			return &cfile, nil
		} else {
			return nil, fmt.Errorf("requested dataType is %s, but catalogFile.Type is %s", dataType, cfile.Type)
		}
	} else {
		return nil, err
	}

}

func GetNamespaceFilesMap(dataType string, useCahe bool) (map[string][]*blockchain.CatalogFile, error) {
	var cacheKey string
	if dataType == "data" {
		cacheKey = CacheNsFilesMapData
	} else {
		cacheKey = CacheNsFilesMapModel
	}

	cacheVal, ok := GetCache().Get(cacheKey)
	if ok && useCahe {
		return cacheVal.(map[string][]*blockchain.CatalogFile), nil
	}

	cli, err := pbc.GetBlockchainClient()
	if err != nil {
		return nil, err
	}
	data, err := cli.ListCatalogNs(&blockchain.ListCatalogNsOptions{
		Type: dataType,
	})
	if err != nil {
		return nil, err
	}

	ret := sync.Map{}
	// 并发查
	wg := new(sync.WaitGroup)
	getFileFunc := func(ns string) {
		defer wg.Done()
		files, err := cli.ListCatalogFiles(&blockchain.ListCatalogFilesOptions{
			Namespace:   ns,
			Type:        dataType,
			CurrentTime: time.Now().UnixNano(),
		})
		if err != nil {
			logger.Error("ListCatalogFiles in ListNs", err)
		}
		fileArr := []*blockchain.CatalogFile{}
		for idx, file := range files {
			if file.Status == blockchain.CatalogFileOnlineStatus {
				fileArr = append(fileArr, &files[idx])
			}
		}
		ret.Store(ns, fileArr)
	}
	// 筛选过后的data
	var newData blockchain.CatalogNsList
	// 获取用户信息中的orgid
	orgInfo, _ := beego.AppConfig.GetSection("orginfo")
	logger.Debugf("GetNamespaceFilesMap 审核未通过 %v", orgInfo)
	if orgInfo1 := GetOrgInfoByID(string(orgInfo["id"])); orgInfo1 != nil {
		logger.Debugf("GetNamespaceFilesMap 审核未通过 %v", orgInfo1)
		if orgInfo1.Apply == 0 {
			logger.Debugf("GetNamespaceFilesMap 审核未通过")
			for _, item := range data {
				if string(item.Owner[:]) == string(orgInfo1.Pubkey) {
					newData = append(newData, item)
				}
			}
			logger.Debugf("GetNamespaceFilesMap 审核未通过 %v", newData)
		} else {
			// 获取所有机构
			orgInfoList, err := GetOrgInfoList()
			if err != nil {
				logger.Error("GetOrgList failed:", err)
			}
			for _, info := range orgInfoList {
				if info.Apply == 1 {
					for _, item := range data {
						if string(item.Owner[:]) == string(info.Pubkey) {
							newData = append(newData, item)
						}
					}
				}
			}
		}
	}

	for _, item := range newData {
		if len(item.Name) == 0 {
			continue
		}
		wg.Add(1)
		go getFileFunc(item.Name)
	}
	wg.Wait()

	res := make(map[string][]*blockchain.CatalogFile)
	ret.Range(func(key, value interface{}) bool {
		res[key.(string)] = value.([]*blockchain.CatalogFile)
		return true
	})

	GetCache().SetEx(cacheKey, res, cacheTTLMin)
	return res, err
}

// GetExecutorList 返回任务执行器列表
func GetExecutorList() (executorList []dbc.ExecutorNode, err error) {
	if cacheItem, ok := GetCache().Get(CacheExecutorList); !ok {
		// 获取所有的执行器
		reqCli, err := dai.GetRequesterClient()
		if err != nil {
			logger.Errorf("GetRequesterClient failed, err: %v", err)
			return nil, err
		}
		executorNodes, err := reqCli.ListExecutorNodes()
		if err != nil {
			logger.Errorf("ListExecutorNodes failed, err: %v", err)
			return nil, err
		}

		for _, executorNode := range executorNodes {
			executorList = append(executorList, executorNode)
		}

		GetCache().SetEx(CacheExecutorList, executorList, cacheTTLMin)
		return executorList, nil
	} else {
		return cacheItem.([]dbc.ExecutorNode), nil
	}
}

func GetOrgInfoList() ([]*blockchain.OrgInfo, error) {
	orgInfoList, ok := GetCache().Get(CacheOrgInfoList)
	if !ok {
		cli, err := pbc.GetBlockchainClient()
		if err != nil {
			return nil, err
		}
		orgInfoList, err = cli.ListOrgInfo()
		if err != nil {
			return nil, err
		}
		GetCache().SetEx(CacheOrgInfoList, orgInfoList, cacheTTLMin)
	}

	return orgInfoList.([]*blockchain.OrgInfo), nil
}

// 带缓存的查询
func GetOrgInfoByPK(pubkey string) (orgInfo *blockchain.OrgInfo) {
	orgInfoList, err := GetOrgInfoList()
	if err != nil {
		return nil
	}

	for _, orgInfo := range orgInfoList {
		if string(orgInfo.Pubkey) == pubkey {
			return orgInfo
		}
	}
	return nil
}

// 带缓存的查询
func GetOrgInfoByID(orgID string) (orgInfo *blockchain.OrgInfo) {
	orgInfoList, err := GetOrgInfoList()
	if err != nil {
		return nil
	}

	for _, orgInfo := range orgInfoList {
		if orgInfo.ID == orgID {
			return orgInfo
		}
	}
	return nil
}

// 带缓存的查询
func GetOrgInfoByName(orgName string) *blockchain.OrgInfo {
	if orgName == "" {
		return nil
	}

	orgInfoList, err := GetOrgInfoList()
	if err != nil {
		return nil
	}

	for _, orgInfo := range orgInfoList {
		if orgInfo.Name == orgName {
			return orgInfo
		}
	}
	return nil
}
