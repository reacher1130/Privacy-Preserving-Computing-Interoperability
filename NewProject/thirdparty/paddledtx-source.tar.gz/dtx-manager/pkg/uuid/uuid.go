package uuid

import (
	uuid "github.com/satori/go.uuid"
)

// GenUUID generate uuid v4
func GenUUID() string {
	return uuid.NewV4().String()
}

// ValidUUID valid uuid
func ValidUUID(uid string) bool {
	_, err := uuid.FromString(uid)
	return err == nil
}
