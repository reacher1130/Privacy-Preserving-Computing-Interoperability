// Package 测试工具, 线下生成Header 签名参数
package main

import (
	"baidu/blockchain/dtx-manager/controllers"
	"encoding/hex"
	"fmt"
	"time"

	"github.com/xuperchain/crypto/client/service/xchain"
)

// var privateKey = "{\"Curvname\":\"P-256\",\"X\":70198575946712020153343767490333640815836345458244284812951767135094527850077,\"Y\":84197415022087799490484611211607695604299543129749978553839446179891048287817,\"D\":26885028506293168459482658847400183432735407890665826880539374109744615651220}"

var privateKey = "{\"Curvname\":\"P-256\",\"X\":84481410971599616841556660120626165092168860307846393821186493541503177245161,\"Y\":21228896261419530668031774289491310293962432593862980929295640038766904269305,\"D\":20673437276839049330343984781102343810083452724353501637945501797763864702445}"

func main() {
	info :=
		`fileName=data.csv`

	c := &controllers.BaseController{}
	fmt.Println("X-User-Pubkey:", c.ConvertPubKeyToJS(privateKey))
	fmt.Println("Authorization:", GenerateAuthorization(info))

	// pk, pub, _ := ecdsa.GenerateKeyPair()
	// fmt.Println(pk.String())
	// fmt.Println(pub.String())
}

func GenerateAuthorization(str string) string {
	timestamp := time.Now().Unix()
	xcc := new(xchain.XchainCryptoClient)
	priKey, _ := xcc.GetEcdsaPrivateKeyFromJsonStr(privateKey)
	hash := xcc.HashUsingSha256([]byte(fmt.Sprintf("%s%d", str, timestamp)))
	sign, _ := xcc.SignECDSA(priKey, hash)
	ret := hex.EncodeToString(sign)
	return fmt.Sprintf("auth-v1/%d/%s", timestamp, ret)
}
