module baidu/blockchain/dtx-manager

go 1.17

require (
	github.com/beego/beego/v2 v2.0.1
	github.com/spf13/viper v1.8.1
)

require (
	bou.ke/monkey v1.0.2
	github.com/PaddlePaddle/PaddleDTX/crypto v0.0.0
	github.com/PaddlePaddle/PaddleDTX/dai v0.0.0
	github.com/PaddlePaddle/PaddleDTX/xdb v0.0.0
	github.com/cloudflare/cfssl v0.0.0-20180223231731-4e2dcbde5004
	github.com/go-sql-driver/mysql v1.5.0
	github.com/google/uuid v1.3.0
	github.com/hyperledger/fabric-sdk-go v1.0.0-beta1
	github.com/smartystreets/goconvey v1.7.2
	github.com/test-go/testify v1.1.4
	github.com/xuperchain/crypto v0.0.0-20211221122406-302ac826ac90
	google.golang.org/grpc v1.41.0
)

require (
	github.com/ChainSafe/go-schnorrkel v0.0.0-20200626160457-b38283118816
	github.com/Knetic/govaluate v3.0.1-0.20171022003610-9aa49832a739+incompatible
	github.com/beorn7/perks v1.0.1
	github.com/btcsuite/btcd v0.20.1-beta
	github.com/btcsuite/btcutil v0.0.0-20190425235716-9e5f4b9a998d
	github.com/cespare/xxhash/v2 v2.2.0
	github.com/cjqpker/slidewindow v1.0.2
	github.com/consensys/gnark-crypto v0.5.3
	github.com/cosmos/go-bip39 v0.0.0-20180819234021-555e2067c45d
	github.com/davecgh/go-spew v1.1.1
	github.com/fsnotify/fsnotify v1.6.0
	github.com/go-kit/kit v0.10.0
	github.com/go-logfmt/logfmt v0.5.1
	github.com/gogo/protobuf v1.3.2
	github.com/golang/mock v1.5.0
	github.com/golang/protobuf v1.5.2
	github.com/google/certificate-transparency-go v1.0.21
	github.com/gopherjs/gopherjs v1.17.2
	github.com/grpc-ecosystem/grpc-gateway v1.16.0
	github.com/gtank/merlin v0.1.1-0.20191105220539-8318aed1a79f
	github.com/gtank/ristretto255 v0.1.2
	github.com/hashicorp/golang-lru v0.5.5-0.20210104140557-80c98217689d
	github.com/hashicorp/hcl v1.0.0
	github.com/hyperledger/burrow v0.30.5
	github.com/hyperledger/fabric-lib-go v1.0.0
	github.com/hyperledger/fabric-protos-go v0.0.0-20200707132912-fee30f3ccd23
	github.com/jtolds/gls v4.20.0+incompatible
	github.com/libp2p/go-buffer-pool v0.0.2
	github.com/magiconair/properties v1.8.5
	github.com/matttproud/golang_protobuf_extensions v1.0.4
	github.com/mimoo/StrobeGo v0.0.0-20181016162300-f8f6d4d2b643
	github.com/mitchellh/mapstructure v1.4.1
	github.com/pelletier/go-toml v1.9.3
	github.com/pkg/errors v0.9.1
	github.com/pmezard/go-difflib v1.0.0
	github.com/prometheus/client_golang v1.14.0
	github.com/prometheus/client_model v0.3.0
	github.com/prometheus/common v0.39.0
	github.com/prometheus/procfs v0.9.0
	github.com/satori/go.uuid v1.2.0
	github.com/shiena/ansicolor v0.0.0-20151119151921-a422bbe96644
	github.com/sirupsen/logrus v1.9.0
	github.com/smartystreets/assertions v1.13.0
	github.com/spf13/afero v1.6.0
	github.com/spf13/cast v1.3.1
	github.com/spf13/jwalterweatherman v1.1.0
	github.com/spf13/pflag v1.0.5
	github.com/stretchr/testify v1.8.4
	github.com/subosito/gotenv v1.2.0
	github.com/tendermint/go-amino v0.14.1
	github.com/tendermint/tendermint v0.33.1
	github.com/tmthrgd/go-hex v0.0.0-20190303111820-0bdcb15db631
	github.com/xuperchain/xuper-sdk-go v0.0.0-20210430070222-16051cc40b09
	golang.org/x/crypto v0.11.0
	golang.org/x/mod v0.9.0
	golang.org/x/net v0.10.0
	golang.org/x/sys v0.10.0
	golang.org/x/text v0.11.0
	golang.org/x/tools v0.7.0
	google.golang.org/genproto v0.0.0-20211208223120-3a66f561d7aa
	google.golang.org/protobuf v1.28.1
	gopkg.in/ini.v1 v1.67.0
	gopkg.in/yaml.v2 v2.4.0
	gopkg.in/yaml.v3 v3.0.1
	k8s.io/apimachinery v0.21.2
	k8s.io/client-go v0.21.2
)

require (
	github.com/go-logr/logr v0.4.0 // indirect
	github.com/google/go-cmp v0.5.9 // indirect
	github.com/google/gofuzz v1.1.0 // indirect
	github.com/googleapis/gnostic v0.4.1 // indirect
	github.com/imdario/mergo v0.3.7 // indirect
	github.com/json-iterator/go v1.1.12 // indirect
	github.com/modern-go/concurrent v0.0.0-20180306012644-bacd9c7ef1dd // indirect
	github.com/modern-go/reflect2 v1.0.2 // indirect
	golang.org/x/oauth2 v0.3.0 // indirect
	golang.org/x/term v0.10.0 // indirect
	golang.org/x/time v0.0.0-20210220033141-f8bda1e9f3ba // indirect
	google.golang.org/appengine v1.6.7 // indirect
	gopkg.in/inf.v0 v0.9.1 // indirect
	k8s.io/api v0.21.2 // indirect
	k8s.io/klog/v2 v2.8.0 // indirect
	k8s.io/utils v0.0.0-20201110183641-67b214c5f920 // indirect
	sigs.k8s.io/structured-merge-diff/v4 v4.1.0 // indirect
	sigs.k8s.io/yaml v1.2.0 // indirect
)

replace github.com/go-kit/kit => github.com/go-kit/kit v0.8.0

replace github.com/xuperchain/crypto v0.0.0-20211221122406-302ac826ac90 => github.com/xuperchain/crypto v0.0.0-20200701044454-40fff89406a7

replace github.com/PaddlePaddle/PaddleDTX/dai => ../PaddleDTX/dai

replace github.com/PaddlePaddle/PaddleDTX/crypto => ../PaddleDTX/crypto

replace github.com/PaddlePaddle/PaddleDTX/xdb => ../PaddleDTX/xdb

replace baidu/blockchain/dtx-manager => ../dtx-manager
