package xchain

import (
	"strings"

	"github.com/xuperchain/xuper-sdk-go/account"
	"github.com/xuperchain/xuper-sdk-go/contract"
	"github.com/xuperchain/xuper-sdk-go/xchain"

	"baidu/blockchain/dtx-manager/config"
	errorx "baidu/blockchain/dtx-manager/pkg/codeerror"
)

type XChain struct {
	DtxContractName     string              // DtxContractName is name of dtx contract
	ManagerContractName string              // ManagerContractName is name of dtx-manager contract
	ContractAccount     string              // ContractAccount is a contract account
	ChainName           string              // ChainName is name of blockchain
	Account             *account.Account    // Account is the local account, and is also the client account to request blockchain
	XchainClient        *xchain.XuperClient // XchainClient is the util used to connect and request blockchain
}

// New creates a XChain client which is used for connecting and requesting blockchain
func New(conf *config.XchainConf) (*XChain, error) {
	if len(conf.Mnemonic) == 0 {
		return nil, errorx.NewError(errorx.ErrCodeConfig, "missing mnemonic")
	}
	if len(conf.DtxContractName) == 0 {
		return nil, errorx.NewError(errorx.ErrCodeConfig, "missing contract-name")
	}
	if len(conf.ContractAccount) == 0 {
		return nil, errorx.NewError(errorx.ErrCodeConfig, "missing contract-account")
	}
	if len(conf.ChainAddress) == 0 {
		return nil, errorx.NewError(errorx.ErrCodeConfig, "missing chain-node")
	}
	if len(conf.ChainName) == 0 {
		return nil, errorx.NewError(errorx.ErrCodeConfig, "missing chain-name")
	}
	// get xchain account using mnemonic
	acc, err := account.RetrieveAccount(conf.Mnemonic, 1)
	if err != nil {
		return nil, errorx.New(err, errorx.ErrCodeInternal,
			"RetrieveAccount failed, err: %v", err)
	}
	// create xchain client
	xuperClient, err := xchain.NewXuperClient(conf.ChainAddress)
	if err != nil {
		return nil, errorx.New(err, errorx.ErrCodeInternal,
			"NewXuperClient failed, err: %v", err)
	}
	return &XChain{
		DtxContractName:     conf.DtxContractName,
		ManagerContractName: conf.ManagerContractName,
		ContractAccount:     conf.ContractAccount,
		ChainName:           conf.ChainName,
		Account:             acc,
		XchainClient:        xuperClient,
	}, nil
}

// 调用dtx dai合约函数
func (x *XChain) InvokeDtxContract(args map[string]string, mName string) ([]byte, error) {
	// initiate client for native contract
	nativeContract := contract.InitNativeContractWithClient(
		x.Account, x.ChainName, x.DtxContractName, x.ContractAccount, x.XchainClient)
	return invokeContract(nativeContract, args, mName)
}

// 调用dtx manager合约
func (x *XChain) InvokeManagerContract(args map[string]string, mName string) ([]byte, error) {
	// initiate client for native contract
	nativeContract := contract.InitNativeContractWithClient(
		x.Account, x.ChainName, x.ManagerContractName, x.ContractAccount, x.XchainClient)
	return invokeContract(nativeContract, args, mName)
}

// 查询dtx dai合约函数
func (x *XChain) QueryDtxContract(args map[string]string, mName string) ([]byte, error) {
	// initiate client for native contract
	nativeContract := contract.InitNativeContractWithClient(
		x.Account, x.ChainName, x.DtxContractName, x.ContractAccount, x.XchainClient)
	return queryContract(nativeContract, args, mName)
}

// 查询dtx manager合约
func (x *XChain) QueryManagerContract(args map[string]string, mName string) ([]byte, error) {
	// initiate client for native contract
	nativeContract := contract.InitNativeContractWithClient(
		x.Account, x.ChainName, x.ManagerContractName, x.ContractAccount, x.XchainClient)
	return queryContract(nativeContract, args, mName)
}

// InvokeContract invokes the contract
func invokeContract(nativeContract *contract.NativeContract, args map[string]string, mName string) ([]byte, error) {
	// pre-invoke contract
	preSelectUTXOResponse, err := nativeContract.PreInvokeNativeContract(mName, args)
	if err != nil {
		// handle error
		indexStart := strings.Index(err.Error(), "{")
		indexStop := strings.Index(err.Error(), "}")
		if indexStart > 0 && indexStop > 0 && indexStop >= indexStart {
			message := err.Error()[indexStart : indexStop+1]
			if len(message) > 0 {
				if c, m, ok := errorx.TryParseFromString(message); ok {
					return nil, errorx.WithMessage(errorx.NewError(c, m), "failed to PreInvokeNativeContract")
				}
			}
		}
		return nil, errorx.WithMessage(err, "failed to PreInvokeNativeContract")
	}
	// invoke contract
	txid, err := nativeContract.PostNativeContract(preSelectUTXOResponse)
	if err != nil {
		return nil, errorx.New(err, errorx.ErrCodeInternal,
			"PostNativeContract failed, err: %v", err)
	}
	return []byte(txid), nil
}

// QueryContract queries the contract
func queryContract(nativeContract *contract.NativeContract, args map[string]string, mName string) ([]byte, error) {
	// send request
	resp, err := nativeContract.QueryNativeContract(mName, args)
	if err != nil {
		// handle error
		indexStart := strings.Index(err.Error(), "{")
		indexStop := strings.Index(err.Error(), "}")
		if indexStart > 0 && indexStop > 0 && indexStop >= indexStart {
			message := err.Error()[indexStart : indexStop+1]
			if len(message) > 0 {
				if c, m, ok := errorx.TryParseFromString(message); ok {
					return nil, errorx.WithMessage(errorx.NewError(c, m), "failed to QueryNativeContract")
				}
			}
		}
		return nil, errorx.WithMessage(err, "failed to QueryNativeContract")
	}
	return resp.GetResponse().GetResponses()[0].GetBody(), nil
}
