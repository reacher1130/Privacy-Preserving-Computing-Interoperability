package xchain

import (
	"baidu/blockchain/dtx-manager/blockchain"
	errorx "baidu/blockchain/dtx-manager/pkg/codeerror"
	"encoding/json"
)

// PublishCatalogFileAuth 发布目录链申请权限
func (x *XChain) PublishCatalogFileAuth(opt *blockchain.PublishCatalogFileAuthOptions) error {
	s, err := json.Marshal(*opt)
	if err != nil {
		return errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal PublishCatalogFileAuthOptions")
	}
	args := map[string]string{
		"opt": string(s),
	}
	mName := "PublishCatalogFileAuth"
	if _, err = x.InvokeManagerContract(args, mName); err != nil {
		return err
	}
	return nil
}

// ConfirmCatalogFileAuth 确认权限申请
func (x *XChain) ConfirmCatalogFileAuth(opt *blockchain.ConfirmCatalogFileAuthOptions) error {
	s, err := json.Marshal(*opt)
	if err != nil {
		return errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal ConfirmCatalogFileAuthOptions")
	}
	args := map[string]string{
		"opt": string(s),
	}
	mName := "ConfirmCatalogFileAuth"
	if _, err = x.InvokeManagerContract(args, mName); err != nil {
		return err
	}
	return nil
}

// RejectCatalogFileAuth 拒绝资源权限权限申请
func (x *XChain) RejectCatalogFileAuth(opt *blockchain.RejectCatalogFileAuthOptions) error {
	s, err := json.Marshal(*opt)
	if err != nil {
		return errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal RejectCatalogFileAuth")
	}
	args := map[string]string{
		"opt": string(s),
	}
	mName := "RejectCatalogFileAuth"
	if _, err = x.InvokeManagerContract(args, mName); err != nil {
		return err
	}
	return nil
}

// RecycleCatalogFileAuth 回收资源权限权限申请
func (x *XChain) RecycleCatalogFileAuth(opt *blockchain.RecycleCatalogFileAuthOptions) error {
	s, err := json.Marshal(*opt)
	if err != nil {
		return errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal RecycleCatalogFileAuthOptions")
	}
	args := map[string]string{
		"opt": string(s),
	}
	mName := "RecycleCatalogFileAuth"
	if _, err = x.InvokeManagerContract(args, mName); err != nil {
		return err
	}
	return nil
}

// ListCatalogFileAuth 查询授权申请列表
func (x *XChain) ListCatalogFileAuth(opt *blockchain.ListCatalogFileAuthOptions) (blockchain.CatalogFileAuthList, error) {
	var f blockchain.CatalogFileAuthList
	opts, err := json.Marshal(*opt)
	if err != nil {
		return f, errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal ListCatalogFileAuthOptions")
	}
	args := map[string]string{
		"opt": string(opts),
	}
	mName := "ListCatalogFileAuth"
	resp, err := x.QueryManagerContract(args, mName)
	if err != nil {
		return f, err
	}
	if err = json.Unmarshal([]byte(resp), &f); err != nil {
		return f, errorx.New(err, errorx.ErrCodeInternal,
			"failed to unmarshal CatalogFileAuthList")
	}
	return f, nil
}

// GetCatalogFileAuthDetailByID 查询授权申请详情
func (x *XChain) GetCatalogFileAuthDetailByID(authID string) (blockchain.CatalogFileAuthApplication, error) {
	var f blockchain.CatalogFileAuthApplication
	args := map[string]string{
		"id": authID,
	}
	mName := "GetCatalogFileAuthDetailByID"
	s, err := x.QueryManagerContract(args, mName)
	if err != nil {
		return f, err
	}
	if err = json.Unmarshal([]byte(s), &f); err != nil {
		return f, errorx.New(err, errorx.ErrCodeInternal,
			"failed to unmarshal CatalogFileAuth")
	}

	return f, nil
}
