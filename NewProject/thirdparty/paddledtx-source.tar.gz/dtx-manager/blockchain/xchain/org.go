package xchain

import (
	"baidu/blockchain/dtx-manager/blockchain"
	errorx "baidu/blockchain/dtx-manager/pkg/codeerror"
	"encoding/json"
)

// SetOrgInfo
func (x *XChain) SetOrgInfo(opt *blockchain.OrgInfo) error {
	s, err := json.Marshal(*opt)
	if err != nil {
		return errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal OrgInfoOptions")
	}
	args := map[string]string{
		"opt": string(s),
	}
	mName := "SetOrgInfo"
	if _, err = x.InvokeManagerContract(args, mName); err != nil {
		return err
	}
	return nil
}

// QueryOrgInfo
func (x *XChain) QueryOrgInfo(id string) (*blockchain.OrgInfo, error) {
	var org blockchain.OrgInfo
	args := map[string]string{
		"id": id,
	}
	mName := "QueryOrgInfo"
	resp, err := x.QueryManagerContract(args, mName)
	if err != nil {
		return nil, err
	}
	if err = json.Unmarshal([]byte(resp), &org); err != nil {
		return nil, errorx.New(err, errorx.ErrCodeInternal, "fail to unmarshal OrgInfo")
	}
	return &org, nil
}

// QueryOrgInfoByPK
func (x *XChain) QueryOrgInfoByPK(pubkey string) (*blockchain.OrgInfo, error) {
	var org blockchain.OrgInfo
	args := map[string]string{
		"id": pubkey,
	}
	mName := "QueryOrgInfoByPK"
	resp, err := x.QueryManagerContract(args, mName)
	if err != nil {
		return nil, err
	}
	if err = json.Unmarshal([]byte(resp), &org); err != nil {
		return nil, errorx.New(err, errorx.ErrCodeInternal, "fail to unmarshal OrgInfo")
	}
	return &org, nil
}

// ListOrgInfo
func (x *XChain) ListOrgInfo() ([]*blockchain.OrgInfo, error) {
	var orgs []*blockchain.OrgInfo

	args := map[string]string{}
	mName := "ListOrgInfo"
	resp, err := x.QueryManagerContract(args, mName)
	if err != nil {
		return nil, err
	}
	if err = json.Unmarshal([]byte(resp), &orgs); err != nil {
		return nil, errorx.New(err, errorx.ErrCodeInternal, "fail to unmarshal OrgInfo")
	}
	return orgs, nil

}
