package main

import (
	"encoding/json"

	util "github.com/PaddlePaddle/PaddleDTX/xdb/pkgs/strings"
	"github.com/xuperchain/xuperchain/core/contractsdk/go/code"

	"baidu/blockchain/dtx-manager/blockchain"
	errorx "baidu/blockchain/dtx-manager/pkg/codeerror"
)

func (m *DtxManager) SetOrgInfo(ctx code.Context) code.Response {
	// get
	s, ok := ctx.Args()["opt"]
	if !ok {
		return code.Error(errorx.NewError(errorx.ErrCodeParam, "invalid arguments. expecting OrgInfo"))
	}

	// unmarshal opt
	var opt blockchain.OrgInfo
	if err := json.Unmarshal(s, &opt); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeInternal, "failed to unmarshal OrgInfo"))
	}

	msg, err := util.GetSigMessage(opt)
	if err != nil {
		return code.Error(errorx.Internal(err, "failed to get the message to sign"))
	}
	// verify signature by applier's public key
	err = m.checkSign(opt.Signature, opt.Pubkey, []byte(msg))
	if err != nil {
		return code.Error(errorx.Internal(err, "failed to verify signature"))
	}

	indexPK := packOrgInfoPK(opt.Pubkey)
	if err := ctx.PutObject([]byte(indexPK), s); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeWriteBlockchain, "failed to set SetOrgInfo on chain"))
	}

	indexID := packOrgInfoID([]byte(opt.ID))
	if err := ctx.PutObject([]byte(indexID), s); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeWriteBlockchain, "failed to set SetOrgInfo on chain"))
	}

	return code.OK([]byte("OK"))

}

func (m *DtxManager) queryOrgInfoByIndex(ctx code.Context, idx []byte) code.Response {
	if resp, err := ctx.GetObject(idx); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeNotFound, "OrgInfo not found"))
	} else {
		return code.OK(resp)
	}
}

func (m *DtxManager) QueryOrgInfoByPK(ctx code.Context) code.Response {
	// get
	pk, ok := ctx.Args()["id"]
	if !ok {
		return code.Error(errorx.NewError(errorx.ErrCodeParam, "invalid arguments. expecting OrgInfo.Pubkey"))
	}

	indexPK := packOrgInfoPK([]byte(string(pk)))
	return m.queryOrgInfoByIndex(ctx, []byte(indexPK))
}

func (m *DtxManager) QueryOrgInfo(ctx code.Context) code.Response {
	// get
	id, ok := ctx.Args()["id"]
	if !ok {
		return code.Error(errorx.NewError(errorx.ErrCodeParam, "invalid arguments. expecting OrgInfo.ID"))
	}

	indexID := packOrgInfoID(id)
	return m.queryOrgInfoByIndex(ctx, []byte(indexID))
}

func (m *DtxManager) ListOrgInfo(ctx code.Context) code.Response {

	// get iter by prefix
	iter := ctx.NewIterator(code.PrefixRange([]byte(prefixOrgInfoID)))
	defer iter.Close()

	// iterate iter
	var orgs []*blockchain.OrgInfo
	for iter.Next() {
		var org blockchain.OrgInfo
		err := json.Unmarshal(iter.Value(), &org)
		if err != nil {
			return code.Error(err)
		}
		orgs = append(orgs, &org)
	}

	s, err := json.Marshal(orgs)
	if err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal OrgInfoList"))
	}
	return code.OK(s)
}
