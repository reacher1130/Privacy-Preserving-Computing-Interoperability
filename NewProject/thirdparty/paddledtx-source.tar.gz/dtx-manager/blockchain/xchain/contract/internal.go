package main

import (
	"fmt"
	"math"
)

const (
	// orgInfo
	prefixOrgInfoPK = "index_orgInfo_pk"
	prefixOrgInfoID = "index_orgInfo_id"

	// Define the contract prefix key of file and file namespace operations
	prefixCatalogFilenameIndex     = "index_catalog_fn"
	prefixCatalogFileListByNsIndex = "index_catalog_fs_list"
	prefixCatalogOwnerNsIndex      = "index_catalog_ofns"
	prefixCatalogNsIndex           = "index_catalog_fns"
	prefixCatalogNsListIndex       = "index_catalog_fns_list"
	prefixCatalogFileIDIndex       = "index_catalog_fid"
	// Define the contract prefix key of catalog file authorization application operations
	prefixCatalogFileAuthIndex           = "index_catalog_auth"
	prefixCatalogFileAuthApplierIndex    = "index_catalog_fa_applier"
	prefixCatalogFileAuthAuthorizerIndex = "index_catalog_fa_authorizer"
	prefixCatalogFileAuthListIndex       = "index_catalog_fa_list"
)

func packOrgInfoPK(pubkey []byte) string {
	return fmt.Sprintf("%s/%x", prefixOrgInfoPK, pubkey)
}

func packOrgInfoID(id []byte) string {
	return fmt.Sprintf("%s/%x", prefixOrgInfoID, id)
}

// packCatalogNsIndex 定义目录链合约key前缀
// example： key为 `index_catalog_fns/数据模型/ns创建人/ns名称`
func packCatalogOwnerNsIndex(owner []byte, dataType, ns string) string {
	return fmt.Sprintf("%s/%s/%x/%s", prefixCatalogOwnerNsIndex, dataType, owner, ns)
}

// packCatalogNsIndex 定义目录链合约key前缀
// example： key为 `index_catalog_fns/数据模型/ns名称`
func packCatalogNsIndex(dataType, ns string) string {
	return fmt.Sprintf("%s/%s/%s", prefixCatalogNsIndex, dataType, ns)
}

// packCatalogNsListIndex 定义目录链列表合约key前缀
// example： list key为 `index_catalog_fns_list/数据模型/ns创建人/创建时间/ns名称`
func packCatalogNsListIndex(owner []byte, dataType, ns string, createTime int64) string {
	return fmt.Sprintf("%s/%s/%x/%d/%s", prefixCatalogNsListIndex, dataType, owner, subByInt64Max(createTime), ns)
}

// packCatalogNsListFilter 定义目录链列表查询过滤器
func packCatalogNsListFilter(dataType string, owner []byte) string {
	filter := prefixCatalogNsListIndex + "/" + dataType + "/"
	if len(owner) > 0 {
		filter += fmt.Sprintf("%x/", owner)
	}
	return filter
}

// packCatalogFileIDIndex 定义目录链合约key前缀
// example： key为 `index_catalog_fid/fileID`
func packCatalogFileIDIndex(fileID string) string {
	return fmt.Sprintf("%s/%s", prefixCatalogFileIDIndex, fileID)
}

// packFileNameIndex 定义目录链合约key前缀
// example： key为 `index_catalog_fn/type数据资源/ns/文件名称`
func packFileNameIndex(dataType, ns, name string) string {
	return fmt.Sprintf("%s/%s/%s/%s", prefixCatalogFilenameIndex, dataType, ns, name)
}

// packCatalogFileListByNsIndex used to list catalog files by ns, ns+pubTime+name is combined into a contract unique key
// 查询目录链下文件列表
func packCatalogFileListByNsIndex(dataType, ns string, pubTime int64) string {
	return fmt.Sprintf("%s/%s/%s/%d", prefixCatalogFileListByNsIndex, dataType, ns, subByInt64Max(pubTime))
}

// packCatalogFileNameFilter 定义目录链下文件列表查询过滤器
func packCatalogFileNameFilter(dataType, ns string) string {
	filter := prefixCatalogFileListByNsIndex + "/" + dataType + "/" // default
	if len(ns) > 0 {
		filter += fmt.Sprintf("%s/", ns)
	}
	return filter
}

// packCatalogFileAuthIndex 定义目录链文件授权合约key前缀
// example： key为 `index_catalog_auth/授权ID`
func packCatalogFileAuthIndex(id string) string {
	return fmt.Sprintf("%s/%s", prefixCatalogFileAuthIndex, id)
}

// packCatalogFileAuthApplierIndex 定义目录链文件授权合约key前缀
// example： key为 `index_catalog_fa_applier/资源类型/申请者/申请授权时间/授权ID`
func packCatalogFileAuthApplierIndex(applier []byte, dataType, authID string, createTime int64) string {
	return fmt.Sprintf("%s/%s/%x/%d/%s", prefixCatalogFileAuthApplierIndex, dataType, applier, subByInt64Max(createTime), authID)
}

// packCatalogFileAuthAuthorizerIndex 定义目录链文件授权合约key前缀
// example：key为 `index_catalog_fa_authorizer/资源类型/授权者/申请授权时间/授权ID`
func packCatalogFileAuthAuthorizerIndex(authorizer []byte, dataType, authID string, createTime int64) string {
	return fmt.Sprintf("%s/%s/%x/%d/%s", prefixCatalogFileAuthAuthorizerIndex, dataType, authorizer, subByInt64Max(createTime), authID)
}

// packApplierAndAuthorizerIndex define the contract key for applier and authorizer file authorization application
// example：key为 `index_catalog_fa_list/资源类型/申请者/授权者/申请授权时间/授权ID`
func packApplierAndAuthorizerIndex(applier, authorizer []byte, dataType, authID string, createTime int64) string {
	return fmt.Sprintf("%s/%s/%x/%x/%d/%s", prefixCatalogFileAuthListIndex, dataType, applier, authorizer, subByInt64Max(createTime), authID)
}

// packFileAuthFilter get the contract key for the authorization list of iterative query
func packCatalogFileAuthFilter(dataType string, applier, authorizer []byte) string {
	// If Applier and Authorizer public key not empty
	if len(applier) > 0 && len(authorizer) > 0 {
		return prefixCatalogFileAuthListIndex + "/" + fmt.Sprintf("%s/%x/%x/", dataType, applier, authorizer)
	} else if len(applier) > 0 {
		return prefixCatalogFileAuthApplierIndex + "/" + fmt.Sprintf("%s/%x/", dataType, applier)
	} else {
		return prefixCatalogFileAuthAuthorizerIndex + "/" + fmt.Sprintf("%s/%x/", dataType, authorizer)
	}
}

// return maxInt64 - N
func subByInt64Max(n int64) int64 {
	return math.MaxInt64 - n
}
