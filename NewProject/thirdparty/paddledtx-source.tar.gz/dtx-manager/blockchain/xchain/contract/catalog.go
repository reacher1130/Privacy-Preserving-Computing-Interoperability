package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"strconv"

	"github.com/PaddlePaddle/PaddleDTX/crypto/core/ecdsa"
	"github.com/PaddlePaddle/PaddleDTX/crypto/core/hash"
	util "github.com/PaddlePaddle/PaddleDTX/xdb/pkgs/strings"
	"github.com/xuperchain/xuperchain/core/contractsdk/go/code"

	"baidu/blockchain/dtx-manager/blockchain"
	errorx "baidu/blockchain/dtx-manager/pkg/codeerror"
)

// AddCatalogNamespace adds catalog namespace
func (m *DtxManager) AddCatalogNamespace(ctx code.Context) code.Response {
	// get AddFileNs
	s, ok := ctx.Args()["opt"]
	if !ok {
		return code.Error(errorx.NewError(errorx.ErrCodeParam, "missing param:opt"))
	}
	// unmarshal opt
	var opt blockchain.AddCatalogNsOptions
	if err := json.Unmarshal(s, &opt); err != nil {
		return code.Error(errorx.Internal(err, "failed to unmarshal AddCatalogNsOptions"))
	}

	ns := opt.Namespace
	// 判断命名空间资源类型, 仅支持模型资源或者数据资源
	if ns.Type != blockchain.CatalogFileTypeOfData && ns.Type != blockchain.CatalogFileTypeOfModel {
		return code.Error(errorx.NewError(errorx.ErrCodeParam, "invalid param:dataType"))
	}

	s, err := json.Marshal(ns)
	if err != nil {
		return code.Error(errorx.Internal(err, "failed to marshal namespace"))
	}
	// get the message to sign
	msg, err := util.GetSigMessage(opt)
	if err != nil {
		return code.Error(errorx.Internal(err, "failed to get the message to sign"))
	}
	// verify sig
	err = m.checkSign(opt.Signature, ns.Owner, []byte(msg))
	if err != nil {
		return code.Error(err)
	}

	// judge if packCatalogNsIndex exists
	catalogNsIndex := packCatalogNsIndex(ns.Type, ns.Name)
	// get catalog ns
	if _, err := ctx.GetObject([]byte(catalogNsIndex)); err == nil {
		return code.Error(errorx.NewError(errorx.ErrCodeAlreadyExists, "duplicated catalog namespace"))
	}

	// put index-catalog-ns on chain
	if err := ctx.PutObject([]byte(catalogNsIndex), s); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeWriteBlockchain, "failed to set index-catalog-ns on chain"))
	}

	// put index-catalog-owner-ns on chain
	catalogOwnerNsIndex := packCatalogOwnerNsIndex(ns.Owner, ns.Type, ns.Name)
	if err := ctx.PutObject([]byte(catalogOwnerNsIndex), s); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeWriteBlockchain, "failed to set index-catalog-owner-ns on chain"))
	}

	// put listIndex-catalog-ns on chain
	nsCatalogListIndex := packCatalogNsListIndex(ns.Owner, ns.Type, ns.Name, ns.CreateTime)
	if err := ctx.PutObject([]byte(nsCatalogListIndex), s); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeWriteBlockchain, "failed to set listIndex-catalog-ns on chain"))
	}

	return code.OK([]byte("OK"))
}

// ListCatalogNs lists catalog namespace
func (m *DtxManager) ListCatalogNs(ctx code.Context) code.Response {
	// get opt
	s, ok := ctx.Args()["opt"]
	if !ok {
		return code.Error(errorx.NewError(errorx.ErrCodeParam, "missing param:opt"))
	}
	// unmarshal opt
	var opt blockchain.ListCatalogNsOptions
	if err := json.Unmarshal(s, &opt); err != nil {
		return code.Error(errorx.Internal(err,
			"failed to unmarshal ListCatalogNsOptions"))
	}
	// 判断命名空间资源类型, 仅支持模型资源或者数据资源
	if opt.Type != blockchain.CatalogFileTypeOfData && opt.Type != blockchain.CatalogFileTypeOfModel {
		return code.Error(errorx.NewError(errorx.ErrCodeParam, "invalid param:dataType"))
	}
	// pack prefix
	// 目录链查询,
	prefix := packCatalogNsListFilter(opt.Type, opt.Owner)

	// get iter by prefix
	iter := ctx.NewIterator(code.PrefixRange([]byte(prefix)))
	defer iter.Close()

	// iterate iter
	var nss []blockchain.CatalogNamespace
	for iter.Next() {
		if opt.Limit > 0 && int64(len(nss)) >= opt.Limit {
			break
		}
		var ns blockchain.CatalogNamespace
		if err := json.Unmarshal(iter.Value(), &ns); err != nil {
			return code.Error(errorx.New(err, errorx.ErrCodeInternal,
				"failed to unmarshal namespaces"))
		}
		if ns.CreateTime < opt.TimeStart || (opt.TimeEnd > 0 && ns.CreateTime > opt.TimeEnd) {
			continue
		}
		nss = append(nss, ns)
	}

	s, err := json.Marshal(nss)
	if err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal namespace list"))
	}
	return code.OK(s)
}

// PublishFileToCatalog publishes catalog files to chain
func (m *DtxManager) PublishFileToCatalog(ctx code.Context) code.Response {
	// get PublishFileToCatalogOptions
	s, ok := ctx.Args()["opt"]
	if !ok {
		return code.Error(errorx.NewError(errorx.ErrCodeParam, "missing param:catalogFile"))
	}
	// unmarshal opt
	var opt blockchain.PublishFileToCatalogOptions
	if err := json.Unmarshal(s, &opt); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeInternal,
			"failed to unmarshal PublishFileToCatalogOptions"))
	}
	// get file
	f := opt.File

	// 判断资源类型, 仅支持模型资源或者数据资源
	if f.Type != blockchain.CatalogFileTypeOfData && f.Type != blockchain.CatalogFileTypeOfModel {
		return code.Error(errorx.NewError(errorx.ErrCodeParam, "invalid param:dataType"))
	}

	// verify sig
	msg, err := util.GetSigMessage(opt)
	if err != nil {
		return code.Error(errorx.Internal(err, "failed to get the message to sign"))
	}
	err = m.checkSign(opt.Signature, f.Owner, []byte(msg))
	if err != nil {
		return code.Error(err)
	}

	f.Status = blockchain.CatalogFileOnlineStatus

	// judge if fileid exists，判断文件ID是否重复
	catalogFileID := packCatalogFileIDIndex(opt.File.FileID)
	if _, err := ctx.GetObject([]byte(catalogFileID)); err == nil {
		return code.Error(errorx.NewError(errorx.ErrCodeAlreadyExists, "duplicated fileID"))
	}

	// judge if packCatalogNsIndex exists，判断目录是否存在
	fileNsIndex := packCatalogNsIndex(f.Type, f.Namespace)
	if _, err := ctx.GetObject([]byte(fileNsIndex)); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeNotFound, "file namespace not found"))
	}

	// judge if filenameIndex exists，判断文件名是否重复
	filenameIndex := packFileNameIndex(f.Type, f.Namespace, f.Name)
	if id, err := ctx.GetObject([]byte(filenameIndex)); err == nil {
		fc, err := m.getFileByID(ctx, id)
		if err != nil {
			return code.Error(err)
		}
		// 文件是否过期
		if fc.ExpireTime > f.PublishTime {
			return code.Error(errorx.NewError(errorx.ErrCodeAlreadyExists, "duplicated file name"))
		}
	}

	// marshal file
	s, err = json.Marshal(f)
	if err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeInternal, "failed to marshal File"))
	}

	// if there's already a file with the same name in user's storage, overwrite it with the new one directly
	// set id-file on chain，设置数据资源/模型资源内容
	if err := ctx.PutObject([]byte(catalogFileID), s); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeWriteBlockchain, "failed to set id-file on chain"))
	}
	// set filenameIndex-id on chain，通过文件名查询文件详情
	if err := ctx.PutObject([]byte(filenameIndex), []byte(catalogFileID)); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeWriteBlockchain, "failed to set index-id on chain"))
	}
	// 用于查询目录链下文件列表
	fileListByNsIndex := packCatalogFileListByNsIndex(f.Type, f.Namespace, f.PublishTime)
	if err := ctx.PutObject([]byte(fileListByNsIndex), []byte(catalogFileID)); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeWriteBlockchain, "failed to set file catalogFileListByNsIndex-id on chain"))
	}

	return code.OK([]byte("Published"))
}

// ListCatalogFiles lists catalog files. contians data files and model files.
func (m *DtxManager) ListCatalogFiles(ctx code.Context) code.Response {
	// get opt
	s, ok := ctx.Args()["opt"]
	if !ok {
		return code.Error(errorx.NewError(errorx.ErrCodeParam, "missing param:opt"))
	}
	// unmarshal opt
	var opt blockchain.ListCatalogFilesOptions
	if err := json.Unmarshal(s, &opt); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeInternal,
			"failed to unmarshal ListCatalogFilesOptions"))
	}

	// 判断资源类型, 仅支持模型资源或者数据资源
	if opt.Type != blockchain.CatalogFileTypeOfData && opt.Type != blockchain.CatalogFileTypeOfModel {
		return code.Error(errorx.NewError(errorx.ErrCodeParam, "invalid param:dataType"))
	}

	// pack prefix
	prefix := packCatalogFileNameFilter(opt.Type, opt.Namespace)

	// get iter by prefix
	iter := ctx.NewIterator(code.PrefixRange([]byte(prefix)))
	defer iter.Close()

	// iterate iter
	var fs []blockchain.CatalogFile
	for iter.Next() {
		if opt.Limit > 0 && int64(len(fs)) >= opt.Limit {
			break
		}
		f, err := m.getFileByID(ctx, iter.Value())
		if err != nil {
			return code.Error(err)
		}
		if f.PublishTime < opt.TimeStart || (opt.TimeEnd > 0 && f.PublishTime > opt.TimeEnd) || f.ExpireTime <= opt.CurrentTime {
			continue
		}
		if len(opt.Owner) > 0 && fmt.Sprintf("%x", f.Owner) != fmt.Sprintf("%x", opt.Owner) {
			continue
		}
		fs = append(fs, f)
	}

	s, err := json.Marshal(fs)
	if err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal Files"))
	}
	return code.OK(s)
}

// GetCatalogFileDetailByFileName 根据文件名称查询文件详情
// 参数 currentTime用于判断文件是否过期
func (m *DtxManager) GetCatalogFileDetailByFileName(ctx code.Context) code.Response {
	// get catalog file data type
	dataType, ok := ctx.Args()["type"]
	if !ok {
		return code.Error(errorx.NewError(errorx.ErrCodeParam, "missing param:type"))
	}
	// 判断资源类型, 仅支持模型资源或者数据资源
	if string(dataType) != blockchain.CatalogFileTypeOfData && string(dataType) != blockchain.CatalogFileTypeOfModel {
		return code.Error(errorx.NewError(errorx.ErrCodeParam, "invalid param:dataType"))
	}
	// get ns
	ns, ok := ctx.Args()["ns"]
	if !ok {
		return code.Error(errorx.NewError(errorx.ErrCodeParam, "missing param:ns"))
	}
	// get name
	name, ok := ctx.Args()["name"]
	if !ok {
		return code.Error(errorx.NewError(errorx.ErrCodeParam, "missing param:name"))
	}
	ctime, err := m.getCtxTime(ctx, "currentTime")
	if err != nil {
		return code.Error(err)
	}
	// judge if fileNsIndex exists
	fileNsIndex := packCatalogNsIndex(string(dataType), string(ns))
	if _, err := ctx.GetObject([]byte(fileNsIndex)); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeParam, "bad param, ns not found"))
	}
	// pack filenameindex
	filenameIndex := packFileNameIndex(string(dataType), string(ns), string(name))
	// get id from index
	id, err := ctx.GetObject([]byte(filenameIndex))
	if err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeNotFound, "fileID not found with name+ns"))
	}
	// get file from id
	// catalogFileID := packCatalogFileIDIndex(id)
	s, err := ctx.GetObject(id)
	if err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeNotFound, "file not found"))
	}

	var f blockchain.CatalogFile
	if err = json.Unmarshal(s, &f); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeInternal,
			"failed to unmarshal CatalogFile"))
	}
	if f.ExpireTime < ctime {
		return code.Error(errorx.NewError(errorx.ErrCodeExpired, "CatalogFile already expire"))
	}
	return code.OK(s)
}

// GetCatalogFileDetailByID 根据文件ID查询文件详情
func (m *DtxManager) GetCatalogFileDetailByID(ctx code.Context) code.Response {
	// get id
	id, ok := ctx.Args()["id"]
	if !ok {
		return code.Error(errorx.NewError(errorx.ErrCodeParam, "missing param:id"))
	}
	ctime, err := m.getCtxTime(ctx, "currentTime")
	if err != nil {
		return code.Error(err)
	}
	// get file from id
	catalogFileID := packCatalogFileIDIndex(string(id))
	fs, err := ctx.GetObject([]byte(catalogFileID))
	if err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeNotFound, "file not found"))
	}
	var f blockchain.CatalogFile
	if err = json.Unmarshal(fs, &f); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeInternal, "failed to unmarshal CatalogFile"))
	}
	if f.ExpireTime < ctime {
		return code.Error(errorx.NewError(errorx.ErrCodeExpired, "CatalogFile already expire"))
	}
	return code.OK(fs)
}

func (m *DtxManager) OfflineCatalogFile(ctx code.Context) code.Response {
	return m.setCatalogFileOnlineStatus(ctx, false)
}

func (m *DtxManager) OnlineCatalogFile(ctx code.Context) code.Response {
	return m.setCatalogFileOnlineStatus(ctx, true)
}

// setCatalogFileOnlineStatus sets catalog file online/offline status in chain
func (m *DtxManager) setCatalogFileOnlineStatus(ctx code.Context, online bool) code.Response {
	s, ok := ctx.Args()["opt"]
	if !ok {
		return code.Error(errorx.NewError(errorx.ErrCodeParam, "missing param:opt"))
	}
	var opt blockchain.CatalogFileOperationOpt
	if err := json.Unmarshal(s, &opt); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeInternal, "failed to unmarshal CatalogFileOperationOpt"))
	}

	// get file from id
	catalogFileID := packCatalogFileIDIndex(opt.FileID)
	s, err := ctx.GetObject([]byte(catalogFileID))
	if err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeNotFound, "catalog file not found"))
	}

	var f blockchain.CatalogFile
	if err = json.Unmarshal(s, &f); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeInternal,
			"failed to unmarshal CatalogFile"))
	}

	// both partners are able to operate model
	if !bytes.Equal(opt.Pubkey, f.Owner) {
		// get partner info
		ctx.Args()["id"] = opt.Pubkey
		resp := m.QueryOrgInfoByPK(ctx)
		if len(resp.Body) == 0 {
			return code.Error(errorx.NewError(errorx.ErrCodeNotFound, "orgInfo not found by pk"))
		}
		var org blockchain.OrgInfo
		if err := json.Unmarshal(resp.Body, &org); err != nil {
			return code.Error(errorx.New(err, errorx.ErrCodeInternal, "failed to unmarshal OrgInfo"))
		}
		if org.Name != f.PartnerName {
			return code.Error(errorx.NewError(errorx.ErrCodeInternal, "not authorized to operate model"))
		}
	}

	// verify sig
	msg, err := util.GetSigMessage(opt)
	if err != nil {
		return code.Error(errorx.Internal(err, "failed to get the message to sign"))
	}
	err = m.checkSign(opt.Signature, opt.Pubkey, []byte(msg))
	if err != nil {
		return code.Error(err)
	}
	if online {
		f.Status = blockchain.CatalogFileOnlineStatus
	} else {
		f.Status = blockchain.CatalogFileOfflelineStatus
	}

	// marshal new catalog file
	newf, err := json.Marshal(f)
	if err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal new CatalogFile"))
	}
	// set id-file on chain，设置数据资源/模型资源内容
	if err := ctx.PutObject([]byte(catalogFileID), newf); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeWriteBlockchain, "failed to set id-file on chain"))
	}

	return code.OK([]byte("OK"))
}

// UpdateCatalogFileByID updates catalog file by ID, only data files can be updated.
func (m *DtxManager) UpdateCatalogFileByID(ctx code.Context) code.Response {
	s, ok := ctx.Args()["opt"]
	if !ok {
		return code.Error(errorx.NewError(errorx.ErrCodeParam, "missing param:opt"))
	}
	var opt blockchain.UpdateCatalogFileOptions
	if err := json.Unmarshal(s, &opt); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeInternal, "failed to unmarshal UpdateCatalogFileOptions"))
	}

	// get file from id
	catalogFileID := packCatalogFileIDIndex(opt.FileID)
	s, err := ctx.GetObject([]byte(catalogFileID))
	if err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeNotFound, "catalog file not found"))
	}

	var f blockchain.CatalogFile
	if err = json.Unmarshal(s, &f); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeInternal,
			"failed to unmarshal CatalogFile"))
	}
	// 下线文件&过期文件不支持更新
	if f.Status == blockchain.CatalogFileOfflelineStatus || f.ExpireTime <= opt.CurrentTime {
		return code.Error(errorx.New(err, errorx.ErrCodeNotFound, "catalog file is expired or is offline, can not update"))
	}

	// verify sig
	msg, err := util.GetSigMessage(opt)
	if err != nil {
		return code.Error(errorx.Internal(err, "failed to get the message to sign"))
	}
	err = m.checkSign(opt.Signature, f.Owner, []byte(msg))
	if err != nil {
		return code.Error(err)
	}
	f.ExpireTime = opt.NewExpireTime
	f.Version = opt.NewVersion
	f.Length = opt.NewLength
	f.Number = opt.NewNumber
	f.MerkleRoot = opt.NewMerkleRoot
	f.Ext = opt.NewExt

	// marshal new catalog file
	newf, err := json.Marshal(f)
	if err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal node"))
	}
	// set id-file on chain，设置数据资源/模型资源内容
	if err := ctx.PutObject([]byte(catalogFileID), newf); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeWriteBlockchain, "failed to set id-file on chain"))
	}

	return code.OK([]byte("OK"))
}

func (m *DtxManager) getFileByID(ctx code.Context, fileID []byte) (f blockchain.CatalogFile, err error) {
	s, err := ctx.GetObject(fileID)
	if err != nil {
		return f, errorx.New(err, errorx.ErrCodeNotFound,
			"the file[%s] not found", string(fileID))
	}
	if err = json.Unmarshal(s, &f); err != nil {
		return f, errorx.New(err, errorx.ErrCodeInternal,
			"failed to unmarshal File")
	}
	return f, nil
}

// checkSign 签名验证，仅存储数据的操作需要签名和验签
func (m *DtxManager) checkSign(sign, owner, mes []byte) (err error) {
	// verify sig
	if len(owner) != ecdsa.PublicKeyLength || len(sign) != ecdsa.SignatureLength {
		return errorx.NewError(errorx.ErrCodeParam, "bad param:signature")
	}
	var pubkey [ecdsa.PublicKeyLength]byte
	var sig [ecdsa.SignatureLength]byte
	copy(pubkey[:], owner)
	copy(sig[:], sign)
	if err := ecdsa.Verify(pubkey, hash.HashUsingSha256(mes), sig); err != nil {
		return errorx.New(err, errorx.ErrCodeBadSignature, "failed to verify signature")
	}
	return nil
}

// getCtxTime 从合约参数获取时间
func (m *DtxManager) getCtxTime(ctx code.Context, timeName string) (int64, error) {
	pTime, cok := ctx.Args()[timeName]
	if !cok {
		return 0, errorx.NewError(errorx.ErrCodeParam, "missing param:%s", timeName)
	}
	ptime, err := strconv.ParseInt(string(pTime), 10, 64)
	if err != nil {
		return 0, errorx.New(err, errorx.ErrCodeParam, "bad param:%d", ptime)
	}
	return ptime, nil
}
