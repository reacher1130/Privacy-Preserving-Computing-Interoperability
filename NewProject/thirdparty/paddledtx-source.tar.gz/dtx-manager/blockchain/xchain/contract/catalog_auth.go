package main

import (
	"encoding/json"

	util "github.com/PaddlePaddle/PaddleDTX/xdb/pkgs/strings"
	"github.com/xuperchain/xuperchain/core/contractsdk/go/code"

	"baidu/blockchain/dtx-manager/blockchain"
	errorx "baidu/blockchain/dtx-manager/pkg/codeerror"
)

// PublishCatalogFileAuth add applier's file authorization application into chain
// In order to facilitate the applier or authorizer to query the list of applications,
// the authorization application will be written under the index_catalogfileauth_list of applier and authorizer
func (m *DtxManager) PublishCatalogFileAuth(ctx code.Context) code.Response {
	// get PublishCatalogFileAuthOptions
	s, ok := ctx.Args()["opt"]
	if !ok {
		return code.Error(errorx.NewError(errorx.ErrCodeParam, "missing param: opt"))
	}
	// unmarshal opt
	var opt blockchain.PublishCatalogFileAuthOptions
	if err := json.Unmarshal(s, &opt); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeInternal,
			"failed to unmarshal PublishCatalogFileAuthOptions"))
	}
	fa := opt.FileAuthApplication

	// 判断授权申请类型是不是查看或使用
	if fa.Type != blockchain.CatalogFileAuthLook && fa.Type != blockchain.CatalogFileAuthUse {
		return code.Error(errorx.NewError(errorx.ErrCodeParam, "invalid param: PublishCatalogFileAuthOptions of type"))
	}
	// 模型资源仅支持申请使用权限
	if fa.TaskID != "" && fa.Type != blockchain.CatalogFileAuthUse {
		return code.Error(errorx.NewError(errorx.ErrCodeParam, "invalid param: PublishCatalogFileAuthOptions of type and taskID"))
	}
	// 资源类型判断，查询数据资源或者模型资源授权申请列表
	if fa.DataType != blockchain.CatalogFileTypeOfData && fa.DataType != blockchain.CatalogFileTypeOfModel {
		return code.Error(errorx.NewError(errorx.ErrCodeParam, "invalid param:dataType"))
	}

	msg, err := util.GetSigMessage(opt)
	if err != nil {
		return code.Error(errorx.Internal(err, "failed to get the message to sign"))
	}
	// verify signature by applier's public key
	err = m.checkSign(opt.Signature, fa.Applier, []byte(msg))
	if err != nil {
		return code.Error(err)
	}

	fa.Status = blockchain.CatalogFileAuthUnapproved
	// marshal fileAuthApplication
	s, err = json.Marshal(fa)
	if err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeInternal,
			"fail to marshal fileAuthApplication"))
	}

	// judge if fileAuthIndex exists
	fileAuthIndex := packCatalogFileAuthIndex(fa.ID)
	if _, err := ctx.GetObject([]byte(fileAuthIndex)); err == nil {
		return code.Error(errorx.NewError(errorx.ErrCodeAlreadyExists, "duplicated catalog file authID"))
	}

	// put index_catalogfileauth into chain
	if err := ctx.PutObject([]byte(fileAuthIndex), s); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeWriteBlockchain, "failed to set index_catalogfileauth on chain"))
	}
	// put index_catalogfileauth_list_applier into chain
	applierListIndex := packCatalogFileAuthApplierIndex(fa.Applier, fa.DataType, fa.ID, fa.CreateTime)
	if err := ctx.PutObject([]byte(applierListIndex), []byte(fa.ID)); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeWriteBlockchain, "failed to set index_catalogfileauth_list_applier on chain"))
	}
	// put index_catalogfileauth_list_authorizer into chain
	authorizerListIndex := packCatalogFileAuthAuthorizerIndex(fa.Authorizer, fa.DataType, fa.ID, fa.CreateTime)
	if err := ctx.PutObject([]byte(authorizerListIndex), []byte(fa.ID)); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeWriteBlockchain, "failed to set index_catalogfileauth_list_authorizer on chain"))
	}

	// put index_catalogfileauth_list_applier_authorizer into chain
	authListIndex := packApplierAndAuthorizerIndex(fa.Applier, fa.Authorizer, fa.DataType, fa.ID, fa.CreateTime)
	if err := ctx.PutObject([]byte(authListIndex), []byte(fa.ID)); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeWriteBlockchain, "failed to set index_catalogfileauth_list_applier_authorizer on chain"))
	}

	return code.OK([]byte("OK"))
}

// ConfirmCatalogFileAuth is called when the dataOwner node confirms file's authorization
func (m *DtxManager) ConfirmCatalogFileAuth(ctx code.Context) code.Response {
	var opt blockchain.ConfirmCatalogFileAuthOptions
	// get opt
	p, ok := ctx.Args()["opt"]
	if !ok {
		return code.Error(errorx.NewError(errorx.ErrCodeParam, "missing param:opt"))
	}
	if err := json.Unmarshal(p, &opt); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeInternal,
			"fail to unmarshal ConfirmCatalogFileAuthOptions"))
	}
	// query authorization application detail by authID
	fa, err := m.getFileAuthByID(ctx, opt.ID)
	if err != nil {
		return code.Error(err)
	}
	// verify signature by authorizer's public key
	msg, err := util.GetSigMessage(opt)
	if err != nil {
		return code.Error(errorx.Internal(err, "failed to get the message to sign"))
	}
	if err := m.checkSign(opt.Signature, fa.Authorizer, []byte(msg)); err != nil {
		return code.Error(err)
	}

	// check status
	if fa.Status != blockchain.CatalogFileAuthUnapproved {
		return code.Error(errorx.NewError(errorx.ErrCodeParam,
			"confirm catalog file auth error, catalogFileAuthStatus is not Unapproved, authID: %s, fileAuthStatus: %s",
			fa.ID, fa.Status))
	}
	// 授权查看权限，authKey不能为空，使用权限authKey可以为空
	if fa.Type == blockchain.CatalogFileAuthLook && len(opt.AuthKey) <= 0 {
		return code.Error(errorx.NewError(errorx.ErrCodeParam,
			"confirm catalog file look auth error, authKey is empty"))
	}
	// 确认授权，授权到期时间必须大于当前时间
	if opt.ExpireTime <= opt.CurrentTime {
		return code.Error(errorx.NewError(errorx.ErrCodeParam,
			"confirm catalog file auth error, ExpireTime is invilad"))
	}
	// update authorization status
	fa.ApprovalTime = opt.CurrentTime
	fa.Status = blockchain.CatalogFileAuthApproved
	fa.ExpireTime = opt.ExpireTime
	fa.AuthKey = opt.AuthKey

	s, err := json.Marshal(fa)
	if err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeInternal, "fail to marshal CatalogFileAuthApplication"))
	}
	// update index_catalogfileauth on xchain
	index := packCatalogFileAuthIndex(fa.ID)
	if err := ctx.PutObject([]byte(index), s); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeWriteBlockchain,
			"fail to confirm index_catalogfileauth on xchain"))
	}
	return code.OK([]byte("OK"))
}

// RejectCatalogFileAuth is called when the dataOwner node rejects file's authorization
func (m *DtxManager) RejectCatalogFileAuth(ctx code.Context) code.Response {
	var opt blockchain.RejectCatalogFileAuthOptions
	// get opt
	p, ok := ctx.Args()["opt"]
	if !ok {
		return code.Error(errorx.NewError(errorx.ErrCodeParam, "missing param:opt"))
	}
	if err := json.Unmarshal(p, &opt); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeInternal,
			"fail to unmarshal RejectCatalogFileAuthOptions"))
	}
	if opt.RejectReason == "" {
		return code.Error(errorx.NewError(errorx.ErrCodeParam,
			"invalid param RejectReason, RejectReason should not be empty"))
	}
	// query authorization application detail by authID
	fa, err := m.getFileAuthByID(ctx, opt.ID)
	if err != nil {
		return code.Error(err)
	}
	// verify signature by authorizer's public key
	msg, err := util.GetSigMessage(opt)
	if err != nil {
		return code.Error(errorx.Internal(err, "failed to get the message to sign"))
	}
	if err := m.checkSign(opt.Signature, fa.Authorizer, []byte(msg)); err != nil {
		return code.Error(err)
	}

	// check status
	if fa.Status != blockchain.CatalogFileAuthUnapproved {
		return code.Error(errorx.NewError(errorx.ErrCodeParam,
			"reject catalog file auth error, catalogFileAuthStatus is not Unapproved, authID: %s, fileAuthStatus: %s",
			fa.ID, fa.Status))
	}
	// update authorization status
	fa.ApprovalTime = opt.CurrentTime
	fa.Status = blockchain.CatalogFileAuthRejected
	fa.RejectReason = opt.RejectReason

	s, err := json.Marshal(fa)
	if err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeInternal, "fail to marshal CatalogFileAuthApplication"))
	}
	// update index_catalogfileauth on xchain
	index := packCatalogFileAuthIndex(fa.ID)
	if err := ctx.PutObject([]byte(index), s); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeWriteBlockchain,
			"fail to reject index_catalogfileauth on xchain"))
	}
	return code.OK([]byte("OK"))
}

// RecycleCatalogFileAuth is called when the dataOwner node rejects file's authorization
func (m *DtxManager) RecycleCatalogFileAuth(ctx code.Context) code.Response {
	var opt blockchain.RecycleCatalogFileAuthOptions
	// get opt
	p, ok := ctx.Args()["opt"]
	if !ok {
		return code.Error(errorx.NewError(errorx.ErrCodeParam, "missing param:opt"))
	}
	if err := json.Unmarshal(p, &opt); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeInternal,
			"fail to unmarshal RecycleCatalogFileAuthOptions"))
	}
	if opt.RecycleReason == "" {
		return code.Error(errorx.NewError(errorx.ErrCodeParam,
			"invalid param RecycleReason, RecycleReason should not be empty"))
	}
	// query authorization application detail by authID
	fa, err := m.getFileAuthByID(ctx, opt.ID)
	if err != nil {
		return code.Error(err)
	}
	// verify signature by authorizer's public key
	msg, err := util.GetSigMessage(opt)
	if err != nil {
		return code.Error(errorx.Internal(err, "failed to get the message to sign"))
	}
	if err := m.checkSign(opt.Signature, fa.Authorizer, []byte(msg)); err != nil {
		return code.Error(err)
	}

	// check status
	if fa.Status != blockchain.CatalogFileAuthApproved {
		return code.Error(errorx.NewError(errorx.ErrCodeParam,
			"reject catalog file auth error, catalogFileAuthStatus is not Approved, authID: %s, fileAuthStatus: %s",
			fa.ID, fa.Status))
	}
	// update authorization status
	fa.ExpireTime = opt.CurrentTime // 回收授权，则授权到期时间为当前时间
	fa.Status = blockchain.CatalogFileAuthRecycled
	fa.RejectReason = opt.RecycleReason

	s, err := json.Marshal(fa)
	if err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeInternal, "fail to marshal CatalogFileAuthApplication"))
	}
	// update index_catalogfileauth on xchain
	index := packCatalogFileAuthIndex(fa.ID)
	if err := ctx.PutObject([]byte(index), s); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeWriteBlockchain,
			"fail to recycle index_catalogfileauth on xchain"))
	}
	return code.OK([]byte("OK"))
}

// ListCatalogFileAuth list the authorization applications of files
// Support query by time range and fileID
func (m *DtxManager) ListCatalogFileAuth(ctx code.Context) code.Response {
	s, ok := ctx.Args()["opt"]
	if !ok {
		return code.Error(errorx.NewError(errorx.ErrCodeParam, "missing param:opt"))
	}
	// unmarshal opt
	var opt blockchain.ListCatalogFileAuthOptions
	if err := json.Unmarshal(s, &opt); err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeInternal,
			"failed to unmarshal ListCatalogFileAuthOptions"))
	}
	// 资源类型判断，查询数据资源或者模型资源授权申请列表
	if opt.DataType != blockchain.CatalogFileTypeOfData && opt.DataType != blockchain.CatalogFileTypeOfModel {
		return code.Error(errorx.NewError(errorx.ErrCodeParam, "invalid param:dataType"))
	}
	prefix := packCatalogFileAuthFilter(opt.DataType, opt.Applier, opt.Authorizer)

	// get iter by prefix
	iter := ctx.NewIterator(code.PrefixRange([]byte(prefix)))
	defer iter.Close()

	totalCount := int64(0)
	indexStart := (opt.PageNo - 1) * opt.PageSize
	indexEnd := opt.PageNo * opt.PageSize
	var fas blockchain.CatalogFileAuthList
	for iter.Next() {
		fa, err := m.getFileAuthByID(ctx, string(iter.Value()))
		if err != nil {
			return code.Error(err)
		}
		if opt.TimeNow > 0 && fa.ExpireTime > 0 && opt.TimeNow >= fa.ExpireTime {
			continue
		}
		if fa.CreateTime < opt.TimeStart || (opt.TimeEnd > 0 && fa.CreateTime > opt.TimeEnd) {
			continue
		}
		// If the fileID is not empty, query this fileID's authorization applications
		if opt.FileID != "" && opt.FileID != fa.FileID {
			continue
		}
		if opt.Status != "" && opt.Status != fa.Status {
			continue
		}
		if opt.AuthType != "" && opt.AuthType != fa.Type {
			continue
		}
		if opt.DataStatus != "" {
			fileIDIndex := packCatalogFileIDIndex(fa.FileID)
			fd, err := m.getFileByID(ctx, []byte(fileIDIndex))
			// 文件不存或状态不符合, 则跳过
			if err != nil || opt.DataStatus != fd.Status {
				continue
			}
		}

		totalCount++

		if opt.PageSize <= 0 || (totalCount > indexStart && totalCount <= indexEnd) {
			// 分页参数无效, 或index在分页范围内
			fas.List = append(fas.List, fa)
		}
	}
	fas.Total = totalCount

	s, err := json.Marshal(fas)
	if err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal CatalogFileAuthList"))
	}
	return code.OK(s)
}

// GetCatalogFileAuthDetailByID query authorization application detail by authID
func (m *DtxManager) GetCatalogFileAuthDetailByID(ctx code.Context) code.Response {
	// get id
	fileAuthID, ok := ctx.Args()["id"]
	if !ok {
		return code.Error(errorx.NewError(errorx.ErrCodeParam, "missing param: fileAuthID"))
	}

	// get authorization application detail by index_catalogfileauth
	index := packCatalogFileAuthIndex(string(fileAuthID))
	s, err := ctx.GetObject([]byte(index))
	if err != nil {
		return code.Error(errorx.New(err, errorx.ErrCodeNotFound, "CatalogFileAuthApplication not found"))
	}
	return code.OK(s)
}

// getFileAuthByID query file's authorization application by authID
func (m *DtxManager) getFileAuthByID(ctx code.Context, authID string) (fa blockchain.CatalogFileAuthApplication, err error) {
	index := packCatalogFileAuthIndex(authID)
	s, err := ctx.GetObject([]byte(index))
	if err != nil {
		return fa, errorx.New(err, errorx.ErrCodeNotFound,
			"the catalog file authApplication[%s] not found", authID)
	}

	if err = json.Unmarshal([]byte(s), &fa); err != nil {
		return fa, errorx.New(err, errorx.ErrCodeInternal,
			"fail to unmarshal CatalogFileAuthApplication")
	}
	return fa, nil
}
