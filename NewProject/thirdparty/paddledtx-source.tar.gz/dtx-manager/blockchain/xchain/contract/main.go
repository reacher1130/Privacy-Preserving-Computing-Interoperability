package main

import (
	"github.com/xuperchain/xuperchain/core/contractsdk/go/code"
	"github.com/xuperchain/xuperchain/core/contractsdk/go/driver"
)

type DtxManager struct{}

func (m *DtxManager) Initialize(ctx code.Context) code.Response {
	creator, ok := ctx.Args()["creator"]
	if !ok {
		return code.Errors("missing creator")
	}
	if err := ctx.PutObject([]byte("creator"), creator); err != nil {
		return code.Error(err)
	}
	return code.OK(nil)
}

func main() {
	driver.Serve(new(DtxManager))
}
