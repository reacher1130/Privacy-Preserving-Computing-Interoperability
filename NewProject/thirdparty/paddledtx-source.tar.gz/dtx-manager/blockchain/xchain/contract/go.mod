module contract

go 1.17

require (
	baidu/blockchain/dtx-manager v0.0.0
	github.com/PaddlePaddle/PaddleDTX/crypto v0.0.0
	github.com/PaddlePaddle/PaddleDTX/xdb v0.0.0
	github.com/xuperchain/xuperchain v0.0.0-20210208123615-2d08ff11de3e
)

require (
	github.com/go-playground/locales v0.13.0 // indirect
	github.com/go-playground/universal-translator v0.17.0 // indirect
	github.com/go-playground/validator/v10 v10.4.1 // indirect
	github.com/leodido/go-urn v1.2.0 // indirect
)

require (
	google.golang.org/genproto v0.0.0-20211208223120-3a66f561d7aa // indirect
	google.golang.org/grpc v1.41.0 // indirect
)

require (
	github.com/golang/protobuf v1.5.2 // indirect
	github.com/pkg/errors v0.9.1 // indirect
	golang.org/x/crypto v0.11.0 // indirect
	golang.org/x/net v0.10.0 // indirect
	golang.org/x/sys v0.10.0 // indirect
	golang.org/x/text v0.11.0 // indirect
	google.golang.org/protobuf v1.28.1 // indirect
)

replace github.com/go-kit/kit => github.com/go-kit/kit v0.8.0

replace github.com/PaddlePaddle/PaddleDTX/crypto => ../../../../PaddleDTX/crypto

replace github.com/PaddlePaddle/PaddleDTX/xdb => ../../../../PaddleDTX/xdb

replace baidu/blockchain/dtx-manager => ../../../../dtx-manager
