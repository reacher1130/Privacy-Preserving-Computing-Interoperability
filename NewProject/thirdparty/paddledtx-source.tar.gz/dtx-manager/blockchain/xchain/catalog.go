package xchain

import (
	"encoding/json"
	"strconv"
	"time"

	"baidu/blockchain/dtx-manager/blockchain"
	errorx "baidu/blockchain/dtx-manager/pkg/codeerror"
)

// AddCatalogNamespace 新增资源命名空间
func (x *XChain) AddCatalogNamespace(opt *blockchain.AddCatalogNsOptions) error {
	s, err := json.Marshal(*opt)
	if err != nil {
		return errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal AddCatalogNsOptions")
	}
	args := map[string]string{
		"opt": string(s),
	}
	mName := "AddCatalogNamespace"
	if _, err = x.InvokeManagerContract(args, mName); err != nil {
		return err
	}
	return nil
}

// ListCatalogNs 查询目录链列表
func (x *XChain) ListCatalogNs(opt *blockchain.ListCatalogNsOptions) (blockchain.CatalogNsList, error) {
	var ns blockchain.CatalogNsList
	opts, err := json.Marshal(*opt)
	if err != nil {
		return ns, errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal ListCatalogNsOptions")
	}
	args := map[string]string{
		"opt": string(opts),
	}
	mName := "ListCatalogNs"
	resp, err := x.QueryManagerContract(args, mName)
	if err != nil {
		return ns, err
	}
	if err = json.Unmarshal([]byte(resp), &ns); err != nil {
		return ns, errorx.New(err, errorx.ErrCodeInternal,
			"failed to unmarshal CatalogFile Ns")
	}
	return ns, nil
}

// PublishFileToCatalog 发布数据或模型到目录链
func (x *XChain) PublishFileToCatalog(opt *blockchain.PublishFileToCatalogOptions) (string, error) {
	s, err := json.Marshal(*opt)
	if err != nil {
		return "", errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal PublishFileToCatalogOptions")
	}
	args := map[string]string{
		"opt": string(s),
	}
	mName := "PublishFileToCatalog"
	var txid []byte
	if txid, err = x.InvokeManagerContract(args, mName); err != nil {
		return "", err
	}
	return string(txid), nil
}

// ListCatalogFiles 查询目录链下资源文件
func (x *XChain) ListCatalogFiles(opt *blockchain.ListCatalogFilesOptions) (blockchain.CatalogFileList, error) {
	var f blockchain.CatalogFileList
	opts, err := json.Marshal(*opt)
	if err != nil {
		return f, errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal ListCatalogFilesOptions")
	}
	args := map[string]string{
		"opt": string(opts),
	}
	mName := "ListCatalogFiles"
	resp, err := x.QueryManagerContract(args, mName)
	if err != nil {
		return f, err
	}
	if err = json.Unmarshal([]byte(resp), &f); err != nil {
		return f, errorx.New(err, errorx.ErrCodeInternal,
			"failed to unmarshal Catalog Files")
	}
	return f, nil
}

// GetCatalogFileDetailByFileName 通过资源名称查询资源详情
func (x *XChain) GetCatalogFileDetailByFileName(dataType, namespace, name string) (blockchain.CatalogFile, error) {
	var f blockchain.CatalogFile
	args := map[string]string{
		"type":        dataType,
		"ns":          namespace,
		"name":        name,
		"currentTime": strconv.FormatInt(time.Now().UnixNano(), 10),
	}
	mName := "GetCatalogFileDetailByFileName"
	s, err := x.QueryManagerContract(args, mName)
	if err != nil {
		return f, err
	}
	if err = json.Unmarshal([]byte(s), &f); err != nil {
		return f, errorx.New(err, errorx.ErrCodeInternal,
			"failed to unmarshal Catalog File")
	}
	return f, nil
}

// GetCatalogFileDetailByID 通过资源id查询资源详情
func (x *XChain) GetCatalogFileDetailByID(id string) (blockchain.CatalogFile, error) {
	var f blockchain.CatalogFile
	args := map[string]string{
		"id":          id,
		"currentTime": strconv.FormatInt(time.Now().UnixNano(), 10),
	}
	mName := "GetCatalogFileDetailByID"
	s, err := x.QueryManagerContract(args, mName)
	if err != nil {
		return f, err
	}

	if err = json.Unmarshal([]byte(s), &f); err != nil {
		return f, errorx.New(err, errorx.ErrCodeInternal,
			"failed to unmarshal Catalog File")
	}

	return f, nil
}

// OfflineCatalogFile 下线数据或模型资源
func (x *XChain) OfflineCatalogFile(opt *blockchain.OfflineCatalogFileOpt) error {
	s, err := json.Marshal(*opt)
	if err != nil {
		return errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal OfflineCatalogFileOpt")
	}
	args := map[string]string{
		"opt": string(s),
	}
	mName := "OfflineCatalogFile"
	if _, err = x.InvokeManagerContract(args, mName); err != nil {
		return err
	}
	return nil
}

// OnlineCatalogFile 上线数据或模型资源
func (x *XChain) OnlineCatalogFile(opt *blockchain.OnlineCatalogFileOpt) error {
	s, err := json.Marshal(*opt)
	if err != nil {
		return errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal OnlineCatalogFileOpt")
	}
	args := map[string]string{
		"opt": string(s),
	}
	mName := "OnlineCatalogFile"
	if _, err = x.InvokeManagerContract(args, mName); err != nil {
		return err
	}
	return nil
}

// UpdateCatalogFileByID 更新数据资源
func (x *XChain) UpdateCatalogFileByID(opt *blockchain.UpdateCatalogFileOptions) error {
	s, err := json.Marshal(*opt)
	if err != nil {
		return errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal UpdateCatalogFileOptions")
	}
	args := map[string]string{
		"opt": string(s),
	}
	mName := "UpdateCatalogFileByID"
	if _, err = x.InvokeManagerContract(args, mName); err != nil {
		return err
	}
	return nil
}
