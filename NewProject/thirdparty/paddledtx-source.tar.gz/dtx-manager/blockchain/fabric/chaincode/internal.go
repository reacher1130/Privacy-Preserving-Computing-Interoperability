package main

import (
	"fmt"
	"math"
)

const (
	compositeKeyNamespace = "\x00"
	minUnicodeRuneValue   = 0

	// orgInfo
	prefixOrgInfoPK = "index_orgInfo_pk"
	prefixOrgInfoID = "index_orgInfo_id"

	// Define the contract prefix key of file and file namespace operations
	prefixCatalogFilenameIndex     = "index_catalog_fn"
	prefixCatalogFileListByNsIndex = "index_catalog_fs_list"
	prefixCatalogOwnerNsIndex      = "index_catalog_ofns"
	prefixCatalogNsIndex           = "index_catalog_fns"
	prefixCatalogNsListIndex       = "index_catalog_fns_list"
	prefixCatalogFileIDIndex       = "index_catalog_fid"
	// Define the contract prefix key of catalog file authorization application operations
	prefixCatalogFileAuthIndex           = "index_catalog_auth"
	prefixCatalogFileAuthApplierIndex    = "index_catalog_fa_applier"
	prefixCatalogFileAuthAuthorizerIndex = "index_catalog_fa_authorizer"
	prefixCatalogFileAuthListIndex       = "index_catalog_fa_list"
)

func packOrgInfoPK(pubkey []byte) string {
	attributes := []string{
		prefixOrgInfoPK,
		fmt.Sprintf("%x", pubkey),
	}
	return createCompositeKey(attributes)
}

func packOrgInfoID(id []byte) string {
	attributes := []string{
		prefixOrgInfoID,
		fmt.Sprintf("%x", id),
	}
	return createCompositeKey(attributes)
}

// packCatalogOwnerNsIndex 定义目录链合约key前缀
// example： key为 `index_catalog_fns/数据模型/ns创建人/ns名称`
func packCatalogOwnerNsIndex(owner []byte, dataType, ns string) string {
	attributes := []string{
		prefixCatalogOwnerNsIndex,
		dataType,
		fmt.Sprintf("%x", owner),
		ns,
	}
	return createCompositeKey(attributes)
}

// packCatalogNsIndex 定义目录链合约key前缀
// example： key为 `index_catalog_fns/数据模型/ns名称`
func packCatalogNsIndex(dataType, ns string) string {
	attributes := []string{
		prefixCatalogNsIndex,
		dataType,
		ns,
	}
	return createCompositeKey(attributes)
}

// packCatalogNsListIndex 定义目录链列表合约key前缀
// example： list key为 `index_catalog_fns_list/数据模型/ns创建人/创建时间/ns名称`
func packCatalogNsListIndex(owner []byte, dataType, ns string, createTime int64) string {
	attributes := []string{
		prefixCatalogNsListIndex,
		dataType,
		fmt.Sprintf("%x", owner),
		fmt.Sprintf("%d", subByInt64Max(createTime)),
		ns,
	}
	return createCompositeKey(attributes)
}

// packCatalogNsListFilter 定义目录链列表查询过滤器
func packCatalogNsListFilter(dataType string, owner []byte) (prefix string, attr []string) {
	prefix = prefixCatalogNsListIndex
	attr = []string{dataType}
	if len(owner) > 0 {
		attr = append(attr, fmt.Sprintf("%x", owner))
	}
	return prefix, attr
}

// packCatalogFileIDIndex 定义目录链合约key前缀
// example： key为 `index_catalog_fid/fileID`
func packCatalogFileIDIndex(fileID string) string {
	attributes := []string{
		prefixCatalogFileIDIndex,
		fileID,
	}
	return createCompositeKey(attributes)
}

// packFileNameIndex 定义目录链合约key前缀
// example： key为 `index_catalog_fn/type数据资源/ns/文件名称`
func packFileNameIndex(dataType, ns, name string) string {
	attributes := []string{
		prefixCatalogFilenameIndex,
		dataType,
		ns,
		name,
	}
	return createCompositeKey(attributes)
}

// packCatalogFileListByNsIndex used to list catalog files by ns, ns+pubTime+name is combined into a contract unique key
// 查询目录链下文件列表
func packCatalogFileListByNsIndex(dataType, ns string, pubTime int64) string {
	attributes := []string{
		prefixCatalogFileListByNsIndex,
		dataType,
		ns,
		fmt.Sprintf("%d", subByInt64Max(pubTime)),
	}
	return createCompositeKey(attributes)
}

// packCatalogFileNameFilter 定义目录链下文件列表查询过滤器
func packCatalogFileNameFilter(dataType, ns string) (prefix string, attr []string) {
	prefix = prefixCatalogFileListByNsIndex
	attr = []string{dataType}
	if len(ns) > 0 {
		attr = append(attr, ns)
	}
	return prefix, attr
}

// packCatalogFileAuthIndex 定义目录链文件授权合约key前缀
// example： key为 `index_catalog_auth/授权ID`
func packCatalogFileAuthIndex(id string) string {
	attributes := []string{
		prefixCatalogFileAuthIndex,
		id,
	}
	return createCompositeKey(attributes)
}

// packCatalogFileAuthApplierIndex 定义目录链文件授权合约key前缀
// example： key为 `index_catalog_fa_applier/资源类型/申请者/申请授权时间/授权ID`
func packCatalogFileAuthApplierIndex(applier []byte, dataType, authID string, createTime int64) string {
	attributes := []string{
		prefixCatalogFileAuthApplierIndex,
		dataType,
		fmt.Sprintf("%x", applier),
		fmt.Sprintf("%d", subByInt64Max(createTime)),
		authID,
	}
	return createCompositeKey(attributes)
}

// packCatalogFileAuthAuthorizerIndex 定义目录链文件授权合约key前缀
// example：key为 `index_catalog_fa_authorizer/资源类型/授权者/申请授权时间/授权ID`
func packCatalogFileAuthAuthorizerIndex(authorizer []byte, dataType, authID string, createTime int64) string {
	attributes := []string{
		prefixCatalogFileAuthAuthorizerIndex,
		dataType,
		fmt.Sprintf("%x", authorizer),
		fmt.Sprintf("%d", subByInt64Max(createTime)),
		authID,
	}
	return createCompositeKey(attributes)
}

// packApplierAndAuthorizerIndex define the contract key for applier and authorizer file authorization application
// example：key为 `index_catalog_fa_list/资源类型/申请者/授权者/申请授权时间/授权ID`
func packApplierAndAuthorizerIndex(applier, authorizer []byte, dataType, authID string, createTime int64) string {
	attributes := []string{
		prefixCatalogFileAuthListIndex,
		dataType,
		fmt.Sprintf("%x", applier),
		fmt.Sprintf("%x", authorizer),
		fmt.Sprintf("%d", subByInt64Max(createTime)),
		authID,
	}
	return createCompositeKey(attributes)
}

// packFileAuthFilter get the contract key for the authorization list of iterative query
func packCatalogFileAuthFilter(dataType string, applier, authorizer []byte) (prefix string, attr []string) {
	// If Applier and Authorizer public key not empty
	if len(applier) > 0 && len(authorizer) > 0 {
		return prefixCatalogFileAuthListIndex, []string{
			dataType,
			fmt.Sprintf("%x", applier),
			fmt.Sprintf("%x", authorizer),
		}
	} else if len(applier) > 0 {
		return prefixCatalogFileAuthApplierIndex, []string{
			dataType,
			fmt.Sprintf("%x", applier),
		}
	} else {
		return prefixCatalogFileAuthAuthorizerIndex, []string{
			dataType,
			fmt.Sprintf("%x", authorizer),
		}
	}
}

func createCompositeKey(attributes []string) string {
	ck := compositeKeyNamespace
	for _, att := range attributes {
		ck += att + string([]rune{minUnicodeRuneValue})
	}
	return ck
}

// return maxInt64 - N
func subByInt64Max(n int64) int64 {
	return math.MaxInt64 - n
}
