package main

import (
	"encoding/json"

	util "github.com/PaddlePaddle/PaddleDTX/xdb/pkgs/strings"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	pb "github.com/hyperledger/fabric/protos/peer"

	"baidu/blockchain/dtx-manager/blockchain"
	errorx "baidu/blockchain/dtx-manager/pkg/codeerror"
)

// PublishCatalogFileAuth add applier's file authorization application into chain
// In order to facilitate the applier or authorizer to query the list of applications,
// the authorization application will be written under the index_catalogfileauth_list of applier and authorizer
func (m *DtxManager) PublishCatalogFileAuth(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	// get PublishCatalogFileAuthOptions
	if len(args) < 1 {
		return shim.Error("invalid arguments. expecting PublishCatalogFileAuthOptions")
	}

	// unmarshal opt
	var opt blockchain.PublishCatalogFileAuthOptions
	if err := json.Unmarshal([]byte(args[0]), &opt); err != nil {
		return shim.Error(errorx.New(err, errorx.ErrCodeInternal,
			"failed to unmarshal PublishCatalogFileAuthOptions").Error())
	}

	fa := opt.FileAuthApplication
	// 判断授权申请类型是不是查看或使用
	if fa.Type != blockchain.CatalogFileAuthLook && fa.Type != blockchain.CatalogFileAuthUse {
		return shim.Error(errorx.NewError(errorx.ErrCodeParam, "invalid param: PublishCatalogFileAuthOptions of type").Error())
	}
	// 模型资源仅支持申请使用权限
	if fa.TaskID != "" && fa.Type != blockchain.CatalogFileAuthUse {
		return shim.Error(errorx.NewError(errorx.ErrCodeParam, "invalid param: PublishCatalogFileAuthOptions of type and taskID").Error())
	}
	// 资源类型判断，查询数据资源或者模型资源授权申请列表
	if fa.DataType != blockchain.CatalogFileTypeOfData && fa.DataType != blockchain.CatalogFileTypeOfModel {
		return shim.Error(errorx.NewError(errorx.ErrCodeParam, "invalid param:dataType").Error())
	}

	msg, err := util.GetSigMessage(opt)
	if err != nil {
		return shim.Error(errorx.Internal(err, "failed to get the message to sign").Error())
	}
	// verify signature by applier's public key
	err = m.checkSign(opt.Signature, fa.Applier, []byte(msg))
	if err != nil {
		return shim.Error(err.Error())
	}

	fa.Status = blockchain.CatalogFileAuthUnapproved
	// marshal fileAuthApplication
	s, err := json.Marshal(fa)
	if err != nil {
		return shim.Error(errorx.New(err, errorx.ErrCodeInternal,
			"fail to marshal fileAuthApplication").Error())
	}

	// judge if fileAuthIndex exists
	fileAuthIndex := packCatalogFileAuthIndex(fa.ID)
	if resp := m.GetValue(stub, []string{fileAuthIndex}); len(resp.Payload) != 0 {
		return shim.Error(errorx.NewError(errorx.ErrCodeAlreadyExists, "duplicated file authID").Error())
	}

	// put index_catalogfileauth into chain
	if resp := m.SetValue(stub, []string{fileAuthIndex, string(s)}); resp.Status == shim.ERROR {
		return shim.Error(errorx.NewError(errorx.ErrCodeWriteBlockchain,
			"failed to set index_catalogfileauth on chain: %s", resp.Message).Error())
	}

	// put index_catalogfileauth_list_applier into chain
	applierListIndex := packCatalogFileAuthApplierIndex(fa.Applier, fa.DataType, fa.ID, fa.CreateTime)
	if resp := m.SetValue(stub, []string{applierListIndex, fa.ID}); resp.Status == shim.ERROR {
		return shim.Error(errorx.NewError(errorx.ErrCodeWriteBlockchain,
			"failed to set index_catalogfileauth_list_applier on chain: %s", resp.Message).Error())
	}

	// put index_catalogfileauth_list_authorizer into chain
	authorizerListIndex := packCatalogFileAuthAuthorizerIndex(fa.Authorizer, fa.DataType, fa.ID, fa.CreateTime)
	if resp := m.SetValue(stub, []string{authorizerListIndex, fa.ID}); resp.Status == shim.ERROR {
		return shim.Error(errorx.NewError(errorx.ErrCodeWriteBlockchain,
			"failed to set index_catalogfileauth_list_authorizer on chain: %s", resp.Message).Error())
	}

	// put index_catalogfileauth_list_applier_authorizer into chain
	authListIndex := packApplierAndAuthorizerIndex(fa.Applier, fa.Authorizer, fa.DataType, fa.ID, fa.CreateTime)
	if resp := m.SetValue(stub, []string{authListIndex, fa.ID}); resp.Status == shim.ERROR {
		return shim.Error(errorx.NewError(errorx.ErrCodeWriteBlockchain,
			"failed to set index_catalogfileauth_list_applier_authorizer on chain: %s", resp.Message).Error())
	}
	return shim.Success([]byte("OK"))
}

// ConfirmCatalogFileAuth is called when the dataOwner node confirms file's authorization
func (m *DtxManager) ConfirmCatalogFileAuth(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	// get opt
	if len(args) < 1 {
		return shim.Error("invalid arguments. expecting ConfirmCatalogFileAuthOptions")
	}

	// unmarshal opt
	var opt blockchain.ConfirmCatalogFileAuthOptions
	if err := json.Unmarshal([]byte(args[0]), &opt); err != nil {
		return shim.Error(errorx.New(err, errorx.ErrCodeInternal,
			"failed to unmarshal ConfirmCatalogFileAuthOptions").Error())
	}

	// query authorization application detail by authID
	fa, err := m.getFileAuthByID(stub, opt.ID)
	if err != nil {
		return shim.Error(err.Error())
	}
	// verify signature by authorizer's public key
	msg, err := util.GetSigMessage(opt)
	if err != nil {
		return shim.Error(errorx.Internal(err, "failed to get the message to sign").Error())
	}
	if err := m.checkSign(opt.Signature, fa.Authorizer, []byte(msg)); err != nil {
		return shim.Error(err.Error())
	}

	// check status
	if fa.Status != blockchain.CatalogFileAuthUnapproved {
		return shim.Error(errorx.NewError(errorx.ErrCodeParam,
			"confirm catalog file auth error, catalogFileAuthStatus is not Unapproved, authID: %s, fileAuthStatus: %s",
			fa.ID, fa.Status).Error())
	}
	// 授权查看权限，authKey不能为空，使用权限authKey可以为空
	if fa.Type == blockchain.CatalogFileAuthLook && len(opt.AuthKey) <= 0 {
		return shim.Error(errorx.NewError(errorx.ErrCodeParam,
			"confirm catalog file look auth error, authKey is empty").Error())
	}
	// 确认授权，授权到期时间必须大于当前时间
	if opt.ExpireTime <= opt.CurrentTime {
		return shim.Error(errorx.NewError(errorx.ErrCodeParam,
			"confirm catalog file auth error, ExpireTime is invilad").Error())
	}

	// update authorization status
	fa.ApprovalTime = opt.CurrentTime
	fa.Status = blockchain.CatalogFileAuthApproved
	fa.ExpireTime = opt.ExpireTime
	fa.AuthKey = opt.AuthKey

	s, err := json.Marshal(fa)
	if err != nil {
		return shim.Error(errorx.New(err, errorx.ErrCodeInternal, "fail to marshal CatalogFileAuthApplication").Error())
	}
	// update index_fileauth on chain
	index := packCatalogFileAuthIndex(fa.ID)
	if resp := m.SetValue(stub, []string{index, string(s)}); resp.Status == shim.ERROR {
		return shim.Error(errorx.NewError(errorx.ErrCodeWriteBlockchain,
			"failed to confirm index_catalogfileauth on chain: %s", resp.Message).Error())
	}

	return shim.Success([]byte("OK"))
}

// RejectCatalogFileAuth is called when the dataOwner node rejects file's authorization
func (m *DtxManager) RejectCatalogFileAuth(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	// get opt
	if len(args) < 1 {
		return shim.Error("invalid arguments. expecting RejectCatalogFileAuthOptions")
	}

	// unmarshal opt
	var opt blockchain.RejectCatalogFileAuthOptions
	if err := json.Unmarshal([]byte(args[0]), &opt); err != nil {
		return shim.Error(errorx.New(err, errorx.ErrCodeInternal,
			"failed to unmarshal RejectCatalogFileAuthOptions").Error())
	}
	if opt.RejectReason == "" {
		return shim.Error(errorx.NewError(errorx.ErrCodeParam,
			"invalid param RejectReason, RejectReason should not be empty").Error())
	}

	// query authorization application detail by authID
	fa, err := m.getFileAuthByID(stub, opt.ID)
	if err != nil {
		return shim.Error(err.Error())
	}
	// verify signature by authorizer's public key
	msg, err := util.GetSigMessage(opt)
	if err != nil {
		return shim.Error(errorx.Internal(err, "failed to get the message to sign").Error())
	}
	if err := m.checkSign(opt.Signature, fa.Authorizer, []byte(msg)); err != nil {
		return shim.Error(err.Error())
	}

	// check status
	if fa.Status != blockchain.CatalogFileAuthUnapproved {
		return shim.Error(errorx.NewError(errorx.ErrCodeParam,
			"confirm file auth error, catalogFileAuthStatus is not Unapproved, authID: %s, catalogFileAuthStatus: %s",
			fa.ID, fa.Status).Error())
	}
	// update authorization status
	fa.ApprovalTime = opt.CurrentTime
	fa.Status = blockchain.CatalogFileAuthRejected
	fa.RejectReason = opt.RejectReason

	s, err := json.Marshal(fa)
	if err != nil {
		return shim.Error(errorx.New(err, errorx.ErrCodeInternal, "fail to marshal CatalogFileAuthApplication").Error())
	}
	// update index_fileauth on chain
	index := packCatalogFileAuthIndex(fa.ID)
	if resp := m.SetValue(stub, []string{index, string(s)}); resp.Status == shim.ERROR {
		return shim.Error(errorx.NewError(errorx.ErrCodeWriteBlockchain,
			"failed to confirm index_catalogfileauth on chain: %s", resp.Message).Error())
	}

	return shim.Success([]byte("OK"))
}

// RecycleCatalogFileAuth is called when the dataOwner node rejects file's authorization
func (m *DtxManager) RecycleCatalogFileAuth(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	// get opt
	if len(args) < 1 {
		return shim.Error("invalid arguments. expecting RecycleCatalogFileAuthOptions")
	}

	// unmarshal opt
	var opt blockchain.RecycleCatalogFileAuthOptions
	if err := json.Unmarshal([]byte(args[0]), &opt); err != nil {
		return shim.Error(errorx.New(err, errorx.ErrCodeInternal,
			"failed to unmarshal RecycleCatalogFileAuthOptions").Error())
	}
	if opt.RecycleReason == "" {
		return shim.Error(errorx.NewError(errorx.ErrCodeParam,
			"invalid param RecycleReason, RecycleReason should not be empty").Error())
	}

	// query authorization application detail by authID
	fa, err := m.getFileAuthByID(stub, opt.ID)
	if err != nil {
		return shim.Error(err.Error())
	}
	// verify signature by authorizer's public key
	msg, err := util.GetSigMessage(opt)
	if err != nil {
		return shim.Error(errorx.Internal(err, "failed to get the message to sign").Error())
	}
	if err := m.checkSign(opt.Signature, fa.Authorizer, []byte(msg)); err != nil {
		return shim.Error(err.Error())
	}

	// check status
	if fa.Status != blockchain.CatalogFileAuthApproved {
		return shim.Error(errorx.NewError(errorx.ErrCodeParam,
			"reject catalog file auth error, catalogFileAuthStatus is not Approved, authID: %s, fileAuthStatus: %s",
			fa.ID, fa.Status).Error())
	}
	// update authorization status
	fa.ExpireTime = opt.CurrentTime // 回收授权，则授权到期时间为当前时间
	fa.Status = blockchain.CatalogFileAuthRecycled
	fa.RejectReason = opt.RecycleReason

	s, err := json.Marshal(fa)
	if err != nil {
		return shim.Error(errorx.New(err, errorx.ErrCodeInternal, "fail to marshal CatalogFileAuthApplication").Error())
	}
	// update index_fileauth on chain
	index := packCatalogFileAuthIndex(fa.ID)
	if resp := m.SetValue(stub, []string{index, string(s)}); resp.Status == shim.ERROR {
		return shim.Error(errorx.NewError(errorx.ErrCodeWriteBlockchain,
			"failed to confirm index_catalogfileauth on chain: %s", resp.Message).Error())
	}

	return shim.Success([]byte("OK"))
}

// ListCatalogFileAuth list the authorization applications of files
// Support query by time range and fileID
func (m *DtxManager) ListCatalogFileAuth(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	if len(args) < 1 {
		return shim.Error("invalid arguments. expecting ListCatalogFileAuthOptions")
	}

	// unmarshal opt
	var opt blockchain.ListCatalogFileAuthOptions
	if err := json.Unmarshal([]byte(args[0]), &opt); err != nil {
		return shim.Error(errorx.New(err, errorx.ErrCodeInternal,
			"failed to unmarshal ListCatalogFileAuthOptions").Error())
	}
	prefix, attr := packCatalogFileAuthFilter(opt.DataType, opt.Applier, opt.Authorizer)
	// get iter by prefix
	iterator, err := stub.GetStateByPartialCompositeKey(prefix, attr)
	if err != nil {
		return shim.Error(err.Error())
	}
	defer iterator.Close()

	// iterate iter
	totalCount := int64(0)
	indexStart := (opt.PageNo - 1) * opt.PageSize
	indexEnd := opt.PageNo * opt.PageSize
	var fas blockchain.CatalogFileAuthList
	for iterator.HasNext() {
		queryResponse, err := iterator.Next()
		if err != nil {
			return shim.Error(err.Error())
		}
		fa, err := m.getFileAuthByID(stub, string(queryResponse.Value))
		if err != nil {
			return shim.Error(err.Error())
		}
		if opt.TimeNow > 0 && fa.ExpireTime > 0 && opt.TimeNow >= fa.ExpireTime {
			continue
		}
		if fa.CreateTime < opt.TimeStart || (opt.TimeEnd > 0 && fa.CreateTime > opt.TimeEnd) {
			continue
		}
		// If the fileID is not empty, query this fileID's authorization applications
		if opt.FileID != "" && opt.FileID != fa.FileID {
			continue
		}
		if opt.Status != "" && opt.Status != fa.Status {
			continue
		}
		if opt.AuthType != "" && opt.AuthType != fa.Type {
			continue
		}
		if opt.DataStatus != "" {
			fileIDIndex := packCatalogFileIDIndex(fa.FileID)
			fd, err := m.getFileByID(stub, fileIDIndex)
			// 文件不存或状态不符合, 则跳过
			if err != nil || opt.DataStatus != fd.Status {
				continue
			}
		}

		totalCount++
		if opt.PageSize <= 0 || (totalCount > indexStart && totalCount <= indexEnd) {
			// 分页参数无效, 或index在分页范围内
			fas.List = append(fas.List, fa)
		}

	}
	fas.Total = totalCount

	s, err := json.Marshal(fas)
	if err != nil {
		return shim.Error(errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal CatalogFileAuthList").Error())
	}
	return shim.Success(s)
}

// GetCatalogFileAuthDetailByID query authorization application detail by authID
func (m *DtxManager) GetCatalogFileAuthDetailByID(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	if len(args) < 1 {
		return shim.Error("invalid arguments. missing param: fileAuthID")
	}

	// get authorization application detail by index_fileauth
	index := packCatalogFileAuthIndex(string(args[0]))
	resp := m.GetValue(stub, []string{index})
	if len(resp.Payload) == 0 {
		return shim.Error(errorx.NewError(errorx.ErrCodeNotFound, "CatalogFileAuthApplication not found: %s", resp.Message).Error())
	}
	return shim.Success(resp.Payload)
}

// getFileAuthByID query file's authorization application by authID
func (m *DtxManager) getFileAuthByID(stub shim.ChaincodeStubInterface, authID string) (fa blockchain.CatalogFileAuthApplication, err error) {
	index := packCatalogFileAuthIndex(authID)
	resp := m.GetValue(stub, []string{index})
	if len(resp.Payload) == 0 {
		return fa, errorx.NewError(errorx.ErrCodeNotFound, "CatalogFileAuthApplication[%s] not found: %s", authID, resp.Message)
	}

	if err = json.Unmarshal([]byte(resp.Payload), &fa); err != nil {
		return fa, errorx.New(err, errorx.ErrCodeInternal,
			"fail to unmarshal CatalogFileAuthApplication")
	}
	return fa, nil
}
