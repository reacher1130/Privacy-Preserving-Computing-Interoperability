package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"strconv"

	"github.com/PaddlePaddle/PaddleDTX/crypto/core/ecdsa"
	"github.com/PaddlePaddle/PaddleDTX/crypto/core/hash"
	util "github.com/PaddlePaddle/PaddleDTX/xdb/pkgs/strings"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	pb "github.com/hyperledger/fabric/protos/peer"

	"baidu/blockchain/dtx-manager/blockchain"
	errorx "baidu/blockchain/dtx-manager/pkg/codeerror"
)

// AddCatalogNamespace adds catalog namespace
func (m *DtxManager) AddCatalogNamespace(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	if len(args) < 1 {
		return shim.Error("invalid arguments. expecting AddCatalogNsOptions")
	}

	// unmarshal opt
	var opt blockchain.AddCatalogNsOptions
	if err := json.Unmarshal([]byte(args[0]), &opt); err != nil {
		return shim.Error(errorx.Internal(err, "failed to unmarshal AddCatalogNsOptions").Error())
	}

	ns := opt.Namespace
	// 判断命名空间资源类型, 仅支持模型资源或者数据资源
	if ns.Type != blockchain.CatalogFileTypeOfData && ns.Type != blockchain.CatalogFileTypeOfModel {
		return shim.Error(errorx.NewError(errorx.ErrCodeParam, "invalid param:dataType").Error())
	}
	s, err := json.Marshal(ns)
	if err != nil {
		return shim.Error(errorx.Internal(err, "failed to marshal namespace").Error())
	}
	// get the message to sign
	msg, err := util.GetSigMessage(opt)
	if err != nil {
		return shim.Error(errorx.Internal(err, "failed to get the message to sign").Error())
	}
	// verify sig
	err = m.checkSign(opt.Signature, ns.Owner, []byte(msg))
	if err != nil {
		return shim.Error(err.Error())
	}

	// judge if packCatalogNsIndex exists
	catalogNsIndex := packCatalogNsIndex(ns.Type, ns.Name)
	if resp := m.GetValue(stub, []string{catalogNsIndex}); len(resp.Payload) != 0 {
		return shim.Error(errorx.NewError(errorx.ErrCodeAlreadyExists, "duplicated catalog namespace").Error())
	}
	// put index-catalog-ns on chain
	if resp := m.SetValue(stub, []string{catalogNsIndex, string(s)}); resp.Status == shim.ERROR {
		return shim.Error(errorx.NewError(errorx.ErrCodeWriteBlockchain,
			"failed to set index-catalog-ns on chain: %s", resp.Message).Error())
	}

	// put index-catalog-owner-ns on chain
	catalogOwnerNsIndex := packCatalogOwnerNsIndex(ns.Owner, ns.Type, ns.Name)
	if resp := m.SetValue(stub, []string{catalogOwnerNsIndex, string(s)}); resp.Status == shim.ERROR {
		return shim.Error(errorx.NewError(errorx.ErrCodeWriteBlockchain,
			"failed to set index-catalog-owner-ns on chain: %s", resp.Message).Error())
	}

	// put listIndex-catalog-ns on chain
	nsCatalogListIndex := packCatalogNsListIndex(ns.Owner, ns.Type, ns.Name, ns.CreateTime)
	if resp := m.SetValue(stub, []string{nsCatalogListIndex, string(s)}); resp.Status == shim.ERROR {
		return shim.Error(errorx.NewError(errorx.ErrCodeWriteBlockchain,
			"failed to set listIndex-catalog-ns on chain: %s", resp.Message).Error())
	}

	return shim.Success([]byte("OK"))
}

// ListCatalogNs lists catalog namespace
func (m *DtxManager) ListCatalogNs(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	if len(args) < 1 {
		return shim.Error("invalid arguments. expecting ListCatalogNsOptions")
	}
	// unmarshal opt
	var opt blockchain.ListCatalogNsOptions
	if err := json.Unmarshal([]byte(args[0]), &opt); err != nil {
		return shim.Error(errorx.Internal(err, "failed to unmarshal ListCatalogNsOptions").Error())
	}

	// 判断命名空间资源类型, 仅支持模型资源或者数据资源
	if opt.Type != blockchain.CatalogFileTypeOfData && opt.Type != blockchain.CatalogFileTypeOfModel {
		return shim.Error(errorx.NewError(errorx.ErrCodeParam, "invalid param:dataType").Error())
	}

	// pack prefix
	prefix, attr := packCatalogNsListFilter(opt.Type, opt.Owner)

	// get iter by prefix
	iterator, err := stub.GetStateByPartialCompositeKey(prefix, attr)
	if err != nil {
		return shim.Error(err.Error())
	}
	defer iterator.Close()

	// iterate iter
	var nss []blockchain.CatalogNamespace
	for iterator.HasNext() {
		queryResponse, err := iterator.Next()
		if err != nil {
			return shim.Error(err.Error())
		}
		if opt.Limit > 0 && int64(len(nss)) >= opt.Limit {
			break
		}
		var ns blockchain.CatalogNamespace
		if err := json.Unmarshal(queryResponse.Value, &ns); err != nil {
			return shim.Error(errorx.Internal(err, "failed to unmarshal namespaces").Error())
		}
		if ns.CreateTime < opt.TimeStart || (opt.TimeEnd > 0 && ns.CreateTime > opt.TimeEnd) {
			continue
		}
		nss = append(nss, ns)
	}

	s, err := json.Marshal(nss)
	if err != nil {
		return shim.Error(errorx.Internal(err, "failed to marshal namespace list").Error())
	}
	return shim.Success(s)
}

// PublishFileToCatalog publishes catalog files to chain
func (m *DtxManager) PublishFileToCatalog(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	// get PublishFileToCatalogOptions
	if len(args) < 1 {
		return shim.Error("invalid arguments. expecting PublishFileToCatalogOptions")
	}

	// unmarshal opt
	var opt blockchain.PublishFileToCatalogOptions
	if err := json.Unmarshal([]byte(args[0]), &opt); err != nil {
		return shim.Error(errorx.Internal(err, "failed to unmarshal PublishFileToCatalogOptions").Error())
	}

	// get file
	f := opt.File

	// 判断资源类型, 仅支持模型资源或者数据资源
	if f.Type != blockchain.CatalogFileTypeOfData && f.Type != blockchain.CatalogFileTypeOfModel {
		return shim.Error(errorx.NewError(errorx.ErrCodeParam, "invalid param:dataType").Error())
	}

	// verify sig
	msg, err := util.GetSigMessage(opt)
	if err != nil {
		return shim.Error(errorx.Internal(err, "failed to get the message to sign").Error())
	}
	err = m.checkSign(opt.Signature, f.Owner, []byte(msg))
	if err != nil {
		return shim.Error(err.Error())
	}

	f.Status = blockchain.CatalogFileOnlineStatus

	// judge if fileid exists，判断文件ID是否重复
	catalogFileID := packCatalogFileIDIndex(opt.File.FileID)
	if resp := m.GetValue(stub, []string{catalogFileID}); len(resp.Payload) != 0 {
		return shim.Error(errorx.NewError(errorx.ErrCodeAlreadyExists, "duplicated catalog fileID").Error())
	}

	// judge if packCatalogNsIndex exists，判断目录是否存在
	fileNsIndex := packCatalogNsIndex(f.Type, f.Namespace)
	if resp := m.GetValue(stub, []string{fileNsIndex}); len(resp.Payload) == 0 {
		return shim.Error(errorx.New(err, errorx.ErrCodeNotFound, "file namespace not found").Error())
	}

	// judge if filenameIndex exists，判断文件名是否重复
	filenameIndex := packFileNameIndex(f.Type, f.Namespace, f.Name)
	if resp := m.GetValue(stub, []string{filenameIndex}); len(resp.Payload) != 0 {
		fc, err := m.getFileByID(stub, string(resp.Payload))
		if err != nil {
			return shim.Error(err.Error())
		}
		// 文件是否过期
		if fc.ExpireTime > f.PublishTime {
			return shim.Error(errorx.NewError(errorx.ErrCodeAlreadyExists, "duplicated file name").Error())
		}
	}

	// marshal file
	s, err := json.Marshal(f)
	if err != nil {
		return shim.Error(errorx.New(err, errorx.ErrCodeInternal, "failed to marshal File").Error())
	}

	// if there's already a file with the same name in user's storage, overwrite it with the new one directly
	// set id-file on chain，设置数据资源/模型资源内容
	if resp := m.SetValue(stub, []string{catalogFileID, string(s)}); resp.Status == shim.ERROR {
		return shim.Error(errorx.NewError(errorx.ErrCodeWriteBlockchain,
			"failed to set id-file on chain: %s", resp.Message).Error())
	}

	// set filenameIndex-id on chain, 通过文件名查询文件详情
	if resp := m.SetValue(stub, []string{filenameIndex, catalogFileID}); resp.Status == shim.ERROR {
		return shim.Error(errorx.NewError(errorx.ErrCodeWriteBlockchain,
			"failed to set index-id on chain: %s", resp.Message).Error())
	}

	// 用于查询目录链下文件列表
	fileListByNsIndex := packCatalogFileListByNsIndex(f.Type, f.Namespace, f.PublishTime)
	if resp := m.SetValue(stub, []string{fileListByNsIndex, catalogFileID}); resp.Status == shim.ERROR {
		return shim.Error(errorx.NewError(errorx.ErrCodeWriteBlockchain,
			"failed to set catalogFileListByNsIndex-id on chain: %s", resp.Message).Error())
	}

	return shim.Success([]byte(stub.GetTxID()))
}

// ListCatalogFiles lists catalog files. contians data files and model files.
func (m *DtxManager) ListCatalogFiles(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	if len(args) < 1 {
		return shim.Error("invalid arguments. expecting ListCatalogFilesOptions")
	}

	// unmarshal opt
	var opt blockchain.ListCatalogFilesOptions
	if err := json.Unmarshal([]byte(args[0]), &opt); err != nil {
		return shim.Error(errorx.New(err, errorx.ErrCodeInternal,
			"failed to unmarshal ListCatalogFilesOptions").Error())
	}
	// 判断资源类型, 仅支持模型资源或者数据资源
	if opt.Type != blockchain.CatalogFileTypeOfData && opt.Type != blockchain.CatalogFileTypeOfModel {
		return shim.Error(errorx.NewError(errorx.ErrCodeParam, "invalid param:dataType").Error())
	}

	// pack prefix
	prefix, attr := packCatalogFileNameFilter(opt.Type, opt.Namespace)
	// get iter by prefix
	iterator, err := stub.GetStateByPartialCompositeKey(prefix, attr)
	if err != nil {
		return shim.Error(err.Error())
	}
	defer iterator.Close()

	// iterate iter
	var fs []blockchain.CatalogFile
	for iterator.HasNext() {
		queryResponse, err := iterator.Next()
		if err != nil {
			return shim.Error(err.Error())
		}

		if opt.Limit > 0 && int64(len(fs)) >= opt.Limit {
			break
		}
		f, err := m.getFileByID(stub, string(queryResponse.Value))
		if err != nil {
			return shim.Error(err.Error())
		}
		if f.PublishTime < opt.TimeStart || (opt.TimeEnd > 0 && f.PublishTime > opt.TimeEnd) || f.ExpireTime <= opt.CurrentTime {
			continue
		}
		if len(opt.Owner) > 0 && fmt.Sprintf("%x", f.Owner) != fmt.Sprintf("%x", opt.Owner) {
			continue
		}

		fs = append(fs, f)
	}

	s, err := json.Marshal(fs)
	if err != nil {
		return shim.Error(errorx.New(err, errorx.ErrCodeInternal, "failed to marshal Files").Error())
	}
	return shim.Success(s)
}

// GetCatalogFileDetailByFileName 根据文件名称查询文件详情
// 参数 currentTime用于判断文件是否过期
func (m *DtxManager) GetCatalogFileDetailByFileName(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	if len(args) < 4 {
		return shim.Error("invalid arguments. expecting owner, ns, name and currentTime")
	}

	// get catalog file data type
	dataType := args[0]
	// get ns
	ns := args[1]
	// get name
	name := args[2]
	// get current timestamp
	ctime, err := strconv.ParseInt(args[3], 10, 64)
	if err != nil {
		return shim.Error(errorx.New(err, errorx.ErrCodeInternal, "failed to parse params of currentTime").Error())
	}

	// judge if fileNsIndex exists
	fileNsIndex := packCatalogNsIndex(string(dataType), string(ns))
	if resp := m.GetValue(stub, []string{fileNsIndex}); len(resp.Payload) == 0 {
		return shim.Error(errorx.NewError(errorx.ErrCodeParam, "bad param, ns not found: %s", resp.Message).Error())
	}

	// pack filenameindex
	filenameIndex := packFileNameIndex(string(dataType), string(ns), string(name))
	//get id from index
	resp := m.GetValue(stub, []string{filenameIndex})
	if len(resp.Payload) == 0 {
		return shim.Error(errorx.NewError(errorx.ErrCodeNotFound, "fileID not found with name+ns: %s", resp.Message).Error())
	}
	// get file from id
	resp = m.GetValue(stub, []string{string(resp.Payload)})
	if len(resp.Payload) == 0 {
		return shim.Error(errorx.NewError(errorx.ErrCodeNotFound, "CatalogFile not found: %s", resp.Message).Error())
	}

	var f blockchain.CatalogFile
	if err = json.Unmarshal(resp.Payload, &f); err != nil {
		return shim.Error(errorx.New(err, errorx.ErrCodeInternal,
			"failed to unmarshal CatalogFile").Error())
	}
	if f.ExpireTime < ctime {
		return shim.Error(errorx.NewError(errorx.ErrCodeExpired, "CatalogFile already expire").Error())
	}
	return shim.Success(resp.Payload)
}

func (m *DtxManager) GetCatalogFileDetailByID(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	if len(args) < 2 {
		return shim.Error("invalid arguments. expecting id and currentTime")
	}

	// get id
	id := args[0]

	// get current timestamp
	ctime, err := strconv.ParseInt(args[1], 10, 64)
	if err != nil {
		return shim.Error(errorx.New(err, errorx.ErrCodeInternal, "failed to parse timestamp").Error())
	}

	//get file from id
	catalogFileID := packCatalogFileIDIndex(string(id))
	resp := m.GetValue(stub, []string{catalogFileID})
	if len(resp.Payload) == 0 {
		return shim.Error(errorx.NewError(errorx.ErrCodeNotFound, "CatalogFile not found: %s", resp.Message).Error())
	}
	var f blockchain.CatalogFile
	if err = json.Unmarshal(resp.Payload, &f); err != nil {
		return shim.Error(errorx.New(err, errorx.ErrCodeInternal, "failed to unmarshal CatalogFile").Error())
	}

	if f.ExpireTime < ctime {
		return shim.Error(errorx.NewError(errorx.ErrCodeExpired, "CatalogFile already expire").Error())
	}
	return shim.Success(resp.Payload)
}

func (m *DtxManager) OfflineCatalogFile(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	return m.setCatalogFileOnlineStatus(stub, args, false)
}

func (m *DtxManager) OnlineCatalogFile(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	return m.setCatalogFileOnlineStatus(stub, args, true)
}

// setCatalogFileOnlineStatus sets catalog file online/offline status in chain
func (m *DtxManager) setCatalogFileOnlineStatus(stub shim.ChaincodeStubInterface, args []string, online bool) pb.Response {
	// unmarshal opt
	var opt blockchain.CatalogFileOperationOpt
	if err := json.Unmarshal([]byte(args[0]), &opt); err != nil {
		return shim.Error(errorx.New(err, errorx.ErrCodeInternal,
			"failed to unmarshal CatalogFileOperationOpt").Error())
	}

	// get file from id
	catalogFileID := packCatalogFileIDIndex(opt.FileID)
	resp := m.GetValue(stub, []string{catalogFileID})
	if len(resp.Payload) == 0 {
		return shim.Error(errorx.NewError(errorx.ErrCodeNotFound, "catalog file not found: %s", resp.Message).Error())
	}
	// unmarshal CatalogFile
	var f blockchain.CatalogFile
	if err := json.Unmarshal(resp.Payload, &f); err != nil {
		return shim.Error(errorx.New(err, errorx.ErrCodeInternal,
			"failed to unmarshal CatalogFile").Error())
	}

	// both partners are able to operate model
	if !bytes.Equal(opt.Pubkey, f.Owner) {
		// get partner info
		resp := m.QueryOrgInfoByPK(stub, []string{string(opt.Pubkey)})
		if len(resp.Payload) == 0 {
			return shim.Error(errorx.NewError(errorx.ErrCodeNotFound, "orgInfo not found by pk").Error())
		}
		var org blockchain.OrgInfo
		if err := json.Unmarshal(resp.Payload, &org); err != nil {
			return shim.Error(errorx.New(err, errorx.ErrCodeInternal, "failed to unmarshal OrgInfo").Error())
		}
		if org.Name != f.PartnerName {
			return shim.Error(errorx.NewError(errorx.ErrCodeInternal, "not authorized to operate model").Error())
		}
	}

	// get the message to sign
	msg, err := util.GetSigMessage(opt)
	if err != nil {
		return shim.Error(errorx.Internal(err, "failed to get the message to sign").Error())
	}
	if err := m.checkSign(opt.Signature, opt.Pubkey, []byte(msg)); err != nil {
		return shim.Error(err.Error())
	}
	if online {
		f.Status = blockchain.CatalogFileOnlineStatus
	} else {
		f.Status = blockchain.CatalogFileOfflelineStatus
	}

	// marshal new catalog file
	newf, err := json.Marshal(f)
	if err != nil {
		return shim.Error(errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal new CatalogFile").Error())
	}

	// set id-file on chain，设置数据资源/模型资源内容
	if resp := m.SetValue(stub, []string{catalogFileID, string(newf)}); resp.Status == shim.ERROR {
		return shim.Error(errorx.NewError(errorx.ErrCodeWriteBlockchain,
			"failed to set id-file on chain: %s", resp.Message).Error())
	}

	return shim.Success([]byte("OK"))
}

// UpdateCatalogFileByID updates catalog file by ID, only data files can be updated.
func (m *DtxManager) UpdateCatalogFileByID(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	if len(args) < 1 {
		return shim.Error("invalid arguments. expecting UpdateCatalogFileOptions")
	}

	// unmarshal opt
	var opt blockchain.UpdateCatalogFileOptions
	if err := json.Unmarshal([]byte(args[0]), &opt); err != nil {
		return shim.Error(errorx.New(err, errorx.ErrCodeInternal,
			"failed to unmarshal UpdateCatalogFileOptions").Error())
	}
	//get file from id
	catalogFileID := packCatalogFileIDIndex(opt.FileID)
	f, err := m.getFileByID(stub, catalogFileID)
	if err != nil {
		return shim.Error(err.Error())
	}

	// 下线文件&过期文件不支持更新
	if f.Status == blockchain.CatalogFileOfflelineStatus || f.ExpireTime <= opt.CurrentTime {
		return shim.Error(errorx.New(err, errorx.ErrCodeNotFound, "catalog file is expired or is offline, can not update").Error())
	}

	// verify sig
	msg, err := util.GetSigMessage(opt)
	if err != nil {
		return shim.Error(errorx.Internal(err, "failed to get the message to sign").Error())
	}
	err = m.checkSign(opt.Signature, f.Owner, []byte(msg))
	if err != nil {
		return shim.Error(err.Error())
	}

	// marshal file
	f.ExpireTime = opt.NewExpireTime
	f.Version = opt.NewVersion
	f.Length = opt.NewLength
	f.Number = opt.NewNumber
	f.MerkleRoot = opt.NewMerkleRoot
	f.Ext = opt.NewExt

	newf, err := json.Marshal(f)
	if err != nil {
		return shim.Error(errorx.New(err, errorx.ErrCodeInternal, "failed to marshal File").Error())
	}
	// set id-file on chain
	if resp := m.SetValue(stub, []string{catalogFileID, string(newf)}); resp.Status == shim.ERROR {
		return shim.Error(errorx.NewError(errorx.ErrCodeWriteBlockchain,
			"failed to set id-file on chain: %s", resp.Message).Error())
	}
	return shim.Success([]byte("OK"))
}

func (m *DtxManager) getFileByID(stub shim.ChaincodeStubInterface, fileID string) (f blockchain.CatalogFile, err error) {
	resp := m.GetValue(stub, []string{fileID})
	if len(resp.Payload) == 0 {
		return f, errorx.New(err, errorx.ErrCodeNotFound, "file[%s] not found", fileID)
	}
	if err = json.Unmarshal(resp.Payload, &f); err != nil {
		return f, errorx.New(err, errorx.ErrCodeInternal, "failed to unmarshal File")
	}
	return f, nil
}

// checkSign 签名验证，仅存储数据的操作需要签名和验签
func (m *DtxManager) checkSign(sign, owner, mes []byte) (err error) {
	// verify sig
	if len(owner) != ecdsa.PublicKeyLength || len(sign) != ecdsa.SignatureLength {
		return errorx.NewError(errorx.ErrCodeParam, "bad param:signature")
	}
	var pubkey [ecdsa.PublicKeyLength]byte
	var sig [ecdsa.SignatureLength]byte
	copy(pubkey[:], owner)
	copy(sig[:], sign)
	if err := ecdsa.Verify(pubkey, hash.HashUsingSha256(mes), sig); err != nil {
		return errorx.New(err, errorx.ErrCodeBadSignature, "failed to verify signature")
	}
	return nil
}
