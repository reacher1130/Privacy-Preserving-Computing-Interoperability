package main

import (
	"fmt"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	pb "github.com/hyperledger/fabric/protos/peer"
)

type DtxManager struct{}

func (m *DtxManager) Init(stub shim.ChaincodeStubInterface) pb.Response {
	fmt.Println("init DtxManager chaincode")
	return shim.Success(nil)
}

func (m *DtxManager) Invoke(stub shim.ChaincodeStubInterface) pb.Response {
	fn, args := stub.GetFunctionAndParameters()
	switch fn {
	case "SetValue":
		return m.SetValue(stub, args)
	case "GetValue":
		return m.GetValue(stub, args)
	case "SetOrgInfo":
		return m.SetOrgInfo(stub, args)
	case "QueryOrgInfo":
		return m.QueryOrgInfo(stub, args)
	case "QueryOrgInfoByPK":
		return m.QueryOrgInfoByPK(stub, args)
	case "ListOrgInfo":
		return m.ListOrgInfo(stub, args)
	case "AddCatalogNamespace":
		return m.AddCatalogNamespace(stub, args)
	case "ListCatalogNs":
		return m.ListCatalogNs(stub, args)
	case "PublishFileToCatalog":
		return m.PublishFileToCatalog(stub, args)
	case "ListCatalogFiles":
		return m.ListCatalogFiles(stub, args)
	case "GetCatalogFileDetailByFileName":
		return m.GetCatalogFileDetailByFileName(stub, args)
	case "GetCatalogFileDetailByID":
		return m.GetCatalogFileDetailByID(stub, args)
	case "OfflineCatalogFile":
		return m.OfflineCatalogFile(stub, args)
	case "OnlineCatalogFile":
		return m.OnlineCatalogFile(stub, args)
	case "UpdateCatalogFileByID":
		return m.UpdateCatalogFileByID(stub, args)
	case "PublishCatalogFileAuth":
		return m.PublishCatalogFileAuth(stub, args)
	case "ConfirmCatalogFileAuth":
		return m.ConfirmCatalogFileAuth(stub, args)
	case "RejectCatalogFileAuth":
		return m.RejectCatalogFileAuth(stub, args)
	case "RecycleCatalogFileAuth":
		return m.RecycleCatalogFileAuth(stub, args)
	case "ListCatalogFileAuth":
		return m.ListCatalogFileAuth(stub, args)
	case "GetCatalogFileAuthDetailByID":
		return m.GetCatalogFileAuthDetailByID(stub, args)
	default:
		return shim.Error("Invalid invoke function name.")
	}
}

func (m *DtxManager) SetValue(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	err := stub.PutState(args[0], []byte(args[1]))
	if err != nil {
		return shim.Error("set right fail " + err.Error())
	}
	return shim.Success(nil)
}

func (m *DtxManager) GetValue(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	result, err := stub.GetState(args[0])
	if err != nil {
		return shim.Error("query" + args[0] + " fail:" + err.Error())
	}
	return shim.Success(result)
}

func main() {
	err := shim.Start(new(DtxManager))
	if err != nil {
		fmt.Printf("failed to start DtxManager chaincode: %s", err)
	}
}
