package main

import (
	"baidu/blockchain/dtx-manager/blockchain"
	errorx "baidu/blockchain/dtx-manager/pkg/codeerror"
	"encoding/json"

	util "github.com/PaddlePaddle/PaddleDTX/xdb/pkgs/strings"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	pb "github.com/hyperledger/fabric/protos/peer"
)

func (m *DtxManager) SetOrgInfo(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	// get
	if len(args) < 1 {
		return shim.Error("invalid arguments. expecting OrgInfo")
	}

	// unmarshal opt
	var opt blockchain.OrgInfo
	if err := json.Unmarshal([]byte(args[0]), &opt); err != nil {
		return shim.Error(errorx.New(err, errorx.ErrCodeInternal,
			"failed to unmarshal OrgInfo").Error())
	}

	msg, err := util.GetSigMessage(opt)
	if err != nil {
		return shim.Error(errorx.Internal(err, "failed to get the message to sign").Error())
	}
	// verify signature by applier's public key
	err = m.checkSign(opt.Signature, opt.Pubkey, []byte(msg))
	if err != nil {
		return shim.Error(err.Error())
	}

	if resp := m.SetValue(stub, []string{packOrgInfoPK(opt.Pubkey), args[0]}); resp.Status == shim.ERROR {
		return shim.Error(errorx.NewError(errorx.ErrCodeWriteBlockchain,
			"failed to set SetOrgInfo on chain: %s", resp.Message).Error())
	}

	if resp := m.SetValue(stub, []string{packOrgInfoID([]byte(opt.ID)), args[0]}); resp.Status == shim.ERROR {
		return shim.Error(errorx.NewError(errorx.ErrCodeWriteBlockchain,
			"failed to set SetOrgInfo on chain: %s", resp.Message).Error())
	}

	return shim.Success([]byte("OK"))
}

func (m *DtxManager) QueryOrgInfoByPK(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	if len(args) < 1 {
		return shim.Error("invalid arguments. expecting OrgInfo.Pubkey")
	}

	resp := m.GetValue(stub, []string{packOrgInfoPK([]byte(args[0]))})
	if len(resp.Payload) == 0 {
		return shim.Error(errorx.NewError(errorx.ErrCodeNotFound, "OrgInfo not found: %s", resp.Message).Error())
	}
	return shim.Success(resp.Payload)
}

func (m *DtxManager) QueryOrgInfo(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	if len(args) < 1 {
		return shim.Error("invalid arguments. expecting OrgInfo.ID")
	}

	resp := m.GetValue(stub, []string{packOrgInfoID([]byte(args[0]))})
	if len(resp.Payload) == 0 {
		return shim.Error(errorx.NewError(errorx.ErrCodeNotFound, "OrgInfo not found: %s", resp.Message).Error())
	}
	return shim.Success(resp.Payload)
}

func (m *DtxManager) ListOrgInfo(stub shim.ChaincodeStubInterface, args []string) pb.Response {

	// get iter by prefix
	iterator, err := stub.GetStateByPartialCompositeKey(prefixOrgInfoPK, []string{})
	if err != nil {
		return shim.Error(err.Error())
	}
	defer iterator.Close()

	// iterate iter
	var orgs []*blockchain.OrgInfo
	for iterator.HasNext() {
		queryResponse, err := iterator.Next()
		if err != nil {
			return shim.Error(err.Error())
		}
		var org blockchain.OrgInfo
		err = json.Unmarshal(queryResponse.Value, &org)
		if err != nil {
			continue
		}
		if org.Apply == 1 {
			//	orgs = append(orgs, &org)
		}
		orgs = append(orgs, &org)
	}

	s, err := json.Marshal(orgs)
	if err != nil {
		return shim.Error(errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal OrgInfo").Error())
	}
	return shim.Success(s)
}
