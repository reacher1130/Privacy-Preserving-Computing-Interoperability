package fabric

import (
	"encoding/json"
	"strconv"
	"time"

	"baidu/blockchain/dtx-manager/blockchain"
	errorx "baidu/blockchain/dtx-manager/pkg/codeerror"
)

// AddCatalogNamespace 新增资源命名空间
func (f *Fabric) AddCatalogNamespace(opt *blockchain.AddCatalogNsOptions) error {
	s, err := json.Marshal(*opt)
	if err != nil {
		return errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal AddCatalogNsOptions")
	}

	if _, err = f.InvokeManagerContract([][]byte{s}, "AddCatalogNamespace"); err != nil {
		return err
	}
	return nil
}

// ListCatalogNs 查询目录链列表
func (f *Fabric) ListCatalogNs(opt *blockchain.ListCatalogNsOptions) (blockchain.CatalogNsList, error) {
	var ns blockchain.CatalogNsList
	opts, err := json.Marshal(*opt)
	if err != nil {
		return ns, errorx.New(err, errorx.ErrCodeInternal, "failed to marshal ListCatalogNsOptions")
	}

	resp, err := f.QueryManagerContract([][]byte{opts}, "ListCatalogNs")
	if err != nil {
		return ns, err
	}
	if len(resp) == 0 {
		return ns, nil
	}
	if err = json.Unmarshal(resp, &ns); err != nil {
		return ns, errorx.New(err, errorx.ErrCodeInternal,
			"failed to unmarshal CatalogFile Ns")
	}
	return ns, nil
}

// PublishFileToCatalog 发布数据或模型到目录链
func (f *Fabric) PublishFileToCatalog(opt *blockchain.PublishFileToCatalogOptions) (string, error) {
	s, err := json.Marshal(*opt)
	if err != nil {
		return "", errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal PublishFileToCatalogOptions")
	}

	var txid []byte
	if txid, err = f.InvokeManagerContract([][]byte{s}, "PublishFileToCatalog"); err != nil {
		return "", err
	}
	return string(txid), nil
}

// ListCatalogFiles 查询目录链下资源文件
func (f *Fabric) ListCatalogFiles(opt *blockchain.ListCatalogFilesOptions) (blockchain.CatalogFileList, error) {
	var files blockchain.CatalogFileList

	opts, err := json.Marshal(*opt)
	if err != nil {
		return files, errorx.New(err, errorx.ErrCodeInternal, "failed to marshal ListCatalogFilesOptions")
	}

	s, err := f.QueryManagerContract([][]byte{opts}, "ListCatalogFiles")
	if err != nil {
		return files, err
	}
	if len(s) == 0 {
		return files, nil
	}
	if err = json.Unmarshal(s, &files); err != nil {
		return files, errorx.New(err, errorx.ErrCodeInternal,
			"failed to unmarshal Catalog Files")
	}
	return files, nil
}

// GetCatalogFileDetailByFileName 通过资源名称查询资源详情
func (f *Fabric) GetCatalogFileDetailByFileName(dataType, namespace, name string) (blockchain.CatalogFile, error) {
	var file blockchain.CatalogFile

	args := [][]byte{[]byte(dataType), []byte(namespace), []byte(name), []byte(strconv.FormatInt(time.Now().UnixNano(), 10))}
	s, err := f.QueryManagerContract(args, "GetCatalogFileDetailByFileName")
	if err != nil {
		return file, err
	}
	if err = json.Unmarshal(s, &file); err != nil {
		return file, errorx.New(err, errorx.ErrCodeInternal, "failed to unmarshal Catalog File")
	}

	return file, nil
}

// GetCatalogFileDetailByID 通过资源id查询资源详情
func (f *Fabric) GetCatalogFileDetailByID(id string) (blockchain.CatalogFile, error) {
	var file blockchain.CatalogFile
	args := [][]byte{[]byte(id), []byte(strconv.FormatInt(time.Now().UnixNano(), 10))}
	s, err := f.QueryManagerContract(args, "GetCatalogFileDetailByID")
	if err != nil {
		return file, err
	}

	if err = json.Unmarshal(s, &file); err != nil {
		return file, errorx.New(err, errorx.ErrCodeInternal, "failed to unmarshal Catalog File")
	}

	return file, nil
}

// 下线数据或模型资源
func (f *Fabric) OfflineCatalogFile(opt *blockchain.OfflineCatalogFileOpt) error {
	s, err := json.Marshal(*opt)
	if err != nil {
		return errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal OfflineCatalogFileOpt")
	}

	if _, err = f.InvokeManagerContract([][]byte{s}, "OfflineCatalogFile"); err != nil {
		return err
	}
	return nil
}

// 上线数据或模型资源
func (f *Fabric) OnlineCatalogFile(opt *blockchain.OnlineCatalogFileOpt) error {
	s, err := json.Marshal(*opt)
	if err != nil {
		return errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal OnlineCatalogFileOpt")
	}

	if _, err = f.InvokeManagerContract([][]byte{s}, "OnlineCatalogFile"); err != nil {
		return err
	}
	return nil
}

// UpdateCatalogFileByID 更新数据资源
func (f *Fabric) UpdateCatalogFileByID(opt *blockchain.UpdateCatalogFileOptions) error {
	s, err := json.Marshal(*opt)
	if err != nil {
		return errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal UpdateCatalogFileOptions")
	}

	if _, err := f.InvokeManagerContract([][]byte{s}, "UpdateCatalogFileByID"); err != nil {
		return err
	}
	return nil
}
