package fabric

import (
	"encoding/json"

	"baidu/blockchain/dtx-manager/blockchain"
	errorx "baidu/blockchain/dtx-manager/pkg/codeerror"
)

// PublishCatalogFileAuth 发布目录链申请权限
func (f *Fabric) PublishCatalogFileAuth(opt *blockchain.PublishCatalogFileAuthOptions) error {
	s, err := json.Marshal(*opt)
	if err != nil {
		return errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal PublishCatalogFileAuthOptions")
	}

	if _, err = f.InvokeManagerContract([][]byte{s}, "PublishCatalogFileAuth"); err != nil {
		return err
	}
	return nil
}

// ConfirmCatalogFileAuth 确认权限申请
func (f *Fabric) ConfirmCatalogFileAuth(opt *blockchain.ConfirmCatalogFileAuthOptions) error {
	s, err := json.Marshal(*opt)
	if err != nil {
		return errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal ConfirmCatalogFileAuthOptions")
	}

	if _, err = f.InvokeManagerContract([][]byte{s}, "ConfirmCatalogFileAuth"); err != nil {
		return err
	}
	return nil
}

// RejectCatalogFileAuth 拒绝资源权限权限申请
func (f *Fabric) RejectCatalogFileAuth(opt *blockchain.RejectCatalogFileAuthOptions) error {
	s, err := json.Marshal(*opt)
	if err != nil {
		return errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal RejectCatalogFileAuthOptions")
	}

	if _, err = f.InvokeManagerContract([][]byte{s}, "RejectCatalogFileAuth"); err != nil {
		return err
	}
	return nil
}

// RecycleCatalogFileAuth 回收资源权限权限申请
func (f *Fabric) RecycleCatalogFileAuth(opt *blockchain.RecycleCatalogFileAuthOptions) error {
	s, err := json.Marshal(*opt)
	if err != nil {
		return errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal RecycleCatalogFileAuthOptions")
	}

	if _, err = f.InvokeManagerContract([][]byte{s}, "RecycleCatalogFileAuth"); err != nil {
		return err
	}
	return nil
}

// ListCatalogFileAuth 查询授权申请列表
func (f *Fabric) ListCatalogFileAuth(opt *blockchain.ListCatalogFileAuthOptions) (blockchain.CatalogFileAuthList, error) {
	var fas blockchain.CatalogFileAuthList

	opts, err := json.Marshal(*opt)
	if err != nil {
		return fas, errorx.New(err, errorx.ErrCodeInternal,
			"fail to marshal ListCatalogFileAuthOptions")
	}
	s, err := f.QueryManagerContract([][]byte{opts}, "ListCatalogFileAuth")
	if err != nil {
		return fas, err
	}
	if err = json.Unmarshal(s, &fas); err != nil {
		return fas, errorx.New(err, errorx.ErrCodeInternal,
			"fail to unmarshal CatalogFileAuthList")
	}
	return fas, nil
}

// GetCatalogFileAuthDetailByID 查询授权申请详情
func (f *Fabric) GetCatalogFileAuthDetailByID(authID string) (blockchain.CatalogFileAuthApplication, error) {
	var fa blockchain.CatalogFileAuthApplication
	s, err := f.QueryManagerContract([][]byte{[]byte(authID)}, "GetCatalogFileAuthDetailByID")
	if err != nil {
		return fa, err
	}

	if err = json.Unmarshal(s, &fa); err != nil {
		return fa, errorx.New(err, errorx.ErrCodeInternal, "fail to unmarshal CatalogFileAuth")
	}

	return fa, nil
}
