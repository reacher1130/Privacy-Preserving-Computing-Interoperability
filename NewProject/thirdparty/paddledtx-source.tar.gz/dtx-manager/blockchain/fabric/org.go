package fabric

import (
	"baidu/blockchain/dtx-manager/blockchain"
	errorx "baidu/blockchain/dtx-manager/pkg/codeerror"
	"encoding/json"
)

// SetOrgInfo
func (f *Fabric) SetOrgInfo(opt *blockchain.OrgInfo) error {
	s, err := json.Marshal(*opt)
	if err != nil {
		return errorx.New(err, errorx.ErrCodeInternal,
			"failed to marshal OrgInfo")
	}

	if _, err = f.InvokeManagerContract([][]byte{s}, "SetOrgInfo"); err != nil {
		return err
	}
	return nil
}

// QueryOrgInfo
func (f *Fabric) QueryOrgInfo(id string) (*blockchain.OrgInfo, error) {
	var org blockchain.OrgInfo
	s, err := f.QueryManagerContract([][]byte{[]byte(id)}, "QueryOrgInfo")
	if err != nil {
		return nil, err
	}

	if err = json.Unmarshal(s, &org); err != nil {
		return nil, errorx.New(err, errorx.ErrCodeInternal, "fail to unmarshal OrgInfo")
	}
	return &org, nil
}

// QueryOrgInfoByPK
func (f *Fabric) QueryOrgInfoByPK(pubkey string) (*blockchain.OrgInfo, error) {
	var org blockchain.OrgInfo
	s, err := f.QueryManagerContract([][]byte{[]byte(pubkey)}, "QueryOrgInfoByPK")
	if err != nil {
		return nil, err
	}

	if err = json.Unmarshal(s, &org); err != nil {
		return nil, errorx.New(err, errorx.ErrCodeInternal, "fail to unmarshal OrgInfo")
	}
	return &org, nil
}

func (f *Fabric) ListOrgInfo() ([]*blockchain.OrgInfo, error) {
	var orgs []*blockchain.OrgInfo
	s, err := f.QueryManagerContract([][]byte{}, "ListOrgInfo")
	if err != nil {
		return nil, err
	}

	if err = json.Unmarshal(s, &orgs); err != nil {
		return nil, errorx.New(err, errorx.ErrCodeInternal, "fail to unmarshal OrgInfo")
	}
	// 去重
	var uniqueOrgInfo []*blockchain.OrgInfo
	if orgs != nil {
		m := make(map[string]interface{})
		// 筛选未审批的机构
		for _, orgInfo := range orgs {
			if m[orgInfo.ID] != nil {
				continue
			} else {
				m[orgInfo.ID] = orgInfo
				uniqueOrgInfo = append(uniqueOrgInfo, orgInfo)
			}
		}
		// 将审批后的加入map
		for _, orgInfo := range orgs {
			if orgInfo.Apply != 0 {
				m[orgInfo.ID] = orgInfo
				uniqueOrgInfo = append(uniqueOrgInfo, orgInfo)
			}
		}
	}

	return uniqueOrgInfo, nil
}
