package blockchain

const (
	CatalogFileOnlineStatus    = "online"  // 在线状态
	CatalogFileOfflelineStatus = "offline" // 下线状态

	CatalogFileTypeOfData  = "data"  // 数据资源
	CatalogFileTypeOfModel = "model" // 模型资源

	StorageTypeLocal = "local" // 本地存储
	StorageTypeXdb   = "xdb"   // xdb存储

	// Define Catalog File authorization status stored in Contract
	CatalogFileAuthUnapproved = "Unapproved" // the applier published file's authorization application and the authorizer has not yet approved
	CatalogFileAuthApproved   = "Approved"   // the authorizer approved applier's authorization application
	CatalogFileAuthRejected   = "Rejected"   // the authorizer rejected applier's authorization application
	CatalogFileAuthRecycled   = "Recycled"   // the applier's authorization application is recycled

	// 定义授权类型
	CatalogFileAuthLook = "Look" // 查看权限，数据资源authKey不为空
	CatalogFileAuthUse  = "Use"  // 使用权限，使用权限的authKey为空
)

// 机构信息
type OrgInfo struct {
	ID        string `json:"orgID"`
	Name      string `json:"orgName"`
	DID       string `json:"orgDID"`
	Pubkey    []byte `json:"pubkey"`
	Signature []byte `json:"signature"`
	Apply     int    `json:"apply"`
}

// 资源命名空间管理
type CatalogNamespace struct {
	Name        string `json:"name"`
	Description string `json:"description"`
	Owner       []byte `json:"owner"`
	Type        string `json:"type"`
	CreateTime  int64  `json:"createTime"`
}

// 新增资源命名空间
type AddCatalogNsOptions struct {
	Namespace CatalogNamespace `json:"namespace"` // 命名空间
	Signature []byte           `json:"signature"` // 对namespace签名
}

// 查询资源命名空间
type ListCatalogNsOptions struct {
	Owner     []byte `json:"owner"` // 目录链是公开资源，无需owner，非必传字段，不传，默认查询所有空开目录链
	Type      string `json:"type"`  // 目录链资源空间类型，数据资源命名空间或模型资源命名空间
	TimeStart int64  `json:"timeStart"`
	TimeEnd   int64  `json:"timeEnd"`
	Limit     int64  `json:"limit"`
}

type CatalogNsList []CatalogNamespace

// 目录链结构
type CatalogFile struct {
	FileID      string `json:"fileID"` // 数据资源或模型资源，全局唯一键
	TaskID      string `json:"taskID"`
	Type        string `json:"type"`        // 资源类型，数据资源或服务资源
	StorageType string `json:"storageType"` // 存储方式
	Name        string `json:"name"`        // 文件名称或模型名称，type+ns+name下唯一
	Version     string `json:"version"`     // 文件版本
	Description string `json:"description"`
	Namespace   string `json:"namespace"`
	MerkleRoot  []byte `json:"merkleRoot"`
	Status      string `json:"status"`      // 状态，上线或下线, "online"代表上线，"offline"代表下线
	Owner       []byte `json:"owner"`       // 发布方公钥
	OwnerName   string `json:"ownerName"`   // 资源发布方组织名称
	PartnerName string `json:"partnerName"` // 协作方组织名称
	Length      uint64 `json:"length"`      // 文件大小
	PublishTime int64  `json:"publishTime"`
	ExpireTime  int64  `json:"expireTime"` // file expire time，过期时间, 不允许为空
	Number      int64  `json:"number"`     // 样本总数
	Ext         []byte `json:"ext"`        // 密文数据，上层业务加密存储
}

// 更新数据资源
type UpdateCatalogFileOptions struct {
	FileID        string `json:"fileID"`        // 数据资源或模型资源文件ID，全局唯一
	NewExpireTime int64  `json:"newExpireTime"` // 必传
	NewVersion    string `json:"newVersion"`    // 必传
	NewLength     uint64 `json:"length"`        // 必传
	NewNumber     int64  `json:"newNumber"`     // 必传
	NewMerkleRoot []byte `json:"merkleRoot"`    // 必传
	NewExt        []byte `json:"newExt"`        // 必传
	CurrentTime   int64  `json:"currentTime"`   // 必传
	Signature     []byte `json:"signature"`     // 必传
}

type CatalogFileList []CatalogFile

// 数据资源或模型服务资源发布
type PublishFileToCatalogOptions struct {
	File      CatalogFile `json:"catalogFile"` // 文件
	Signature []byte      `json:"signature"`   // 对file签名
}

// 查询数据或模型资源
type ListCatalogFilesOptions struct {
	Owner       []byte `json:"owner"`       // 非必传
	Namespace   string `json:"namespace"`   // 非必传
	CurrentTime int64  `json:"currentTime"` // 非必传，如果传该值，则文件过期时间会与CurrentTime比较，过滤掉已经过期的文件
	Type        string `json:"type"`        // 必传, 否则查询结果为空
	TimeStart   int64  `json:"timeStart"`
	TimeEnd     int64  `json:"timeEnd"`
	Limit       int64  `json:"limit"`
}

// 下线数据或模型资源
type CatalogFileOperationOpt struct {
	FileID    string `json:"fileID"` // 数据或模型资源ID
	Pubkey    []byte `json:"pubkey"`
	Signature []byte `json:"signature"` // 签名
}

// 上线模型或数据资源
type OfflineCatalogFileOpt CatalogFileOperationOpt
type OnlineCatalogFileOpt CatalogFileOperationOpt

// 数据或模型资源权限管理
type CatalogFileAuthApplication struct {
	ID           string   `json:"id"`           // authID
	FileID       string   `json:"fileID"`       // 数据资源或模型资源ID，全局唯一键
	DataType     string   `json:"dataType"`     // 资源类型，数据资源或服务资源
	TaskID       string   `json:"taskID"`       // 服务资源ID、即任务ID，冗余存储一下，方便查询
	Name         string   `json:"name"`         // 权限申请名称，由申请方提供
	Description  string   `json:"description"`  // 授权描述
	Applier      []byte   `json:"applier"`      // 发起方
	Authorizer   []byte   `json:"authorizer"`   // 授权方
	Type         string   `json:"type"`         // 权限申请类型，申请查看或申请使用，模型资源仅有申请使用权限，权限申请类型说明见下文
	AuthKey      []byte   `json:"authKey"`      // 查看申请授权时，该值必传
	Status       string   `json:"status"`       // 待审批、已通过、已拒绝、已回收
	CreateTime   int64    `json:"createTime"`   // 发起授权申请时间
	ApprovalTime int64    `json:"approvalTime"` // 授权时间
	RejectReason string   `json:"rejectReason"` // 授权通过时，该值为空，授权拒绝或授权被回收，该值为拒绝理由或回收理由
	ExpireTime   int64    `json:"expireTime"`   // 授权到期时间
	Features     []string `json:"features"`     // 申请查看的特征列信息，由申请方指定，申请查看时，该字段为空，申请使用则需要传入特征列信息
}

// 发起权限申请
type PublishCatalogFileAuthOptions struct {
	FileAuthApplication CatalogFileAuthApplication `json:"fileAuthApplication"`
	Signature           []byte                     `json:"signature"` //对fileAuthApplication签名
}

// 确认权限申请
type ConfirmCatalogFileAuthOptions struct {
	ID          string `json:"id"` // authID
	AuthKey     []byte `json:"authKey"`
	CurrentTime int64  `json:"currentTime"`
	ExpireTime  int64  `json:"expireTime"`
	Signature   []byte `json:"signature"`
}

// 拒绝权限申请
type RejectCatalogFileAuthOptions struct {
	ID           string `json:"id"`
	CurrentTime  int64  `json:"currentTime"`
	RejectReason string `json:"rejectReason"`
	Signature    []byte `json:"signature"`
}

// 权限回收
type RecycleCatalogFileAuthOptions struct {
	ID            string `json:"id"`
	CurrentTime   int64  `json:"currentTime"`
	RecycleReason string `json:"recycleReason"`
	Signature     []byte `json:"signature"`
}

// 查询权限列表
type ListCatalogFileAuthOptions struct {
	Applier    []byte `json:"applier"` // applier与authorizer不可同时为空
	Authorizer []byte `json:"authorizer"`
	FileID     string `json:"fileID"`     // 数据资源或者模型资源ID，可为空
	DataType   string `json:"dataType"`   // 资源类型，数据资源或服务资源, 不可为空
	DataStatus string `json:"dataStatus"` // 数据状态: 数据资源状态
	AuthType   string `json:"authType"`   //Use Look
	Status     string `json:"status"`     // 授权状态: 待审批、已通过、已拒绝、已回收
	TimeNow    int64  `json:"timeNow"`    // 请求发出的时间
	TimeStart  int64  `json:"timeStart"`  // 可为空
	TimeEnd    int64  `json:"timeEnd"`    // 可为空
	Limit      int64  `json:"limit"`      // 可为空
	PageNo     int64  `json:"pageNo"`     // 可为空, 缺省为1
	PageSize   int64  `json:"pageSize"`   // 可为空, 缺省为0, 返回所有
}

type CatalogFileAuthList struct {
	Total int64                        `json:"total"`
	List  []CatalogFileAuthApplication `json:"list"`
}

// 对于数据资源，CatalogFile的Ext字段包含每个特征的解析信息
// 解析信息包括名称、类型、描述、统计信息
// Ext可通过对 map[string]CatalogFileInfo 进行json编码获得
type CatalogFileInfo struct {
	Name        string   `json:"name"`
	Type        string   `json:"type"` // 类型可分为float和string两种
	Description string   `json:"description"`
	DataInfo    DataInfo `json:"dataInfo"`
}

// 数据资源每个特征的统计信息，包括均值、最大值、最小值、中位数、众数、标准差
// float类型的特征，计算Mean、Maximum、Minimum、Median、StandDev
// string类型的特征，计算Mode
type DataInfo struct {
	Mean     float64 `json:"mean"`
	Maximum  float64 `json:"maximum"`
	Minimum  float64 `json:"minimum"`
	Median   float64 `json:"median"`
	Mode     string  `json:"mode"`
	StandDev float64 `json:"standDev"`
}

// 对于模型资源，CatalogFile的Ext字段包含模型的评估结果，本期只支持静态模型评估
type ModelInfo struct {
	ModelEval     float64 `json:"modelEval"`
	ModelLiveEval float64 `json:"modelLiveEval"`
}
