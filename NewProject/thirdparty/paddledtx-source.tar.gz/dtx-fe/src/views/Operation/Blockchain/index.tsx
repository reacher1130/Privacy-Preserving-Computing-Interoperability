import React, {useEffect, useState} from 'react';
import {Col, Row, message, Table} from 'antd';
import type {TablePaginationConfig} from 'antd/es/table';
import styles from './index.less';
import {NavKeys, useCurrentNav} from '@/slice/sider';
import Content from '@/components/Content';

import {
  BlockchainListResponse,
  getBlockchainList,
} from '@/libs/api';

const {Column} = Table;
const STATUS = {
  Running: '运行中',
};
type StatusType = typeof STATUS | {[key: string]: string};
export default function Blockchain() {
  useCurrentNav(NavKeys.operationBlockchain);
  const [messageApi, contextHolder] = message.useMessage();
  const [resp, setResp] = useState<BlockchainListResponse['data']>({
    mnemonic: '',
    contractName: '',
    nodeList: [],
  });
  const pageSize = 10;
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState<TablePaginationConfig>({
    current: 1,
    pageSize,
  });
  const handleTableChange = (pagination: TablePaginationConfig) => {
    setPagination({
      ...pagination,
    });
  };
  useEffect(() => {
    getBlockchainList({})
      .then(resp => {
        if (+resp.code === 0) {
          const data = resp.data;
          setResp(data);
        } else {
          messageApi.error('系统错误请稍后重试');
        }
        setLoading(false);
      })
      .catch(err => {
        messageApi.error('系统错误请稍后重试');
        console.error(err);
        setLoading(false);
      });
  }, []);
  return (
    <Content>
      {contextHolder}
      <div className={styles.infoBox}>
        <Row className={styles.gridBox} gutter={[16, 24]}>
          <Col flex="100px" className={styles.grid}>
            合约名称：
          </Col>
          <Col flex="auto" className={styles.grid}>
            {resp?.contractName ? resp?.contractName : '--'}
          </Col>
        </Row>
      </div>
      <Table
        className={styles.list}
        pagination={pagination}
        dataSource={resp?.nodeList}
        loading={loading}
        onChange={handleTableChange}
        rowKey={record => `${record.name}_${Math.random() * 100}`}
      >
        <Column title="区块链节点名称" dataIndex="name" key="name" />
        <Column title="区块链节点地址" dataIndex="host" key="host" />
        <Column
          title="区块链节点状态"
          dataIndex="status"
          key="status"
          render={status => (
            <span className={styles[status as keyof StatusType]}>
              {STATUS[status as keyof StatusType]}
            </span>
          )}
        />
      </Table>
    </Content>
  );
}
