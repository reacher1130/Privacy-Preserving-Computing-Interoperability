import React, {
  PropsWithChildren,
  useEffect,
  useState,
  useCallback,
} from 'react';
import {useNavigate} from 'react-router-dom';
import {
  message,
  Col,
  Row,
  Tabs,
  TabsProps,
  Table,
  Form,
  Input,
  InputNumber,
} from 'antd';
import {useForm} from 'antd/es/form/Form';
import {useSelector, useDispatch} from 'react-redux';
import {PlusOutlined} from '@ant-design/icons';
import type {TablePaginationConfig} from 'antd/es/table';
import cx from 'classnames';
import {tdRender} from '@/components/Table/ToolTip';
import Empty from '@components/Empty';
import DotStatus from '@/components/DotStatus';

import * as echarts from 'echarts/core';
// import * as echartall from 'echarts';
import {PieChart} from 'echarts/charts';
import {
  ToolboxComponent,
  TitleComponent,
  TooltipComponent,
  GridComponent,
  MarkPointComponent,
  MarkLineComponent,
  LegendComponent,
  DatasetComponent,
  TransformComponent,
} from 'echarts/components';
import {CanvasRenderer} from 'echarts/renderers';
import type {
  // 组件类型的定义后缀都为 ComponentOption
  TitleComponentOption,
  TooltipComponentOption,
  GridComponentOption,
  DatasetComponentOption,
} from 'echarts/components';
import type {ComposeOption} from 'echarts/core';

import {getFormSubmissionInfo} from 'react-router-dom/dist/dom';
import styles from './index.less';
import {
  AllNode,
  StorageAllNode,
  deleteStorageNode,
  modifyStorageNode,
  deleteDataOwnerNode,
  modifyDataOwnerNode,
  getStorageOverview,
  getStorageNodeList,
  StorageOverviewResponse,
  StorageNodeListResponse,
} from '@/libs/api';
import ModalBox from '@/components/Modal';
import Button from '@/components/Button';
import Content from '@/components/Content';
import {NavKeys, useCurrentNav} from '@/slice/sider';
import {StorageListHeader, DataListHeader} from '@/views/Operation/AddNode';
import {PwD} from '../PermissonWrap';
import {PermissionValue} from '@/pages/Account/PermissionCreator';
import {BaseResponse} from '@/slice/commonApi';

// 通过 ComposeOption 来组合出一个只有必须组件和图表的 Option 类型
type ECOption = ComposeOption<
  | TitleComponentOption
  | TooltipComponentOption
  | GridComponentOption
  | DatasetComponentOption
>;
echarts.use([
  ToolboxComponent,
  TitleComponent,
  TooltipComponent,
  GridComponent,
  MarkPointComponent,
  MarkLineComponent,
  LegendComponent,
  DatasetComponent,
  TransformComponent,
  PieChart,
  CanvasRenderer,
]);
// type EChartsOption = echartall.EChartsOption;

const {Column} = Table;
type StorageTabsProps = PropsWithChildren;

const ModifyModelBox: React.FC<{
  name: string;
  type: string;
  open: boolean;
  resetModifyModel: () => void;
  onOk: () => void;
}> = ({name, type, open = false, resetModifyModel, onOk}) => {
  const [form] = useForm();

  const onSubmit = useCallback(() => {
    form.validateFields().then(async values => {
      if (type === '数据') {
        var resp = await modifyDataOwnerNode({...values});
      } else {
        var resp = await modifyStorageNode({...values});
      }
      if (+resp.code === 0) {
        onOk();
        resetModifyModel();
        message.success('修改成功');
      } else {
        message.error(resp.msg);
      }
    }, console.error);
  }, [form]);

  return (
    <div className={styles.header}>
      <ModalBox
        title={`修改${type}节点`}
        open={open}
        onOk={onSubmit}
        onCancel={() => resetModifyModel()}
      >
        <Form
          form={form}
          labelCol={{flex: '100px'}}
          initialValues={
            type === 'data' ? {dataownerName: name} : {storageName: name}
          }
        >
          {type === 'data' ? (
            <Form.Item
              name="dataownerName"
              label="节点名称"
              rules={[
                {
                  min: 4,
                  max: 20,
                  required: true,
                  message: '请输入节点序号，4到20个字符',
                },
              ]}
            >
              <Input placeholder="请输入节点序号" disabled />
            </Form.Item>
          ) : (
            <Form.Item
              name="storageName"
              label="节点名称"
              rules={[
                {
                  min: 4,
                  max: 20,
                  required: true,
                  message: '请输入节点序号，4到20个字符',
                },
              ]}
            >
              <Input placeholder="请输入节点序号" disabled />
            </Form.Item>
          )}
          <Form.Item
            name="replicas"
            label="服务副本数量"
            rules={[
              {
                type: 'number',
                required: true,
                message: '请输入服务副本数量，4到20个字符',
              },
            ]}
          >
            <InputNumber
              placeholder="请输入服务副本数量"
              controls={false}
              style={{width: '100%'}}
            />
          </Form.Item>
        </Form>
      </ModalBox>
    </div>
  );
};

const StorageTabs: React.FC<StorageTabsProps> = (props: StorageTabsProps) => {
  const pageSize = 10;
  const [loading, setLoading] = useState(false);
  const [pagination, setPagination] = useState<TablePaginationConfig>({
    current: 1,
    pageSize,
  });
  const handleTableChange = (pagination: TablePaginationConfig) => {
    setPagination({
      ...pagination,
    });
  };
  // const [list, setList] = useState([]);
  const [tabKey, setTabKey] = useState<string>('1');
  const onTabChange: (activeKey: string) => void = activeKey => {
    setPagination({
      current: 1,
      pageSize,
    });
    setTabKey(activeKey);
  };
  const [resp, setResp] = useState<StorageNodeListResponse['data']>({
    storageNodeList: [],
    dataNodeList: [],
  });

  const getList = () => {
    getStorageNodeList({})
      .then(resp => {
        if (+resp.code === 0) {
          const data = resp.data;
          setResp(data);
        }
      })
      .catch(err => {
        console.error(err);
      });
  };
  const onDelete: (name: string, type: string) => void = async (name, type) => {
    if (type === '数据') {
      var resp = await deleteDataOwnerNode({dataownerName: name});
    } else {
      var resp = await deleteStorageNode({storageName: name});
    }
    resetModalInfo();
    if (+resp.code === 0) {
      message.success('删除成功');
      getList();
    } else {
      message.error(resp.msg || '删除失败');
    }
  };

  const [modalInfo, setModalInfo] = useState({
    title: '',
    content: '',
    open: false,
    onOk: () => {},
  });
  const resetModalInfo = () =>
    setModalInfo({
      open: false,
      title: '',
      content: '',
      onOk: () => {},
    });
  const deleteNode: (name: string, type: string) => void = (
    name,
    type = '数据'
  ) => {
    setModalInfo({
      open: true,
      title: `删除${type}节点`,
      content: `${type}节点删除后不可恢复，是否确认删除?`,
      onOk: () => onDelete(name, type),
    });
  };

  const [nodeInfo, setNodeInfo] = useState({
    type: '',
    name: '',
    open: false,
    onOk: () => {},
  });
  const modifyModel: (name: string, type: string) => void = (name, type) => {
    setNodeInfo({
      type,
      name,
      open: true,
      onOk: () => {
        getList();
      },
    });
  };
  const resetModifyModel: () => void = () => {
    setNodeInfo({
      type: '',
      name: '',
      open: false,
      onOk: () => {},
    });
  };

  useEffect(() => {
    getList();
  }, []);

  const items: TabsProps['items'] = [
    {
      key: '1',
      label: '存储节点列表',
      children: (
        <>
          <StorageListHeader
            nodeId={resp.storageNodeList.length + 1}
            onSearch={getList}
          />
          <Table
            className={styles.list}
            pagination={pagination}
            dataSource={resp.storageNodeList}
            loading={loading}
            onChange={handleTableChange}
            locale={{emptyText: <Empty msg="暂无数据" />}}
            rowKey={record => `${record.name}_${Math.random() * 100}`}
          >
            <Column title="存储节点名称" dataIndex="name" key="name" />
            <Column title="存储节点地址" dataIndex="host" key="host" />
            <Column
              title="存储节点ID"
              dataIndex="nodeID"
              key="nodeID"
              render={tdRender({maxWidth: 180})}
            />
            <Column
              title="存储节点状态"
              dataIndex="status"
              key="status"
              render={(_: any, record: AllNode) => {
                switch (record.status) {
                  case 'Offline':
                    return <DotStatus type="orange">不可用</DotStatus>;
                  case 'Online':
                    return <DotStatus type="green">运行中</DotStatus>;
                }
              }}
            />
            <Column
              title="操作"
              key="operate"
              render={(_: any, record: AllNode) => {
                return (
                  <>
                    <PwD rP={PermissionValue.Write}>
                      <span
                        className={styles.operate}
                        onClick={() => modifyModel(record.name, '存储')}
                      >
                        修改
                      </span>
                      <span
                        className={styles.operate}
                        onClick={() => deleteNode(record.name, '存储')}
                      >
                        删除
                      </span>
                    </PwD>
                  </>
                );
              }}
            />
          </Table>
          <ModalBox
            open={modalInfo?.open}
            title={modalInfo?.title}
            onCancel={() => resetModalInfo()}
            onOk={modalInfo?.onOk}
          >
            {modalInfo?.content}
          </ModalBox>
          <ModifyModelBox
            key={nodeInfo.name}
            type={nodeInfo.type}
            name={nodeInfo.name}
            open={nodeInfo.open}
            resetModifyModel={resetModifyModel}
            onOk={nodeInfo?.onOk}
          />
        </>
      ),
    },
    {
      key: '2',
      label: '数据节点列表',
      children: (
        <>
          <DataListHeader
            nodeId={resp.dataNodeList.length + 1}
            onSearch={getList}
          />
          <Table
            className={styles.list}
            pagination={pagination}
            dataSource={resp.dataNodeList}
            loading={loading}
            onChange={handleTableChange}
            locale={{emptyText: <Empty msg="暂无数据" />}}
            rowKey={record => `${record.name}_${Math.random() * 100}`}
          >
            <Column title="数据节点名称" dataIndex="name" key="name" />
            <Column title="数据节点地址" dataIndex="host" key="host" />
            <Column
              title="数据节点ID"
              dataIndex="nodeID"
              key="nodeID"
              render={tdRender({maxWidth: 180})}
            />
            <Column
              title="数据节点状态"
              dataIndex="status"
              key="status"
              render={(_: any, record: AllNode) => {
                switch (record.status) {
                  case 'Offline':
                    return <DotStatus type="orange">不可用</DotStatus>;
                  case 'Online':
                    return <DotStatus type="green">运行中</DotStatus>;
                }
              }}
            />
            <Column
              title="操作"
              key="operate"
              render={(_: any, record: AllNode) => {
                return (
                  <>
                    <PwD rP={PermissionValue.Write}>
                      <span
                        className={styles.operate}
                        onClick={() => modifyModel(record.name, '数据')}
                      >
                        修改
                      </span>
                      <span
                        className={styles.operate}
                        onClick={() => deleteNode(record.name, '数据')}
                      >
                        删除
                      </span>
                    </PwD>
                  </>
                );
              }}
            />
          </Table>
          <ModalBox
            open={modalInfo?.open}
            title={modalInfo?.title}
            onCancel={() => resetModalInfo()}
            onOk={modalInfo?.onOk}
          >
            {modalInfo?.content}
          </ModalBox>
          <ModifyModelBox
            key={nodeInfo.name}
            name={nodeInfo.name}
            type={nodeInfo.type}
            open={nodeInfo.open}
            resetModifyModel={resetModifyModel}
            onOk={nodeInfo?.onOk}
          />
        </>
      ),
    },
  ];
  return <Tabs defaultActiveKey="1" items={items} onChange={onTabChange} />;
};

interface PieOptions {
  health: string;
  unHealth: string;
  tipTitle: string;
}

export default function Mine() {
  useCurrentNav(NavKeys.operationStorage);

  const [resp, setResp] = useState<StorageOverviewResponse['data']>();

  const getOption: (params: PieOptions) => any = params => {
    const {health = '', unHealth = '', tipTitle = ''} = params;
    const option = {
      title: {
        text: '健康度',
        subtext: health ? `${health}%` : '',
        left: 'center',
        top: '40%',
        textStyle: {
          fontSize: 24,
        },
        subtextStyle: {
          fontSize: 30,
        },
      },
      tooltip: {
        trigger: 'item',
        textStyle: {
          fontSize: 22,
        },
      },
      color: ['#00b936', '#eee'],
      series: [
        {
          name: `${tipTitle ? tipTitle : ''}`,
          type: 'pie',
          radius: ['40%', '70%'],
          avoidLabelOverlap: false,
          label: {
            show: false,
            position: 'center',
          },
          emphasis: {
            label: {
              show: false,
            },
          },
          labelLine: {
            show: false,
          },
          data: [
            {value: health, name: '健康度'},
            {value: unHealth, name: '不健康度'},
          ],
        },
      ],
    };
    return option;
  };
  const getInfo = () => {
    getStorageOverview({})
      .then(resp => {
        if (+resp.code === 0) {
          const data = resp.data || {};
          setResp(data);
        }
      })
      .catch(err => {
        console.error(err);
      });
  };

  useEffect(() => {
    getInfo();
    const fileChartDom = document.getElementById('circleForFile');
    const fileChart = echarts.init(fileChartDom);
    const fileHealthRate = resp?.filesHealthRate
      ? (resp?.filesHealthRate * 100)?.toFixed(2)
      : '';
    const fileUnHealthRate = Math.abs(
      100 - resp?.filesHealthRate * 100
    )?.toFixed(2);
    const fileOpt = getOption({
      health: fileHealthRate,
      unHealth: fileUnHealthRate,
      tipTitle: '文件',
    });
    fileOpt && fileChart.setOption(fileOpt);

    const nodeChartDom = document.getElementById('circleForNode');
    const nodeChart = echarts.init(nodeChartDom);
    const nodeHealthRate = resp?.nodeHealthRate
      ? (resp?.nodeHealthRate * 100)?.toFixed(2)
      : '';
    const nodeUnHealthRate = Math.abs(
      100 - resp?.nodeHealthRate * 100
    )?.toFixed(2);
    const nodeOpt = getOption({
      health: nodeHealthRate,
      unHealth: nodeUnHealthRate,
      tipTitle: '节点',
    });
    nodeOpt && nodeChart.setOption(nodeOpt);
  }, [JSON.stringify(resp)]);

  return (
    <Content>
      <div className={styles.storageTitle}>存储网络健康度</div>
      <div className={styles.storageHeathyBox}>
        <div className={styles.gridBox}>
          <div className={styles.grid}>
            <Row>
              <Col span={8} className={styles.title}>
                文件健康度
              </Col>
              <Col offset={4} span={6} className={styles.desc}>
                命名空间数量: {resp?.nsNum}
              </Col>
              {/* <Col span={6} className={styles.desc}>文件健康指数: {resp?.filesHealthRate}</Col> */}
            </Row>
            <Row className={styles.graphBox}>
              <Col span={12}>
                <div className={styles.circleBox}>
                  <div className={styles.circle} id="circleForFile"></div>
                </div>
              </Col>
              <Col span={12}>
                <Row className={styles.infoRow}>
                  <Col span={12}>
                    <span className={cx(styles.point, styles.heathy)}></span>
                    健康文件数量
                  </Col>
                  <Col>{resp?.greenFileNum}</Col>
                </Row>
                <Row className={styles.infoRow}>
                  <Col span={12}>
                    <span className={cx(styles.point, styles.expired)}></span>
                    过期文件数量
                  </Col>
                  <Col>{resp?.fileExpiredNum}</Col>
                </Row>
                <Row className={styles.infoRow}>
                  <Col span={12}>
                    <span className={cx(styles.point, styles.warning)}></span>
                    报警文件数量
                  </Col>
                  <Col>{resp?.yellowFileNum}</Col>
                </Row>
                <Row className={styles.infoRow}>
                  <Col span={12}>
                    <span className={cx(styles.point, styles.error)}></span>
                    错误文件数量
                  </Col>
                  <Col>{resp?.redFileNum}</Col>
                </Row>
              </Col>
            </Row>
          </div>
          <div className={styles.grid}>
            <Row>
              <Col span={8} className={styles.title}>
                节点健康度
              </Col>
              <Col offset={4} span={6} className={styles.desc}>
                存储节点数量: {resp?.nodeNum}
              </Col>
              {/* <Col span={6} className={styles.desc}>节点健康指数: {resp?.nodeHealthRate}</Col> */}
            </Row>
            <Row className={styles.graphBox}>
              <Col span={12}>
                <div className={styles.circleBox}>
                  <div className={styles.circle} id="circleForNode"></div>
                </div>
              </Col>
              <Col span={12}>
                <Row className={styles.infoRow}>
                  <Col span={12}>
                    <span className={cx(styles.point, styles.heathy)}></span>
                    健康节点数量
                  </Col>
                  <Col>{resp?.greenNodeNum}</Col>
                </Row>
                <Row className={styles.infoRow}>
                  <Col span={12}>
                    <span className={cx(styles.point, styles.warning)}></span>
                    报警节点数量
                  </Col>
                  <Col>{resp?.yellowNodeNum}</Col>
                </Row>
                <Row className={styles.infoRow}>
                  <Col span={12}>
                    <span className={cx(styles.point, styles.error)}></span>
                    错误节点数量
                  </Col>
                  <Col>{resp?.redNodeNum}</Col>
                </Row>
              </Col>
            </Row>
          </div>
        </div>
      </div>
      <StorageTabs />
    </Content>
  );
}
