import React, {
  PropsWithChildren,
  useCallback,
  useEffect,
  useState,
} from 'react';
import {App, Row, Col, Table, Form, Input, InputNumber} from 'antd';
import {PlusOutlined} from '@ant-design/icons';
import {useNavigate} from 'react-router-dom';
import {useForm} from 'antd/es/form/Form';
import type {TablePaginationConfig} from 'antd/es/table';
import dayjs, {Dayjs} from 'dayjs';
import {tdRender} from '@/components/Table/ToolTip';
import Empty from '@components/Empty';
import Button from '@/components/Button';
import DotStatus, {DotStatusProps} from '@/components/DotStatus';
import styles from './index.less';
import Content from '@/components/Content';
import {NavKeys, useCurrentNav} from '@/slice/sider';
import ModalBox from '@/components/Modal';

import {
  createExecutorNode,
  deleteExecutorNode,
  createDataOwnerNode,
  createStorageNode,
  ComputingOverview,
  ComputingOverviewResponse,
  getComputingOverview,
  ComputingNode,
  ComputingNodeListResponse,
  getComputingNodeList,
} from '@/libs/api';
import {PwD} from '../PermissonWrap';
import {PermissionValue} from '@/pages/Account/PermissionCreator';

const StorageListHeader: React.FC<{
  onSearch: (keyword: string) => void;
  nodeId: number;
}> = ({onSearch, nodeId}) => {
  const [form] = useForm();
  const navigate = useNavigate();
  const {message} = App.useApp();
  const [createTaskModalOpen, setCreateTaskModalOpen] = useState(false);

  const onSubmit = useCallback(() => {
    console.log('新增存储节点');
    form.validateFields().then(values => {
      createStorageNode({
        ...values,
        // canvasInfo: '{}',
      }).then(resp => {
        if (resp.code === '0') {
          onSearch('');
          setCreateTaskModalOpen(false);
        }
        // message.error(ErrorCode[resp.code]);
      }, console.error);
    }, console.error);
  }, [form]);

  return (
    <div className={styles.header}>
      <ModalBox
        title="新增存储节点"
        open={createTaskModalOpen}
        onOk={onSubmit}
        onCancel={() => setCreateTaskModalOpen(false)}
      >
        <Form
          form={form}
          labelCol={{flex: '100px'}}
          initialValues={{storageID: nodeId}}
        >
          <Form.Item
            name="storageID"
            label="节点序号"
            rules={[
              {
                type: 'number',
                min: 0,
                max: 100000,
                required: true,
                message: '请输入节点序号，4到20个字符',
              },
            ]}
          >
            <Input placeholder="请输入节点序号" disabled />
          </Form.Item>
          <Form.Item
            name="storageName"
            label="节点名称"
            rules={[
              {
                required: true,
                min: 4,
                max: 20,
                message: '请输入节点名称，4到20个字符',
              },
            ]}
          >
            <Input placeholder="请输入节点名称" />
          </Form.Item>

          <Form.Item
            name="replicas"
            label="服务副本数量"
            rules={[
              {
                type: 'number',
                required: true,
                message: '请输入服务副本数量，4到20个字符',
              },
            ]}
          >
            <InputNumber
              placeholder="请输入服务副本数量"
              controls={false}
              style={{width: '100%'}}
            />
          </Form.Item>
        </Form>
      </ModalBox>
      <div className={styles.search_container}>
        <Input
          placeholder="请输入节点名称"
          className={styles.task_search_input}
          onChange={e => {
            const v = e.target.value;
            onSearch(v);
          }}
        />
      </div>
      <div className={styles.button_container}>
        <PwD rP={PermissionValue.Write}>
          <Button
            type="primary"
            icon={<PlusOutlined />}
            // onClick={() => navigate('/task/create')}
            onClick={() => setCreateTaskModalOpen(true)}
            className={styles.task_create_btn}
          >
            新增存储节点
          </Button>
        </PwD>
      </div>
    </div>
  );
};

const DataListHeader: React.FC<{
  onSearch: (keyword: string) => void;
  nodeId: number;
}> = ({onSearch, nodeId}) => {
  const [form] = useForm();
  const navigate = useNavigate();
  const {message} = App.useApp();
  const [createTaskModalOpen, setCreateTaskModalOpen] = useState(false);

  const onSubmit = useCallback(() => {
    console.log('新增数据节点');
    form.validateFields().then(values => {
      createDataOwnerNode({
        ...values,
        // canvasInfo: '{}',
      }).then(resp => {
        if (resp.code === '0') {
          onSearch('');
          // return navigate(`/task/create?id=${resp.data.id}`);
          setCreateTaskModalOpen(false);
        }
        // message.error(ErrorCode[resp.code]);
      }, console.error);
    }, console.error);
  }, [form]);

  return (
    <div className={styles.header}>
      <ModalBox
        title="新增数据节点"
        open={createTaskModalOpen}
        onOk={onSubmit}
        onCancel={() => setCreateTaskModalOpen(false)}
      >
        <Form
          form={form}
          labelCol={{flex: '100px'}}
          initialValues={{dataownerID: nodeId}}
        >
          <Form.Item
            name="dataownerID"
            label="节点序号"
            rules={[
              {
                type: 'number',
                min: 0,
                max: 100000,
                required: true,
                message: '请输入节点序号，4到20个字符',
              },
            ]}
          >
            <Input placeholder="请输入节点序号" disabled />
          </Form.Item>
          <Form.Item
            name="dataownerName"
            label="节点名称"
            rules={[
              {
                required: true,
                min: 4,
                max: 20,
                message: '请输入节点名称，4到20个字符',
              },
            ]}
          >
            <Input placeholder="请输入节点名称" />
          </Form.Item>
          <Form.Item
            name="replicas"
            label="服务副本数量"
            rules={[
              {
                type: 'number',
                required: true,
                message: '请输入服务副本数量，4到20个字符',
              },
            ]}
          >
            <InputNumber
              placeholder="请输入服务副本数量"
              controls={false}
              style={{width: '100%'}}
            />
          </Form.Item>
        </Form>
      </ModalBox>
      <div className={styles.search_container}>
        <Input
          placeholder="请输入节点名称"
          className={styles.task_search_input}
          onChange={e => {
            const v = e.target.value;
            onSearch(v);
          }}
        />
      </div>
      <div className={styles.button_container}>
        <PwD rP={PermissionValue.Write}>
          <Button
            type="primary"
            icon={<PlusOutlined />}
            // onClick={() => navigate('/task/create')}
            onClick={() => setCreateTaskModalOpen(true)}
            className={styles.task_create_btn}
          >
            新增数据节点
          </Button>
        </PwD>
      </div>
    </div>
  );
};

const ComputingListHeader: React.FC<{
  onSearch: (keyword: string) => void;
  executorID: number;
}> = ({onSearch, executorID}) => {
  const [form] = useForm();
  const navigate = useNavigate();
  const {message} = App.useApp();
  const [createTaskModalOpen, setCreateTaskModalOpen] = useState(false);

  const onSubmit = useCallback(() => {
    console.log('新增计算节点');
    form.validateFields().then(values => {
      createExecutorNode({
        ...values,
        // canvasInfo: '{}',
      }).then(resp => {
        if (+resp.code === 0) {
          onSearch('');
          setCreateTaskModalOpen(false);
        }
        // message.error(ErrorCode[resp.code]);
      }, console.error);
    }, console.error);
  }, [form]);
  return (
    <div className={styles.header}>
      <ModalBox
        title="新增计算节点"
        open={createTaskModalOpen}
        onOk={onSubmit}
        onCancel={() => setCreateTaskModalOpen(false)}
      >
        <Form
          form={form}
          labelCol={{flex: '100px'}}
          initialValues={{executorID: executorID, managerID: 1}}
        >
          <Form.Item
            name="executorID"
            label="节点序号"
            rules={[
              {
                type: 'number',
                min: 0,
                max: 100000,
                required: true,
                message: '请输入节点序号，4到20个字符',
              },
            ]}
          >
            <Input placeholder="请输入节点序号" disabled />
          </Form.Item>
          <Form.Item
            name="executorName"
            label="节点名称"
            rules={[
              {
                required: true,
                min: 4,
                max: 20,
                message: '请输入节点名称，4到20个字符',
              },
            ]}
          >
            <Input placeholder="请输入节点名称" />
          </Form.Item>
          <Form.Item
            name="managerID"
            label="绑定执行器"
            rules={[
              {
                required: true,
                message: '请输入绑定执行器，4到20个字符',
              },
            ]}
          >
            <InputNumber
              placeholder="请输入绑定的执行器"
              controls={false}
              style={{width: '100%'}}
            />
          </Form.Item>
          <Form.Item
            name="orgID"
            label="机构序号"
            rules={[
              {
                type: 'number',
                required: true,
                message: '请输入机构序号，4到20个字符',
              },
            ]}
          >
            <InputNumber
              placeholder="请输入机构序号"
              controls={false}
              style={{width: '100%'}}
            />
          </Form.Item>
          <Form.Item
            name="replicas"
            label="服务副本数量"
            rules={[
              {
                type: 'number',
                required: true,
                message: '请输入服务副本数量，4到20个字符',
              },
            ]}
          >
            <InputNumber
              placeholder="请输入服务副本数量"
              controls={false}
              style={{width: '100%'}}
            />
          </Form.Item>
          <Form.Item
            name="containerPort"
            label="容器端口"
            rules={[
              {
                required: true,
                message: '请输入容器端口，4到20个字符',
              },
            ]}
          >
            <InputNumber
              placeholder="请输入容器端口"
              controls={false}
              style={{width: '100%'}}
            />
          </Form.Item>
          <Form.Item
            name="paddleFLAddress"
            label="查询结果状态"
            rules={[
              {
                required: true,
                message: '请输入查询结果状态，4到20个字符',
              },
            ]}
          >
            <InputNumber
              placeholder="请输入查询结果状态"
              controls={false}
              style={{width: '100%'}}
            />
          </Form.Item>
          <Form.Item
            name="httpPort"
            label="查询结果"
            rules={[
              {
                required: true,
                message: '请输入查询结果，4到20个字符',
              },
            ]}
          >
            <InputNumber
              placeholder="请输入查询结果"
              controls={false}
              style={{width: '100%'}}
            />
          </Form.Item>
        </Form>
      </ModalBox>
      <div className={styles.search_container}>
        <Input
          placeholder="请输入计算节点名称"
          className={styles.task_search_input}
          onChange={e => {
            const v = e.target.value;
            onSearch(v);
          }}
        />
      </div>
      <div className={styles.button_container}>
        <PwD rP={PermissionValue.Write}>
          <Button
            type="primary"
            icon={<PlusOutlined />}
            onClick={() => setCreateTaskModalOpen(true)}
            className={styles.task_create_btn}
          >
            新增计算节点
          </Button>
        </PwD>
      </div>
    </div>
  );
};

export {StorageListHeader, DataListHeader, ComputingListHeader};
