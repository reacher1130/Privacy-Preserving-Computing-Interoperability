import React, {
  PropsWithChildren,
  useCallback,
  useEffect,
  useState,
} from 'react';
import {App, Row, Col, Table, Form, Input, InputNumber, message} from 'antd';
import {PlusOutlined} from '@ant-design/icons';
import {useNavigate} from 'react-router-dom';
import {useForm} from 'antd/es/form/Form';
import type {TablePaginationConfig} from 'antd/es/table';
import dayjs, {Dayjs} from 'dayjs';
import {tdRender} from '@/components/Table/ToolTip';
import Empty from '@components/Empty';
import Button from '@/components/Button';
import DotStatus, {DotStatusProps} from '@/components/DotStatus';

import * as echarts from 'echarts/core';
// import * as echartall from 'echarts';
import {PieChart} from 'echarts/charts';
import {
  ToolboxComponent,
  TitleComponent,
  TooltipComponent,
  GridComponent,
  MarkPointComponent,
  MarkLineComponent,
  LegendComponent,
  DatasetComponent,
  TransformComponent,
} from 'echarts/components';
import {CanvasRenderer} from 'echarts/renderers';
import type {
  // 组件类型的定义后缀都为 ComponentOption
  TitleComponentOption,
  TooltipComponentOption,
  GridComponentOption,
  DatasetComponentOption,
} from 'echarts/components';
import type {ComposeOption} from 'echarts/core';
import styles from './index.less';
import Content from '@/components/Content';
import {NavKeys, useCurrentNav} from '@/slice/sider';
import ModalBox from '@/components/Modal';
import {ComputingListHeader} from '@/views/Operation/AddNode';

import {
  createExecutorNode,
  deleteExecutorNode,
  ModifyExecutorNode,
  ComputingOverview,
  ComputingOverviewResponse,
  getComputingOverview,
  ComputingNode,
  ComputingNodeListResponse,
  getComputingNodeList,
} from '@/libs/api';
import {PwD} from '../PermissonWrap';
import {PermissionValue} from '@/pages/Account/PermissionCreator';
import {number} from 'echarts';
// 通过 ComposeOption 来组合出一个只有必须组件和图表的 Option 类型
type ECOption = ComposeOption<
  | TitleComponentOption
  | TooltipComponentOption
  | GridComponentOption
  | DatasetComponentOption
>;
echarts.use([
  ToolboxComponent,
  TitleComponent,
  TooltipComponent,
  GridComponent,
  MarkPointComponent,
  MarkLineComponent,
  LegendComponent,
  DatasetComponent,
  TransformComponent,
  PieChart,
  CanvasRenderer,
]);
// type EChartsOption = echartall.EChartsOption;

const {Column} = Table;

const HEATH_STATUS = {
  Green: '健康',
  Red: '错误',
  Yellow: '报警',
};

type HeathType = typeof HEATH_STATUS | {[key: string]: string};

const HEATH_COLOR = {
  Green: 'green',
  Red: 'orange',
  Yellow: 'orange',
};
type ColorType = typeof HEATH_COLOR | {[key: string]: string};

interface ComputingTableProps extends PropsWithChildren {
  doSetNodeRate: (nodeRate: number) => void;
  setExecutorID: (executorID: number) => void;
}

const ComputingTable: React.FC<ComputingTableProps> = (
  props: ComputingTableProps
) => {
  const pageSize = 10;
  const [loading, setLoading] = useState(false);
  const [pagination, setPagination] = useState<TablePaginationConfig>({
    current: 1,
    pageSize,
  });
  const handleTableChange = (pagination: TablePaginationConfig) => {
    setPagination({
      ...pagination,
    });
  };
  const [resp, setResp] = useState<ComputingNodeListResponse['data']>();
  const {doSetNodeRate, setExecutorID} = props;
  const [messageApi, contextHolder] = message.useMessage();
  const [createTaskModalOpen, setCreateTaskModalOpen] = useState(false);

  const getList = () => {
    getComputingNodeList({})
      .then(resp => {
        if (+resp.code === 0) {
          const data = resp.data;
          setResp(data);
          doSetNodeRate && doSetNodeRate(data?.health);
          // setExecutorID && setExecutorID(data.nodes.length + 1);
          setExecutorID && setExecutorID(5);
        }
      })
      .catch(err => {
        console.error(err);
      });
  };
  // 节点操作
  // const [nodeID, setNodeID] = useState('');
  const onDelete: (name: string) => void = name => {
    deleteExecutorNode({executorName: name})
      .then(resp => {
        resetModalInfo();
        if (+resp.code === 0) {
          messageApi.success('删除成功');
          // 更新列表
          getList();
        } else {
          messageApi.error(resp.msg || '删除失败');
        }
      })
      .catch(err => {
        messageApi.error('网络异常，请稍后再试');
        console.error(err);
      });
  };

  const [modalInfo, setModalInfo] = useState({
    title: '',
    content: '',
    open: false,
    onOk: () => {},
  });
  const resetModalInfo = () =>
    setModalInfo({
      open: false,
      title: '',
      content: '',
      onOk: () => {},
    });

  const deleteModel: (name: string) => void = name => {
    setModalInfo({
      open: true,
      title: '删除计算节点',
      content: '计算节点删除后不可恢复，是否确认删除?',
      onOk: () => onDelete(name),
    });
  };

  const [nodeInfo, setNodeInfo] = useState({
    name: '',
    open: false,
    onOk: () => {},
  });
  const modifyModel: (name: string) => void = name => {
    setNodeInfo({
      name,
      open: true,
      onOk: () => {
        getList();
      },
    });
  };
  const resetModifyModel: () => void = () => {
    setNodeInfo({
      name: '',
      open: false,
      onOk: () => {},
    });
  };

  useEffect(() => {
    getList();
  }, []);
  return (
    <>
      {contextHolder}
      <Table
        className={styles.list}
        pagination={pagination}
        dataSource={resp?.nodes}
        loading={loading}
        locale={{emptyText: <Empty msg="暂无数据" />}}
        onChange={handleTableChange}
        rowKey={record => `${record.name}_${Math.random() * 100}`}
      >
        <Column title="计算节点名称" dataIndex="name" key="name" />
        <Column title="grpc地址" dataIndex="grpcHost" key="grpcHost" />
        <Column
          title="健康度"
          dataIndex="health"
          key="health"
          render={health => {
            const type = HEATH_COLOR[health as keyof ColorType];
            return (
              <DotStatus type={type as DotStatusProps['type']}>
                {HEATH_STATUS[health as keyof HeathType]}
              </DotStatus>
            );
          }}
        />
        <Column
          title="注册时间"
          dataIndex="registerTime"
          key="registerTime"
          render={registerTime => {
            const time = registerTime
              ? dayjs.unix(registerTime).format('YYYY-MM-DD HH:mm:ss')
              : '--';
            return <span>{time}</span>;
          }}
        />
        <Column
          title="计算节点ID"
          dataIndex="nodeID"
          key="nodeID"
          render={tdRender({maxWidth: 180})}
        />
        <Column
          title="计算节点状态"
          key="status"
          render={(_: any, record: ComputingNode) => {
            switch (record.status) {
              case 'Offline':
                return <DotStatus type="orange">已下线</DotStatus>;
              case 'Online':
                return <DotStatus type="green">已上线</DotStatus>;
            }
          }}
        />
        <Column
          title="操作"
          key="operate"
          render={(_: any, record: ComputingNode) => {
            return (
              <>
                <PwD rP={PermissionValue.Write}>
                  <span
                    className={styles.operate}
                    onClick={() => modifyModel(record.name)}
                  >
                    修改
                  </span>
                  <span
                    className={styles.operate}
                    onClick={() => deleteModel(record.name)}
                  >
                    删除
                  </span>
                </PwD>
              </>
            );
          }}
        />
      </Table>
      <ModalBox
        open={modalInfo?.open}
        title={modalInfo?.title}
        onCancel={() => resetModalInfo()}
        onOk={modalInfo?.onOk}
      >
        {modalInfo?.content}
      </ModalBox>
      <ModifyModelBox
        key={nodeInfo.name}
        name={nodeInfo.name}
        open={nodeInfo.open}
        resetModifyModel={resetModifyModel}
        onOk={nodeInfo?.onOk}
      />
    </>
  );
};
const ModifyModelBox: React.FC<{
  name: string;
  open: boolean;
  resetModifyModel: () => void;
  onOk: () => void;
}> = ({name, open = false, resetModifyModel, onOk}) => {
  const [form] = useForm();

  const onSubmit = useCallback(() => {
    form.validateFields().then(values => {
      ModifyExecutorNode({
        ...values,
      }).then(resp => {
        if (+resp.code === 0) {
          onOk();
          resetModifyModel();
        } else {
          message.error(resp.msg);
        }
      }, console.error);
    }, console.error);
  }, [form]);
  return (
    <div className={styles.header}>
      <ModalBox
        title="修改计算节点"
        open={open}
        onOk={onSubmit}
        onCancel={() => resetModifyModel()}
      >
        <Form
          form={form}
          labelCol={{flex: '100px'}}
          initialValues={{executorName: name}}
        >
          <Form.Item
            name="executorName"
            label="节点名称"
            rules={[
              {
                min: 4,
                max: 20,
                required: true,
                message: '请输入节点序号，4到20个字符',
              },
            ]}
          >
            <Input placeholder="请输入节点序号" disabled />
          </Form.Item>
          <Form.Item
            name="replicas"
            label="服务副本数量"
            rules={[
              {
                type: 'number',
                required: true,
                message: '请输入服务副本数量，4到20个字符',
              },
            ]}
          >
            <InputNumber
              placeholder="请输入服务副本数量"
              controls={false}
              style={{width: '100%'}}
            />
          </Form.Item>
        </Form>
      </ModalBox>
    </div>
  );
};

interface PieOptions {
  title: string;
  health: string;
  unHealth: string;
  name: string;
  opname: string;
}
export default function Computing() {
  useCurrentNav(NavKeys.operationComputing);
  const [resp, setResp] = useState<ComputingOverviewResponse['data']>();
  const [nodeRate, setNodeRate] = useState(0);
  const [executorID, setExecutorID] = useState(0);
  const [payload, setPayload] = useState<{
    pageNo?: number;
    name?: string;
  }>({
    pageNo: 1,
    name: '',
  });

  const getOption: (params: PieOptions) => any = params => {
    const option = {
      title: {
        text: `${params?.title}${params?.name}`,
        subtext: `${params?.health ? params?.health : ''}%`,
        left: 'center',
        top: '40%',
        textStyle: {
          fontSize: 24,
        },
        subtextStyle: {
          fontSize: 30,
        },
      },
      tooltip: {
        trigger: 'item',
        textStyle: {
          fontSize: 22,
        },
      },
      color: ['#00b936', '#eee'],
      series: [
        {
          name: `${params?.title}`,
          type: 'pie',
          radius: ['40%', '70%'],
          avoidLabelOverlap: false,
          label: {
            show: false,
            position: 'center',
          },
          emphasis: {
            label: {
              show: false,
            },
          },
          labelLine: {
            show: false,
          },
          data: [
            {value: params?.health, name: `${params?.name}`},
            {value: params?.unHealth, name: `${params?.opname}`},
          ],
        },
      ],
    };
    return option;
  };
  const getInfo = () => {
    getComputingOverview({})
      .then(resp => {
        if (+resp.code === 0) {
          const data = resp.data;
          setResp(data);
        }
      })
      .catch(err => {
        console.error(err);
      });
  };
  useEffect(() => {
    getInfo();
    const fileChartDom = document.getElementById('circleForTask');
    const fileChart = echarts.init(fileChartDom);
    const taskHealth = (resp?.health * 100)?.toFixed(2);
    const taskUnHealth = Math.abs(100 - resp?.health * 100)?.toFixed(2);
    const fileOpt = getOption({
      title: '任务',
      health: taskHealth,
      unHealth: taskUnHealth,
      name: '成功率',
      opname: '失败率',
    });
    fileOpt && fileChart.setOption(fileOpt);

    const nodeChartDom = document.getElementById('circleForNode');
    const nodeChart = echarts.init(nodeChartDom);
    const nodeHealth = (nodeRate * 100)?.toFixed(2);
    const nodeUnHealth = Math.abs(100 - nodeRate * 100)?.toFixed(2);
    const nodeOpt = getOption({
      title: '节点',
      health: nodeHealth,
      unHealth: nodeUnHealth,
      name: '健康率',
      opname: '不健康率',
    });
    nodeOpt && nodeChart.setOption(nodeOpt);
  }, [JSON.stringify(resp), nodeRate]);

  const doSetNodeRate = (nodeRate: number) => {
    setNodeRate(nodeRate);
  };
  const setTaskKeyword = useCallback(
    (keyword: string) => {
      setPayload({
        pageNo: 1,
        name: keyword,
      });
    },
    [payload.pageNo]
  );

  return (
    <Content>
      <div className={styles.computingTitle}>计算网络概览</div>
      <Row className={styles.computingOverview} gutter={[48, 32]}>
        <Col className={styles.col} span={8}>
          <div className={styles.name}>已处理计算任务总数</div>
          <div className={styles.num}>{resp?.totalTasks}个</div>
        </Col>
        <Col className={styles.col} span={8}>
          <div className={styles.name}>进行中计算任务数</div>
          <div className={styles.num}>{resp?.runningTasks}个</div>
        </Col>
        <Col className={styles.col} span={8}>
          <div className={styles.name}>已成功计算任务数</div>
          <div className={styles.num}>{resp?.successTasks}个</div>
        </Col>
      </Row>
      <div className={styles.computingTitle}>计算节点管理</div>
      <Row className={styles.computingGraph}>
        <Col span={8} className={styles.col}>
          <div className={styles.circleBox}>
            <div className={styles.circle} id="circleForTask"></div>
          </div>
        </Col>
        <Col span={8} className={styles.col}>
          <div className={styles.circleBox}>
            <div className={styles.circle} id="circleForNode"></div>
          </div>
        </Col>
      </Row>
      <div className={styles.computingTitle}>计算节点列表</div>
      <ComputingListHeader onSearch={setTaskKeyword} executorID={executorID} />
      <ComputingTable
        doSetNodeRate={doSetNodeRate}
        setExecutorID={setExecutorID}
      />
    </Content>
  );
}
