import React, {
  MouseEventHandler,
  useCallback,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from 'react';

import {Graph, Node} from '@antv/x6';
import {Stencil} from '@antv/x6-plugin-stencil';
import {Snapline} from '@antv/x6-plugin-snapline';
import {Keyboard} from '@antv/x6-plugin-keyboard';
import {Selection} from '@antv/x6-plugin-selection';

import {register} from '@antv/x6-react-shape';

import {App as AntdApp} from 'antd';
import {useNavigate} from 'react-router-dom';
import {TaskCreateRequest, createTask} from '@/libs/api';
import ErrorCode from '@/libs/errorCode';
import * as compnentList from './Component';
import ports from './config/ports';
import graphConfig from './config/graphConfig';
import stencilConfig from './config/stencilConfig';
import styles from './componentCreator.less';
import nodesConfig, {GraphNodeChildren, NodeType} from './config/nodesConfig';
import graphNodesRules from './config/graphNodesRules';
import formatTaskParams from './formatTaskParams';
import Task from './Component/Task';

export type NodeRefCurrentType = Record<
  string,
  GraphNodeChildren & {nextNodes: string[]}
>;

const onMouseDown: MouseEventHandler<HTMLDivElement> = e => {
  e.stopPropagation();
};

function getDatasetFromFeatureNode(
  graph: Graph,
  currentId: string
): string | null {
  const currentNode = graph.getCellById(currentId);
  const imcomingEdges = graph.getIncomingEdges(currentNode);
  if (imcomingEdges) {
    const edge = imcomingEdges[0];
    const source: any = edge.getSource();
    const cell = graph.getCellById(source.cell);
    if (cell.getData().type.startsWith(NodeType.Datasets)) {
      return cell.id;
    }
    return getDatasetFromFeatureNode(graph, cell.id);
  }
  return null;
}

function getDatasetsForAlgorithm(graph: Graph): string[] {
  const cells = graph
    .getCells()
    .filter(c => c.data?.type === NodeType.DatasetsCompnent)
    .map(c => c.id);
  return cells;
}

function componentCreator(
  label: string,
  Icon: React.ComponentType,
  {
    disabled = false,
    disabledText,
  }: {
    disabled?: boolean;
    disabledText?: string;
  }
): React.ComponentType<{
  node: Node;
  graph: Graph;
}> {
  return function () {
    return disabled ? (
      <div
        className={styles.component_layout}
        onMouseDown={onMouseDown}
        style={{color: '#999', width: '160px', cursor: 'not-allowed'}}
      >
        <Icon /> {label}
        <span style={{fontSize: '10px', color: '#ccc', zoom: '0.8'}}>
          {disabledText}{' '}
        </span>
      </div>
    ) : (
      <div className={styles.component_layout}>
        <Icon /> {label}
      </div>
    );
  };
}

export const initGrahp = (
  canvasContainer: HTMLElement,
  toolsbarContainer: HTMLElement
  // isEdit: boolean
  // type: number,
) => {
  const graph = new Graph({
    ...graphConfig,
    container: canvasContainer,
    interacting: {
      arrowheadMovable: true,
    },
  });
  graph.options.connecting.validateEdge = ({edge}) => {
    const link = edge.getTarget() as any;
    const incoming = graph.getIncomingEdges(link.cell);
    const targetType = graph.getCellById(link.cell).data.type as string;
    if (targetType.includes(NodeType.Algorithm)) {
      return true;
    }
    if (incoming.length === 1) {
      return true;
    }
    return false;
  };
  graph.centerContent();
  graph.use(
    new Snapline({
      enabled: true,
      sharp: true,
    })
  );
  graph.use(
    new Keyboard({
      enabled: true,
    })
  );
  graph.use(
    new Selection({
      showNodeSelectionBox: true,
      rubberband: true,
    })
  );

  const stencil = new Stencil({
    ...stencilConfig,
    target: graph,
  });

  (window as any).stencil = stencil;

  nodesConfig.forEach(n => {
    const childrenNodes = n.children.reduce((all, current) => {
      // if (current.type === NodeType.EvaluateStatic) {
      //     current.disabled = true;
      //     current.disabledText = '';
      // }
      register({
        shape: current.type,
        width: 140,
        height: 40,
        ports,
        component: componentCreator(current.title, n.childrenIcon, {
          disabled: current.disabled,
          disabledText: current.disabledText ?? '(暂未开放)',
        }),
        data: {
          type: current.type,
        },
      });
      all.push(graph.createNode({shape: current.type}));
      return all;
    }, []);
    stencil.load(childrenNodes, n.type);
  });

  toolsbarContainer.append(stencil.container);

  const showPorts = (ports: NodeListOf<Element>, show: boolean) => {
    for (let i = 0, len = ports.length; i < len; i += 1) {
      const p = ports[i] as HTMLElement;
      p.style.visibility = show ? 'visible' : 'hidden';
    }
  };
  graph.on('node:mouseenter', () => {
    const container = canvasContainer;
    const ports = container.querySelectorAll('.x6-port-body');
    showPorts(ports, true);
  });
  graph.on('edge:mouseenter', ({cell}) => {
    cell.addTools([
      {
        name: 'target-arrowhead',
        args: {
          attrs: {
            // d: 'M -10 -8 10 0 -10 8 Z',
            d: 'M -12 -4 0 0 -12 4 Z',
            // d: 'M 0 0 L 12 -4 L 12 4 Z',
            fill: '#F27C49',
            stroke: '#F27C49',
            'stroke-width': 1.5,
            cursor: 'move',
          },
        },
      },
    ]);
  });
  graph.on('edge:mouseleave', ({cell}) => {
    cell.removeTool('target-arrowhead');
  });

  graph.on('node:mouseleave', () => {
    const container = canvasContainer;
    const ports = container.querySelectorAll('.x6-port-body');
    showPorts(ports, false);
  });

  graph.bindKey(['delete', 'backspace'], () => {
    const cells = graph.getSelectedCells();
    if (cells.length) {
      cells.forEach(c => {
        // if (isEdit && c.data?.type.startsWith(NodeType.Task)) {
        //     return;
        // }
        graph.removeCell(c);
      });
    }
  });

  return {
    stencil,
    graph,
  };
};

interface CanvasLayoutProps {
  taskId: number;
}
export const CanvasLayout = React.forwardRef(
  (props: CanvasLayoutProps, ref) => {
    const canvasRef = useRef();
    const toolsbarRef = useRef();
    const graphRef = useRef<Graph>();
    const stencilRef = useRef<Stencil>();
    const dataRef = useRef<any>({
      Task: {
        ...props,
      },
    });
    const [currentNode, setCurrentNode] = useState(null);
    const nodesRef = useRef<NodeRefCurrentType>({});
    const {message} = AntdApp.useApp();
    const navigate = useNavigate();
    const onChange = useCallback(
      (data: any) => {
        dataRef.current[currentNode] = data;
      },
      [currentNode]
    );
    useEffect(() => {
      const {graph, stencil} = initGrahp(
        canvasRef.current,
        toolsbarRef.current /* , !!props.taskId */
      );
      graphRef.current = graph;
      stencilRef.current = stencil;
      graph.on('node:click', ({e, cell}) => {
        e.stopPropagation();
        const id = cell.id;
        setCurrentNode(id);
      });
      graph.on('blank:click', () => {
        setCurrentNode('Task');
      });
      graph.on('view:mounted', ({view}) => {
        if (!view.isNodeView()) {
          return;
        }
        const nodes = nodesRef.current;
        const id = view.cell.id;
        const type = view.cell.getData().type;
        const newNodes = {
          ...nodes,
          [id]: {
            ...nodes[id],
            type,
          },
        };
        nodesRef.current = newNodes;
      });
      graph.on('view:unmounted', ({view}) => {
        const id = view.cell.id;
        const nodes = nodesRef.current;
        const newNodes = {...nodes};
        delete newNodes[id];
        nodesRef.current = newNodes;
        setCurrentNode(null);
      });

      graph.on('edge:connected', ({isNew, edge, previousCell}) => {
        const start = edge.getSourceNode();
        const end = edge.getTargetNode();
        const startId = start.id;
        const endId = end.id;
        if (isNew) {
          nodesRef.current[startId] = {
            ...nodesRef.current[startId],
            nextNodes: [...(nodesRef.current[startId].nextNodes ?? []), endId],
          };
        } else {
          const previousTargetId = previousCell.id;
          nodesRef.current[startId] = {
            ...nodesRef.current[startId],
            nextNodes: [
              ...(nodesRef.current[startId].nextNodes ?? []).filter(
                (id: string) => id !== previousTargetId
              ),
              endId,
            ],
          };
        }
      });
      graph.on('edge:removed', ({edge}) => {
        const start = edge.source as any;
        const end = edge.target as any;
        let nextNodes = nodesRef.current[start.cell].nextNodes;
        if (!nextNodes) {
          return;
        }
        nextNodes = nextNodes.filter((n: any) => n !== end.cell);
        nodesRef.current[start.cell] = {
          ...nodesRef.current[start.cell],
          nextNodes,
        };
      });

      (window as any).graph = graph;
      return () => {
        graph.off('node:click');
        graph.off('blank:click');
        graph.off('view:mounted');
        graph.off('view:unmounted');
        graph.off('node:mouseenter');
        graph.off('node:mouseleave');
        graph.off('edge:connected');
        graph.off('edge:removed');
        graph.unbindKey('delete');
      };
    }, []);
    useImperativeHandle(ref, () => {
      return {
        submit: () => {
          let result = graphNodesRules.global(
            nodesRef.current,
            dataRef.current
          );
          if (!result.status) {
            return message.error({
              content: result.msg,
            });
          }
          Object.values(nodesRef.current).every(n => {
            const {type, nextNodes} = n;
            if (graphNodesRules[type]) {
              result = graphNodesRules[type](
                nodesRef.current,
                nextNodes,
                dataRef.current
              );
            } else {
              result = {status: true};
            }
            return result.status;
          });
          if (!result.status) {
            return message.error({
              content: result.msg,
            });
          }
          const nodeKeys = Object.keys(nodesRef.current);
          nodeKeys.push('Task');
          nodeKeys.every(key => {
            const d = dataRef.current[key];
            if (!d || !d.validate) {
              if (key === 'Task') {
                result = {status: false, msg: '任务信息未完成配置'};
              } else {
                graphRef.current.resetSelection(
                  graphRef.current.getCellById(key)
                );
                const type = graphRef.current.getCellById(key).data.type;
                const title = nodesConfig
                  .flatMap(n => (n.children ? n.children : []))
                  .find(v => v.type === type).title;
                setCurrentNode(key);
                result = {status: false, msg: `${title}组件未完成配置`};
              }
            } else {
              result = {status: true};
            }
            return result.status;
          });
          if (!result.status) {
            return message.error({
              content: result.msg,
            });
          }
          const params = formatTaskParams(dataRef.current, nodesRef.current);
          const payload: TaskCreateRequest = {
            name: params.name,
            desc: params.description,
            type:
              params.algoParam.taskType === 0
                ? 'train'
                : params.algoParam.taskType === 1
                  ? 'predict'
                  : 'psi',
            params,
            canvasInfo: JSON.stringify({
              graph: graphRef.current.toJSON(),
              nodesConfig: nodesRef.current,
              state: dataRef.current,
            }),
          };
          if (props.taskId) {
            payload.id = props.taskId;
          }
          createTask(payload).then(resp => {
            if (resp.code === '0') {
              message.success(props.taskId ? '更新成功' : '创建成功');
              return navigate('/task/list');
            }
            message.error(ErrorCode[resp.code]);
          });
        },
        recover: (graphJson: any, dataJson: any, nodeJson: any) => {
          // 表单状态信息
          // dataRef.current = dataJson;
          Object.assign(dataRef.current, dataJson);

          // 画板信息
          graphRef.current.fromJSON(graphJson);

          // 节点关系信息
          nodesRef.current = nodeJson;
        },

        setInfo: (info: any) => {
          dataRef.current.Task = info;
          // train 0, predict 1, psi 2
          if (info.type === 1) {
            // @ts-ignore
            stencilRef.current.groups.Evaluate.remove();
          } else if (info.type === 2) {
            // @ts-ignore
            stencilRef.current.groups.Evaluate.remove();
            // @ts-ignore
            stencilRef.current.groups.Feature.remove();
            // @ts-ignore
            stencilRef.current.groups.Algorithm.remove();
          }
          setCurrentNode('Task');
        },
      };
    });

    let Type: any = Task;
    let withDatasetId = null;
    if (currentNode && currentNode !== 'Task') {
      // console.log('currentNode');
      // console.log(currentNode);
      // console.log('nodesRef', nodesRef.current);
      // console.log('dataRef', dataRef.current);
      const currentNodeType = nodesRef.current[currentNode].type;
      // 拿到各算法的参数配置组件
      Type = (compnentList as Record<string, React.ComponentType>)[
        currentNodeType
      ];
      // console.log('Type', compnentList);
      // const withDataset = null;
      if (currentNodeType.startsWith(NodeType.Feature)) {
        withDatasetId = getDatasetFromFeatureNode(
          graphRef.current,
          currentNode
        );
      }
      if (currentNodeType.startsWith(NodeType.Algorithm)) {
        withDatasetId = getDatasetsForAlgorithm(graphRef.current);
      }
    }
    return (
      <div className={styles.canvas_container}>
        <div className={styles.toolsbar} ref={toolsbarRef}></div>
        <div className={styles.canvas} ref={canvasRef}></div>
        <div className={styles.tools_form}>
          <Type
            data={dataRef.current[currentNode] ?? {}}
            onChange={onChange}
            state={dataRef.current}
            dataset={withDatasetId}
            key={currentNode}
            taskId={props.taskId}
            type={dataRef.current.Task.type}
          />
        </div>
      </div>
    );
  }
);
