import React, {useCallback, useEffect} from 'react';
import {Form, InputNumber, Row, Select} from 'antd';
import {useForm} from 'antd/lib/form/Form';
import styles from './index.less';

export default function (props) {
  const [form] = useForm();
  const onFormChange = useCallback(() => {
    const config = form.getFieldsValue(true);
    props.onChange(config);
  }, [props, form]);
  useEffect(() => {
    form.setFieldsValue(props.data);
  });
  return (
    <div className={styles.form_component_layout}>
      <Form layout="vertical" form={form} onValuesChange={onFormChange}>
        <Form.Item label="标签(label)" required name="label">
          <Select
            mode="tags"
            options={[
              {
                value: 'id',
                label: 'id',
              },
              {
                value: 'count',
                label: 'count',
              },
              {
                value: 'number',
                label: 'number',
              },
              {
                value: 'level',
                label: 'level',
              },
            ]}
          />
        </Form.Item>

        <Form.Item label="正则参数" name="regParam">
          <InputNumber defaultValue="0" min="0" max="1" step="0.01" />
        </Form.Item>
        <Form.Item label="连续值特征" name="contFeatures">
          <Select
            mode="tags"
            options={[
              {
                value: 'f1',
                label: 'f1',
              },
              {
                value: 'f2',
                label: 'f2',
              },
              {
                value: 'f3',
                label: 'f3',
              },
            ]}
          />
        </Form.Item>
        <Row>
          <h4>停止训练条件</h4>
        </Row>
        <Form.Item label="树节点本数阈值" name="SampleThreshold">
          <InputNumber defaultValue="0" min="0" max="1" step="0.01" />
        </Form.Item>
        <Form.Item label="树节点深度阈值" name="DepthThreshold">
          <InputNumber defaultValue="0" min="0" step="1" />
        </Form.Item>
        <Form.Item label="树节点Gini阈值" name="GiniThreshold">
          <InputNumber defaultValue="0" min="0" max="1" step="0.01" />
        </Form.Item>
      </Form>
    </div>
  );
}
