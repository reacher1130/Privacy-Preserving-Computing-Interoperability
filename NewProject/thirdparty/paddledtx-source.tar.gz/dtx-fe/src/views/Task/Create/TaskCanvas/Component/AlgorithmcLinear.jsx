/* eslint-disable @babel/new-cap */
/* eslint-disable react-hooks/exhaustive-deps */
import React, {useEffect} from 'react';
import {Form, InputNumber, Select} from 'antd';
import {useForm} from 'antd/lib/form/Form';
import {unionBy} from 'lodash';
import styles from './index.less';
import AlgorithmModelSelector from './AlgorithmModelSelector';

const Linear = props => {
  const [form] = useForm();
  const v = Form.useWatch([], form);
  useEffect(() => {
    form.validateFields().then(
      values => {
        values.validate = true;
        props.onChange(values);
      },
      ({values}) => {
        values.validate = false;
        props.onChange(values);
      }
    );
  }, [v]);
  useEffect(() => {
    form.setFieldsValue(props.data);
  }, []);

  const psiLabelList = unionBy(
    props.dataset.reduce(
      (sum, d) => sum.concat(props.state[d]?.psiLabelList ?? []),
      []
    ),
    'value'
  );

  return (
    <div className={styles.form_component_layout}>
      <Form layout="vertical" form={form}>
        <Form.Item label="标签(label)" required name="label">
          <Select options={psiLabelList} />
        </Form.Item>
        <Form.Item label="正则模式" name="regMode" initialValue={0}>
          <Select
            options={[
              {
                value: 0,
                label: '关闭',
              },
              {
                value: 1,
                label: 'L1',
              },
              {
                value: 2,
                label: 'L2',
              },
            ]}
          />
        </Form.Item>
        <Form.Item label="正则参数" name="regParam" initialValue="0.1">
          <InputNumber min="0" max="1" step="0.1" />
        </Form.Item>
        <Form.Item label="学习率" name="alpha" initialValue="0.1">
          <InputNumber min="0" max="1" step="0.1" />
        </Form.Item>
        <Form.Item label="收敛振幅" name="amplitude" initialValue="0.001">
          <InputNumber min="0" max="1" step="0.001" />
        </Form.Item>
        <Form.Item
          label="同态加密精度"
          name="accuracy"
          initialValue="10"
          rules={[
            {
              validator: (rules, value) => {
                if (value % 1 !== 0 && value >= 0) {
                  return Promise.reject('请输入非负整数');
                }
                return Promise.resolve();
              },
            },
          ]}
        >
          <InputNumber min="0" max={Number.MAX_SAFE_INTEGER} step="1" />
        </Form.Item>
        <Form.Item
          label="批量大小"
          name="batchSize"
          initialValue="4"
          rules={[
            {
              validator: (rules, value) => {
                if (value % 1 !== 0 && value >= 0) {
                  return Promise.reject('请输入非负整数');
                }
                return Promise.resolve();
              },
            },
          ]}
        >
          <InputNumber min="0" max={Number.MAX_SAFE_INTEGER} step="1" />
        </Form.Item>
      </Form>
    </div>
  );
};

Linear.displayName = 'AlgorithmcLinear';
export default AlgorithmModelSelector(Linear);
