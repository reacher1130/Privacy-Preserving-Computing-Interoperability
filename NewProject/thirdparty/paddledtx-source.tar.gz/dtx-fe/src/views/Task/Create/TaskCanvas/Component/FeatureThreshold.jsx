/* eslint-disable react-hooks/exhaustive-deps */
import React, {useCallback, useEffect} from 'react';
import {PlusOutlined} from '@ant-design/icons';
import {Button, Form, InputNumber, Select} from 'antd';
import {useForm} from 'antd/lib/form/Form';
import styles from './index.less';

function FeatureGroup(props) {
  const form = Form.useFormInstance();
  return (
    <div>
      <Form.Item
        label="特征名称"
        name={[props.name, 'filterOpts']}
        rules={[
          {
            required: true,
            message: '请选择特征名称',
          },
        ]}
      >
        <Select options={props.plainOptions} />
      </Form.Item>
      <Form.Item
        label="阈值"
        name={[props.name, 'threshold']}
        rules={[
          {
            required: true,
            message: '请填写阈值',
          },
        ]}
      >
        <InputNumber />
      </Form.Item>
      <Form.Item
        label="过滤方式"
        required
        name={[props.name, 'filterMethod']}
        rules={[
          {
            required: true,
            message: '请选择过滤方式',
          },
        ]}
      >
        <Select
          options={[
            {
              value: '>',
              label: '大于',
            },
            {
              value: '>=',
              label: '大于等于',
            },
            {
              value: '<',
              label: '小于',
            },
            {
              value: '<=',
              label: '小于等于',
            },
            {
              value: '==',
              label: '等于',
            },
            {
              value: '!=',
              label: '不等于',
            },
          ]}
        />
      </Form.Item>

      {form.getFieldValue(['Thresholds']).length > 1 ? (
        <div style={{textAlign: 'right'}}>
          <Button onClick={props.remove}>删除</Button>
        </div>
      ) : (
        ''
      )}
    </div>
  );
}
export default function (props) {
  const [form] = useForm();
  const v = Form.useWatch([], form);
  useEffect(() => {
    form.validateFields({validateOnly: true}).then(
      values => {
        values.validate = true;
        props.onChange(values);
      },
      ({values}) => {
        values.validate = false;
        props.onChange(values);
      }
    );
  }, [v]);
  useEffect(() => {
    form.setFieldsValue(props.data);
  }, []);

  const onClick = add => () => add({});
  const onRemove = useCallback((i, r) => {
    return function () {
      r(i);
    };
  }, []);
  const plainOptions = props.state[props.dataset]?.psiLabelList ?? [];
  return (
    <div className={styles.form_component_layout}>
      <Form layout="vertical" form={form}>
        <Form.List name="Thresholds" initialValue={[{}]}>
          {(Thresholds, {add, remove}) => {
            return (
              <>
                <div
                  style={{
                    marginBottom: '10px',
                    textAlign: 'right',
                  }}
                >
                  <Button icon={<PlusOutlined />} onClick={onClick(add)}>
                    添加特征
                  </Button>
                </div>
                {Thresholds.map((Threshold, i) => {
                  return (
                    <FeatureGroup
                      {...Threshold}
                      plainOptions={plainOptions}
                      // eslint-disable-next-line react/no-array-index-key
                      key={i + 'test'}
                      remove={onRemove(i, remove)}
                    />
                  );
                })}
              </>
            );
          }}
        </Form.List>
      </Form>
    </div>
  );
}
