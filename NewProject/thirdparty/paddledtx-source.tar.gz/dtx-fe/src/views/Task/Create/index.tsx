import React, {useCallback, useEffect, useRef} from 'react';
import {InfoCircleOutlined} from '@ant-design/icons';
import {useSearchParams} from 'react-router-dom';
import ContentLayout from '@/components/Content';
import {NavKeys, useCurrentNav} from '@/slice/sider';
import Button from '@/components/Button';
import {fetchTaskDetail} from '@/libs/api';
import styles from './index.less';
import {CanvasLayout, NodeRefCurrentType} from './TaskCanvas/componentCreator';

interface CreateProps {
  title?: string;
}
const Create: React.FC<CreateProps> = () => {
  useCurrentNav(NavKeys.taskList);
  let [searchParams] = useSearchParams();
  let id = searchParams.get('id');
  const canvasRef = useRef<{
    submit: () => void;
    recover: (graphJson: any, dataJson: any, nodeJson: any) => void;
    setInfo: (info: any) => void;
    render: () => void;
  }>();
  const sumbitFn = useCallback(() => {
    canvasRef.current.submit();
  }, []);

  useEffect(() => {
    if (id) {
      fetchTaskDetail({id: parseInt(id, 10)}).then(result => {
        if (result.code === '0') {
          const canvasInfo = JSON.parse(result.data.canvasInfo);
          if ('graph' in canvasInfo) {
            const graphJson = canvasInfo.graph;
            const dataJson = canvasInfo.state;
            const nodeJson: NodeRefCurrentType = canvasInfo.nodesConfig;
            // const {name: taskName} = result.data;
            // let taskNodesId: string[] = [];
            // Object.entries(nodeJson).forEach(([key, value]) => {
            //     if (value?.type?.startsWith(NodeType.Task)) {
            //         return taskNodesId.push(key);
            //     }
            // });
            // if (taskNodesId.length > 0) {
            //     taskNodesId.forEach(t => {
            //         dataJson[t].name = taskName;
            //     });
            // }
            canvasRef.current.recover(graphJson, dataJson, nodeJson);
          }
          canvasRef.current.setInfo({
            taskId: id,
            name: result.data.name,
            desc: result.data.desc,
            type:
              result.data.type === 'train'
                ? 0
                : result.data.type === 'predict'
                  ? 1
                  : 2, // train 0, predict 1, psi 2
          });
        }
      });
    } else {
      canvasRef.current.render();
    }
  }, []);
  return (
    <ContentLayout
      desc={
        <div className={styles.titleBar}>
          <InfoCircleOutlined className={styles.icon} />
          <div className={styles.tip}>
            从工具栏里选择组件，拖入画板。在画板中，选中组件，在右侧修改组件属性。选中组件，点击delete键，删除组件。按住alt拖动画板
          </div>
          <Button type="primary" className={styles.button} onClick={sumbitFn}>
            保存任务
          </Button>
        </div>
      }
    >
      <div className={styles.create_container}>
        <div className={styles.main}>
          <CanvasLayout ref={canvasRef} taskId={id ? parseInt(id, 10) : null} />
        </div>
      </div>
    </ContentLayout>
  );
};

export default Create;
