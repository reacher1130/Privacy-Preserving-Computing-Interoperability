/* eslint-disable react/no-array-index-key */
/* eslint-disable react-hooks/exhaustive-deps */
import React, {useCallback, useEffect, useState} from 'react';
import {Checkbox, Col, Empty, Form, Row} from 'antd';
import {useForm} from 'antd/lib/form/Form';
import EMPTY_IMG from '@pub/images/data_empty.png';
import styles from './index.less';

export default function (props) {
  const plainOptions = props.state[props.dataset]?.psiLabelList ?? [];
  const [form] = useForm();
  const FeatureSelectLength = props.data.FeatureSelect?.length ?? 0;
  const [indeterminate, setIndeterminate] = useState(
    FeatureSelectLength && FeatureSelectLength < plainOptions.length
  );
  const [checkAll, setCheckAll] = useState(
    FeatureSelectLength >= plainOptions.length
  );

  const onChange = useCallback(
    list => {
      form.setFieldValue('FeatureSelect', list);
      setIndeterminate(!!list.length && list.length < plainOptions.length);
      setCheckAll(list.length === plainOptions.length);
    },
    [form]
  );

  const onCheckAllChange = useCallback(
    e => {
      form.setFieldValue(
        'FeatureSelect',
        e.target.checked ? plainOptions.map(v => v.value) : []
      );
      setIndeterminate(false);
      setCheckAll(e.target.checked);
      const config = form.getFieldsValue(true);
      props.onChange(config);
    },
    [form, props]
  );

  const v = Form.useWatch([], form);
  useEffect(() => {
    form.validateFields({validateOnly: true}).then(
      values => {
        values.validate = true;
        props.onChange(values);
      },
      ({values}) => {
        values.validate = false;
        props.onChange(values);
      }
    );
  }, [v]);
  useEffect(() => {
    form.setFieldsValue(props.data);
  }, []);
  return (
    <div className={styles.form_component_layout}>
      <Form layout="horizontal" form={form}>
        {plainOptions.length ? (
          <>
            <Form.Item
              label="特征"
              name="FeatureSelect"
              rules={[
                {
                  required: true,
                  message: '请选择特征',
                },
              ]}
            >
              <Checkbox.Group onChange={onChange}>
                <Row>
                  {plainOptions.map((p, i) => {
                    return (
                      <Col span={8} key={i}>
                        <Checkbox value={p.value}>{p.label}</Checkbox>
                      </Col>
                    );
                  })}
                </Row>
              </Checkbox.Group>
            </Form.Item>
            <Checkbox
              value="all"
              checked={checkAll}
              indeterminate={indeterminate}
              onChange={onCheckAllChange}
            >
              全选
            </Checkbox>
          </>
        ) : (
          <Empty
            image={EMPTY_IMG}
            description="请先设置数据集"
            imageStyle={{marginTop: '76px'}}
          />
        )}
      </Form>
    </div>
  );
}
