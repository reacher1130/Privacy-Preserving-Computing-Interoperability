import {GraphNodeChildren, NodeType} from './nodesConfig';

type Rule = (
  allNodes: Record<string, GraphNodeChildren>,
  nextNodes?: string[],
  dataState?: any
) => {status: boolean; msg?: string};
const taskAndDatasetRule: Rule = (allNodes, nextNodes = []) => {
  const msg = '任务类型组件, 必须和两个数据组件相连';
  if (nextNodes.length !== 2) {
    return {
      status: false,
      msg,
    };
  }
  if (!nextNodes.every(n => allNodes[n].type === NodeType.DatasetsCompnent)) {
    return {
      status: false,
      msg,
    };
  }
  return {
    status: true,
  };
};

const datasetsComponentRule: Rule = (allNodes, nextNodes = []) => {
  const msg = '数据集组件，必须和一个特征工程、算法组件相连';
  if (nextNodes.length !== 1) {
    return {
      status: false,
      msg,
    };
  }

  if (
    !nextNodes.every(
      n =>
        allNodes[n].type.startsWith(NodeType.Algorithm) ||
        allNodes[n].type.startsWith(NodeType.Feature)
    )
  ) {
    return {
      status: false,
      msg,
    };
  }

  return {
    status: true,
  };
};

const FeatureRule: Rule = (allNodes, nextNodes = []) => {
  const msg = '特征工程组件，必须和一个算法组件相连';
  if (nextNodes.length !== 1) {
    return {
      status: false,
      msg,
    };
  }

  if (
    !nextNodes.every(
      n =>
        allNodes[n].type.startsWith(NodeType.Algorithm) ||
        allNodes[n].type.startsWith(NodeType.Feature)
    )
  ) {
    return {
      status: false,
      msg,
    };
  }

  return {
    status: true,
  };
};

const AlgorithmRule: Rule = (allNodes, nextNodes = []) => {
  const msg = '算法组件，只能和评估组件相连';
  if (nextNodes.length === 0) {
    return {
      status: true,
    };
  }
  if (!nextNodes.every(n => allNodes[n].type.startsWith(NodeType.Evaluate))) {
    return {
      status: false,
      msg,
    };
  }
  return {
    status: true,
  };
};
const globalRule = (
  allNodes: Record<string, GraphNodeChildren>,
  dataStatus: any
): {status: boolean; msg?: string} => {
  // const taskType = Object.values(allNodes)
  //     .filter(v => v.type === NodeType.TaskTrain || v.type === NodeType.TaskPredict);
  // if (taskType.length === 0) {
  //     return {
  //         status: false,
  //         msg: '必须添加一个任务类型组件',
  //     };
  // }
  // if (taskType.length !== 1) {
  //     return {
  //         status: false,
  //         msg: '任务类型组件只能有一个',
  //     };
  // }
  if (dataStatus.Task.type === 1) {
    if (
      Object.values(allNodes).findIndex(v =>
        v.type.startsWith(NodeType.Evaluate)
      ) !== -1
    ) {
      return {
        status: false,
        msg: '预测任务无法评估',
      };
    }
  }
  const algorithmType = Object.values(allNodes).filter(v =>
    v.type.startsWith(NodeType.Algorithm)
  );
  if (algorithmType.length === 0) {
    return {
      status: false,
      msg: '必须添加一个算法组件',
    };
  }
  if (algorithmType.length !== 1) {
    return {
      status: false,
      msg: '算法组件只能有一个',
    };
  }
  return {
    status: true,
  };
};

const rules: Record<string, Rule> = {
  global: globalRule,
  // 训练任务
  [NodeType.TaskTrain]: taskAndDatasetRule,

  // 预测任务
  [NodeType.TaskPredict]: taskAndDatasetRule,

  // 数据集
  [NodeType.DatasetsCompnent]: datasetsComponentRule,

  // 特征选择
  [NodeType.FeatureExceptional]: FeatureRule,

  // 区间值替换
  [NodeType.FeatureNumber]: FeatureRule,

  // 缺失值处理
  [NodeType.FeatureBinning]: FeatureRule,

  // 阈值过滤
  [NodeType.FeatureThreshold]: FeatureRule,

  // 多元线性回归
  AlgorithmLinear: AlgorithmRule,

  // 多元逻辑回归
  AlgorithmLogic: AlgorithmRule,

  // PHE
  AlgorithmPHE: AlgorithmRule,

  // PSI
  AlgorithmPSI: AlgorithmRule,

  // OT
  AlgorithmOT: AlgorithmRule,

  // 动态评估
  // EvaluateDynamics: taskAndDatasetRule,

  // 静态评估
  // EvaluateStatic: taskAndDatasetRule,
};

export default rules;
