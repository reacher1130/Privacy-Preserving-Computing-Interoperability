import React from 'react';
export default function () {
  return <div>AlgorithmPHE</div>;
}
