/* eslint-disable react-hooks/exhaustive-deps */
import React, {useCallback, useEffect} from 'react';
import {DeleteOutlined, PlusOutlined} from '@ant-design/icons';
import {Button, Empty, Form, Input, InputNumber, Select, Space} from 'antd';
import {useForm} from 'antd/lib/form/Form';
import useFormInstance from 'antd/es/form/hooks/useFormInstance';
import EMPTY_IMG from '@pub/images/data_empty.png';
import styles from './index.less';

function FeatureValueGroup(props) {
  return (
    <Space.Compact>
      <Form.Item
        label="最小"
        required
        style={{width: '80px'}}
        name={[props.name, 'min']}
        rules={[
          {
            required: true,
            message: '请填写最小值',
          },
          {
            type: 'number',
            message: '请填写数字',
          },
        ]}
      >
        <InputNumber size="small" />
      </Form.Item>
      <Form.Item
        label="最大"
        required
        style={{width: '80px'}}
        name={[props.name, 'max']}
        rules={[
          {
            required: true,
            message: '请填写最大值',
          },
          {
            type: 'number',
            message: '请填写数字',
          },
        ]}
      >
        <InputNumber size="small" />
      </Form.Item>
      <Form.Item
        label="替换为"
        required
        style={{width: '80px'}}
        name={[props.name, 'replace']}
        rules={[
          {
            required: true,
            message: '请填写替换值',
          },
        ]}
      >
        <Input size="small" />
      </Form.Item>
      {props.hasRemove ? (
        <Form.Item label=" " style={{marginLeft: '8px'}}>
          <DeleteOutlined onClick={props.onRemove} />
        </Form.Item>
      ) : (
        ''
      )}
    </Space.Compact>
  );
}
function FeatureGroup(props) {
  const form = useFormInstance();
  return (
    <div>
      <Form.Item
        label="特征名称"
        name={[props.name, 'filterOpts']}
        rules={[
          {
            required: true,
            message: '请选择特征名称',
          },
        ]}
      >
        <Select options={props.plainOptions} />
      </Form.Item>

      <Form.List name={[props.name, 'fieldDatas']}>
        {(fieldDatas, {add, remove}) => {
          return fieldDatas.map((f, i) => {
            return (
              <React.Fragment key={[props.name, i].join(',')}>
                <FeatureValueGroup
                  name={i}
                  index={i}
                  onRemove={() => remove(i)}
                  hasRemove={fieldDatas.length > 1}
                />
                {i === fieldDatas.length - 1 ? (
                  <div onClick={() => add({})}>
                    <PlusOutlined />
                    增加规则
                  </div>
                ) : (
                  ''
                )}
              </React.Fragment>
            );
          });
        }}
      </Form.List>

      {form.getFieldValue(['IntervalReplaces']).length > 1 ? (
        <div style={{textAlign: 'right'}}>
          <Button onClick={props.remove}>删除</Button>
        </div>
      ) : (
        ''
      )}
    </div>
  );
}
export default function (props) {
  const [form] = useForm();
  window.f = form;
  const v = Form.useWatch([], form);
  useEffect(() => {
    form.validateFields({validateOnly: true}).then(
      ({values}) => {
        values = values || form.getFieldsValue();
        values.validate = true;
        props.onChange(values);
      },
      e => {
        const values = e.values;
        values.validate = false;
        props.onChange(values);
      }
    );
  }, [v]);
  useEffect(() => {
    form.setFieldsValue(props.data);
  }, []);
  const onClick = useCallback(add => {
    return () => {
      add({fieldDatas: [{}]});
    };
  }, []);
  const onRemove = useCallback((i, r) => {
    return function () {
      r(i);
    };
  }, []);

  const plainOptions = props.state[props.dataset]?.psiLabelList ?? [];
  return (
    <div className={styles.form_component_layout}>
      <Form layout="vertical" form={form}>
        {plainOptions.length ? (
          <Form.List
            name="IntervalReplaces"
            initialValue={[{fieldDatas: [{}]}]}
          >
            {(IntervalReplaces, {add, remove}) => {
              return (
                <>
                  <div
                    style={{
                      marginBottom: '10px',
                      textAlign: 'right',
                    }}
                  >
                    <Button icon={<PlusOutlined />} onClick={onClick(add)}>
                      添加特征
                    </Button>
                  </div>
                  {IntervalReplaces.map((IntervalReplace, i) => {
                    return (
                      <FeatureGroup
                        {...IntervalReplace}
                        // eslint-disable-next-line react/no-array-index-key
                        key={i + 'test'}
                        name={i}
                        plainOptions={plainOptions}
                        remove={onRemove(i, remove)}
                      />
                    );
                  })}
                </>
              );
            }}
          </Form.List>
        ) : (
          <Empty
            image={EMPTY_IMG}
            description="请先设置数据集"
            imageStyle={{marginTop: '76px'}}
          />
        )}
      </Form>
    </div>
  );
}
