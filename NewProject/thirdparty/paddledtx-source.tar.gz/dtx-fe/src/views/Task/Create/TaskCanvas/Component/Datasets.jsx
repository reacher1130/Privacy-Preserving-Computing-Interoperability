/* eslint-disable react/jsx-no-bind */
/* eslint-disable react-hooks/exhaustive-deps */
import React, {useCallback, useEffect, useState} from 'react';
import {App, Form, Input, Select, Tabs} from 'antd';
import {RightOutlined} from '@ant-design/icons';
import {useForm} from 'antd/lib/form/Form';
import DatasetApi from '@/slice/dataset/api';
import TaskApi from '@/slice/task/api';
import ModalBox from '@/components/Modal';
import {
  DatasetStatus,
  datasetApprovedList,
  datasetPublishedList,
} from '@/libs/api';
import Table from '@/components/Table';
import ErrorCode from '@/libs/errorCode';
import styles from './index.less';
import {ToolTip} from '@/components/Table/ToolTip';
import dayjs from 'dayjs';
import ExpiredTimeText from '@/components/ExpireTimeText';

const DatasetTable = props => {
  const {message} = App.useApp();
  const [pageNo, setPageNo] = useState(1);
  const [list, setList] = useState([]);
  const [total, setTotal] = useState(0);
  const requestApi = props.requestApi;
  const onRowSelect = useCallback((selectedRowKeys, selectedRows) => {
    props.onRowSelect?.(selectedRowKeys[0]);
  });

  useEffect(() => {
    requestApi({
      pageNo,
      pageSize: 10,
    }).then(resp => {
      if (resp.code === '0') {
        setList(resp.data.list);
        setTotal(resp.data.total);
        return;
      }
      return message.error(ErrorCode[resp.code]);
    });
  }, [pageNo]);
  const column = [
    {
      title: '数据资源ID',
      dataIndex: 'resourceID',
      key: 'resourceID',
    },
    {
      title: '数据名称',
      dataIndex: 'resourceName',
      key: 'resourceName',
    },
    {
      title: '数据资源描述',
      dataIndex: 'description',
      key: 'description',
      render: desc => (
        <ToolTip content={desc} maxWidth={100} copyable={false} />
      ),
    },
    {
      title: '版本',
      dataIndex: 'version',
      key: 'version',
    },
    // {
    //     title: '资源状态',
    //     dataIndex: 'status',
    //     key: 'status',
    //     render: status => {
    //         switch (status) {
    //             case DatasetStatus.Offline:
    //                 return '下线';
    //             case DatasetStatus.ParseFail:
    //                 return '解析失败';
    //             case DatasetStatus.Published:
    //                 return '已发布';
    //             case DatasetStatus.Parsing:
    //                 return '解析中';
    //             case DatasetStatus.SaveFail:
    //                 return '保存失败';
    //             case DatasetStatus.Saving:
    //                 return '保存中';
    //             case DatasetStatus.Saved:
    //                 return '已保存';
    //         }
    //     },
    // },
    {
      title: '过期时间',
      dataIndex: 'expireTime',
      key: 'expireTime',
      render: e => {
        return <ExpiredTimeText time={e} />;
      },
    },
  ];
  return (
    <Table
      rowSelection={{
        type: 'radio',
        onChange: onRowSelect,
      }}
      columns={column}
      dataSource={list}
      pagination={{
        total,
        current: pageNo,
        onChange: setPageNo,
      }}
      rowKey={'resourceID'}
    />
  );
};
const MineDatasetTable = props => {
  return (
    <DatasetTable
      isMine
      onRowSelect={props.onRowSelect}
      requestApi={datasetPublishedList}
    />
  );
};

const OtherDatasetTable = props => {
  return (
    <DatasetTable
      onRowSelect={props.onRowSelect}
      requestApi={datasetApprovedList}
    />
  );
};
export default function (props) {
  const [form] = useForm();
  const dataID = Form.useWatch(['dataID'], form);
  const [loading, setLoading] = useState(false);
  const [datasetModal, setDatasetModal] = useState(false);
  const [psiLabelList, setPsiLabelList] = useState([]);
  const [executorList, setExecutorList] = useState([]);
  const [fetchDatasetCatalogFileDetail] =
    DatasetApi.useLazyGetDatasetFileDetailQuery();
  const [fetchExecutorList] = TaskApi.useLazyGetDatasetFileExecutorQuery();
  const onValuesChange = () => {
    let values = form.getFieldsValue();
    values.validate = true;
    values.psiLabelList = psiLabelList;
    props.onChange(values);
  };
  const getPsiList = function (resourceID) {
    setLoading(true);
    Promise.all([
      fetchDatasetCatalogFileDetail(resourceID, true),
      fetchExecutorList(resourceID, true),
    ])
      .then(([detailResp, executorResp]) => {
        detailResp = detailResp.data;
        executorResp = executorResp.data;
        if (detailResp.code === '0' && executorResp.code === '0') {
          const detailData = detailResp.data;
          let psiLabelList = [];
          if (detailData.fromOwn) {
            psiLabelList = detailData.metaInfo.map(v => ({
              value: v.name,
              label: v.name,
            }));
          } else {
            psiLabelList = detailData.features.map(v => ({value: v, label: v}));
          }

          return Promise.resolve({
            psiLabelList,
            executorList: executorResp.data.map(v => ({value: v, label: v})),
          });
        }
        let err = detailResp.msg || executorResp.msg;
        return Promise.reject(err);
      })
      .then(options => {
        setPsiLabelList(options.psiLabelList);
        setExecutorList(options.executorList);
        onValuesChange();
        setLoading(false);
      })
      .catch(console.error);
  };

  useEffect(() => {
    if (dataID) {
      getPsiList(dataID);
    }
  }, [dataID]);

  useEffect(() => {
    form.setFieldsValue(props.data);
    const values = form.getFieldsValue();
    if (values.dataID) {
      getPsiList(values.dataID);
    }
  }, []);

  const onRowSelect = useCallback(id => {
    setDatasetModal(false);
    form.setFieldValue('dataID', id);
    onValuesChange();
  }, []);
  return (
    <div className={styles.form_component_layout}>
      <ModalBox
        title="选择数据集"
        width={1000}
        open={datasetModal}
        onCancel={() => setDatasetModal(false)}
        hideOkBtn
        hideCancelBtn
      >
        <Tabs
          defaultActiveKey="mine"
          items={[
            {
              key: 'mine',
              label: '我的数据集',
              children: <MineDatasetTable onRowSelect={onRowSelect} />,
            },
            {
              key: 'apply',
              label: '授权给我的',
              children: <OtherDatasetTable onRowSelect={onRowSelect} />,
            },
          ]}
        />
      </ModalBox>
      <Form layout="vertical" form={form} onValuesChange={onValuesChange}>
        <Form.Item label="数据ID(dataID)" required name="dataID">
          <Input
            placeholder="选择数据集"
            value={props.data.dataID}
            readOnly
            onClick={() => setDatasetModal(true)}
            suffix={<RightOutlined />}
          />
        </Form.Item>
        <Form.Item label="样本对齐特征" required name="psiLabel">
          <Select
            value={props.data.psiLabel}
            defaultActiveFirstOption
            options={psiLabelList}
            loading={loading}
            disabled={loading}
          />
        </Form.Item>
        <Form.Item label="计算节点(executor)" required name="executor">
          <Select
            value={props.data.executor}
            defaultActiveFirstOption
            options={executorList}
            loading={loading}
            disabled={loading}
          />
        </Form.Item>
      </Form>
    </div>
  );
}
