/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable react/jsx-no-bind */
import React, {useCallback, useEffect, useState} from 'react';
import {PlusOutlined} from '@ant-design/icons';
import {Button, Form, Input, Select} from 'antd';
import {useForm} from 'antd/lib/form/Form';
import styles from './index.less';

function FeatureGroup(props) {
  const form = Form.useFormInstance();
  const [showF2, setShowF2] = useState(false);
  useEffect(() => {
    const fillOpt = form.getFieldValue([
      'MissingValues',
      props.name,
      'fillOpts',
    ]);
    if (+fillOpt === 2) {
      setShowF2(true);
    } else {
      setShowF2(false);
    }
  });
  return (
    <div>
      <Form.Item
        label="特征名称"
        name={[props.name, 'labelName']}
        rules={[
          {
            required: true,
            message: '请选择特征名称',
          },
        ]}
      >
        <Select options={props.options} />
      </Form.Item>
      <Form.Item
        label="处理方式"
        rules={[
          {
            required: true,
            message: '请选择处理方式',
          },
        ]}
        name={[props.name, 'fillOpts']}
      >
        <Select
          onChange={item => (item === '2' ? setShowF2(true) : setShowF2(false))}
          rules={[
            {
              required: true,
              message: '请选择处理方式',
            },
          ]}
          options={[
            {
              value: '0',
              label: '平均值',
            },
            {
              value: '1',
              label: '中位数',
            },
            {
              value: '2',
              label: '指定值',
            },
          ]}
        />
      </Form.Item>
      <Form.Item
        label="指定值"
        name={[props.name, 'f2']}
        rules={[
          {
            required: showF2,
            message: '请选择处理方式',
          },
        ]}
        style={{display: showF2 ? 'block' : 'none'}}
      >
        <Input />
      </Form.Item>
      {form.getFieldValue(['MissingValues']).length > 1 ? (
        <div style={{textAlign: 'right'}}>
          <Button onClick={props.remove}>删除</Button>
        </div>
      ) : (
        ''
      )}
    </div>
  );
}
export default function (props) {
  const [form] = useForm();
  const v = Form.useWatch([], form);
  useEffect(() => {
    form.validateFields().then(
      values => {
        values.validate = true;
        props.onChange(values);
      },
      ({values}) => {
        values.validate = false;
        props.onChange(values);
      }
    );
  }, [v]);
  useEffect(() => {
    form.setFieldsValue(props.data);
  }, []);
  const onClick = add => {
    return () => {
      add({});
    };
  };

  const onRemove = useCallback((i, r) => {
    return function () {
      r(i);
    };
  }, []);
  const psiLabelList = props.state[props.dataset]?.psiLabelList ?? [];
  return (
    <div className={styles.form_component_layout}>
      <Form layout="vertical" form={form}>
        <Form.List name="MissingValues" initialValue={[{}]}>
          {(MissingValues, {add, remove}) => {
            return (
              <>
                <div
                  style={{
                    marginBottom: '10px',
                    textAlign: 'right',
                  }}
                >
                  <Button icon={<PlusOutlined />} onClick={onClick(add)}>
                    添加特征
                  </Button>
                </div>
                {MissingValues.map((MissingValue, i) => {
                  return (
                    <FeatureGroup
                      {...MissingValue}
                      options={psiLabelList}
                      // eslint-disable-next-line react/no-array-index-key
                      key={i}
                      name={i}
                      remove={onRemove(i, remove)}
                    />
                  );
                })}
              </>
            );
          }}
        </Form.List>
      </Form>
    </div>
  );
}
