/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable react/jsx-no-bind */
import React, {useEffect, useState} from 'react';
import {Form, Input} from 'antd';
import TextArea from 'antd/lib/input/TextArea';
import {useForm} from 'antd/lib/form/Form';
import styles from './index.less';
import {fetchTaskExists} from '@/libs/api';

export default function (props) {
  const [form] = useForm();
  const v = Form.useWatch([], form);
  const [first, setFirst] = useState(true);
  useEffect(() => {
    const name = form.getFieldValue('name');
    if (!name) {
      return;
    }
    form.validateFields({validateOnly: first}).then(
      values => {
        setFirst(false);
        values.validate = true;
        props.onChange(values);
      },
      ({values}) => {
        setFirst(false);
        values.validate = false;
        props.onChange(values);
      }
    );
  }, [v]);
  useEffect(() => {
    form.setFieldsValue(props.data);
  }, []);
  return (
    <div className={styles.form_component_layout}>
      <Form layout="vertical" form={form}>
        <Form.Item
          label="任务名称"
          name="name"
          rules={[
            {
              type: 'string',
              required: true,
              max: 20,
              min: 4,
              message: '名称必须大于4个字符小于20个字符',
            },
            {
              validator: (r, v) => {
                return fetchTaskExists({name: v}).then(resp => {
                  if (resp.data !== 0) {
                    return Promise.reject();
                  }
                });
              },
              message: '任务名称不能与已有任务重复',
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          label="任务简介"
          name="description"
          rules={[
            {
              type: 'string',
              required: true,
              max: 140,
              min: 4,
              message: '任务简介必须大于4个字符，小于140个字符',
            },
          ]}
        >
          <TextArea />
        </Form.Item>
      </Form>
    </div>
  );
}
