import {Shape} from '@antv/x6';

export default {
  autoResize: true,
  panning: {
    enabled: true,
    modifiers: 'alt',
  },
  preventDefaultContextMenu: true,
  // mousewheel: true,
  grid: true,
  background: {
    color: '#fafafa',
  },
  connecting: {
    router: 'manhattan',
    connector: {
      name: 'rounded',
      args: {
        radius: 8,
      },
    },
    anchor: 'center',
    connectionPoint: 'anchor',
    allowBlank: false,
    allowNode: false,
    allowMulti: false,
    allowLoop: false,
    allowEdge: false,
    snap: {
      radius: 20,
    },
    createEdge() {
      return new Shape.Edge({
        attrs: {
          line: {
            stroke: '#07afbe',
            strokeWidth: 1,
            targetMarker: {
              name: 'block',
              width: 12,
              height: 8,
            },
          },
        },
        zIndex: 0,
      });
    },
  },
};
