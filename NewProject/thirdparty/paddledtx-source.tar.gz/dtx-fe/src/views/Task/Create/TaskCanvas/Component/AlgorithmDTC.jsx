/* eslint-disable react-hooks/exhaustive-deps */
import React, {useEffect} from 'react';
import {Form, InputNumber, Select} from 'antd';
import {useForm} from 'antd/lib/form/Form';
import {unionBy} from 'lodash';
import styles from './index.less';
import AlgorithmModelSelector from './AlgorithmModelSelector';

const DTC = function (props) {
  const [form] = useForm();
  const v = Form.useWatch([], form);
  useEffect(() => {
    form.validateFields({validateOnly: true}).then(
      values => {
        values.validate = true;
        props.onChange(values);
      },
      ({values}) => {
        values.validate = false;
        props.onChange(values);
      }
    );
  }, [v]);
  useEffect(() => {
    form.setFieldsValue(props.data);
  }, []);
  const psiLabelList = unionBy(
    props.dataset.reduce((sum, d) => {
      return sum.concat(props.state[d]?.psiLabelList ?? []);
    }, []),
    'value'
  );

  return (
    <div className={styles.form_component_layout}>
      <Form layout="vertical" form={form}>
        <Form.Item label="标签(label)" required name="label">
          <Select options={psiLabelList} />
        </Form.Item>
        <Form.Item label="连续值特征" name="contFeatures">
          <Select mode="tags" options={psiLabelList} />
        </Form.Item>
        <Form.Item label="正则参数" name="regParam" initialValue="0.1">
          <InputNumber min="0" max="1" step="0.1" />
        </Form.Item>
        <h4>训练停止条件: </h4>
        <Form.Item
          label="样本数量阈值"
          name="SampleThreshold"
          initialValue="10"
          rules={[
            {
              validator: (r, v) => {
                if (v % 1 === 0 && v >= 0) {
                  return Promise.resolve();
                }
                return Promise.reject();
              },
              message: '请输入非负整数',
            },
          ]}
        >
          <InputNumber min="0" max={Number.MAX_SAFE_INTEGER} step="1" />
        </Form.Item>
        <Form.Item
          label="树最大深度"
          name="DepthThreshold"
          initialValue="15"
          rules={[
            {
              validator: (r, v) => {
                if (v % 1 === 0 && v >= 0) {
                  return Promise.resolve();
                }
                return Promise.reject();
              },
              message: '请输入非负整数',
            },
          ]}
        >
          <InputNumber min="0" max={Number.MAX_SAFE_INTEGER} step="1" />
        </Form.Item>
        <Form.Item
          label="Gini指数阈值"
          name="GiniThreshold"
          initialValue="0.01"
        >
          <InputNumber min="0" max={Number.MAX_SAFE_INTEGER} step="0.01" />
        </Form.Item>
      </Form>
    </div>
  );
};
DTC.displayName = 'AlgorithmDTC';
// eslint-disable-next-line @babel/new-cap
const AlgorithmDTC = AlgorithmModelSelector(DTC);

export default AlgorithmDTC;
