/* eslint-disable react-hooks/exhaustive-deps */
import React, {useEffect} from 'react';
import {Form, Input, Row, Select} from 'antd';
import styles from './index.less';
import {useForm} from 'antd/es/form/Form';
import SelectStatus from '@/components/Select';

interface TaskInfoPanelProps {
  data: {
    name: string;
    desc: string;
    type: 0 | 1;
    taskId: string;
  };
  onChange: (values: any) => void;
}
const Task: React.FC<TaskInfoPanelProps> = props => {
  const [form] = useForm();
  useEffect(() => {
    form.setFieldsValue(props.data);
  }, []);

  const v = Form.useWatch([], form);
  useEffect(() => {
    const name = form.getFieldValue('name');
    if (!name) {
      return;
    }
    form.validateFields().then(
      values => {
        values.validate = true;
        console.log(values);
        props.onChange(values);
      },
      ({values}) => {
        values.validate = false;
        console.log(values);
        props.onChange(values);
      }
    );
  }, [v]);
  return (
    <div className={styles.form_component_layout}>
      <Form form={form} layout="vertical">
        <Form.Item
          label="任务名称"
          name="name"
          rules={[
            {
              required: true,
              min: 4,
              max: 20,
              message: '请输入任务名称，4到20个字符',
            },
          ]}
        >
          <Input placeholder="请输入任务名称" />
        </Form.Item>
        <Form.Item label="任务类型" name="type">
          <Select
            disabled
            className={styles.fakeDisabled_select}
            options={[
              {
                value: 0,
                label: '训练任务',
              },
              {
                value: 1,
                label: '预测任务',
              },
              {
                value: 2,
                label: '隐私求交任务',
              },
            ]}
          />
        </Form.Item>
        <Form.Item
          label="任务简介"
          name="desc"
          rules={[
            {
              min: 4,
              max: 50,
              required: true,
              message: '请输入4到50字以内的任务简介',
            },
          ]}
        >
          <Input.TextArea placeholder="请输入任务简介" />
        </Form.Item>
      </Form>
    </div>
  );
};

export default Task;
