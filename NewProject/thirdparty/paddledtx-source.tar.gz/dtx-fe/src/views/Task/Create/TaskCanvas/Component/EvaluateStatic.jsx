/* eslint-disable react-hooks/exhaustive-deps */
import React, {useCallback, useEffect, useState} from 'react';
import {Form, InputNumber, Select, Switch} from 'antd';
import {useForm} from 'antd/lib/form/Form';
import styles from './index.less';

export default function (props) {
  const [method, setMethod] = useState(props.data.evalRule);
  const [form] = useForm();
  const v = Form.useWatch([], form);
  useEffect(() => {
    setTimeout(() => {
      form.validateFields({validateOnly: true}).then(
        values => {
          values = form.getFieldsValue();
          values.validate = true;
          props.onChange(values);
        },
        ({values}) => {
          values = form.getFieldsValue();
          values.validate = false;
          props.onChange(values);
        }
      );
    }, 10);
  }, [v]);

  const onChange = useCallback(v => {
    setMethod(v);
  }, []);
  useEffect(() => {
    form.setFieldsValue(props.data);
  }, []);
  return (
    <div className={styles.form_component_layout}>
      <Form layout="vertical" form={form}>
        <Form.Item label="评估方法" required name="evalRule">
          <Select
            value={method}
            options={[
              {
                value: 'randomSplit',
                label: '随机划分',
              },
              {
                value: 'cv',
                label: '交叉验证',
              },
            ]}
            onChange={onChange}
          />
        </Form.Item>
        {method ? (
          method === 'randomSplit' ? (
            <Form.Item
              label="验证集比例"
              required
              name="percentLO"
              initialValue="30"
              rules={[
                {
                  validator: (r, v) => {
                    v = parseInt(v, 10);
                    if (v % 1 === 0 && v > 0 && v < 100) {
                      return Promise.resolve();
                    }
                    return Promise.reject();
                  },
                  message: '请填写大于0小于100的整数',
                },
              ]}
            >
              <InputNumber step="1" addonAfter="%" />
            </Form.Item>
          ) : (
            <>
              <Form.Item
                label="折数"
                name="folds"
                initialValue="10"
                rules={[
                  {
                    validator: (r, v) => {
                      if (v % 1 === 0 && v > 0) {
                        return Promise.resolve();
                      }
                      return Promise.reject();
                    },
                    message: '折数只能是正整数',
                  },
                ]}
              >
                <InputNumber min="1" max="10" step="1" />
              </Form.Item>
              <Form.Item
                label="随机打乱样本"
                name="shuffle"
                valuePropName="checked"
              >
                <Switch
                  checkedChildren="开启"
                  unCheckedChildren="关闭"
                  defaultChecked={props.data.shuffle}
                />
              </Form.Item>
            </>
          )
        ) : (
          ''
        )}
      </Form>
    </div>
  );
}
