import React, {useCallback, useEffect} from 'react';
import {Form, InputNumber} from 'antd';
import {useForm} from 'antd/lib/form/Form';
import styles from './index.less';

export default function (props) {
  const [form] = useForm();
  const onFormChange = useCallback(() => {
    const config = form.getFieldsValue(true);
    props.onChange(config);
  }, [props, form]);
  useEffect(() => {
    form.setFieldsValue(props.data);
  });
  return (
    <div className={styles.form_component_layout}>
      <Form layout="vertical" form={form} onValuesChange={onFormChange}>
        <Form.Item label="percentLO" required name="percentLO">
          <InputNumber
            defaultValue="10"
            min="1"
            max="100"
            step="0.1"
            addonAfter="%"
          />
        </Form.Item>
      </Form>
    </div>
  );
}
