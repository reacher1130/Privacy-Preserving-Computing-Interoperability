import nodesConfig from './nodesConfig';

export default {
  title: '',
  layoutOptions: {
    columns: 1,
    rowHeight: 40,
  },
  collapsable: false,
  stencilGraphWidth: 200,
  groups: nodesConfig.map(v => {
    return {
      name: v.type,
      title: v.title,
      graphHeight: (v.children.length * 2 + 1) * 20,
    };
  }),
};
