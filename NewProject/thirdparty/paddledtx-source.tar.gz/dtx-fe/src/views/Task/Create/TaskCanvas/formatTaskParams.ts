/* eslint-disable max-nested-callbacks */
import {NodeRefCurrentType} from './componentCreator';
import {NodeType} from './config/nodesConfig';

const MissingValuesMethod = ['average', 'median', 'specified'];

const ThresholdFilterFilterMethod: Record<string, any> = {
  '>': 'g',
  '>=': 'ge',
  '<': 'l',
  '<=': 'le',
  '==': 'e',
  '!=': 'ne',
};

/**
 * 根据数据集 ID 获取特征工程节点列表
 *
 * @param datasetId 数据集 ID
 * @param dataRefCurrent 当前数据引用
 * @param nodesRefCurrent 节点引用当前状态
 * @returns 特征工程节点列表
 */
function getFeatureEngsByDatasetId(
  datasetId: string,
  dataRefCurrent: Record<string, any>,
  nodesRefCurrent: NodeRefCurrentType
) {
  let featureNodes: Array<{
    type: string;
    params: Record<string, any>;
  }> = [];
  const nextNodeId = nodesRefCurrent[datasetId].nextNodes?.[0];
  if (nextNodeId) {
    const nextNode = nodesRefCurrent[nextNodeId];
    if (nextNode.type.startsWith(NodeType.Feature)) {
      featureNodes.push({
        type: nextNode.type,
        params: dataRefCurrent[nextNodeId],
      });
    }
    featureNodes = featureNodes.concat(
      getFeatureEngsByDatasetId(nextNodeId, dataRefCurrent, nodesRefCurrent)
    );
  }
  return featureNodes;
}
export default (
  dataRefCurrent: Record<string, any>,
  nodesRefCurrent: NodeRefCurrentType
) => {
  const params: Record<string, any> = {};
  // const Task = Object.entries(nodesRefCurrent).filter(([_, i]) =>
  //     i.type.startsWith(NodeType.Task)
  // )[0];
  const Algorithm = Object.entries(nodesRefCurrent).filter(([_, i]) =>
    i.type.startsWith(NodeType.Algorithm)
  )[0];

  const Evaluates = Object.entries(nodesRefCurrent)
    .filter(([_, i]) => i.type.startsWith(NodeType.Evaluate))
    .map(([id, {type}]) => ({id, type}));
  // const taskTypeId = Task[0];
  const AlgorithmId = Algorithm[0];

  // 任务名称 简介
  params.name = dataRefCurrent['Task'].name;
  params.description = dataRefCurrent['Task'].desc;

  // 设置数据集
  const datasetIds = Object.entries(nodesRefCurrent)
    .filter(n => {
      const val = n[1];
      if (val.type === NodeType.DatasetsCompnent) {
        return true;
      }
      return false;
    })
    .map(n => n[0]);
  params.dataSets = datasetIds.map(d => {
    const datasetfeatureEngs = getFeatureEngsByDatasetId(
      d,
      dataRefCurrent,
      nodesRefCurrent
    );
    let featureEngs: any[] = [];
    if (datasetfeatureEngs.length) {
      featureEngs = datasetfeatureEngs
        .map((v: any) => {
          switch (v.type) {
            case NodeType.FeatureBinning:
              return {
                missingValues: {
                  fillOpts: v.params.MissingValues.reduce(
                    (sum: any, current: any) => {
                      sum[current.labelName] = {
                        method:
                          MissingValuesMethod[
                            parseInt(current.fillOpts as string, 10)
                          ],
                      };
                      if (current.fillOpts === '2') {
                        sum[current.labelName].value = current.f2;
                      }
                      return sum;
                    },
                    {}
                  ),
                },
              };
            case NodeType.FeatureExceptional:
              return {
                featureSelect: {
                  features: v.params.FeatureSelect,
                },
              };
            case NodeType.FeatureNumber:
              return {
                intervalReplace: {
                  repOpts: v.params.IntervalReplaces.reduce(
                    (sum: any, current: any) => {
                      sum[current.filterOpts] = {
                        intervals: current.fieldDatas.map((f: any) => {
                          return {
                            left: f.min,
                            right: f.max,
                            value: f.replace,
                          };
                        }),
                      };
                      return sum;
                    },
                    {}
                  ),
                },
              };
            case NodeType.FeatureThreshold:
              return {
                thresholdFilter: {
                  filterOpts: v.params.Thresholds.reduce(
                    (sum: any, current: any) => {
                      const m: string = current.filterMethod as string;
                      sum[current.filterOpts] = {
                        threshold: +current.threshold,
                        filterMethod: ThresholdFilterFilterMethod[m],
                      };
                      return sum;
                    },
                    {}
                  ),
                },
              };
          }
        })
        .filter(v => !!v);
    }
    const dataset: {
      executor: any;
      dataID: any;
      psiLabel: any;
      featureEngs?: any;
    } = {
      executor: dataRefCurrent[d].executor,
      dataID: dataRefCurrent[d].dataID,
      psiLabel: dataRefCurrent[d].psiLabel,
    };
    if (featureEngs.length) {
      dataset.featureEngs = featureEngs;
    }

    return dataset;
  });

  // 算法（algoParam） 参数
  if (dataRefCurrent.Task.type === 0) {
    let AlgorithmNode = dataRefCurrent[AlgorithmId];
    params.algoParam = {
      taskType: 0,
      trainParams: {
        label: AlgorithmNode.label,
        regParam: +(AlgorithmNode.regParam ?? '0.1'),
      },
    };
    switch (nodesRefCurrent[AlgorithmId].type) {
      case NodeType.AlgorithmLinear:
        params.algoParam.algo = 0;
        params.algoParam.trainParams.regMode = +(AlgorithmNode.regMode ?? '0');
        params.algoParam.trainParams.alpha = +(AlgorithmNode.alpha ?? '0.1');
        params.algoParam.trainParams.amplitude = +(
          AlgorithmNode.amplitude ?? '0.001'
        );
        params.algoParam.trainParams.accuracy = +(
          AlgorithmNode.accuracy ?? '10'
        );
        params.algoParam.trainParams.batchSize = +(
          AlgorithmNode.batchSize ?? '4'
        );
        break;
      case NodeType.AlgorithmLogic:
        params.algoParam.algo = 1;
        params.algoParam.trainParams.labelName =
          dataRefCurrent[AlgorithmId].labelName;
        params.algoParam.trainParams.regMode = +(AlgorithmNode.regMode ?? '0');
        params.algoParam.trainParams.alpha = +(AlgorithmNode.alpha ?? '0.1');
        params.algoParam.trainParams.amplitude = +(
          AlgorithmNode.amplitude ?? '0.001'
        );
        params.algoParam.trainParams.accuracy = +(
          AlgorithmNode.accuracy ?? '10'
        );
        params.algoParam.trainParams.batchSize = +(
          AlgorithmNode.batchSize ?? '4'
        );
        break;
      case NodeType.AlgorithmDTC:
        params.algoParam.algo = 3;
        params.algoParam.trainParams.contFeatures =
          AlgorithmNode.contFeatures ?? [];
        params.algoParam.trainParams.stopCond = {};
        params.algoParam.trainParams.stopCond.SampleThreshold = +(
          AlgorithmNode.SampleThreshold ?? '10'
        );
        params.algoParam.trainParams.stopCond.DepthThreshold = +(
          AlgorithmNode.DepthThreshold ?? '15'
        );
        params.algoParam.trainParams.stopCond.GiniThreshold = +(
          AlgorithmNode.GiniThreshold ?? '0.01'
        );
        break;
    }
  } else if (dataRefCurrent.Task.type === 2) {
    params.algoParam = {
      algo: 5, // 算法类型是隐私求交5， 当使用隐私求交（ PSI） 组件时， 5 是固定值
      taskType: 2,
      psiParams: dataRefCurrent[AlgorithmId],
    };
  } else {
    params.algoParam = {
      taskType: 1,
      modelTaskID: dataRefCurrent[AlgorithmId].modelTaskID,
    };
    switch (nodesRefCurrent[AlgorithmId].type) {
      case NodeType.AlgorithmLinear:
        params.algoParam.algo = 0;
        break;
      case NodeType.AlgorithmLogic:
        params.algoParam.algo = 1;
        break;
      case NodeType.AlgorithmDTC:
        params.algoParam.algo = 3;
        break;
    }
  }
  // const featureNodes = getFeatureEngs(dataRefCurrent, nodesRefCurrent);
  if (Evaluates.length) {
    Evaluates.forEach(e => {
      const nConf = dataRefCurrent[e.id];
      if (e.type === NodeType.EvaluateStatic) {
        params.algoParam.evalParams = {
          enable: true,
          evalRule: nConf.evalRule === 'randomSplit' ? 0 : 1,
        };
        if (nConf.evalRule === 'randomSplit') {
          params.algoParam.evalParams.randomSplit = {
            percentLO: +nConf.percentLO,
          };
        } else {
          params.algoParam.evalParams.cv = {
            folds: +nConf.folds,
            fshuffle: nConf.shuffle,
          };
        }
      }
    });
  }

  return params;
};
