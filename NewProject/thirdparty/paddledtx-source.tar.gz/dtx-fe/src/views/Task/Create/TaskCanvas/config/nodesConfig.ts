import {
  CalculatorOutlined,
  CodeOutlined,
  DatabaseOutlined,
  FundProjectionScreenOutlined,
  ToolOutlined,
} from '@ant-design/icons';
import Icon from '@ant-design/icons/lib/components/Icon';

export enum NodeType {
  Task = 'Task',
  TaskTrain = 'TaskTrain',
  TaskPredict = 'TaskPredict',
  AlgorithmTaskPsi = 'AlgorithmTaskPsi',
  Datasets = 'Datasets',
  DatasetsCompnent = 'DatasetsComponent',
  Feature = 'Feature',
  FeatureExceptional = 'FeatureExceptional',
  FeatureNumber = 'FeatureNumber',
  FeatureBinning = 'FeatureBinning',
  FeatureThreshold = 'FeatureThreshold',
  Algorithm = 'Algorithm',
  AlgorithmLinear = 'AlgorithmLinear',
  AlgorithmLogic = 'AlgorithmLogic',
  AlgorithmDTC = 'AlgorithmDTC',
  AlgorithmPHE = 'AlgorithmPHE',
  AlgorithmPSI = 'AlgorithmPSI',
  AlgorithmOT = 'AlgorithmOT',
  Evaluate = 'Evaluate',
  EvaluateDynamics = 'EvaluateDynamics',
  EvaluateStatic = 'EvaluateStatic',
}
export interface GraphNodeBase {
  title: string;
  type: NodeType;
}
export interface GraphNodeChildren extends GraphNodeBase {
  disabled?: boolean;
  disabledText?: string;
}
export interface GraphNodeParent extends GraphNodeBase {
  childrenIcon: typeof Icon;
  children: GraphNodeChildren[];
}

const config: GraphNodeParent[] = [
  // {
  //     title: '任务类型组件',
  //     type: NodeType.Task,
  //     childrenIcon: CodeOutlined,
  //     children: [
  //         {
  //             title: '训练任务',
  //             type: NodeType.TaskTrain,
  //             disabled: false,
  //         },
  //         {
  //             title: '预测任务',
  //             type: NodeType.TaskPredict,
  //             disabled: false,
  //         },
  //     ],
  // },
  {
    title: '数据集组件',
    type: NodeType.Datasets,
    childrenIcon: DatabaseOutlined,
    children: [
      {
        title: '数据集',
        type: NodeType.DatasetsCompnent,
        disabled: false,
      },
    ],
  },
  {
    title: '特征工程组件',
    type: NodeType.Feature,
    childrenIcon: ToolOutlined,
    children: [
      {
        title: '特征选择',
        type: NodeType.FeatureExceptional,
        disabled: false,
      },
      {
        title: '区间值替换',
        type: NodeType.FeatureNumber,
        disabled: false,
      },
      {
        title: '缺失值处理',
        type: NodeType.FeatureBinning,
        disabled: false,
      },
      {
        title: '阈值过滤',
        type: NodeType.FeatureThreshold,
        disabled: false,
      },
    ],
  },
  {
    title: '算法组件',
    type: NodeType.AlgorithmTaskPsi,
    childrenIcon: CalculatorOutlined,
    children: [
      {
        title: 'PSI',
        type: NodeType.AlgorithmTaskPsi,
        disabled: false,
      },
    ],
  },
  {
    title: '算法组件',
    type: NodeType.Algorithm,
    childrenIcon: CalculatorOutlined,
    children: [
      {
        title: '多元线性回归',
        type: NodeType.AlgorithmLinear,
        disabled: false,
      },
      {
        title: '多元逻辑回归',
        type: NodeType.AlgorithmLogic,
        disabled: false,
      },
      {
        title: '分类决策树',
        type: NodeType.AlgorithmDTC,
        disabled: false,
      },
      {
        title: '同态加密',
        type: NodeType.AlgorithmPHE,
        disabled: false,
      },
      {
        title: 'PSI',
        type: NodeType.AlgorithmPSI,
        disabled: false,
      },
      // {
      //     title: 'OT',
      //     type: NodeType.AlgorithmOT,
      //     disabled: true,
      // },
    ],
  },
  {
    title: '模型评估组件',
    type: NodeType.Evaluate,
    childrenIcon: FundProjectionScreenOutlined,
    children: [
      {
        title: '动态评估',
        type: NodeType.EvaluateDynamics,
        disabled: true,
      },
      {
        title: '静态评估',
        type: NodeType.EvaluateStatic,
      },
    ],
  },
];

export default config;
