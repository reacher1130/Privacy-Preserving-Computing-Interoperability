import React, {useCallback, useEffect, useState} from 'react';
import {App, Form, Input, Tabs} from 'antd';
import {useForm} from 'antd/es/form/Form';
import {RightOutlined} from '@ant-design/icons';
import ModalBox from '@/components/Modal';
import {modelApprovedList, modelPublishedList} from '@/libs/api';
import {ToolTip} from '@/components/Table/ToolTip';
import ErrorCode from '@/libs/errorCode';
import Table from '@/components/Table';
import styles from './index.less';
import {NodeType} from '../config/nodesConfig';
import ExpiredTimeText from '@/components/ExpireTimeText';

interface AlgorithmModelSelectorProps {
  type: number;
  data: any;
  onChange: (values: Record<string, any>) => void;
  algoType: number;
}
const ModelTable = (props: {
  requestApi: any;
  onRowSelect: (arg0: any) => void;
  isMine?: boolean;
  algoType: number;
}) => {
  const {message} = App.useApp();
  const [pageNo, setPageNo] = useState(1);
  const [list, setList] = useState([]);
  const [total, setTotal] = useState(0);
  const requestApi = props.requestApi;
  const onRowSelect = useCallback((selectedRowKeys: any[]) => {
    props.onRowSelect?.(selectedRowKeys[0]);
  }, []);

  useEffect(() => {
    requestApi({
      pageNo,
      pageSize: 10,
    }).then((resp: any) => {
      if (resp.code === '0') {
        setList(resp.data.list);
        setTotal(resp.data.total);
        return;
      }
      return message.error(ErrorCode[resp.code]);
    });
  }, [pageNo]);
  const column = [
    {
      title: '模型资源ID',
      dataIndex: 'resourceID',
      key: 'resourceID',
    },
    {
      title: '模型名称',
      dataIndex: 'resourceName',
      key: 'resourceName',
    },
    {
      title: '模型资源源描述',
      dataIndex: 'description',
      key: 'description',
      render: (desc: string) => (
        <ToolTip content={desc} maxWidth={100} copyable={false} />
      ),
    },
    {
      title: '算法类型',
      dataIndex: 'algoType',
      key: 'algoType',
      render: (algoType: number) => {
        switch (algoType) {
          case 0:
            return '多元线性回归';
          case 1:
            return '多元逻辑回归';
          case 3:
            return '分类决策树';
        }
      },
    },
    // {
    //     title: '资源状态',
    //     dataIndex: 'status',
    //     key: 'status',
    //     render: status => {
    //         switch (status) {
    //             case DatasetStatus.Offline:
    //                 return '下线';
    //             case DatasetStatus.ParseFail:
    //                 return '解析失败';
    //             case DatasetStatus.Published:
    //                 return '已发布';
    //             case DatasetStatus.Parsing:
    //                 return '解析中';
    //             case DatasetStatus.SaveFail:
    //                 return '保存失败';
    //             case DatasetStatus.Saving:
    //                 return '保存中';
    //             case DatasetStatus.Saved:
    //                 return '已保存';
    //         }
    //     },
    // },
    {
      title: '过期时间',
      dataIndex: 'expireTime',
      key: 'expireTime',
      render: (e: number) => <ExpiredTimeText time={e} />,
    },
  ];
  return (
    <Table
      rowSelection={{
        type: 'radio',
        onChange: onRowSelect,
        getCheckboxProps: (record: any) => ({
          disabled: record.algoType !== props.algoType, // Column configuration not to be checked
        }),
      }}
      columns={column}
      dataSource={list}
      pagination={{
        total,
        current: pageNo,
        onChange: setPageNo,
      }}
      rowKey={'resourceID'}
    />
  );
};
const MineModelTable = (props: any) => {
  return (
    <ModelTable
      isMine
      onRowSelect={props.onRowSelect}
      requestApi={modelPublishedList}
      algoType={props.algoType}
    />
  );
};

const OtherModelTable = (props: any) => {
  return (
    <ModelTable
      onRowSelect={props.onRowSelect}
      requestApi={modelApprovedList}
      algoType={props.algoType}
    />
  );
};
const ModelSelector = (props: AlgorithmModelSelectorProps) => {
  const [form] = useForm();

  const [datasetModal, setModelsetModal] = useState(false);
  useEffect(() => {
    form.setFieldsValue(props.data);
  }, []);
  const onValuesChange = () => {
    let values = form.getFieldsValue();
    values.validate = true;
    props.onChange(values);
  };
  const onRowSelect = useCallback((id: string) => {
    setModelsetModal(false);
    form.setFieldValue('modelTaskID', id);
    onValuesChange();
  }, []);
  return (
    <div className={styles.form_component_layout}>
      <ModalBox
        title="选择模型"
        width={1000}
        open={datasetModal}
        onCancel={() => setModelsetModal(false)}
        hideOkBtn
        hideCancelBtn
      >
        <Tabs
          defaultActiveKey="mine"
          items={[
            {
              key: 'mine',
              label: '我的模型',
              children: (
                <MineModelTable
                  onRowSelect={onRowSelect}
                  algoType={props.algoType}
                />
              ),
            },
            {
              key: 'apply',
              label: '授权给我的',
              children: (
                <OtherModelTable
                  onRowSelect={onRowSelect}
                  algoType={props.algoType}
                />
              ),
            },
          ]}
        />
      </ModalBox>
      <Form layout="vertical" form={form} onValuesChange={onValuesChange}>
        <Form.Item label="模型选择" name="modelTaskID">
          <Input
            placeholder="选择模型"
            value={props.data.dataID}
            readOnly
            onClick={() => setModelsetModal(true)}
            suffix={<RightOutlined />}
          />
        </Form.Item>
      </Form>
    </div>
  );
};
const AlgorithmModelSelector = function <T extends AlgorithmModelSelectorProps>(
  Target: React.ComponentType<T>
) {
  return function (props: T) {
    if (props.type === 0) {
      return <Target {...props} />;
    }
    let algoType = 0;
    switch (Target.displayName) {
      case NodeType.AlgorithmLogic:
        algoType = 1;
        break;
      case NodeType.AlgorithmDTC:
        algoType = 3;
    }
    return <ModelSelector {...props} algoType={algoType} />;
  };
};

export default AlgorithmModelSelector;
