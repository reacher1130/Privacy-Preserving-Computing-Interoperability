/* eslint-disable react-hooks/exhaustive-deps */
import React, {useEffect} from 'react';
import {Form, Input, Row, Select} from 'antd';
import styles from './index.less';
import {intersectionBy} from 'lodash';
import {useForm} from 'antd/es/form/Form';
// import SelectStatus from '@/components/Select';

interface TaskInfoPanelProps {
  data: {
    // taskId: string;
    psiAlgorithmType: number;
    eccType: string;
    psiColum: string[] | string;
  };
  dataset: string[];
  state: any;
  onChange: (values: any) => void;
}
const AlgorithmTaskPsi: React.FC<TaskInfoPanelProps> = props => {
  const [form] = useForm();
  useEffect(() => {
    form.setFieldsValue(props.data);
  }, []);

  const v = Form.useWatch([], form);
  const pisType = Form.useWatch('psiAlgorithmType', form);

  useEffect(() => {
    // const name = form.getFieldValue('name');
    // if (!name) {
    //   return;
    // }
    form.validateFields().then(
      values => {
        values.validate = true;
        props.onChange(values);
      },
      ({values}) => {
        values.validate = false;
        props.onChange(values);
      }
    );
  }, [v]);
  const psiLabelList = intersectionBy<{lable: string; value: string}>(
    ...props.dataset.map(id => {
      return props.state[id]?.psiLabelList ?? [];
    }),
    'value'
  );
  console.log('psiLabelList', psiLabelList);
  return (
    <div className={styles.form_component_layout}>
      <Form form={form} layout="vertical">
        <Form.Item label="算法类型" required name="psiAlgorithmType">
          <Select options={[{value: 0, label: 'ECDH_PSI'}]} />
        </Form.Item>
        {pisType === 0 && (
          <Form.Item label="ecc算法类型" required name="eccType">
            <Select
              options={[
                {value: 'secP256r1', label: 'secP256r1'},
                {value: 'sm2', label: 'sm2'},
              ]}
            />
          </Form.Item>
        )}
        <Form.Item label="求交字段" required name="psiColum">
          <Select mode="multiple" options={psiLabelList} />
        </Form.Item>
      </Form>
    </div>
  );
};

export default AlgorithmTaskPsi;
