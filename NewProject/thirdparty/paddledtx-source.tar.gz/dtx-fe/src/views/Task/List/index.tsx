/* eslint-disable react/jsx-no-bind */
import React, {useCallback, useEffect, useState} from 'react';
import {PlusOutlined} from '@ant-design/icons';
import {useNavigate} from 'react-router-dom';
import {App, Form, Input} from 'antd';
import {ColumnType} from 'antd/es/table';
import dayjs from 'dayjs';
import {useForm} from 'antd/es/form/Form';
import Content from '@/components/Content';
import {NavKeys, useCurrentNav} from '@/slice/sider';
import Table from '@/components/Table';
import Button from '@/components/Button';
import {
  TaskItem,
  TaskStatus,
  copyTask,
  createTask,
  deleteTask,
  fetchTaskList,
  publishTask,
  startTask,
} from '@/libs/api';
import {ToolTip} from '@/components/Table/ToolTip';
import ModalBox from '@/components/Modal';
import {PermissionValue} from '@/pages/Account/PermissionCreator';
import ErrorCode from '@/libs/errorCode';
import SelectStatus from '@/components/Select';
import EvalModal from '../Eval/Modal';
import {PwD} from '../PermissonWrap';
import styles from './index.less';
import DotStatus from '@/components/DotStatus';
export const taskStatusCN = {
  [TaskStatus.Edit]: '编辑中',
  [TaskStatus.Ready]: '待启动',
  [TaskStatus.Processing]: '计算中',
  [TaskStatus.Finished]: '已完成',
  [TaskStatus.Failed]: '计算失败',
};
const ListHeader: React.FC<{onSearch: (keyword: string) => void}> = ({
  onSearch,
}) => {
  const [form] = useForm();
  const navigate = useNavigate();
  const {message} = App.useApp();
  const [createTaskModalOpen, setCreateTaskModalOpen] = useState(false);

  const onSubmit = useCallback(() => {
    form.validateFields().then(values => {
      createTask({
        ...values,
        canvasInfo: '{}',
      }).then(resp => {
        if (resp.code === '0') {
          return navigate(`/task/create?id=${resp.data.id}`);
        }
        message.error(ErrorCode[resp.code]);
      }, console.error);
    }, console.error);
  }, [form]);
  return (
    <div className={styles.header}>
      <ModalBox
        title="创建任务"
        open={createTaskModalOpen}
        onOk={onSubmit}
        onCancel={() => setCreateTaskModalOpen(false)}
      >
        <Form form={form} labelCol={{flex: '70px'}}>
          <Form.Item
            name="name"
            label="任务名称"
            rules={[
              {
                required: true,
                min: 4,
                max: 20,
                message: '请输入任务名称，4到20个字符',
              },
            ]}
          >
            <Input placeholder="请输入任务名称" />
          </Form.Item>
          <Form.Item
            name="type"
            label="任务类型"
            rules={[
              {
                required: true,
                message: '请填写任务名称',
              },
            ]}
            initialValue={'train'}
          >
            <SelectStatus
              optsList={[
                {
                  value: 'train',
                  label: '训练任务',
                },
                {
                  value: 'predict',
                  label: '预测任务',
                },
                {
                  value: 'psi',
                  label: '隐私求交任务',
                },
              ]}
            />
          </Form.Item>
          <Form.Item
            name="desc"
            label="任务简介"
            rules={[
              {
                min: 4,
                max: 50,
                required: true,
                message: '请输入4到50字以内的任务简介',
              },
            ]}
          >
            <Input.TextArea placeholder="请输入4到50字以内的任务简介" />
          </Form.Item>
        </Form>
      </ModalBox>
      <div className={styles.search_container}>
        <Input
          placeholder="请输入任务名称"
          className={styles.task_search_input}
          onChange={e => {
            const v = e.target.value;
            onSearch(v);
          }}
        />
      </div>
      <div className={styles.button_container}>
        <PwD rP={PermissionValue.Write}>
          <Button
            type="primary"
            icon={<PlusOutlined />}
            // onClick={() => navigate('/task/create')}
            onClick={() => setCreateTaskModalOpen(true)}
            className={styles.task_create_btn}
          >
            创建任务
          </Button>
        </PwD>
      </div>
    </div>
  );
};
const List: React.FC = () => {
  const [list, setList] = useState([]);
  const [total, setTotal] = useState(0);
  const [payload, setPayload] = useState<{
    pageNo?: number;
    name?: string;
  }>({
    pageNo: 1,
    name: '',
  });
  const [evalConf, setEvalConf] = useState<{
    open: boolean;
    id: number;
  }>({
    open: false,
    id: null,
  });
  const {message} = App.useApp();
  const navigate = useNavigate();
  const [confirmConf, setConfirmConf] = useState<{
    open: boolean;
    title?: string;
    msg?: string;
    id?: number;
    onOk?: (id: number) => Promise<any>;
  }>({open: false});
  useCurrentNav(NavKeys.taskList);
  const loadTaskList = useCallback(() => {
    fetchTaskList({...payload, pageSize: 10}).then(resp => {
      if (resp.code === '0') {
        setList(resp.data.list);
        setTotal(resp.data.total);
      }
    });
  }, [payload]);

  const setTaskKeyword = useCallback(
    (keyword: string) => {
      setPayload({
        pageNo: 1,
        name: keyword,
      });
    },
    [payload.pageNo]
  );

  useEffect(() => {
    loadTaskList();
  }, [payload]);

  useEffect(() => {
    const timer = setInterval(loadTaskList, 5000);
    return () => {
      clearInterval(timer);
    };
  }, [payload]);
  const cloneTask = useCallback(
    (id: number) => {
      copyTask({id}).then(resp => {
        if (resp.code === '0') {
          message.success('复制成功');
        } else {
          message.error(ErrorCode[resp.code]);
        }
      }, console.error);
    },
    [loadTaskList]
  );

  const pubTask = useCallback(
    (id: number) => {
      setConfirmConf({
        open: true,
        title: '发布任务',
        msg: '任务发布后不支持编辑，是否发布任务？',
        id,
        onOk: (taskId: number) =>
          publishTask({id: taskId}).then(resp => {
            if (resp.code === '0') {
              message.success('发布成功');
              setConfirmConf({open: false});
            } else {
              message.error(ErrorCode[resp.code]);
            }
          }, console.error),
      });
    },
    [loadTaskList, message]
  );

  const bootTask = useCallback(
    (id: number) => {
      setConfirmConf({
        open: true,
        title: '启动任务',
        msg: '任务完成前无法停止，确定启动任务吗？',
        id,
        onOk: (taskId: number) =>
          startTask({id: taskId}).then(resp => {
            if (resp.code === '0') {
              message.success('启动成功');
              setConfirmConf({open: false});
            } else {
              message.error(ErrorCode[resp.code]);
            }
          }, console.error),
      });
    },
    [loadTaskList, message]
  );

  const delTask = useCallback(
    (id: number) => {
      setConfirmConf({
        open: true,
        title: '删除任务',
        msg: '将清除该可视化建模的所有配置与编辑的内容，且不可恢复，是否继续删除？',
        id,
        onOk: (taskId: number) =>
          deleteTask({id: taskId}).then(resp => {
            if (resp.code === '0') {
              message.success('删除成功');
              setConfirmConf({open: false});
            } else {
              message.error(ErrorCode[resp.code]);
            }
          }, console.error),
      });
    },
    [loadTaskList, message]
  );

  const staticEvalTask = useCallback((id: number) => {
    setEvalConf({
      open: true,
      id,
    });
  }, []);
  const columns: Array<ColumnType<TaskItem>> = [
    {
      title: '任务名称',
      dataIndex: 'name',
      render: name => <ToolTip content={name} maxLen={20} copyable={false} />,
    },
    {
      title: '任务ID',
      dataIndex: 'taskID',
      render: taskID => <ToolTip content={taskID} maxLen={20} />,
    },
    {
      title: '任务类型',
      dataIndex: 'type',
      render: (type: string) => {
        switch (type) {
          case 'train':
            return '训练任务';
          case 'psi':
            return '隐私求交任务';
          case 'predict':
            return '预测任务';
          default:
            return '---';
        }
      },
    },
    {
      title: '任务状态',
      dataIndex: 'status',
      render: (status: TaskStatus) => {
        const str = taskStatusCN[status];
        switch (status) {
          case TaskStatus.Failed:
            return <DotStatus type="orange">{str}</DotStatus>;
          case TaskStatus.Edit:
            return <DotStatus type="blue">{str}</DotStatus>;
          default:
            return <DotStatus type="green">{str}</DotStatus>;
        }
      },
    },
    {
      title: '任务描述',
      dataIndex: 'desc',
      render: desc => <ToolTip content={desc} maxLen={20} copyable={false} />,
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      render: (create_time: number) =>
        dayjs(create_time * 1000).format('YYYY-MM-DD HH:mm:ss'),
    },
    {
      title: '最后编辑时间',
      dataIndex: 'updateTime',
      render: (update_time: number) =>
        dayjs(update_time * 1000).format('YYYY-MM-DD HH:mm:ss'),
    },
    {
      title: '操作',
      render: record => {
        const {id, status} = record;
        switch (status) {
          case TaskStatus.Edit:
            return (
              <PwD rP={PermissionValue.Write}>
                <span className={styles.operate} onClick={() => pubTask(id)}>
                  发布
                </span>
                <span
                  className={styles.operate}
                  onClick={() => {
                    navigate(`/task/create?id=${id}`);
                  }}
                >
                  编辑
                </span>
                <span className={styles.operate} onClick={() => cloneTask(id)}>
                  复制
                </span>
                <span className={styles.operate} onClick={() => delTask(id)}>
                  删除
                </span>
              </PwD>
            );
          case TaskStatus.Ready:
            return (
              <>
                <span
                  className={styles.operate}
                  onClick={() => navigate(`/task/detail/${id}`)}
                >
                  详情
                </span>
                <PwD rP={PermissionValue.Write}>
                  <span className={styles.operate} onClick={() => bootTask(id)}>
                    启动
                  </span>
                  <span
                    className={styles.operate}
                    onClick={() => cloneTask(id)}
                  >
                    复制
                  </span>
                </PwD>
              </>
            );
          case TaskStatus.Processing:
            return <></>;
          case TaskStatus.Finished:
            return (
              <div className={styles.buttonGroup}>
                {record.evaluable ? (
                  <span
                    className={styles.operate}
                    onClick={() => staticEvalTask(record.id)}
                  >
                    静态评估
                  </span>
                ) : (
                  ''
                )}
                <span
                  className={styles.operate}
                  onClick={() => navigate(`/task/detail/${id}`)}
                >
                  详情
                </span>
                <PwD rP={PermissionValue.Write}>
                  <span
                    className={styles.operate}
                    onClick={() => cloneTask(id)}
                  >
                    复制
                  </span>
                </PwD>
                {record.type === 'predict' || record.type === 'psi' ? (
                  <a
                    download={`${record.name}.csv`}
                    href={`/dtx/v1/task/result/download?id=${id}`}
                    className={styles.operate}
                  >
                    下载结果
                  </a>
                ) : (
                  ''
                )}
              </div>
            );
          case TaskStatus.Failed:
            return (
              <>
                <span
                  className={styles.operate}
                  onClick={() => navigate(`/task/detail/${id}`)}
                >
                  详情
                </span>
                <PwD rP={PermissionValue.Write}>
                  <span
                    className={styles.operate}
                    onClick={() => cloneTask(id)}
                  >
                    复制
                  </span>
                </PwD>
              </>
            );
        }
      },
    },
  ];

  return (
    <Content>
      <EvalModal
        open={evalConf.open}
        onClose={() => setEvalConf({open: false, id: null})}
        id={evalConf.id}
      />
      <ListHeader onSearch={setTaskKeyword} />
      <ModalBox
        open={confirmConf.open}
        title={confirmConf.title}
        onCancel={() => setConfirmConf({open: false})}
        onOk={() =>
          confirmConf.onOk(confirmConf.id).finally(() => loadTaskList())
        }
      >
        {confirmConf.msg}
      </ModalBox>
      <Table
        className={styles.list}
        columns={columns}
        dataSource={list}
        bordered
        rowKey={record => {
          return record.id;
        }}
        pagination={{
          total,
          pageSize: 10,
          current: payload.pageNo,
          onChange(page) {
            setPayload({
              ...payload,
              pageNo: page,
            });
          },
        }}
      />
    </Content>
  );
};

export default List;
