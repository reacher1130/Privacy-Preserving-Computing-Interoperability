import {Col, Row, Tabs, Typography} from 'antd';
import React, {ReactNode, useEffect, useState} from 'react';
import {useParams} from 'react-router-dom';
import dayjs from 'dayjs';
import Content from '@/components/Content';
import {NavKeys, useCurrentNav} from '@/slice/sider';
import ReactJson from '@microlink/react-json-view';
import {
  TaskDetailResponse,
  TaskLogResponse,
  TaskStatus,
  fetchDatasetDetail,
  fetchTaskDetail,
  fetchTaskLog,
} from '@/libs/api';
import styles from './index.less';
import {taskStatusCN} from '../List';
import TextCopy from '@/components/TextCopy';

export interface DetailInfoItemProps {
  label: ReactNode;
  content: ReactNode;
  className?: string;
}

const DetailInfoItem: React.FC<DetailInfoItemProps> = props => {
  const {label, content} = props;
  return (
    <Row className={styles.row}>
      <Col flex={'120px'}>{`${label}:`}</Col>
      <Col flex={'auto'}>{content}</Col>
    </Row>
  );
};

const DetailInfo: React.FC<
  Partial<TaskDetailResponse['data']> & {log: Partial<TaskLogResponse['data']>}
> = props => {
  if (!props) {
    return '';
  }
  const taskStatusText = taskStatusCN[props.status];
  let taskStatusComponent: ReactNode = null;
  if (props.status === TaskStatus.Failed) {
    taskStatusComponent = (
      <span className={styles.error}>{taskStatusText}</span>
    );
  } else if (props.status === TaskStatus.Finished) {
    taskStatusComponent = (
      <span className={styles.success}>{taskStatusText}</span>
    );
  } else {
    taskStatusComponent = (
      <span className={styles.warning}>{taskStatusText}</span>
    );
  }
  const copyInstallCode =() => {
    console.log('111')
    const fileUrl = '/static/unicom-dtx/public/predict.csv'; // 文件的URL地址
    const link = document.createElement('a');
    link.href = fileUrl;
    link.setAttribute('download', 'predict');
    link.click();
  }
  return (
    <>
      <DetailInfoItem label="任务名称" content={props.name} />
      <DetailInfoItem label="任务简介" content={props.desc} />
      <DetailInfoItem
        label="任务ID"
        content={<TextCopy content={props.taskID} />}
      />
      <DetailInfoItem
        label="任务类型"
        content={
          props.type === 'predict'
            ? '预测任务'
            : props.type === 'train'
              ? '训练任务'
              : '隐私求交任务'
        }
      />
      <DetailInfoItem label="任务类型" content={taskStatusComponent} />
      {
        props.status === TaskStatus.Finished ? <div>下载文件:<span className={styles.downBtn}  onClick={() => copyInstallCode()}>立即下载</span></div> : ''
      }
      {
        props.status === TaskStatus.Finished ? <div>下载文件:<span className={styles.downBtn}  onClick={() => copyInstallCode()}>立即下载2</span></div> : ''
      }
      {props.errMsg ? (
        <DetailInfoItem
          label="失败原因"
          content={<span className={styles.error}>{props.errMsg}</span>}
        />
      ) : (
        ''
      )}
      <DetailInfoItem label="任务创建方" content={props.createBy || '--'} />
      <DetailInfoItem label="用户名" content={props.creatorName || '--'} />
      <DetailInfoItem
        label="创建时间"
        content={dayjs.unix(props.createTime).format('YYYY-MM-DD HH:mm:ss')}
      />

      {props.params && props.log ? (
        <>
          <Tabs
            items={[
              {
                key: 'params',
                label: '参数信息',
                children: (
                  <ReactJson
                    src={JSON.parse(props.params)}
                    name={false}
                    theme="solarized"
                    enableClipboard={false}
                    displayObjectSize={false}
                    displayDataTypes={false}
                    style={{padding: '20px'}}
                  />
                ),
              },
              {
                key: 'log',
                label: '审计日志',
                children: (
                  <div className={styles.log}>
                    {props.log
                      .split(/\n/)
                      .filter(l => l.trim())
                      .map(l => {
                        let [date, time, ...columns]: ReactNode[] =
                          l.split(' ');
                        return [
                          <span className={styles.time} key="time">
                            {date + ' ' + time}
                          </span>,
                          columns.join(' '),
                          <br key="br" />,
                        ];
                      })}
                  </div>
                ),
              },
            ]}
          />
        </>
      ) : (
        ''
      )}
    </>
  );
};

const Detail: React.FC<any> = () => {
  const {id} = useParams();
  const [detail, setDetail] = useState<TaskDetailResponse['data']>(null);
  const [log, setLog] = useState<TaskLogResponse['data']>(null);
  useCurrentNav(NavKeys.taskList);
  useEffect(() => {
    fetchTaskDetail({
      id: +id,
    }).then(resp => {
      if (resp.code === '0') {
        setDetail(resp.data);
      }
    }, console.error);
    fetchTaskLog({
      id: +id,
    }).then(resp => {
      if (resp.code === '0') {
        setLog(resp.data);
      }
    }, console.error);
  }, []);

  const paths = [
    {url: '/task/list', name: '任务管理'},
    {url: '', name: '任务详情'},
  ];
  return (
    <Content paths={paths}>
      <DetailInfo {...detail} log={log} />
    </Content>
  );
};
export default Detail;
