import React from 'react';
import ModalBox from '@/components/Modal';
import StaticEval, {StaticEvalProps} from './Static';

export interface EvalModalProps extends StaticEvalProps {
  open: boolean;
  onClose: () => void;
}
const EvalModal: React.FC<EvalModalProps> = props => {
  const {open, onClose, ...staticEvalProps} = props;

  return (
    <ModalBox
      hideCancelBtn
      width={1048}
      title="静态评估"
      open={open}
      onCancel={() => onClose?.()}
      onOk={() => onClose?.()}
    >
      <StaticEval {...staticEvalProps} />
    </ModalBox>
  );
};

export default EvalModal;
