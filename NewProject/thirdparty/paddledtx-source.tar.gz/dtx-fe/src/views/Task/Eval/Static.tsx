/* eslint-disable import/extensions */
/* eslint-disable @typescript-eslint/func-call-spacing */
import React, {useEffect, useRef, useState} from 'react';
import * as echarts from 'echarts';
import {Spin} from 'antd';
import {
  GraphicComponentLooseOption,
  GridOption,
  TitleOption,
} from 'echarts/types/dist/shared';
import {
  DTCEvalResult,
  LinearEvalResult,
  LogicEvalResult,
  TaskEvalResponse,
  fetchTaskEvalResult,
} from '@/libs/api';

import styles from './styles.less';

/**
 * 生成回归案例指标得分图表。
 *
 * @param props - 属性对象。包含一个名为result的键，其值为线性评估结果中的回归案例指标得分。
 */
function RegressionCaseMetricScores(props: {
  result: LinearEvalResult['regressionCaseMetricScores'];
}) {
  const {result} = props;
  const ref = useRef();
  useEffect(() => {
    if (ref.current) {
      const stage = echarts.init(ref.current);
      const option: echarts.EChartsOption = {
        tooltip: {
          show: true,
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
            snap: true,
          },
        },
        xAxis: {
          type: 'category',
          data: Object.keys(result.RMSEs),
          axisPointer: {
            show: true,
          },
        },
        yAxis: {
          type: 'value',
        },
        series: [
          {
            data: Object.values(result.RMSEs),
            type: 'line',
            step: 'start',
            markLine: {
              data: [
                {
                  name: 'meanRMSE',
                  yAxis: result.meanRMSE,
                  label: {
                    show: true,
                    position: 'insideStartTop',
                    formatter: params => {
                      return `${params.name}: ${params.value}`;
                    },
                  },
                },
              ],
            },
          },
        ],
      };
      if (result.stdDevRMSE) {
        (option.series as any[])[0].markLine.data.push({
          name: 'stdDevRMSE',
          yAxis: result.stdDevRMSE,
          label: {
            show: true,
            position: 'insideStartTop',
            formatter: (params: any) => {
              return `${params.name}: ${params.value}`;
            },
          },
        });
      }
      if (Object.keys(result.RMSEs).length === 1) {
        (option.series as any[])[0].markPoint = {
          data: [
            {
              type: 'max',
              label: {
                formatter: (params: any) => {
                  return params.value.toFixed(2);
                },
              },
            },
          ],
        };
      }
      stage.setOption(option);
      return () => stage.dispose();
    }
  }, []);
  return <div ref={ref} className={styles.stage}></div>;
}

/**
 * 将二元类别指标分数转换为二进制数。
 *
 * @param props - 包含逻辑评估结果的属性对象。
 * @returns 返回一个包含二进制类别指标分数的组件。
 */
function BinaryClassCaseMetricScores(props: {
  result: LogicEvalResult['binaryClassCaseMetricScores'];
}) {
  const {result} = props;
  const ref = useRef<HTMLDivElement>();
  useEffect(() => {
    if (ref.current) {
      const {metricsPerFold} = result;
      const folds = Object.entries(metricsPerFold);
      const count = folds.length;
      const gapH = 80;
      const gapV = 40;
      const h = folds.length === 1 ? 500 : 300;
      const w = folds.length === 1 ? 1000 : 500;
      const container = document.createElement('div');
      container.style.height = `${
        gapH + Math.ceil(count / 2) * h + Math.floor(count / 2) * gapH
      }px`;
      ref.current.append(container);
      const stage = echarts.init(container);
      let options: echarts.EChartsOption = {
        tooltip: {
          show: true,
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
            snap: true,
          },
          formatter: params => {
            // @ts-ignore
            return params[0].value[2].toString();
          },
        },
        xAxis: folds.map((f, i) => {
          return {
            gridIndex: i,
            min: 0,
            max: 1,
            interval: 0.1,
          };
        }),
        yAxis: folds.map((f, i) => {
          return {
            gridIndex: i,
            min: 0,
            max: 1,
            interval: 0.1,
          };
        }),
        grid: [],
        title: [],
      };
      const series: echarts.SeriesOption | echarts.SeriesOption[] = [];
      const graphic: GraphicComponentLooseOption[] = [];
      folds.forEach(([k, v], index) => {
        (options.grid as GridOption[]).push({
          left: w * (index % 2) + gapV,
          width: w - gapV - gapV / 2,
          top: gapH + h * Math.floor(index / 2) + Math.floor(index / 2) * gapH,
          height: h - gapH,
        });
        const ROC = Object.values(v.ROC);
        series.push({
          // eslint-disable-next-line max-nested-callbacks
          data: ROC.map((p: any) => [p.p[0], p.p[1], p.p[2]]),
          type: 'line',
          step: 'start',
          xAxisIndex: parseInt(k, 10),
          yAxisIndex: parseInt(k, 10),
        });
        graphic.push({
          type: 'text',
          z: 100,
          left: w * (index % 2) + gapV,
          top:
            gapH +
            h * Math.floor(index / 2) +
            Math.floor(index / 2) * gapH +
            h -
            gapH / 2,
          style: {
            fill: '#333',
            width: w - gapV - gapV / 2,
            overflow: 'break',
            lineHeight: 18,
            text: [
              // @ts-ignore
              'accuracy:' + v.accuracy,
              // @ts-ignore
              'precision:' + v.precision,
              // @ts-ignore
              'recall:' + v.recall,
              // @ts-ignore
              'F1Score:' + v.F1Score,
              // @ts-ignore
              'AUC:' + v.AUC,
            ].join('    '),
            font: '12px sans-serif',
          },
        });
        if (folds.length > 1) {
          (options.title as TitleOption[]).push({
            textAlign: 'center',
            left: w * (index % 2) + gapV + w / 2,
            top:
              gapH +
              h * Math.floor(index / 2) +
              Math.floor(index / 2) * gapH -
              gapH / 2,
            text: `${(index + 1).toString()}折`,
          });
        }
      });
      graphic.push({
        type: 'text',
        z: 100,
        left: gapV,
        top: 0,
        style: {
          fill: '#333',
          width: 1000,
          overflow: 'break',
          lineHeight: 20,
          text: [
            'caseType:' + result.caseType,
            'avgAccuracy:' + result.avgAccuracy,
            'avgPrecision:' + result.avgPrecision,
            'avgRecall:' + result.avgRecall,
            'avgF1Score:' + result.avgF1Score,
            'avgAUC:' + result.avgAUC,
          ].join('    '),
          font: '14px bolder sans-serif',
        },
      });
      options.series = series;
      // @ts-ignore
      options.graphic = graphic;
      stage.setOption(options);
    }
  }, []);

  return <div ref={ref} className={styles.stage}></div>;
}

/**
 * 生成多分类案例指标评分图。
 *
 * @param props - 属性对象，包含结果数据。
 * @returns 返回一个带有指标评分图的 div 元素。
 */
function MultiClassCaseMetricScores(props: {
  result: DTCEvalResult['multiClassCaseMetricScores'];
}) {
  const {result} = props;
  const ref = useRef<HTMLDivElement>();
  useEffect(() => {
    if (ref.current) {
      const {metricsPerFold} = result;
      const folds = Object.entries(metricsPerFold);
      const count = folds.length;
      const gapH = 80;
      const gapV = 40;
      const h = folds.length === 1 ? 500 : 300;
      const w = folds.length === 1 ? 1000 : 500;
      const container = document.createElement('div');
      container.style.height = `${
        gapH + Math.ceil(count / 2) * h + Math.floor(count / 2) * gapH
      }px`;
      ref.current.append(container);
      const stage = echarts.init(container);
      let options: echarts.EChartsOption = {
        tooltip: {
          show: true,
          trigger: 'axis',
          axisPointer: {
            type: 'cross',
            snap: true,
          },
          formatter: params => {
            // @ts-ignore
            return params[0].value[2].toString();
          },
        },
        xAxis: folds.map((f, i) => {
          return {
            gridIndex: i,
            min: 0,
            max: 1,
            interval: 0.1,
          };
        }),
        yAxis: folds.map((f, i) => {
          return {
            gridIndex: i,
            min: 0,
            max: 1,
            interval: 0.1,
          };
        }),
        grid: [],
        title: [],
      };

      const series: echarts.SeriesOption | echarts.SeriesOption[] = [];
      const graphic: GraphicComponentLooseOption[] = [];
      folds.forEach(([k, v], index) => {
        (options.grid as GridOption[]).push({
          left: w * (index % 2) + gapV,
          width: w - gapV - gapV / 2,
          top: gapH + h * Math.floor(index / 2) + Math.floor(index / 2) * gapH,
          height: h - gapH,
        });
        const points = Object.values((v as any).reports).map(
          r => (r as any).points
        );
        points.forEach(point => {
          series.push({
            // eslint-disable-next-line max-nested-callbacks
            data: point.map((p: any) => [p.p[0], p.p[1], p.p[2]]),
            type: 'line',
            step: 'start',
            xAxisIndex: parseInt(k, 10),
            yAxisIndex: parseInt(k, 10),
          });
        });
        graphic.push({
          type: 'text',
          z: 100,
          left: w * (index % 2) + gapV,
          top:
            gapH +
            h * Math.floor(index / 2) +
            Math.floor(index / 2) * gapH +
            h -
            gapH / 2,
          style: {
            fill: '#333',
            width: w - gapV - gapV / 2,
            overflow: 'break',
            lineHeight: 18,
            text: [
              // @ts-ignore
              'overallAccuracy:' + v.overallAccuracy,
              // @ts-ignore
              'overallPrecision:' + v.overallPrecision,
              // @ts-ignore
              'overallRecall:' + v.overallRecall,
              // @ts-ignore
              'overallF1Score:' + v.overallF1Score,
              // @ts-ignore
              'overallAUC:' + v.overallAUC,
            ].join('    '),
            font: '12px sans-serif',
          },
        });
        if (folds.length > 1) {
          (options.title as TitleOption[]).push({
            textAlign: 'center',
            left: w * (index % 2) + gapV + w / 2,
            top:
              gapH +
              h * Math.floor(index / 2) +
              Math.floor(index / 2) * gapH -
              gapH / 2,
            text: `${(index + 1).toString()}折`,
          });
        }
      });
      graphic.push({
        type: 'text',
        z: 100,
        left: gapV,
        top: 0,
        style: {
          fill: '#333',
          width: 1000,
          overflow: 'break',
          lineHeight: 20,
          text: [
            'caseType:' + result.caseType,
            'avgAccuracy:' + result.avgAccuracy,
            'avgPrecision:' + result.avgPrecision,
            'avgRecall:' + result.avgRecall,
            'avgF1Score:' + result.avgF1Score,
            'avgAUC:' + result.avgAUC,
          ].join('    '),
          font: '14px bolder sans-serif',
        },
      });
      options.series = series;
      // @ts-ignore
      options.graphic = graphic;
      stage.setOption(options);
    }
  }, []);
  return <div ref={ref} className={styles.stage}></div>;
}
export interface StaticEvalProps {
  id: number;
}
const StaticEval: React.FC<StaticEvalProps> = props => {
  const {id} = props;
  const [evalResult, setEvalResult] = useState<{
    status: string;
    error: string;
    result: TaskEvalResponse['data'];
  }>({
    status: 'idle',
    error: '',
    result: null,
  });
  useEffect(() => {
    if (id) {
      setEvalResult({
        status: 'loading',
        error: '',
        result: null,
      });
      fetchTaskEvalResult({id})
        .then(resp => {
          if (resp.code === '0') {
            return setEvalResult({
              status: 'success',
              error: '',
              result: resp.data,
            });
          }
          return setEvalResult({
            status: 'error',
            error: resp.msg,
            result: null,
          });
        })
        .catch((err: Error) => {
          setEvalResult({
            status: 'fail',
            error: err.message,
            result: null,
          });
        });
    }
  }, [id]);
  const evalComponent = (result: TaskEvalResponse['data']) => {
    if ('regressionCaseMetricScores' in result) {
      return (
        <RegressionCaseMetricScores
          result={(result as LinearEvalResult).regressionCaseMetricScores}
        />
      );
    }
    console.log(result);
    if ('binaryClassCaseMetricScores' in result) {
      console.log('binaryClassCaseMetricScores');
      return (
        <BinaryClassCaseMetricScores
          result={(result as LogicEvalResult).binaryClassCaseMetricScores}
        />
      );
    }

    if ('multiClassCaseMetricScores' in result) {
      return (
        <MultiClassCaseMetricScores
          result={(result as DTCEvalResult).multiClassCaseMetricScores}
        />
      );
    }
  };
  return (
    <Spin spinning={evalResult.status === 'loading'}>
      {evalResult.status === 'success'
        ? evalComponent(evalResult.result)
        : evalResult.error}
    </Spin>
  );
};

export default StaticEval;
