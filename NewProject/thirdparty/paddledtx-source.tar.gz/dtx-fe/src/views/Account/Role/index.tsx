/* eslint-disable react/jsx-no-bind */
import React, {PropsWithChildren, useEffect, useState} from 'react';
import {App, Table, Form, Input, Space, Checkbox, message} from 'antd';
import type {CheckboxChangeEvent} from 'antd/es/checkbox';
import Content from '@/components/Content';
import Button from '@/components/Button';
import ModalBox from '@/components/Modal';
import {NavKeys, useCurrentNav} from '@/slice/sider';
import dayjs, {Dayjs} from 'dayjs';
import Empty from '@components/Empty';
import ErrorCode from '@/libs/errorCode';

import {
  RoleRights,
  RoleRightsTbItem,
  RoleListResponse,
  RoleListResponseMeta,
  getRoleList,
  CreateRoleRequest,
  createRole,
  ModifyRoleRequest,
  modifyRole,
  deleteRole,
} from '@/libs/api';

import styles from './index.less';

export enum DefaultRoleType {
  Admin = 'admin',
  Default = 'default',
}

export enum OperateType {
  Delete = 'delete',
  Create = 'create',
  Modify = 'modify',
  Read = 'read',
}

// 定义权限字符串'11' 转换为[1, 1], 代表各位权限的索引
export enum AuthIndexType {
  Modify = 0,
  Read,
}

const {Column} = Table;

interface RoleTableProps extends PropsWithChildren {
  onChange?: (e?: any) => void;
  value?: RoleRights;
  operate: string;
  alwaysChange: boolean;
}
const RoleTable: React.FC<RoleTableProps> = (props: RoleTableProps) => {
  const {onChange, value, operate, alwaysChange} = props;
  useEffect(() => {}, [alwaysChange]);

  const chekcboxChange = (
    e: CheckboxChangeEvent,
    colVal: any,
    record: RoleRightsTbItem,
    opName: OperateType
  ) => {
    const checked = e.target.checked;
    const itemName = record.enName;
    const val = value[itemName];
    const valArr = val?.split('');
    const index =
      opName === OperateType.Read ? AuthIndexType.Read : AuthIndexType.Modify;
    if (checked) {
      valArr[index] = '1';
    } else {
      valArr[index] = '0';
    }
    const valStr = valArr.join('');
    onChange({
      ...value,
      [itemName]: valStr,
    });
  };

  const isChecked = (index: AuthIndexType, record?: RoleRightsTbItem) => {
    // index: 修改modify操作对应的是0, 详情操作read对应的是1
    if (!record) {
      return;
    }
    const itemName = record.enName;
    const val = value[itemName];
    const valArr = val?.split('');
    const isChecked = valArr?.[index] ? valArr[index] === '1' : false;
    return isChecked;
  };

  return (
    <Table
      className={styles.list}
      pagination={false}
      dataSource={[
        {
          name: '数据管理',
          view: 0,
          modify: 0,
          enName: 'data',
        },
        {
          name: '模型管理',
          view: 0,
          modify: 0,
          enName: 'service',
        },
        {
          name: '任务管理',
          view: 0,
          modify: 0,
          enName: 'task',
        },
        {
          name: '算法管理',
          view: 0,
          modify: 0,
          enName: 'algorithm',
        },
        {
          name: '运维管理',
          view: 0,
          modify: 0,
          enName: 'op',
        },
        {
          name: '用户管理',
          view: 0,
          modify: 0,
          enName: 'permission',
        },
      ]}
      locale={{emptyText: <Empty msg="暂无数据" />}}
      rowKey={record => `${record.name}_${Math.random() * 100}`}
    >
      <Column title="权限管理" dataIndex="name" key="name" />
      <Column
        title="查询"
        dataIndex="view"
        key="view"
        render={(_: any, record: RoleRightsTbItem) => {
          if (
            operate === OperateType.Read &&
            isChecked(AuthIndexType.Read, record)
          ) {
            return (
              <Checkbox
                defaultChecked={isChecked(AuthIndexType.Read, record)}
                disabled={operate === OperateType.Read}
              />
            );
          }
          if (
            operate === OperateType.Read &&
            !isChecked(AuthIndexType.Read, record)
          ) {
            return <Checkbox disabled={operate === OperateType.Read} />;
          }
          return (
            <Checkbox
              checked={isChecked(AuthIndexType.Read, record)}
              onChange={e => chekcboxChange(e, _, record, OperateType.Read)}
            />
          );
        }}
      />
      <Column
        title="修改"
        dataIndex="modify"
        key="modify"
        render={(_: any, record: RoleRightsTbItem) => {
          if (
            operate === OperateType.Read &&
            isChecked(AuthIndexType.Modify, record)
          ) {
            return (
              <Checkbox
                defaultChecked={isChecked(AuthIndexType.Modify, record)}
                disabled={operate === OperateType.Read}
              />
            );
          }
          if (
            operate === OperateType.Read &&
            !isChecked(AuthIndexType.Modify, record)
          ) {
            return <Checkbox disabled={operate === OperateType.Read} />;
          }
          return (
            <Checkbox
              checked={isChecked(AuthIndexType.Modify, record)}
              onChange={e => chekcboxChange(e, _, record, OperateType.Modify)}
            />
          );
        }}
      />
    </Table>
  );
};

interface CreateRoleFormProps extends PropsWithChildren {
  close: (e?: any) => void;
  authority: RoleRights;
  rolename: string;
  operate: string;
  alwaysChange: boolean; // 用于解决点击修改取消再点修改，详情取消再点详情（无值变化，触发渲染）
  updateList: () => void;
}
const CreateRoleForm: React.FC<CreateRoleFormProps> = (
  props: CreateRoleFormProps
) => {
  const [form] = Form.useForm();
  const formItemLayout = {
    labelCol: {span: 6},
    wrapperCol: {span: 18},
  };
  const buttonItemLayout = {
    wrapperCol: {span: 16, offset: 6},
  };
  const {message: messageApi} = App.useApp();
  const {authority, rolename, operate, alwaysChange} = props;

  const toCreateRole: (params: CreateRoleRequest) => void = params => {
    createRole(params)
      .then(resp => {
        if (+resp.code === 0) {
          messageApi.success('角色创建成功');
          props.updateList();
        } else {
          const msg = ErrorCode[resp.code] || '角色创建失败';
          messageApi.error(msg);
        }
      })
      .catch(err => {
        messageApi.error('角色创建失败');
        console.error(err);
      });
  };

  const toModifyRole: (params: ModifyRoleRequest) => void = params => {
    modifyRole(params)
      .then(resp => {
        if (+resp.code === 0) {
          messageApi.success('角色修改成功');
          props.updateList();
        } else {
          const msg = ErrorCode[resp.code] || '角色修改失败';
          messageApi.error(msg);
        }
      })
      .catch(err => {
        messageApi.error('角色修改失败');
        console.error(err);
      });
  };

  let timer: null | number = null;

  const onFinish = (values: any) => {
    const {rolename, authority} = values;
    if (operate === OperateType.Create) {
      toCreateRole({rolename, authority: JSON.stringify(authority)});
    } else if (operate === OperateType.Modify) {
      toModifyRole({rolename, authority: JSON.stringify(authority)});
    }
    timer = window.setTimeout(() => {
      form.resetFields();
      props.close?.();
      window.clearTimeout(timer);
      timer = null;
    }, 0);
  };

  useEffect(() => {
    form.setFieldValue('authority', authority);
    form.setFieldValue('rolename', rolename);
    return () => {
      timer && window.clearTimeout(timer);
      timer = null;
    };
  }, [JSON.stringify(authority), operate, rolename, alwaysChange]);
  return (
    <>
      <Form
        {...formItemLayout}
        layout="horizontal"
        form={form}
        className={styles.form}
        onFinish={onFinish}
        onValuesChange={console.log}
      >
        <Form.Item
          label="角色名称"
          name="rolename"
          className={styles.formItem}
          rules={[
            {
              required: true,
              message: '请输入角色名称',
            },
            {
              pattern: /^[^_]/,
              message: '角色名称只能以字母开头',
            },
            {
              pattern: /^[^0-9]/,
              message: '角色名称只能以字母开头',
            },
            {
              pattern: /^[_a-zA-Z0-9]*$/,
              message: '输入字符不支持，请输入小写字母、数字、横线',
            },
            {
              min: 1,
              max: 16,
              message: '角色名称最少1个字符, 最大16个字符',
            },
          ]}
        >
          <Input
            disabled={operate !== 'create'}
            placeholder="角色名称1-16位,支持字母、数字和下划线"
            autoComplete="off"
          />
        </Form.Item>
        <Form.Item
          label="角色权限"
          name="authority"
          className={styles.formItem}
          rules={[
            {
              required: true,
              message: '请选择角色权限',
            },
          ]}
          initialValue={authority}
        >
          <RoleTable operate={operate} alwaysChange={alwaysChange} />
        </Form.Item>
        {operate !== OperateType.Read && (
          <Form.Item {...buttonItemLayout}>
            <Space size="middle">
              <Button htmlType="submit" type="primary">
                提交
              </Button>
              <Button
                htmlType="button"
                onClick={() => {
                  props.close?.();
                  form.resetFields();
                }}
              >
                取消
              </Button>
            </Space>
          </Form.Item>
        )}
      </Form>
    </>
  );
};

interface RoleListTableProps extends PropsWithChildren {
  setShowAddRole?: (isShow: boolean) => void;
  setShowDelteNote?: (isShow: boolean) => void;
  setAuthority?: (authority: RoleRights) => void;
  setOperate?: (operate: OperateType) => void;
  setRoleName?: (rolename: string) => void;
  list: RoleListResponse['data'];
}
const RoleListTable: React.FC<RoleListTableProps> = (
  props: RoleListTableProps
) => {
  const {
    setShowAddRole,
    setAuthority,
    setOperate,
    setRoleName,
    setShowDelteNote,
  } = props;
  const onModify: (
    record: RoleListResponseMeta,
    operate: OperateType
  ) => void = (record, operate) => {
    if (operate === OperateType.Delete) {
      setShowDelteNote && setShowDelteNote(true);
    } else {
      setShowAddRole && setShowAddRole(true);
    }
    setAuthority && setAuthority(record?.authority);
    setOperate && setOperate(operate);
    setRoleName && setRoleName(record?.rolename);
  };
  return (
    <Table
      className={styles.list}
      pagination={false}
      dataSource={props.list}
      rowKey={record => `${record.rolename || ''}_${Math.random() * 100}`}
    >
      <Column title="角色名称" dataIndex="rolename" key="rolename" />
      <Column
        title="创建时间"
        dataIndex="createTime"
        key="createTime"
        render={createTime =>
          dayjs.unix(createTime).format('YYYY-MM-DD HH:mm:ss')
        }
      />
      <Column
        title="操作"
        key="operate"
        render={(_: any, record: RoleListResponseMeta) => {
          return (
            <div className={styles.operate}>
              <span
                className={styles.opname}
                onClick={() => onModify(record, OperateType.Read)}
              >
                详情
              </span>
              {record?.rolename !== DefaultRoleType['Admin'] && (
                <span
                  className={styles.opname}
                  onClick={() => onModify(record, OperateType.Modify)}
                >
                  修改
                </span>
              )}
              {record?.rolename !== DefaultRoleType['Admin'] && (
                <span
                  className={styles.opname}
                  onClick={() => onModify(record, OperateType.Delete)}
                >
                  删除
                </span>
              )}
            </div>
          );
        }}
      />
    </Table>
  );
};

export default function AccountRole() {
  useCurrentNav(NavKeys.accountRole);

  const [showAddRole, setShowAddRole] = useState(false); // 控制展示创建角色弹窗
  const [showDeleteNote, setShowDelteNote] = useState(false);
  const closeAddRole = () => {
    setShowAddRole(false);
  };
  const rights: RoleRights = {
    permission: '00',
    data: '00',
    service: '00',
    task: '00',
    algorithm: '00',
    op: '00',
  };
  const [authority, setAuthority] = useState<RoleRights>(rights);
  const [operate, setOperate] = useState(OperateType.Create);
  const [rolename, setRoleName] = useState('');

  const onAddRole = () => {
    setShowAddRole(true);
    setAuthority(rights);
    setOperate(OperateType.Create);
    setRoleName('');
  };

  const [resp, setResp] = useState<RoleListResponse['data']>();
  const getList = () => {
    getRoleList()
      .then(resp => {
        if (+resp.code === 0) {
          const data = resp.data;
          setResp(data);
        }
      })
      .catch(err => {
        console.error(err);
      });
  };

  useEffect(() => {
    getList();
  }, []);
  const {message} = App.useApp();
  const toDeleteRole = () => {
    deleteRole({rolename})
      .then(resp => {
        if (+resp.code === 0) {
          message.success('角色删除成功');
          setShowDelteNote(false);
          getList();
        } else {
          const msg = ErrorCode[resp.code] || '角色删除失败';
          message.error(msg);
        }
      })
      .catch(err => {
        console.error(err);
      });
  };

  return (
    <Content>
      <Button
        className={styles.createRoleButton}
        onClick={onAddRole}
        type="primary"
      >
        新增角色
      </Button>
      <RoleListTable
        setShowAddRole={setShowAddRole}
        setShowDelteNote={setShowDelteNote}
        setAuthority={setAuthority}
        setOperate={setOperate}
        setRoleName={setRoleName}
        list={resp}
      />
      <ModalBox
        open={showAddRole}
        title={
          operate === OperateType.Create
            ? '新增角色'
            : operate === OperateType.Read
              ? '角色详情'
              : operate === OperateType.Modify
                ? '修改角色'
                : ''
        }
        hideCancelBtn
        hideOkBtn
        onCancel={() => {
          setShowAddRole(false);
        }}
      >
        <CreateRoleForm
          alwaysChange={showAddRole}
          close={closeAddRole}
          authority={authority}
          rolename={rolename}
          operate={operate}
          updateList={getList}
        />
      </ModalBox>
      <ModalBox
        open={showDeleteNote}
        title="删除角色"
        onCancel={() => {
          setShowDelteNote(false);
        }}
        onOk={() => {
          toDeleteRole();
        }}
      >
        确定要删除角色 <b>{rolename}</b> 吗？
      </ModalBox>
    </Content>
  );
}
