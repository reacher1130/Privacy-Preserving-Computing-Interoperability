import React, {PropsWithChildren, useEffect, useState} from 'react';
import styles from './index.less';
import {useNavigate} from 'react-router-dom';
import {NavKeys, useCurrentNav} from '@/slice/sider';
import {UserInitialStateType as AccountInitialType} from '@/slice/user';
import {message, Col, Row, Form, Input, Space} from 'antd';
import Content from '@/components/Content';
import {useSelector, useDispatch} from 'react-redux';
import Button from '@/components/Button';
import ModalBox from '@/components/Modal';
import store from '@/store';
import ErrorCode from '@/libs/errorCode';
import TextCopy from '@/components/TextCopy';

import {
  UserInfoResponse,
  userInfo,
  UserResetPwdRequest,
  UserResetPwdResponse,
  resetPwd,
} from '@/libs/api';

interface EditFormProps extends PropsWithChildren {
  close: (e?: any) => void;
}
const EditForm: React.FC<EditFormProps> = (props: EditFormProps) => {
  const [form] = Form.useForm();
  const formItemLayout = {
    labelCol: {span: 6},
    wrapperCol: {span: 14},
  };
  const buttonItemLayout = {
    wrapperCol: {span: 14, offset: 6},
  };
  const [messageApi, contextHolder] = message.useMessage();
  const [error, setError] = useState('');
  const comparePw: (changedValues: any, values: any) => void = (
    changedValues,
    values
  ) => {
    const {newpwd, renewpwd} = values;
    if (newpwd?.length && renewpwd?.length && newpwd !== renewpwd) {
      setError('两次密码输入不一致，请重新输入');
    } else {
      setError('');
    }
  };
  const [resp, setResp] = useState<UserResetPwdResponse>();
  const toResetPwd: (params: UserResetPwdRequest) => void = params => {
    resetPwd(params)
      .then(resp => {
        if (+resp.code === 0) {
          messageApi.success('密码修改成功');
        } else {
          const msg = ErrorCode[resp.code] || '密码修改失败';
          messageApi.error(msg);
        }
      })
      .catch(err => {
        messageApi.error('密码修改失败');
        console.error(err);
      });
  };
  const userInfo = useSelector<
    {UserInfo: AccountInitialType},
    AccountInitialType
  >(state => state.UserInfo).user;
  const onFinish = (values: any) => {
    if (error) {
      return false;
    }
    const {username} = userInfo;
    const {newpwd, password} = values;
    toResetPwd({newpwd, password, username});
    const timer = window.setTimeout(() => {
      form.resetFields();
      props.close?.();
    }, 3000);
  };
  return (
    <>
      {contextHolder}
      <Form
        {...formItemLayout}
        layout="horizontal"
        form={form}
        className={styles.form}
        onFinish={onFinish}
        onValuesChange={comparePw}
      >
        <Form.Item
          label="原密码"
          name="password"
          className={styles.formItem}
          rules={[
            {
              required: true,
              message: '请输入原密码',
            },
          ]}
        >
          <Input.Password
            type="password"
            placeholder="请输入原密码"
            autoComplete="off"
            maxLength={16}
          />
        </Form.Item>
        <Form.Item
          label="新密码"
          name="newpwd"
          className={styles.formItem}
          rules={[
            {
              required: true,
              message: '请输入新密码',
            },
            {
              pattern:
                /((?=.*\d)(?=.*\D)|(?=.*[a-zA-Z])(?=.*[^a-zA-Z]))(?!^.*[\u4E00-\u9FA5].*$)^\S{8,14}$/,
              message: '8~14位字符，至少包含字母/数字以及标点符号中的2种',
            },
          ]}
        >
          <Input.Password
            type="password"
            placeholder="请输入新密码"
            autoComplete="off"
            maxLength={14}
          />
        </Form.Item>
        <Form.Item
          label="确认新密码"
          name="renewpwd"
          className={styles.formItem}
          rules={[
            {
              required: true,
              message: '请输入新密码',
            },
            {
              pattern:
                /((?=.*\d)(?=.*\D)|(?=.*[a-zA-Z])(?=.*[^a-zA-Z]))(?!^.*[\u4E00-\u9FA5].*$)^\S{8,14}$/,
              message: '8~14位字符，至少包含字母/数字以及标点符号中的2种',
            },
          ]}
        >
          <Input.Password
            type="password"
            placeholder="请输入新密码"
            autoComplete="off"
            maxLength={14}
          />
        </Form.Item>
        {error && (
          <div className={styles.error}>
            <span>两次密码输入不一致，请重新输入</span>
          </div>
        )}
        <Form.Item {...buttonItemLayout}>
          <Space size="middle">
            <Button htmlType="submit" type="primary">
              提交
            </Button>
            <Button
              htmlType="button"
              onClick={() => {
                props.close?.();
                form.resetFields();
              }}
            >
              取消
            </Button>
          </Space>
        </Form.Item>
      </Form>
    </>
  );
};

export default function Mine() {
  useCurrentNav(NavKeys.accountMine);

  const [resp, setResp] = useState<UserInfoResponse['data']>();
  const getUserInfo = () => {
    userInfo()
      .then(resp => {
        if (+resp.code === 0) {
          const data = resp.data;
          setResp(data);
        }
      })
      .catch(err => {
        console.error(err);
      });
  };

  useEffect(() => {
    getUserInfo();
  }, []);

  const [showEdit, setShowEdit] = useState(false);
  const close = () => {
    setShowEdit(false);
  };
  const editPassWord = () => {
    setShowEdit(true);
  };
  const userInfoObj = store.getState().UserInfo;
  const {user} = userInfoObj;
  return (
    <Content>
      <div className={styles.accountTitle}>账户信息</div>
      <Row className={styles.detailRow}>
        <Col className={styles.col}>账户名称：</Col>
        <Col className={styles.col}>
          {resp?.username}
          <span className={styles.editPassword} onClick={editPassWord}>
            修改密码
          </span>
        </Col>
      </Row>
      <Row className={styles.detailRow}>
        <Col className={styles.col}>账户私钥：</Col>
        <Col className={styles.col}>
          <a
            className={styles.link}
            download="private.key"
            href={`data:text/plain;charset=utf-8,${user['X-User-PriKey']}`}
          >
            立即下载
          </a>
        </Col>
      </Row>
      <Row className={styles.detailRow}>
        <Col className={styles.col}>账户公钥：</Col>
        <Col className={styles.col} style={{whiteSpace: 'pre'}}>
          {
            <TextCopy
              content={JSON.stringify(user['X-User-Pubkey'], null, 8)}
            />
          }
        </Col>
      </Row>
      <Row className={styles.detailRow}>
        <Col className={styles.col}>账户权限：</Col>
        <Col className={styles.col}>{resp?.role}</Col>
      </Row>
      <div className={`${styles.accountTitle} ${styles.titleMargin}`}>
        所属机构
      </div>
      <Row className={styles.detailRow}>
        <Col className={styles.col}>机构名称：</Col>
        <Col className={styles.col}>{resp?.orgName}</Col>
      </Row>
      <Row className={styles.detailRow}>
        <Col className={styles.col}>机构DID ：</Col>
        <Col className={styles.col}>{<TextCopy content={resp?.orgDID} />}</Col>
      </Row>
      <Row className={styles.detailRow}>
        <Col className={styles.col}>机构公钥：</Col>
        <Col className={styles.col}>
          {<TextCopy content={resp?.orgPubKey} />}
        </Col>
      </Row>

      <ModalBox
        open={showEdit}
        title="修改密码"
        hideCancelBtn={true}
        hideOkBtn={true}
        onCancel={() => {
          setShowEdit(false);
        }}
      >
        <EditForm close={close} />
      </ModalBox>
    </Content>
  );
}
