import React, {useEffect, useState} from 'react';
import {message, Table, Radio} from 'antd';
import type {RadioChangeEvent} from 'antd';
import Content from '@/components/Content';
import ModalBox from '@/components/Modal';
import dayjs, {Dayjs} from 'dayjs';
import type {TablePaginationConfig} from 'antd/es/table';
import Empty from '@components/Empty';
import ErrorCode from '@/libs/errorCode';

import {
  RoleListResponse,
  getRoleList,
  AccountListResponse,
  getAccountList,
  bindRole,
} from '@/libs/api';
import {NavKeys, useCurrentNav} from '@/slice/sider';
import styles from './index.less';

const {Column} = Table;

interface RightsManager {
  username: string;
  rolename: string;
  registerTime: string;
  bindTime: string;
}
export default function Mine() {
  useCurrentNav(NavKeys.accountRights);
  const [messageApi, contextHolder] = message.useMessage();
  const [pagination, setPagination] = useState<TablePaginationConfig>({
    current: 1,
    pageSize: 20,
  });
  const [showBind, setShowBind] = useState(false);
  const [record, setRecord] = useState<RightsManager>(); // 记录当前操作的列表想
  const [resp, setResp] = useState<RoleListResponse['data']>();
  const [list, setList] = useState<AccountListResponse['data']>();

  const handleTableChange = (pagination: TablePaginationConfig) => {
    setPagination({
      ...pagination,
    });
  };

  // 获取弹窗角色列表
  const fetchRoleList = () => {
    getRoleList()
      .then(resp => {
        if (+resp.code === 0) {
          const data = resp.data;
          setResp(data);
        }
      })
      .catch(err => {
        console.error(err);
      });
  };

  useEffect(() => {
    fetchRoleList();
  }, []);

  const fetchAccountList = () => {
    getAccountList()
      .then(resp => {
        if (+resp.code === 0) {
          const data = resp.data;
          const newData = data.filter(item => {
            if (item) {
              return item;
            }
          });
          setList(newData);
        }
      })
      .catch(err => {
        console.error(err);
      });
  };

  useEffect(() => {
    fetchAccountList();
  }, []);

  const [rolename, setRolename] = useState('');

  const onEdit: (record: RightsManager) => void = record => {
    setRecord(record);
    setRolename(record?.rolename);
    setShowBind(true);
  };

  const onRoleChange = (e: RadioChangeEvent) => {
    setRolename(e.target.value);
  };

  const toBindRole = () => {
    const {username} = record;
    bindRole({username, rolename})
      .then(resp => {
        if (+resp.code === 0) {
          messageApi.success('绑定角色成功');
          fetchAccountList();
        } else {
          const msg = ErrorCode[resp.code] || '绑定角色失败';
          messageApi.error(msg);
        }
        setShowBind(false);
      })
      .catch(err => {
        console.error(err);
        messageApi.error('绑定角色失败');
        setShowBind(false);
      });
  };

  return (
    <Content>
      {contextHolder}
      <Table
        className={styles.list}
        pagination={pagination}
        dataSource={list}
        locale={{emptyText: <Empty msg="暂无数据" />}}
        onChange={handleTableChange}
        rowKey={record => `${record?.username}`}
      >
        <Column title="账户名称" dataIndex="username" key="username" />
        <Column title="角色" dataIndex="rolename" key="rolename" />
        <Column
          title="注册时间"
          dataIndex="createTime"
          key="createTime"
          render={createTime =>
            dayjs.unix(createTime).format('YYYY-MM-DD HH:mm:ss')
          }
        />
        <Column
          title="绑定时间"
          dataIndex="bindTime"
          key="bindTime"
          render={bindTime =>
            dayjs.unix(bindTime).format('YYYY-MM-DD HH:mm:ss')
          }
        />
        <Column
          title="操作"
          key="operate"
          render={(_: any, record: RightsManager) => {
            return (
              <span className={styles.editRole} onClick={() => onEdit(record)}>
                编辑角色
              </span>
            );
          }}
        />
      </Table>
      <ModalBox
        open={showBind}
        title="绑定角色"
        onCancel={() => {
          setShowBind(false);
        }}
        onOk={toBindRole}
      >
        <div>
          <Radio.Group onChange={onRoleChange} value={rolename}>
            {resp?.length > 0 &&
              resp.map(item => {
                return (
                  <Radio key={item.rolename} value={item.rolename}>
                    {item.rolename}
                  </Radio>
                );
              })}
          </Radio.Group>
        </div>
      </ModalBox>
    </Content>
  );
}
