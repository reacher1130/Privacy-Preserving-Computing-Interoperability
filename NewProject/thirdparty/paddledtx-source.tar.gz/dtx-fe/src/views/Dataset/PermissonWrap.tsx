import React, {PropsWithChildren} from 'react';
import {
  Permission,
  PermissionFobiddenType,
  PermissionType,
  PermissionValue,
} from '@/pages/Account/PermissionCreator';

interface PermissionWrapProps extends PropsWithChildren {
  rP: PermissionValue;
}
export default function Pw(props: PermissionWrapProps) {
  return (
    <Permission roleType={PermissionType.Dataset} rolePermisson={props.rP}>
      {props.children}
    </Permission>
  );
}

export function PwD(props: PermissionWrapProps) {
  return (
    <Permission
      roleType={PermissionType.Dataset}
      rolePermisson={props.rP}
      forbiddenStyle={{
        type: PermissionFobiddenType.disabled,
      }}
    >
      {props.children}
    </Permission>
  );
}
