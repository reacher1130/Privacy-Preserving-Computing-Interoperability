/* eslint-disable react/jsx-no-bind */
import {App, Col, Form, Input, Row, Select} from 'antd';
import React, {ReactNode, useCallback, useEffect, useState} from 'react';
import {useParams} from 'react-router-dom';
import dayjs from 'dayjs';
import Content from '@/components/Content';
import {NavKeys, useCurrentNav} from '@/slice/sider';
import {
  Dataset,
  DatasetStatus,
  Meta,
  fetchDatasetDetail,
  updateDatasetMeta,
} from '@/libs/api';
import styles from './index.less';
import Table from '@/components/Table';
import Button from '@/components/Button';
import {useForm} from 'antd/es/form/Form';
import ErrorCode from '@/libs/errorCode';
import TextCopy from '@/components/TextCopy';
import Pw, {PwD} from '../PermissonWrap';
import {PermissionValue} from '@/pages/Account/PermissionCreator';

export interface DetailProps {}

const dataInfoToCN: Record<string, string> = {
  mean: '均值',
  mode: '众数',
  median: '中位数',
  max: '最大值',
  min: '最小值',
};

export interface DetailInfoItemProps {
  label: ReactNode;
  content: ReactNode;
  download?: string;
  className?: string;
}

const DetailInfoItem: React.FC<DetailInfoItemProps> = props => {
  const {label, content} = props;
  return (
    <Row className={styles.row} wrap={false}>
      <Col flex={'120px'}>{`${label}:`}</Col>
      <Col flex={'auto'}>{content}</Col>
    </Row>
  );
};

const DetailInfo: React.FC<Partial<Dataset>> = props => {
  if (!props) {
    return '';
  }
  console.log(props);
  return (
    <>
      <Row className={styles.row}>
        <Col flex={'120px'}>文件名称：</Col>
        <Col flex={'300px'}>{`${props.resourceName}`}</Col>
      </Row>
      <Row className={styles.row}>
        <Col flex={'120px'}>数据资源文件：</Col>
        <Col flex={'300px'}>{`${props.resourceName}.csv`}</Col>
        <Col flex={'auto'}>
          <a
            href={`/dtx/v1/data/download?id=${props.id}&type=data`}
            download={`${props.resourceName}.csv`}
          >
            下载
          </a>
        </Col>
      </Row>
      <Row className={styles.row}>
        <Col flex={'120px'}>解析文件：</Col>
        <Col flex={'300px'}>{`${props.resourceName}.meta`}</Col>
        <Col flex={'auto'}>
          <a
            href={`/dtx/v1/data/download?id=${props.id}&type=meta`}
            download={`${props.resourceName}.meta`}
          >
            下载
          </a>
        </Col>
      </Row>
      <DetailInfoItem
        label="过期时间"
        content={dayjs.unix(props.expireTime).format('YYYY-MM-DD HH:mm:ss')}
      />
      <DetailInfoItem label="所属资源空间" content={props.namespace} />
      <DetailInfoItem label="文件信息描述" content={props.description} />
      <DetailInfoItem
        label="存储方式"
        content={props.storageType ? '本地存储' : 'XDB去中心化存储'}
      />
      <DetailInfoItem
        label="存证hash"
        content={props.tx_id ? <TextCopy content={props.tx_id} /> : '--'}
      />
    </>
  );
};
const DetailFeature: React.FC<{
  metaInfo: Meta[];
  status: DatasetStatus;
  onMetaInfoUpdate: (metaInfo: any) => void;
}> = props => {
  const [currentUpdate, setCurrentUpdate] = useState(false);
  const [form] = useForm();

  const onSubmit = useCallback(() => {
    form.validateFields().then(values => {
      props.onMetaInfoUpdate?.(values.metaInfo);
      setCurrentUpdate(false);
    }, console.error);
  }, [form]);
  return (
    <div>
      <h4>
        特征详情
        <PwD rP={PermissionValue.Write}>
          {+props.status === DatasetStatus.Saved ? (
            currentUpdate ? (
              <Button
                type="primary"
                onClick={onSubmit}
                className={styles.updateMetaButton}
              >
                完成
              </Button>
            ) : (
              <Button
                type="primary"
                onClick={() => setCurrentUpdate(true)}
                className={styles.updateMetaButton}
              >
                更新
              </Button>
            )
          ) : (
            <></>
          )}
        </PwD>
      </h4>
      <Form form={form}>
        <Table
          className={styles.list}
          dataSource={props.metaInfo}
          columns={[
            {
              title: '特征列名称',
              dataIndex: 'name',
              width: 100,
              render: (name, record, index) => {
                return currentUpdate ? (
                  <Form.Item
                    name={['metaInfo', index, 'name']}
                    initialValue={name}
                  >
                    <Input disabled className={styles.fakeFeild} />
                  </Form.Item>
                ) : (
                  name
                );
              },
            },
            {
              title: '特征数据类型',
              dataIndex: 'type',
              width: 140,
              render: (type, record, index) => {
                return currentUpdate ? (
                  <Form.Item
                    name={['metaInfo', index, 'type']}
                    initialValue={type}
                  >
                    <Select
                      className={styles.typeSelect}
                      options={[
                        {
                          value: 'int',
                          label: 'int',
                        },
                        {
                          value: 'float',
                          label: 'float',
                        },
                        {
                          value: 'string',
                          label: 'string',
                        },
                      ]}
                    />
                  </Form.Item>
                ) : (
                  type
                );
              },
            },
            {
              title: '特征列描述',
              dataIndex: 'description',
              width: 300,
              render: (description, record, index) => {
                return currentUpdate ? (
                  <Form.Item
                    name={['metaInfo', index, 'description']}
                    initialValue={description}
                    rules={[
                      {
                        required: true,
                        message: '请填写特征描述',
                      },
                    ]}
                  >
                    <Input.TextArea />
                  </Form.Item>
                ) : (
                  description
                );
              },
            },
            {
              title: '特征统计分析',
              dataIndex: 'dataInfo',
              render: (dataInfo: any, record: any) => {
                const type = record.type;
                if (type === 'string') {
                  return (
                    <div className={styles.dataInfo}>
                      <Row>
                        <Col>
                          {dataInfoToCN.mode}:{' '}
                          {dataInfo.mode === '' ? 'Null' : dataInfo.mode}
                        </Col>
                      </Row>
                    </div>
                  );
                }
                return (
                  <div className={styles.dataInfo}>
                    {Object.keys(dataInfo).map(k => {
                      return (
                        <Row key={k}>
                          <Col>
                            {dataInfoToCN[k]}:{' '}
                            {dataInfo[k] === '' ? 'Null' : dataInfo[k]}
                          </Col>
                        </Row>
                      );
                    })}
                  </div>
                );
              },
            },
          ]}
          rowKey="name"
        />
      </Form>
    </div>
  );
};
const Detail: React.FC<DetailProps> = () => {
  const {resourceID} = useParams();
  const {message} = App.useApp();
  const [detail, setDetail] = useState<Dataset>(null);
  useCurrentNav(NavKeys.datasetMine);
  const getDetail = useCallback(() => {
    fetchDatasetDetail({
      resourceID,
    }).then(resp => {
      if (resp.code === '0') {
        setDetail(resp.data);
      }
    }, console.error);
  }, []);
  useEffect(() => {
    getDetail();
  }, []);

  const onMetaInfoUpdate = useCallback((metaInfo: any) => {
    updateDatasetMeta({
      resourceID,
      metaInfo,
    }).then(resp => {
      if (resp.code === '0') {
        message.success('修改成功');
        getDetail();
      } else {
        message.error(ErrorCode[resp.code]);
      }
    });
  }, []);

  const paths = [
    {url: '/dataset/mine', name: '我的数据资源'},
    {url: '', name: '数据资源详情'},
  ];

  const {metaInfo, status, ...info} = detail ?? {};
  return (
    <Content paths={paths}>
      <DetailInfo {...info} />
      <DetailFeature
        status={status}
        metaInfo={metaInfo}
        onMetaInfoUpdate={onMetaInfoUpdate}
      />
    </Content>
  );
};
export default Detail;
