/* eslint-disable react/jsx-no-bind */
import React, {useCallback, useEffect, useState} from 'react';
import {App, Form, Input, Spin, Tabs} from 'antd';
import {useForm} from 'antd/es/form/Form';
import dayjs from 'dayjs';
import {useNavigate} from 'react-router-dom';
import {ColumnsType} from 'antd/es/table';
import Content from '@/components/Content';
import Table from '@/components/Table';
import {NavKeys, useCurrentNav} from '@/slice/sider';
import {
  AuthStatus,
  DatasetAuthItem,
  DatasetAuthListRequest,
  datasetAuthOperate,
  datasetAuthList,
} from '@/libs/api';
import {tdRender} from '@/components/Table/ToolTip';
import ModalBox from '@/components/Modal';
import DatePick from '@/components/SingleDatePicker';
import Button from '@/components/Button';
import ErrorCode from '@/libs/errorCode';
import DotStatus, {DotStatusProps} from '@/components/DotStatus';
import styles from './index.less';
import {PwD} from '../PermissonWrap';
import {PermissionValue} from '@/pages/Account/PermissionCreator';

export interface AuthorizationProps {}
type AuthorizationType = React.FC<AuthorizationProps>;

const AuthTypeCN = {
  [AuthStatus.Approved]: '已授权',
  [AuthStatus.Unapproved]: '申请中',
  [AuthStatus.Rejected]: '已驳回',
};

const ApplyForm: React.FC<{
  authID: string;
  onSuccess: () => void;
}> = props => {
  const {authID} = props;
  const [form] = useForm();
  const {message} = App.useApp();
  const [loading, setLoading] = useState(false);
  const onSubmit = () => {
    form.validateFields().then(result => {
      setLoading(true);
      const {expireTime} = result;
      datasetAuthOperate({
        expireTime: dayjs(expireTime).unix(),
        status: 'pass',
        authID,
      })
        .then(resp => {
          if (resp.code === '0') {
            message.success('授权成功');
            props.onSuccess?.();
          } else {
            message.error(ErrorCode[resp.code]);
          }
        })
        .finally(() => {
          setLoading(false);
        });
    }, console.error);
  };
  return (
    <Form form={form}>
      <Form.Item
        name="expireTime"
        label="授权过期时间："
        rules={[
          {
            required: true,
            message: '请填写过期时间',
          },
        ]}
      >
        <DatePick
          placeholder="请选择过期时间"
          disabledDate={DatePick.disabledFromNow}
        />
      </Form.Item>
      <Form.Item style={{textAlign: 'right'}}>
        <Button type="primary" disabled={loading} onClick={onSubmit}>
          {loading ? <Spin /> : '确定'}
        </Button>
      </Form.Item>
    </Form>
  );
};

const RejectForm: React.FC<{
  authID: string;
  onSuccess: () => void;
}> = props => {
  const {authID} = props;
  const [form] = useForm();
  const {message} = App.useApp();
  const [loading, setLoading] = useState(false);
  const onSubmit = () => {
    form.validateFields().then(result => {
      setLoading(true);
      const {reason} = result;
      datasetAuthOperate({
        reason,
        status: 'reject',
        authID,
      })
        .then(resp => {
          if (resp.code === '0') {
            message.success('已驳回');
            props.onSuccess?.();
          } else {
            message.error(ErrorCode[resp.code]);
          }
        })
        .finally(() => {
          setLoading(false);
        });
    }, console.error);
  };
  return (
    <Form layout="vertical" form={form}>
      <Form.Item
        name="reason"
        label="驳回原因:"
        rules={[
          {
            required: true,
            max: 200,
            min: 4,
            message: '请填写驳回原因，4到200字之间',
          },
        ]}
      >
        <Input.TextArea placeholder="请填写驳回原因" />
      </Form.Item>
      <Form.Item style={{textAlign: 'right'}}>
        <Button type="primary" disabled={loading} onClick={onSubmit}>
          {loading ? <Spin /> : '确定'}
        </Button>
      </Form.Item>
    </Form>
  );
};

const AuthorizationTable = (props: {
  authType: DatasetAuthListRequest['type'];
}) => {
  useCurrentNav(NavKeys.datasetAuthorization);
  const navigate = useNavigate();
  const [pageNo, setPageNo] = useState(1);
  const [total, setTotal] = useState(0);
  const [list, setList] = useState([]);
  const getAuthList = useCallback(() => {
    datasetAuthList({
      pageNo,
      pageSize: 10,
      type: props.authType,
    }).then(resp => {
      if (resp.code === '0') {
        setList(resp.data.list);
        setTotal(resp.data.total);
      }
    }, console.error);
  }, [pageNo, props.authType]);

  const [applyModalOpen, setApplyModalOpen] = useState(false);
  const [rejectModalOpen, setRejectModalOpen] = useState(false);
  const [operateAuthID, setOperateAuthID] = useState('');

  const columns: ColumnsType<DatasetAuthItem> = [
    {
      title: '授权ID',
      dataIndex: 'authID',
      render: tdRender({maxWidth: 180}),
    },
    {
      title: '授权对象ID',
      dataIndex: 'resourceID',
      render: tdRender({maxLen: 20}),
    },
    {
      title: '授权对象名称',
      dataIndex: 'resourceName',
      render: tdRender({maxLen: 20}),
    },
    {
      title: '授权类型',
      dataIndex: 'authType',
      render: (authType: string) => {
        return authType === 'Use' ? '使用' : '查看';
      },
    },
    {
      title: '申请时间',
      dataIndex: 'createTime',
      render: (createTime: number) => {
        return dayjs.unix(createTime).format('YYYY-MM-DD HH:mm:ss');
      },
    },
    {
      title: '授权到期时间',
      dataIndex: 'expireTime',
      render: (expireTime: number) => {
        if (expireTime) {
          return dayjs.unix(expireTime).format('YYYY-MM-DD HH:mm:ss');
        }
        return '--';
      },
    },
    {
      title: '授权状态',
      dataIndex: 'status',
      render: (status: AuthStatus) => {
        let className: DotStatusProps['type'] = null;
        switch (status) {
          case AuthStatus.Approved:
            className = 'green';
            break;
          case AuthStatus.Unapproved:
            className = 'blue';
            break;
          case AuthStatus.Rejected:
            className = 'orange';
        }
        return <DotStatus type={className}>{AuthTypeCN[status]}</DotStatus>;
      },
    },
    {
      title: '操作',
      dataIndex: 'authID',
      render: (id: string, record) => {
        const status = record.status;
        const DetailAction = (
          <span
            className={styles.operate}
            onClick={() => navigate(`detail/${id}`)}
          >
            查看详情
          </span>
        );
        if (props.authType === 'auth') {
          switch (status) {
            case AuthStatus.Approved:
            case AuthStatus.Rejected:
              return DetailAction;
            case AuthStatus.Unapproved:
              return (
                <>
                  {DetailAction}
                  <PwD rP={PermissionValue.Write}>
                    <span
                      className={styles.operate}
                      onClick={() => {
                        setOperateAuthID(id);
                        setApplyModalOpen(true);
                      }}
                    >
                      授权
                    </span>
                    <span
                      className={styles.operate}
                      onClick={() => {
                        setOperateAuthID(id);
                        setRejectModalOpen(true);
                      }}
                    >
                      驳回
                    </span>
                  </PwD>
                </>
              );
          }
        }
        return DetailAction;
      },
    },
  ];

  useEffect(() => {
    getAuthList();
  }, [pageNo]);

  return (
    <>
      <ModalBox
        open={applyModalOpen}
        onCancel={() => {
          setOperateAuthID('');
          setApplyModalOpen(false);
        }}
        hideCancelBtn
        hideOkBtn
        title="过期时间"
      >
        <ApplyForm
          authID={operateAuthID}
          onSuccess={() => {
            setOperateAuthID('');
            setApplyModalOpen(false);
            getAuthList();
          }}
        />
      </ModalBox>
      <ModalBox
        open={rejectModalOpen}
        onCancel={() => {
          setOperateAuthID('');
          setRejectModalOpen(false);
        }}
        hideCancelBtn
        hideOkBtn
      >
        <RejectForm
          authID={operateAuthID}
          onSuccess={() => {
            setOperateAuthID('');
            setRejectModalOpen(false);
            getAuthList();
          }}
        />
      </ModalBox>
      <Table
        columns={columns}
        dataSource={list}
        pagination={{
          total,
          pageSize: 10,
          onChange: setPageNo,
        }}
        bordered
        rowKey="authID"
      />
    </>
  );
};
const Authorization: AuthorizationType = () => {
  const [authListType, setAuthListType] =
    useState<DatasetAuthListRequest['type']>('apply');
  const onChange = useCallback((activeKey: DatasetAuthListRequest['type']) => {
    setAuthListType(activeKey);
  }, []);
  return (
    <Content>
      <Tabs
        defaultActiveKey="apply"
        items={[
          {
            key: 'apply',
            label: '我的申请',
            children: <AuthorizationTable authType={authListType} />,
          },
          {
            key: 'auth',
            label: '我的授权',
            children: <AuthorizationTable authType={authListType} />,
          },
        ]}
        onChange={onChange}
      />
    </Content>
  );
};

export default Authorization;
