/* eslint-disable react/jsx-no-bind */
import React, {useCallback, useState} from 'react';
import {Button, Row, Col, Form, Checkbox, App} from 'antd';
import dayjs from 'dayjs';
import {useForm} from 'antd/es/form/Form';
import {CheckboxChangeEvent} from 'antd/es/checkbox';
import Table from '@/components/Table';
import {DatasetCatalogFileDetailResponse, datasetUseAuth} from '@/libs/api';
import ErrorCode from '@/libs/errorCode';
import ModalBox from '@/components/Modal';
import DotStatus from '@/components/DotStatus';
import {PermissionValue} from '@/pages/Account/PermissionCreator';
import {PwD} from '../PermissonWrap';
import styles from './style.less';

const dataInfoToCN: Record<string, string> = {
  mean: '均值',
  mode: '众数',
  median: '中位数',
  max: '最大值',
  min: '最小值',
};
function formatFileSize(bytes: number, decimalPoint = 2) {
  if (bytes === 0) {
    return '0 Bytes';
  }
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return (
    parseFloat((bytes / Math.pow(k, i)).toFixed(decimalPoint)) + ' ' + sizes[i]
  );
}
const ApplyFeatures: React.FC<{
  resourceID: string;
  onSuccess: () => void;
  metaInfoKeys: string[];
  featuresKeys: string[];
}> = props => {
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [form] = useForm();
  const {message} = App.useApp();
  const [applyFields, setApplyFields] = useState([]);
  const onValuesChange = () => {
    form.validateFields().then(values => {
      let {keys} = values;
      keys = keys.filter((k: string) => !props.featuresKeys.includes(k));
      setApplyFields(keys);
    }, console.error);
  };
  const onConfirm = useCallback(() => {
    datasetUseAuth({
      resourceID: props.resourceID,
      keys: applyFields,
    }).then(resp => {
      if (resp.code === '0' /* || resp.code === 'DuplicateErr'*/) {
        message.success('申请成功');
        props.onSuccess?.();
      } else {
        message.error(ErrorCode[resp.code]);
      }
    });
  }, [applyFields, props.resourceID]);

  const indeterminate =
    form.getFieldValue('keys')?.length > 0 &&
    form.getFieldValue('keys')?.length < props.metaInfoKeys.length;
  const checkAll =
    props.metaInfoKeys.length === form.getFieldValue('keys')?.length;
  const onCheckAllChange = (e: CheckboxChangeEvent) => {
    const checked = e.target.checked ? props.metaInfoKeys : [];
    form.setFieldValue('keys', checked);
    onValuesChange();
  };
  return (
    <Form layout="vertical" form={form} onValuesChange={onValuesChange}>
      <ModalBox
        open={confirmOpen}
        onCancel={() => setConfirmOpen(false)}
        onOk={onConfirm}
      >
        请确认申请本数据集以下特征列的使用权限，申请提交后可进入[授权管理]页面，在授权申请列表进行查看。
        {applyFields.map(a => {
          return <p key={a}>{a}</p>;
        })}
      </ModalBox>
      <Form.Item
        name="keys"
        label="选择需要申请的字段:"
        initialValue={props.featuresKeys ?? []}
      >
        <Checkbox.Group>
          {props.metaInfoKeys.map(m => {
            const hasExecute = props.featuresKeys.includes(m);
            return (
              <Checkbox value={m} disabled={hasExecute} key={m}>
                {m}
              </Checkbox>
            );
          })}
        </Checkbox.Group>
      </Form.Item>
      <Checkbox
        indeterminate={indeterminate}
        checked={checkAll}
        onChange={onCheckAllChange}
      >
        全选
      </Checkbox>
      <Form.Item style={{textAlign: 'right'}}>
        <Button
          type="primary"
          disabled={!applyFields.length}
          onClick={() => {
            setConfirmOpen(true);
          }}
        >
          确认
        </Button>
      </Form.Item>
    </Form>
  );
};
export type DatasetNamespaceFileDetailProps =
  DatasetCatalogFileDetailResponse['data'] & {
    getLook: () => void;
  };
const Detail: React.FC<DatasetNamespaceFileDetailProps> = props => {
  let {
    fileID,
    name,
    orgName,
    fromOwn,
    features,
    publishTime,
    expireTime,
    metaInfo,
    totalNumber,
    description,
    size,
  } = props;
  const [applyUseModalOpen, setApplyModalOpen] = useState(false);
  const onSuccess = useCallback(() => {
    setApplyModalOpen(false);
  }, []);

  let useDisabled = false;
  let browseDisabled = false;
  if (fromOwn) {
    useDisabled = true;
    browseDisabled = true;
  } else {
    if (metaInfo.length === 0) {
      useDisabled = true;
      browseDisabled = false;
    } else if (features.length === metaInfo.length) {
      useDisabled = true;
      browseDisabled = true;
    } else {
      useDisabled = false;
      browseDisabled = true;
    }
  }
  return (
    <div className={styles.catalogCol}>
      <ModalBox
        open={applyUseModalOpen}
        onCancel={() => setApplyModalOpen(false)}
        hideCancelBtn
        hideOkBtn
      >
        <ApplyFeatures
          resourceID={fileID}
          onSuccess={onSuccess}
          metaInfoKeys={metaInfo.map(m => m.name)}
          featuresKeys={features}
        />
      </ModalBox>
      <div className={styles.title}>
        <strong>{name}</strong>
      </div>
      <div className={styles.info}>
        {/* {
                    fromOwn || features.length === metaInfo.map(m => m.name).length && features.length !== 0 ? ('') : (
                        <div className={styles.operateBox}>
                            <PwD rP={PermissionValue.Write}>
                                {
                                    metaInfo.length ? (
                                        <Button
                                            className={styles.btn}
                                            type="primary"
                                            onClick={() => {
                                                setApplyModalOpen(true);
                                            }}
                                        >
                                            申请使用
                                        </Button>
                                    ) : (
                                        <Button
                                            className={styles.btn}
                                            onClick={props.getLook}
                                            type="primary"
                                        >
                                            申请查看
                                        </Button>
                                    )
                                }
                            </PwD>
                        </div>
                    )
                } */}
        <div className={styles.operateBox}>
          <PwD rP={PermissionValue.Write}>
            <Button
              className={styles.btn}
              type="primary"
              onClick={() => {
                setApplyModalOpen(true);
              }}
              disabled={useDisabled}
            >
              申请使用
            </Button>
            <Button
              className={styles.btn}
              onClick={props.getLook}
              type="primary"
              disabled={browseDisabled}
            >
              申请查看
            </Button>
          </PwD>
        </div>

        <Row className={styles.detailRow}>
          <Col className={styles.col}>数据持有方：</Col>
          <Col className={styles.col}>{orgName}</Col>
        </Row>
        <Row className={styles.detailRow}>
          <Col className={styles.col}>数据集ID：</Col>
          <Col className={styles.col}>{fileID}</Col>
        </Row>
        <Row className={styles.detailRow}>
          <Col className={styles.col}>样本数：</Col>
          <Col className={styles.col}>{totalNumber}</Col>
        </Row>
        <Row className={styles.detailRow}>
          <Col className={styles.col}>文件大小：</Col>
          <Col className={styles.col}>{formatFileSize(size)}</Col>
        </Row>
        <Row className={styles.detailRow}>
          <Col className={styles.col}>资源描述：</Col>
          <Col className={styles.col}>{description}</Col>
        </Row>
        <Row className={styles.detailRow}>
          <Col className={styles.col}>发布时间：</Col>
          <Col className={styles.col}>
            {dayjs.unix(publishTime).format('YYYY-MM-DD HH:mm:ss')}
          </Col>
        </Row>
        <Row className={styles.detailRow}>
          <Col className={styles.col}>过期时间：</Col>
          <Col className={styles.col}>
            {dayjs.unix(expireTime).format('YYYY-MM-DD HH:mm:ss')}
          </Col>
        </Row>
      </div>
      <Table
        className={styles.list}
        pagination={false}
        rowKey={'name'}
        emptyText="没有查看权限，请先申请权限"
        columns={[
          {
            title: '特征名称',
            dataIndex: 'name',
          },
          {
            title: '使用状态',
            dataIndex: 'name',
            key: 'apply_status',
            render: (name: string) => {
              const hasExecute = features.includes(name);
              return hasExecute && !fromOwn ? (
                <DotStatus type="green">已申请</DotStatus>
              ) : fromOwn ? (
                <DotStatus type="green">可用</DotStatus>
              ) : (
                <DotStatus type="gray">未申请</DotStatus>
              );
            },
          },
          {
            title: '特征数据类型',
            dataIndex: 'type',
          },
          {
            title: '特征列描述',
            dataIndex: 'description',
          },
          {
            title: '特征统计分析',
            dataIndex: 'dataInfo',
            render: (dataInfo: any, record: any) => {
              const type = record.type;
              if (type === 'string') {
                return (
                  <div className={styles.dataInfo}>
                    <Row>
                      <Col flex="48px">{dataInfoToCN.mode}:</Col>
                      <Col>{dataInfo.mode === '' ? 'Null' : dataInfo.mode}</Col>
                    </Row>
                  </div>
                );
              }
              return (
                <div className={styles.dataInfo}>
                  {Object.keys(dataInfo).map(k => {
                    return (
                      <Row key={k}>
                        <Col flex="48px">{dataInfoToCN[k]}:</Col>
                        <Col>{dataInfo[k] === '' ? 'Null' : dataInfo[k]}</Col>
                      </Row>
                    );
                  })}
                </div>
              );
            },
          },
        ]}
        dataSource={metaInfo}
      />
    </div>
  );
};

export default Detail;
