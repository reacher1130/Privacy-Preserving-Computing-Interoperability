/* eslint-disable react/jsx-no-bind */
import React, {
  ReactNode,
  useCallback,
  useEffect,
  useRef,
  useState,
} from 'react';
import {App, Select, Tree} from 'antd';
import {DataNode} from 'antd/es/tree';
import Content from '@/components/Content';
import {NavKeys, useCurrentNav} from '@/slice/sider';
import {
  DatasetCatalogFileDetailResponse,
  DatasetNamespaceCatalogFile,
  DatasetNamespaceCatalogResponse,
  datasetLookAuth,
  datasetNamespaceCatalog,
  datasetNamespaceOrgStat,
  fetchDatasetCatalogFileDetail,
} from '@/libs/api';
// eslint-disable-next-line import/extensions
import styles from './style.less';
import Detail from './Detail';
import {useNavigate, useSearchParams} from 'react-router-dom';
import ErrorCode from '@/libs/errorCode';
import {DownOutlined, LinkOutlined} from '@ant-design/icons';
interface CatalogProps {}

interface TreeNode {
  title: string | ReactNode;
  key: string;
  icon?: ReactNode;
  parentId: string | undefined;
  children?: any[];
  isLeaf?: boolean;
  selectable?: boolean;
}

const Catalog: React.FC<CatalogProps> = () => {
  useCurrentNav(NavKeys.datasetSpace);
  let [searchParams, setSearchParams] = useSearchParams();
  const queryId = searchParams.get('resourceID');
  const [orgID, setOrgID] = useState(searchParams.get('orgID') || '');
  const [orgData, setOrgData] = useState(null);
  const first = useRef(!!queryId);
  const defaultKey = useRef('');
  const [resourceID, setResourceID] = useState(queryId);
  useEffect(() => {
    setResourceID(queryId);
  }, [queryId]);
  function transObjToArr(
    catalogData: DatasetNamespaceCatalogResponse['data']
  ): TreeNode[] {
    const keys = Object.keys(catalogData);
    let list: TreeNode[] = [];
    keys.forEach((key, index) => {
      list.push({
        title: key ? key : '/',
        parentId: undefined,
        selectable: false,
        key: `${index}`,
      });
      const item: DatasetNamespaceCatalogFile[] = catalogData[key];
      if (item.length) {
        item.forEach(node => {
          if (!first.current) {
            console.log(first.current, node);
            first.current = true;
            setResourceID(node.fileID);
          }

          list.push({
            title: node.fileName,
            parentId: `${index}`,
            isLeaf: true,
            icon: <LinkOutlined />,
            key: `${index}_${node.fileID}`,
          });
        });
      }
    });
    return list;
  }
  function convert(data: TreeNode[]): DataNode[] {
    const tree: DataNode[] = [];
    let map: {[key: string]: any} = {};
    data.forEach(item => {
      item.children = [];
      map[item.key] = item;
    });
    data.forEach(item => {
      if (item.parentId) {
        console.log(resourceID, item.key, defaultKey.current);
        if (resourceID && item.key.includes(resourceID)) {
          defaultKey.current = item.key;
        } else if (!defaultKey.current) {
          defaultKey.current = item.key;
        }
        map[item.parentId].children.push(item);
      } else {
        tree.push(item);
      }
    });
    return tree;
  }

  const {message} = App.useApp();
  const [treeData, setTreeData] = useState<DataNode[]>();
  const fetchDatasetNamespaceCatalog = useCallback((orgName?: string) => {
    datasetNamespaceCatalog({orgName}).then(resp => {
      if (resp.code === '0') {
        const list = transObjToArr(resp.data);
        const tree: DataNode[] = convert(list);
        setTreeData(tree);
      }
    }, console.error);
  }, []);
  useEffect(() => {
    datasetNamespaceOrgStat().then(resp => {
      if (resp.code) {
        const orgData = resp.data.list.map(v => {
          return {
            value: v.orgID,
            label: v.orgName,
          };
        });
        orgData.unshift({
          value: '',
          label: '全部',
        });
        if (orgID) {
          fetchDatasetNamespaceCatalog(
            orgData.find(o => o.value === orgID).label
          );
        } else {
          fetchDatasetNamespaceCatalog();
        }
        setOrgData(orgData);
      } else {
        message.error(ErrorCode[resp.code]);
      }
    });
  }, [orgID]);

  const [detail, setDetail] =
    useState<DatasetCatalogFileDetailResponse['data']>(null);

  const datasetCatalogFileDetail = useCallback(() => {
    fetchDatasetCatalogFileDetail({resourceID})
      .then(resp => {
        if (+resp.code === 0) {
          setDetail(resp.data);
        } else {
          message.error(ErrorCode[resp.code]);
        }
      })
      .catch(console.error);
  }, [resourceID]);
  useEffect(() => {
    if (resourceID) {
      datasetCatalogFileDetail();
    }
  }, [resourceID]);

  const authLook = useCallback(() => {
    datasetLookAuth({resourceID}).then(resp => {
      if (resp.code === '0') {
        message.success('申请成功，请等待持有方审核');
      } else {
        message.error(ErrorCode[resp.code]);
      }
    });
  }, [resourceID]);

  return (
    <Content
      paths={[
        {
          url: '/dataset/space',
          name: '数据资源空间',
        },
        {
          url: '',
          name: '数据资源目录',
        },
      ]}
    >
      <div className={styles.catalogFlexbox}>
        <div className={styles.catalogCol}>
          {orgData ? (
            <Select
              className={styles.orgSelect}
              options={orgData}
              defaultValue={orgID || ''}
              style={{display: 'block', marginRight: '10px'}}
              onChange={value => {
                if (value) {
                  setSearchParams({orgID: value});
                } else {
                  setSearchParams({});
                }
                first.current = false;
                defaultKey.current = '';
                setResourceID(null);
                setOrgID(value);
              }}
            />
          ) : (
            ''
          )}
          {treeData && (
            <Tree.DirectoryTree
              onSelect={([selectedKeys]) => {
                const key = selectedKeys.toString().split('_')[1];
                setResourceID(key);
                // navigate(`/dataset/catalog?resourceID=${key}`);
                setSearchParams({resourceID: key, orgID});
                defaultKey.current = selectedKeys as string;
              }}
              defaultExpandAll
              selectedKeys={[defaultKey.current]}
              switcherIcon={<DownOutlined />}
              treeData={treeData}
              className={styles.tree}
            />
          )}
        </div>
        {detail ? <Detail {...detail} getLook={authLook} /> : ''}
      </div>
    </Content>
  );
};

export default Catalog;
