import React, {useCallback, useEffect, useState} from 'react';
import {RcFile} from 'antd/es/upload';
import {useForm} from 'antd/es/form/Form';
import {useNavigate, useParams} from 'react-router-dom';
import dayjs from 'dayjs';
import {App, Form, Radio, UploadProps} from 'antd';
import TextArea from 'antd/es/input/TextArea';
import Uploader from '@/components/Uploader';
import ContentLayout from '@/components/Content';
import Input from '@/components/CustomInput';
import SelectStatus from '@/components/Select';
import Button from '@/components/Button';
import {useCurrentNav} from '@/slice/sider';
import DatePick from '@/components/SingleDatePicker';
import {
  createDataset,
  datasetNamespaceList,
  datasetUploadFile,
  fetchDatasetDetail,
  updateDataset,
} from '@/libs/api';
import ErrorCode from '@/libs/errorCode';

interface CreateProps {}
type CreateType = React.FC<CreateProps>;
const Item = Form.Item;
const Create: CreateType = () => {
  const {resourceID} = useParams();
  const formItemLayout = {
    labelCol: {flex: '100px'},
    wrapperCol: {flex: '0 1 300px'},
  };
  useCurrentNav('datasetMine');

  const [form] = useForm();
  const [namespace, setNamespace] = useState([]);
  const customRequest: UploadProps['customRequest'] = useCallback(
    ({file, onError, onSuccess}) => {
      return datasetUploadFile({
        file: file as RcFile,
        fileName: (file as RcFile).name,
      }).then(
        resp => {
          if (resp.code === '0') {
            onSuccess(resp.data.filePath);
          } else {
            const err = new Error(ErrorCode[resp.code]);
            onError(err);
          }
        },
        err => {
          onError(err);
        }
      );
    },
    []
  );

  const {message} = App.useApp();
  const navigate = useNavigate();
  useEffect(() => {
    datasetNamespaceList().then(resp => {
      if (resp.code === '0') {
        setNamespace(resp.data);
      }
    });

    if (resourceID) {
      fetchDatasetDetail({resourceID}).then(resp => {
        if (resp.code === '0') {
          const data = resp.data;
          form.setFieldsValue({
            name: data.resourceName,
            expireTime: dayjs(data.expireTime * 1000),
            fileVersion: data.version,
            namespace: data.namespace,
            storageType: data.storageType,
            description: data.description,
          });
        } else {
          message.error(ErrorCode[resp.code]);
        }
      });
    }
  }, []);

  const gotoMine = () => navigate('/dataset/mine');
  const onSubmit = useCallback(() => {
    form.validateFields().then(config => {
      // eslint-disable-next-line @babel/new-cap
      config.expireTime = dayjs(config.expireTime).unix();
      if (resourceID) {
        return updateDataset({
          id: parseInt(resourceID, 10),
          expireTime: config.expireTime,
          filePath: config.filePath,
          fileVersion: config.fileVersion,
          metaPath: config.metaPath,
        }).then(resp => {
          if (resp.code === '0') {
            message.success('更新成功');
            setTimeout(gotoMine, 1000);
          } else {
            message.error(ErrorCode[resp.code]);
          }
        });
      }
      return createDataset(config).then(resp => {
        if (resp.code === '0') {
          message.success('创建成功');
          setTimeout(gotoMine, 1000);
        } else {
          message.error(ErrorCode[resp.code]);
        }
      });
    }, console.error);
  }, []);
  return (
    <ContentLayout
      paths={[
        {
          url: '/dataset/mine',
          name: '我的数据资源',
        },
        {
          url: '',
          name: resourceID ? '更新数据资源' : '创建数据资源',
        },
      ]}
    >
      <Form {...formItemLayout} form={form}>
        <Item
          label="文件名称"
          name="name"
          rules={[
            {
              required: true,
              min: 4,
              max: 20,
              message: '请输入名称，4到20个字符',
            },
          ]}
        >
          <Input placeholder="请输入文件名" disabled={!!resourceID} />
        </Item>
        <Item
          label="过期时间"
          name="expireTime"
          required
          rules={[
            {
              validator(rule, value) {
                const now = new Date();
                if (!value || value < now) {
                  return Promise.reject('过期时间不能早于当前时间');
                }
                return Promise.resolve(value);
              },
            },
          ]}
        >
          <DatePick placeholder="请选择过期时间" />
        </Item>
        <Item
          label="上传数据资源"
          name="filePath"
          rules={[
            {
              required: true,
              message: '请上传数据资源文件',
            },
          ]}
          required
        >
          <Uploader
            accept=".csv"
            multiple={false}
            maxCount={1}
            customRequest={customRequest}
          />
        </Item>

        <Item
          label="数据资源版本"
          name="fileVersion"
          rules={[
            {
              type: 'string',
              min: 1,
              max: 20,
              message: '版本信息最大20个字符',
            },
            {
              required: true,
              message: '请填写版本号',
            },
          ]}
          required
        >
          <Input />
        </Item>
        <Item
          label="上传解析文件"
          name="metaPath"
          required
          rules={[
            {
              required: true,
              message: '请上传解析文件',
            },
          ]}
        >
          <Uploader
            accept=".meta"
            multiple={false}
            maxCount={1}
            customRequest={customRequest}
          />
        </Item>
        <Item label=" " colon={false}>
          <div style={{fontSize: '12px'}}>
            解析文件支持对您的数据源文件进行特征解析，解析后的特征将在数据资源详情展示，在发布上链之前可以修改维护，请按照示例格式上传。
            <p style={{marginBottom: '0'}}>
              <a download={'示例.meta'} href="/static/samplefiles/sample.meta ">
                下载示例
              </a>
            </p>
          </div>
        </Item>
        <Item
          label="资源空间"
          name="namespace"
          rules={[
            {
              required: true,
              message: '请选择资源空间',
            },
          ]}
        >
          <SelectStatus
            optsList={namespace.map(k => ({value: k, label: k}))}
            disabled={!!resourceID}
          />
        </Item>
        <Item label="存储方式" name="storageType" initialValue={0} required>
          <Radio.Group disabled={!!resourceID}>
            <Radio value={0}>XDB去中心化存储</Radio>
            <Radio value={1}>本地存储</Radio>
          </Radio.Group>
        </Item>
        <Item
          label="文件信息描述"
          name="description"
          rules={[
            {
              required: true,
              max: 140,
              min: 10,
              message: '资源信息描述限制10到140个字符',
            },
          ]}
          required
        >
          <TextArea disabled={!!resourceID} />
        </Item>
        <Item style={{textAlign: 'left'}} label=" " colon={false}>
          <Button
            type="primary"
            onClick={onSubmit}
            style={{marginRight: '16px'}}
          >
            确认
          </Button>
          <Button onClick={() => navigate('/dataset/mine')}>取消</Button>
        </Item>
      </Form>
    </ContentLayout>
  );
};

export default Create;
