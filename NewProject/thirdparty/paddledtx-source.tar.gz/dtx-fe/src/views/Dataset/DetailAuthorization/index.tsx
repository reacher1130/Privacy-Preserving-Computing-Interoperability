import React, {ReactNode, useEffect, useState} from 'react';
import styles from './index.less';
import {useNavigate, useParams} from 'react-router-dom';
import {NavKeys, useCurrentNav} from '@/slice/sider';
import {Row, Col} from 'antd';
import Content from '@/components/Content';
import dayjs, {Dayjs} from 'dayjs';

import {
  DatasetAuthorizationDetailReponse,
  datasetAuthorizationDetail,
} from '@/libs/api';
import DotStatus, {DotStatusProps} from '@/components/DotStatus';

const AUTHORIZATION_STATUS = {
  Approved: '已授权',
  Unapproved: '申请中',
  Rejected: '已驳回',
};
type StatusType = typeof AUTHORIZATION_STATUS | {[key: string]: string};

export default function Computing() {
  useCurrentNav(NavKeys.datasetAuthorization);
  const paths = [
    {url: '/dataset/authorization', name: '数据资源授权'},
    {url: '', name: '申请授权详情'},
  ];
  const [resp, setResp] = useState<DatasetAuthorizationDetailReponse['data']>();
  const {authID} = useParams();
  const getDetail = () => {
    datasetAuthorizationDetail({authID})
      .then(resp => {
        if (+resp.code === 0) {
          const data = resp.data;
          setResp(data);
        }
      })
      .catch(err => {
        console.error(err);
      });
  };

  useEffect(() => {
    getDetail();
  }, []);

  let statusText: ReactNode = null;
  if (resp?.status === 'Approved') {
    statusText = (
      <DotStatus type="green">
        {AUTHORIZATION_STATUS[resp?.status as keyof StatusType]}
      </DotStatus>
    );
  } else if (resp?.status === 'Unapproved') {
    statusText = (
      <DotStatus type="blue">
        {AUTHORIZATION_STATUS[resp?.status as keyof StatusType]}
      </DotStatus>
    );
  } else {
    statusText = (
      <DotStatus type="orange">
        {AUTHORIZATION_STATUS[resp?.status as keyof StatusType]}
      </DotStatus>
    );
  }
  return (
    <Content paths={paths}>
      <Row className={styles.dataSetAuthDetailRow}>
        <Col className={styles.col}>授权类型：</Col>
        <Col className={styles.col}>
          {resp?.authType === 'Use' ? '使用' : '查看'}
        </Col>
      </Row>
      <Row className={styles.dataSetAuthDetailRow}>
        <Col className={styles.col}>授权状态：</Col>
        <Col className={styles.col}>{statusText}</Col>
      </Row>
      <Row className={styles.dataSetAuthDetailRow}>
        <Col className={styles.col}>申请时间：</Col>
        <Col className={styles.col}>
          {resp?.createTime
            ? dayjs.unix(resp?.createTime).format('YYYY-MM-DD HH:mm:ss')
            : '--'}
        </Col>
      </Row>
      <Row className={styles.dataSetAuthDetailRow}>
        <Col className={styles.col}>授权时间：</Col>
        <Col className={styles.col}>
          {resp?.approvalTime
            ? dayjs.unix(resp?.approvalTime).format('YYYY-MM-DD HH:mm:ss')
            : '--'}
        </Col>
      </Row>
      {/* {
                resp?.status === 'Approved' ? (
                    <Row className={styles.detailRow}>
                        <Col className={styles.col}>授权时间：</Col>
                        <Col className={styles.col}>
                            {
                                resp?.approvalTime ? dayjs.unix(resp?.approvalTime).format('YYYY-MM-DD HH:mm:ss') : '--'
                            }
                        </Col>
                    </Row>
                ) : ''
            } */}
      <Row className={styles.dataSetAuthDetailRow}>
        <Col className={styles.col}>授权ID：</Col>
        <Col className={styles.col}>{resp?.authID}</Col>
      </Row>
      <Row className={styles.dataSetAuthDetailRow}>
        <Col className={styles.col}>授权对象ID：</Col>
        <Col className={styles.col}>{resp?.resourceID}</Col>
      </Row>
      <Row className={styles.dataSetAuthDetailRow}>
        <Col className={styles.col}>授权对象名称：</Col>
        <Col className={styles.col}>
          {resp?.resourceName ? resp?.resourceName : '--'}
        </Col>
      </Row>
      <Row className={styles.dataSetAuthDetailRow}>
        <Col className={styles.col}>申请机构名称：</Col>
        <Col className={styles.col}>{resp?.applierName}</Col>
      </Row>
      <Row className={styles.dataSetAuthDetailRow}>
        <Col className={styles.col}>申请机构DID：</Col>
        <Col className={styles.col}>{resp?.applierDID}</Col>
      </Row>
      <Row className={styles.dataSetAuthDetailRow}>
        <Col className={styles.col}>申请机构区块链地址：</Col>
        <Col className={styles.col}>{resp?.applier}</Col>
      </Row>
      <Row className={styles.dataSetAuthDetailRow}>
        <Col className={styles.col}>授权机构名称：</Col>
        <Col className={styles.col}>{resp?.authorizerName}</Col>
      </Row>
      <Row className={styles.dataSetAuthDetailRow}>
        <Col className={styles.col}>授权机构DID：</Col>
        <Col className={styles.col}>{resp?.authorizerDID}</Col>
      </Row>
      <Row className={styles.dataSetAuthDetailRow}>
        <Col className={styles.col}>授权机构区块链地址：</Col>
        <Col className={styles.col}>{resp?.authorizer}</Col>
      </Row>
      {resp?.authType === 'Use' ? (
        <Row className={styles.dataSetAuthDetailRow}>
          <Col className={styles.col}>申请字段：</Col>
          <Col className={styles.col}>{resp.features.join(',')}</Col>
        </Row>
      ) : (
        ''
      )}
      {resp?.status === 'Rejected' ? (
        <Row className={styles.dataSetAuthDetailRow}>
          <Col className={styles.col}>驳回原因：</Col>
          <Col className={styles.col}>{resp.rejectReason}</Col>
        </Row>
      ) : (
        ''
      )}
    </Content>
  );
}
