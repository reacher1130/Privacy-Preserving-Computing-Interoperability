import React, {
  ReactElement,
  useCallback,
  useEffect,
  useMemo,
  useState,
} from 'react';
import {useNavigate} from 'react-router-dom';
import {App, Form, Tooltip} from 'antd';
import {PlusOutlined, QuestionCircleOutlined} from '@ant-design/icons';
import {ColumnsType} from 'antd/es/table';
import TextArea from 'antd/es/input/TextArea';
import {useForm} from 'antd/es/form/Form';
import dayjs from 'dayjs';
import Select from '@/components/Select';
import Content from '@/components/Content';
import {useCurrentNav} from '@/slice/sider';
import Button from '@/components/Button';
import Table from '@/components/Table';
import Input from '@/components/CustomInput';
import NumberCounter from '@/components/Counter';
import {
  CreateDatasetNamespaceRquest,
  Dataset,
  DatasetListResponse,
  DatasetStatus,
  createDatasetNamespace,
  datasetNamespaceList,
  datasetNamespaceReplicaLimit,
  deleteDataset,
  fetchDataList,
  offlineDataset,
  onlineDataset,
  publishDataset,
} from '@/libs/api';
import DateRange from '@/components/DateRange';
import {tdRender} from '@/components/Table/ToolTip';
import ModalBox from '@/components/Modal';
import ErrorCode from '@/libs/errorCode';
import ExpiredTimeText from '@/components/ExpireTimeText';
import {
  PermissionValue,
  getPermissionFromCache,
} from '@/pages/Account/PermissionCreator';
import Pw, {PwD} from '../PermissonWrap';
import styles from './style.less';
import RoleApi from '@/slice/role/api';
import store from '@/store';
import DotStatus from '@/components/DotStatus';
import Question from '@/components/Question';

export interface MineProps {
  name?: string;
}

const columns: ColumnsType<Dataset> = [
  {
    title: '数据资源ID',
    dataIndex: 'resourceID',
    key: 'id',
    render: tdRender({maxWidth: 180}),
  },
  {
    title: '数据名称',
    dataIndex: 'resourceName',
    key: 'resourceName',
    render: name => {
      return <div className={styles.nameTd}>{name}</div>;
    },
  },
  {
    title: '数据资源描述',
    dataIndex: 'description',
    key: 'description',
    render: description => {
      return <div className={styles.descTd}>{description}</div>;
    },
  },
  {
    title: '版本',
    dataIndex: 'version',
    key: 'version',
  },
  {
    title: '资源空间',
    dataIndex: 'namespace',
    key: 'namespace',
  },
  {
    title: '资源状态',
    dataIndex: 'status',
    key: 'status',
    render: (item: any) => {
      switch (item) {
        case DatasetStatus.Parsing:
          return (
            <DotStatus type="blue">
              解析中
              <Question
                content="对该数据文件进行特征列、特征描述的解析"
                style={{marginLeft: '5px'}}
              />
            </DotStatus>
          );
        case DatasetStatus.Saving:
          return (
            <DotStatus type="blue">
              保存中
              <Question
                content="数据解析成功，进行存储中"
                style={{marginLeft: '5px'}}
              />
            </DotStatus>
          );
        case DatasetStatus.SaveFail:
          return (
            <DotStatus type="orange">
              保存失败
              <Question
                content="数据保存失败，请重新上传"
                style={{marginLeft: '5px'}}
              />
            </DotStatus>
          );
        case DatasetStatus.ParseFail:
          return (
            <DotStatus type="orange">
              解析失败
              <Question content="数据解析失败" style={{marginLeft: '5px'}} />
            </DotStatus>
          );
        case DatasetStatus.Saved:
          return (
            <DotStatus type="green">
              已保存
              <Question
                content="数据资源存储成功，支持发布上链"
                style={{marginLeft: '5px'}}
              />
            </DotStatus>
          );
        case DatasetStatus.Published:
          return (
            <DotStatus type="green">
              已发布
              <Question
                content="已发布上链，不支持删除链上数据资源"
                style={{marginLeft: '5px'}}
              />
            </DotStatus>
          );
        case DatasetStatus.Offline:
          return (
            <DotStatus type="gray">
              已下线
              <Question
                content="数据资源已下线，不再为使用方提供服务，如需恢复服务可重新上线"
                style={{marginLeft: '5px'}}
              />
            </DotStatus>
          );

        case DatasetStatus.UpdateFail:
          return (
            <DotStatus type="orange">
              更新失败
              <Question
                content="更新失败，请重新更新"
                style={{marginLeft: '5px'}}
              />
            </DotStatus>
          );
        case DatasetStatus.Expired:
          return (
            <DotStatus type="gray">
              已过期
              <Question
                content="数据资源已过期，无法用于创建任务，执行计算"
                style={{marginLeft: '5px'}}
              />
            </DotStatus>
          );
        default:
          break;
      }
    },
  },
  // {
  //     title: '存证hash',
  //     dataIndex: 'tx_id',
  //     key: 'tx_id',
  //     render: tdRender({maxWidth: 180}),
  // },
  // {
  //     title: '创建时间',
  //     dataIndex: 'createTime',
  //     key: 'createTime',
  //     render: (createTime: number) => (
  //         <span>{dayjs.unix(createTime).format('YYYY-MM-DD HH:mm:ss')}</span>
  //     ),
  // },
  {
    title: '更新时间',
    dataIndex: 'updateTime',
    key: 'updateTime',
    render: (updateTime: number) => (
      <span>
        {updateTime
          ? dayjs.unix(updateTime).format('YYYY-MM-DD HH:mm:ss')
          : '-'}
      </span>
    ),
  },
  {
    title: '过期时间',
    dataIndex: 'expireTime',
    key: 'expireTime',
    render: (expireTime: number) => {
      return <ExpiredTimeText time={expireTime} />;
    },
  },
];

interface CreateSpaceModalProps {
  open: boolean;
  onOk?: () => void;
  onCancel?: () => void;
}
const CreateSpaceModal: React.FC<CreateSpaceModalProps> = props => {
  const formItemLayout = {
    labelCol: {span: 3},
    wrapperCol: {span: 21},
  };
  // const [replicaLimit, setReplicaLimit] = useState(0);
  const {message} = App.useApp();
  const [form] = useForm();
  const onOk = useCallback(() => {
    form.validateFields().then((data: CreateDatasetNamespaceRquest) => {
      data.replica = 2;
      createDatasetNamespace(data).then(resp => {
        if (resp.code === '0') {
          message.success('创建成功');
          props.onOk();
        } else {
          message.error(ErrorCode[resp.code]);
        }
      });
    }, console.error);
  }, []);

  // useEffect(() => {
  //     datasetNamespaceReplicaLimit().then(resp => {
  //         if (resp.code === '0') {
  //             setReplicaLimit(resp.data);
  //         }
  //         else {
  //             message.error(ErrorCode[resp.code]);
  //         }
  //     }, console.error);
  // }, []);
  const countChange: (info: {
    value: string;
    count: number;
    maxLength?: number;
  }) => string = info => {
    const {count, maxLength} = info;
    return `${count} / ${maxLength}`;
  };
  return (
    <ModalBox
      {...props}
      title="新增资源空间"
      onOk={onOk}
      wrapClassName={styles.addSpaceWrapClassName}
    >
      <Form {...formItemLayout} form={form} className={styles.addSpaceForm}>
        <Form.Item
          label="名称"
          name="name"
          rules={[
            {
              required: true,
              message: '请输入名称',
            },
            {
              type: 'string',
              max: 20,
              min: 4,
              message: '请输入名称，4到20个字符',
            },
          ]}
          required
        >
          <Input />
        </Form.Item>
        {/* <Form.Item
                    label="文件副本数"
                    name="replica"
                    required
                    initialValue={1}
                    extra={`当前有${replicaLimit}个存储节点，副本数不能大于存储节点数量`}
                >
                    <NumberCounter max={replicaLimit} min={1} disabled={replicaLimit === 0} />
                </Form.Item> */}
        <Form.Item
          label="简介"
          name="description"
          rules={[
            {
              max: 140,
              message: '简介限制在140字以内，请精简内容',
            },
          ]}
        >
          <TextArea
            style={{height: '120px'}}
            placeholder="请输入简介"
            maxLength={140}
            showCount={{formatter: countChange}}
          />
        </Form.Item>
      </Form>
    </ModalBox>
  );
};
interface MineHeaderProps {
  namespace?: string;
  status?: string;
  startTime?: number;
  endTime?: number;
  onNamespaceChange: (namespace: string) => void;
  onStatusChange: (status: number) => void;
  onTimeRangeChange: (startTime: number, endTime: number) => void;
}
const MineHeader: React.FC<MineHeaderProps> = (props: MineHeaderProps) => {
  const [spaceOpen, setSpaceOpen] = useState(false);
  const [spaceList, setSpaceList] = useState([]);
  const navigate = useNavigate();
  const [form] = useForm();
  const onCancel = useCallback(() => setSpaceOpen(false), []);
  const onOk = useCallback(() => setSpaceOpen(false), []);
  const onNewSpaceClick = useCallback(() => setSpaceOpen(true), []);
  const onNewDatasetClick = useCallback(() => navigate('/dataset/create'), []);

  const getDatasetNamespaceList = useCallback(() => {
    datasetNamespaceList().then(resp => {
      if (resp.code === '0') {
        const s = resp.data.map(k => ({
          value: k,
          label: k,
        }));
        s.unshift({
          value: '',
          label: '全部空间',
        });
        setSpaceList(s);
      }
    });
  }, []);
  useEffect(() => {
    getDatasetNamespaceList();
  }, []);

  const onValuesChange = useCallback((record: Record<string, any>) => {
    if ('status' in record) {
      props.onStatusChange(record.status);
    }
    if ('timeRange' in record) {
      props.onTimeRangeChange(
        record.timeRange.startTime,
        record.timeRange.endTime
      );
    }
    if ('namespace' in record) {
      props.onNamespaceChange(record.namespace);
    }
  }, []);
  return (
    <div className={styles.header}>
      <CreateSpaceModal open={spaceOpen} onCancel={onCancel} onOk={onOk} />
      <div className={styles.form_inner}>
        <div className={styles.form_left}>
          <Form layout="inline" form={form} onValuesChange={onValuesChange}>
            <Form.Item name="namespace" initialValue={''}>
              <Select placeholder="选择空间" optsList={spaceList} />
            </Form.Item>
            <Form.Item name="status" initialValue={''}>
              <Select
                placeholder="选择资源状态"
                optsList={[
                  {
                    value: '',
                    label: '全部状态',
                  },
                  {
                    value: DatasetStatus.Parsing.toString(),
                    label: '解析中',
                  },
                  {
                    value: DatasetStatus.Saving.toString(),
                    label: '保存中',
                  },
                  {
                    value: DatasetStatus.Saved.toString(),
                    label: '已保存',
                  },
                  {
                    value: DatasetStatus.Published.toString(),
                    label: '已发布',
                  },
                  {
                    value: DatasetStatus.Offline.toString(),
                    label: '已下线',
                  },
                  {
                    value: DatasetStatus.Expired.toString(),
                    label: '已过期',
                  },
                  {
                    value: DatasetStatus.ParseFail.toString(),
                    label: '解析失败',
                  },
                  {
                    value: DatasetStatus.SaveFail.toString(),
                    label: '存储失败',
                  },
                  {
                    value: DatasetStatus.UpdateFail.toString(),
                    label: '更新失败',
                  },
                ]}
              />
            </Form.Item>
            <Form.Item name="timeRange" style={{marginInlineEnd: 0}}>
              <DateRange allowClear />
            </Form.Item>
          </Form>
        </div>
        <div className={styles.form_middle}></div>
        <div className={styles.form_right}>
          <PwD rP={PermissionValue.Write}>
            <Button
              style={{marginRight: '16px'}}
              type="primary"
              icon={<PlusOutlined />}
              onClick={onNewSpaceClick}
            >
              新增资源空间
            </Button>
          </PwD>
          <PwD rP={PermissionValue.Write}>
            <Button
              type="primary"
              icon={<PlusOutlined />}
              onClick={onNewDatasetClick}
            >
              新增数据资源
            </Button>
          </PwD>
        </div>
      </div>
    </div>
  );
};

function Mine() {
  const navigate = useNavigate();
  const _colums = useMemo(() => [...columns], []);
  const pageSize = 10;
  const [pageNo, setPageNo] = useState(1);
  const [namespace, setNamespace] = useState<Dataset['namespace']>();
  const [status, setStatus] = useState<Dataset['status']>();
  const [timeRange, setTimeRange] = useState<{
    startTime?: number;
    endTime?: number;
  }>({});
  const [resp, setResp] = useState<DatasetListResponse['data']>({
    total: 0,
    list: [],
  });
  const {message} = App.useApp();
  const onChange = (pageNo: number = 1) => {
    setPageNo(pageNo);
  };

  const [confirmConf, setConfirmConf] = useState<{
    open: boolean;
    title?: string;
    msg?: string;
    id?: number;
    onOk?: (id: number) => Promise<any>;
  }>({open: false});

  const loadDatasetList = useCallback(
    function () {
      const {startTime, endTime} = timeRange;
      fetchDataList({
        pageNo,
        pageSize,
        namespace,
        status,
        startTime,
        endTime,
      }).then(resp => {
        if (resp.code === '0') {
          setResp(resp.data);
        } else {
          message.error(ErrorCode[resp.code]);
        }
      });
    },
    [namespace, pageNo, status, timeRange]
  );

  const datasetOnline = useCallback(
    (resourceID: number) => {
      setConfirmConf({
        open: true,
        title: '上线资源',
        msg: '将数据资源特征发布到目录链上，已发布的数据资源不支持维护特征信息，且不能重复发布，是否确认发布？',
        id: resourceID,
        onOk: (id: number) =>
          onlineDataset({id}).then(resp => {
            if (resp.code === '0') {
              message.success('上线成功');
              setConfirmConf({open: false});
            } else {
              message.error(ErrorCode[resp.code]);
            }
          }, console.error),
      });
    },
    [loadDatasetList]
  );

  const datasetOffline = useCallback(
    (resourceID: number) => {
      setConfirmConf({
        open: true,
        title: '下线资源',
        msg: '将数据资源特征从目录链下线，不再为使用方提供相关服务，是否确认下线？',
        id: resourceID,
        onOk: (id: number) =>
          offlineDataset({id})
            .then(resp => {
              if (resp.code === '0') {
                message.success('下线成功');
              } else {
                message.error(ErrorCode[resp.code] ?? '系统错误');
              }
            }, console.error)
            .finally(() => {
              setConfirmConf({open: false});
            }),
      });
    },
    [loadDatasetList, message]
  );

  const datasetPublish = useCallback(
    (resourceID: number) => {
      setConfirmConf({
        open: true,
        title: '发布资源',
        msg: '将数据资源特征发布到目录链上，已发布的数据资源不支持维护特征信息，且不能重复发布，是否确认发布？',
        id: resourceID,
        onOk: (id: number) =>
          publishDataset({id}).then(resp => {
            if (resp.code === '0') {
              message.success('发布成功');
              setConfirmConf({open: false});
            } else {
              message.error(ErrorCode[resp.code]);
            }
          }, console.error),
      });
    },
    [loadDatasetList, message]
  );

  const datasetDelete = useCallback(
    (resourceID: number) => {
      setConfirmConf({
        open: true,
        title: '删除资源',
        msg: '数据资源删除后不可恢复，是否确认删除?',
        id: resourceID,
        onOk: (id: number) =>
          deleteDataset({id}).then(resp => {
            if (resp.code === '0') {
              message.success('删除成功');
              setConfirmConf({open: false});
            } else {
              message.error(ErrorCode[resp.code]);
            }
          }, console.error),
      });
    },
    [loadDatasetList, message]
  );

  const updateButton = (id: string) => (
    <PwD rP={PermissionValue.Write} key="update">
      <span
        className={styles.operate}
        key="update_button"
        onClick={() => navigate(`/dataset/update/${id}`)}
      >
        更新
      </span>
    </PwD>
  );

  const deleteButton = (id: number) => (
    <PwD rP={PermissionValue.Write} key="delete">
      <span
        className={styles.operate}
        key="delete_button"
        onClick={() => {
          datasetDelete(id);
        }}
      >
        删除
      </span>
    </PwD>
  );

  const offlineButton = (id: number) => (
    <PwD rP={PermissionValue.Write} key="offline">
      <span
        className={styles.operate}
        key="online_button"
        onClick={() => {
          datasetOffline(id);
        }}
      >
        下线
      </span>
    </PwD>
  );
  const onlineButton = (id: number) => (
    <PwD rP={PermissionValue.Write} key="online">
      <span
        className={styles.operate}
        key="online_button"
        onClick={() => {
          datasetOnline(id);
        }}
      >
        上线
      </span>
    </PwD>
  );
  const pubButton = (id: number) => (
    <PwD rP={PermissionValue.Write} key="pub">
      <span
        className={styles.operate}
        key="online_button"
        onClick={() => {
          datasetPublish(id);
        }}
      >
        发布
      </span>
    </PwD>
  );

  const detailBotton = (id: string) => (
    <PwD rP={PermissionValue.Read} key="detail">
      <span
        key="detail_button"
        className={styles.operate}
        onClick={() => {
          navigate(`/dataset/detail/${id}`);
        }}
      >
        详情
      </span>
    </PwD>
  );
  // 设置导航高亮，并不是必须的
  useEffect(() => {
    _colums.push({
      title: '操作',
      key: 'action',
      dataIndex: 'status',
      render: (status: number, item: any) => {
        const {id} = item;
        const actions: Array<ReactElement | string> = [];
        switch (status) {
          // case DatasetStatus.Parsing:
          //     break;
          // case DatasetStatus.Saving:
          //     break;
          case DatasetStatus.Saved:
            actions.push(detailBotton(id));
            actions.push(pubButton(id));
            actions.push(deleteButton(id));
            break;
          case DatasetStatus.Published:
            actions.push(detailBotton(id));
            actions.push(updateButton(id));
            actions.push(offlineButton(id));
            break;
          case DatasetStatus.Offline:
            actions.push(detailBotton(id));
            actions.push(onlineButton(id));
            break;
          case DatasetStatus.UpdateFail:
            actions.push(updateButton(id));
          case DatasetStatus.ParseFail:
          case DatasetStatus.SaveFail:
            actions.push(deleteButton(id));
            break;
          case DatasetStatus.Expired:
            actions.push(detailBotton(id));
            actions.push(deleteButton(id));
            break;
          default:
            actions.push('--');
        }
        return <>{actions.map(a => a)}</>;
      },
    });
  }, [_colums, navigate]);

  useEffect(() => {
    loadDatasetList();
  }, [namespace, pageNo, status, timeRange]);

  const onNamespaceChange = useCallback((namespace: string) => {
    setPageNo(1);
    setNamespace(namespace);
  }, []);

  const onStatusChange = useCallback((status: number) => {
    setPageNo(1);
    setStatus(status);
  }, []);

  const onTimeRangeChange = useCallback(
    (startTime: number, endTime: number) => {
      setPageNo(1);
      setTimeRange({
        startTime: startTime,
        endTime: endTime,
      });
    },
    []
  );
  useCurrentNav('datasetMine');
  const confirmCancel = useCallback(() => {
    setConfirmConf({open: false});
  }, []);

  const confirmOk = useCallback(() => {
    confirmConf.onOk(confirmConf.id).finally(() => loadDatasetList());
  }, [confirmConf]);

  return (
    <Content>
      <ModalBox
        open={confirmConf.open}
        title={confirmConf.title}
        onCancel={confirmCancel}
        onOk={confirmOk}
      >
        {confirmConf.msg}
      </ModalBox>
      <MineHeader
        onNamespaceChange={onNamespaceChange}
        onStatusChange={onStatusChange}
        onTimeRangeChange={onTimeRangeChange}
      />
      <Table
        className={styles.table}
        columns={_colums}
        pagination={{
          total: resp.total,
          current: pageNo,
          pageSize,
          onChange,
        }}
        dataSource={resp.list}
        bordered
        rowKey="id"
      />
    </Content>
  );
}

export default Mine;
