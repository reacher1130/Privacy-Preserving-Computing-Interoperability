import React, {
  ReactNode,
  useCallback,
  useEffect,
  useRef,
  useState,
} from 'react';
import {EChartsOption} from 'echarts';
import * as echarts from 'echarts/core';
import {App, Space as AntSpace, Dropdown, Spin} from 'antd';
import Icon from '@ant-design/icons/lib/components/Icon';
import {DownOutlined, RightOutlined} from '@ant-design/icons';
import {Link, useNavigate} from 'react-router-dom';
import ContentLayout from '@/components/Content';
import {
  DatasetNamespaceOrgStatListItem,
  DatasetNamespaceOrgStatResponse,
  datasetNamespaceOrgStat,
  userInfo,
} from '@/libs/api';
import IMG_SPACE_COUNT from '@pub/images/icon-dataset-space-count.png';
import IMG_DATASET_COUNT from '@pub/images/icon-dataset-resoure-count.png';
import IMG_NODE_COUNT from '@pub/images/icon-dataset-node-count.png';
import IMG_USER_COUNT from '@pub/images/icon-dataset-user-count.png';

import IMG_SETTING from '@pub/images/img-dataset-setting.png';
import IMG_BROWSE from '@pub/images/img-dataset-apply-browse.png';
import IMG_USE from '@pub/images/img-dataset-apply-use.png';
import IMG_EXECUTE from '@pub/images/img-dataset-execute.png';

import ICON_ROLE from '@pub/images/icon-dataset-space-role.svg';
import ErrorCode from '@/libs/errorCode';
import {NavKeys, useCurrentNav} from '@/slice/sider';
import styles from './index.less';

interface generateEchartOptionProps {
  backgroundColor: string;
  foregroundColor: string;
  count?: number;
  total?: number;
}
const generateEchartOption = (props: generateEchartOptionProps) => {
  const option: EChartsOption = {
    title: {
      show: true,
      text: props.count.toString(),
      left: 45,
      top: 45,
      textStyle: {
        fontSize: 20,
      },
      textAlign: 'center',
      textVerticalAlign: 'middle',
    },
    series: [
      {
        type: 'pie',
        radius: ['40%', '70%'],
        silent: true,
        top: -20,
        left: -20,
        right: -20,
        bottom: -20,
        startAngle: 270,
        label: {
          show: false,
        },
        avoidLabelOverlap: false,
        data: [
          {value: props.count, itemStyle: {color: props.foregroundColor}},
          {
            value: props.total - props.count,
            itemStyle: {color: props.backgroundColor},
          },
        ],
      },
    ],
  };
  return option;
};

interface SpaceRoleProps {
  orgID: string;
  space: number;
  spaceTotal: number;
  resource: number;
  resourceTotal: number;
  node: number;
  nodeTotal: number;
  name: string;
  isMine: boolean;
  dropDown?: ReactNode;
}
const SpaceRole: React.FC<SpaceRoleProps> = props => {
  const spaceRef = useRef();
  const resourceRef = useRef();
  const nodeRef = useRef();
  const navigate = useNavigate();
  useEffect(() => {
    const c: Array<
      [React.MutableRefObject<HTMLDivElement>, string, string, number, number]
    > = [
      [spaceRef, 'rgb(74, 144, 226)', 'rgba(74, 144, 226, 0.1)', props.space, props.spaceTotal],
      [resourceRef, '#19b5ff', '#d1f1fa', props.resource, props.resourceTotal],
      [nodeRef, '#683aff', '#d8edfa', props.node, props.nodeTotal],
    ];
    const charts = c.map(([r, f, b, c, t]) => {
      const chart = echarts.init(r.current);
      chart.setOption(
        generateEchartOption({
          backgroundColor: b,
          foregroundColor: f,
          count: c,
          total: t,
        })
      );
      return chart;
    });

    return () => {
      charts.forEach(c => c.dispose());
    };
  }, [props.name]);
  return (
    <div className={styles.role_cell}>
      <div className={[styles.title, styles.title_flex].join(' ')}>
        <span className={styles.title_text}>{props.name}</span>
        {props.isMine ? (
          <span
            className={[styles.title_role, styles.title_role_mine].join(' ')}
          >
            我的
          </span>
        ) : (
          <span
            className={[styles.title_role, styles.title_role_other].join(' ')}
          >
            参与方
          </span>
        )}
        {props.dropDown ? props.dropDown : ''}
      </div>
      <div
        className={styles.content}
        onClick={() => {
          navigate(`/dataset/catalog?orgID=${props.orgID}`);
        }}
      >
        <div className={styles.role_cell_panel}>
          <div className={styles.role_cell_title}>
            <Icon component={ICON_ROLE} /> 数据资源空间
          </div>
          <div className={styles.role_cell_content} ref={spaceRef}></div>
        </div>
        <div className={styles.role_cell_panel}>
          <div className={styles.role_cell_title}>
            <Icon component={ICON_ROLE} /> 数据资源数
          </div>
          <div className={styles.role_cell_content} ref={resourceRef}></div>
        </div>
        <div className={styles.role_cell_panel}>
          <div className={styles.role_cell_title}>
            <Icon component={ICON_ROLE} /> 计算节点数
          </div>
          <div className={styles.role_cell_content} ref={nodeRef}></div>
        </div>
      </div>
    </div>
  );
};
const Space: React.FC = () => {
  useCurrentNav(NavKeys.datasetSpace);
  const [loading, setLoading] = useState(false);
  const [totalSpace, setTotalSpace] = useState(0);
  const [totalResource, setTotalResource] = useState(0);
  const [totalNodes, setTotalNodes] = useState(0);
  const [totalOrgs, setTotalOrgs] = useState(0);
  const orgData = useRef<DatasetNamespaceOrgStatResponse['data']['list']>(null);
  const [mineData, setMineData] =
    useState<DatasetNamespaceOrgStatListItem>(null);
  const [otherData, setOtherData] =
    useState<DatasetNamespaceOrgStatListItem>(null);
  const {message} = App.useApp();
  const setOrgData = useCallback((orgID?: string) => {
    if (!orgID) {
      orgID = orgData.current.sort((a, b) => {
        const asum = a.countExecutor + a.countNamespace + a.countResource;
        const bsum = b.countExecutor + b.countNamespace + b.countResource;
        return bsum - asum;
      })[0].orgID;
    }
    const otherOrgData = orgData.current.find(v => v.orgID === orgID);
    setOtherData(otherOrgData);
  }, []);
  useEffect(() => {
    setLoading(true);
    Promise.all([datasetNamespaceOrgStat(), userInfo()])
      .then(([datasetResp, userInfoResp]) => {
        if (datasetResp.code === '0' && userInfoResp.code === '0') {
          const mineOrgData = datasetResp.data.list.find(
            v => v.orgID === userInfoResp.data.orgId
          );
          orgData.current = datasetResp.data.list.filter(
            v => v.orgID !== userInfoResp.data.orgId
          );
          setMineData(mineOrgData);
          setTotalSpace(datasetResp.data.totalNamespace);
          setTotalNodes(datasetResp.data.totalExes);
          setTotalResource(datasetResp.data.totalResource);
          setTotalOrgs(datasetResp.data.totalOrgs);
          setOrgData();
        } else {
          if (datasetResp.code !== '0') {
            message.error(ErrorCode[datasetResp.code]);
          } else {
            message.error(ErrorCode[userInfoResp.code]);
          }
        }
      })
      .finally(() => setLoading(false));
  }, []);
  return (
    <ContentLayout className={styles.space_layout}>
      {loading ? (
        <div className={styles.loadingMask}>
          <Spin className={styles.spin} />
        </div>
      ) : (
        ''
      )}
      <div className={[styles.all_resource_row, styles.space_row].join(' ')}>
        <div className={styles.title}>
          总数据资源
          <span className={styles.more_btn}>
            <Link to="/dataset/catalog" className={styles.moreLink}>
              查看
              <RightOutlined style={{color: '#07afbe'}} />
            </Link>
          </span>
        </div>
        <div className={styles.content}>
          <div className={styles.resoure_cell}>
            <div className={styles.resoure_cell_image}>
              <img src={IMG_SPACE_COUNT} />
            </div>
            <div className={styles.resoure_cell_info}>
              <div className={styles.resource_cell_label}>数据资源空间</div>
              <div className={styles.resource_cell_value}>{totalSpace}</div>
            </div>
          </div>
          <div className={styles.resoure_cell}>
            <div className={styles.resoure_cell_image}>
              <img src={IMG_DATASET_COUNT} />
            </div>
            <div className={styles.resoure_cell_info}>
              <div className={styles.resource_cell_label}>数据资源数</div>
              <div className={styles.resource_cell_value}>{totalResource}</div>
            </div>
          </div>
          <div className={styles.resoure_cell}>
            <div className={styles.resoure_cell_image}>
              <img src={IMG_NODE_COUNT} />
            </div>
            <div className={styles.resoure_cell_info}>
              <div className={styles.resource_cell_label}>计算节点数</div>
              <div className={styles.resource_cell_value}>{totalNodes}</div>
            </div>
          </div>
          <div className={styles.resoure_cell}>
            <div className={styles.resoure_cell_image}>
              <img src={IMG_USER_COUNT} />
            </div>
            <div className={styles.resoure_cell_info}>
              <div className={styles.resource_cell_label}>参与方总数</div>
              <div className={styles.resource_cell_value}>{totalOrgs}</div>
            </div>
          </div>
        </div>
      </div>
      <div className={[styles.all_role_row, styles.space_row].join(' ')}>
        {mineData ? (
          <SpaceRole
            isMine
            space={mineData.countNamespace}
            spaceTotal={totalSpace}
            resource={mineData.countResource}
            resourceTotal={totalResource}
            node={mineData.countExecutor}
            nodeTotal={totalNodes}
            name={mineData.orgName}
            orgID={mineData.orgID}
          />
        ) : (
          ''
        )}
        {otherData ? (
          <SpaceRole
            isMine={false}
            space={otherData.countNamespace}
            spaceTotal={totalSpace}
            resource={otherData.countResource}
            resourceTotal={totalResource}
            node={otherData.countExecutor}
            nodeTotal={totalNodes}
            name={otherData.orgName}
            orgID={otherData.orgID}
            dropDown={
              <Dropdown
                overlayClassName={styles.more_org_dropdown_menu}
                menu={{
                  items: orgData.current
                    .filter(v => v.orgID !== otherData.orgID)
                    .map((o, i) => ({
                      key: i,
                      label: o.orgName,
                      onClick: () => setOrgData(o.orgID),
                    })),
                }}
              >
                <span
                  onClick={e => e.preventDefault()}
                  className={[styles.more_btn, styles.more_org].join(' ')}
                >
                  <AntSpace>
                    点击查看更多机构
                    <DownOutlined />
                  </AntSpace>
                </span>
              </Dropdown>
            }
          />
        ) : (
          ''
        )}
      </div>
      <div className={[styles.all_step_row, styles.space_row].join(' ')}>
        <div className={styles.title}>数据资源使用流程</div>
        <div className={styles.content}>
          <div className={styles.step_cell}>
            <div className={styles.step_cell_img}>
              <img src={IMG_BROWSE} />
            </div>
            <div className={styles.step_cell_title}>
              <span className={styles.step_cell_number}>1</span>
              <span className={styles.step_cell_title_text}>申请查看</span>
            </div>
            <div className={styles.step_cell_content}>
              首先申请所需数据资源的查看权限，获得授权后可查看数据资源特征列与统计信息。
            </div>
          </div>
          <div className={styles.step_cell}>
            <div className={styles.step_cell_img}>
              <img src={IMG_USE} />
            </div>
            <div className={styles.step_cell_title}>
              <span className={styles.step_cell_number}>2</span>
              <span className={styles.step_cell_title_text}>申请使用</span>
            </div>
            <div className={styles.step_cell_content}>
              获得查看权限后，针对计算任务需要用到的特征列，申请使用权限。
            </div>
          </div>
          <div className={styles.step_cell}>
            <div className={styles.step_cell_img}>
              <img src={IMG_SETTING} />
            </div>
            <div className={styles.step_cell_title}>
              <span className={styles.step_cell_number}>3</span>
              <span className={styles.step_cell_title_text}>
                配置数据集组件
              </span>
            </div>
            <div className={styles.step_cell_content}>
              创建计算任务并配置数据集组件时，选取拥有使用权限的数据集特征列。
            </div>
          </div>

          <div className={styles.step_cell}>
            <div className={styles.step_cell_img}>
              <img src={IMG_EXECUTE} />
            </div>
            <div className={styles.step_cell_title}>
              <span className={styles.step_cell_number}>4</span>
              <span className={styles.step_cell_title_text}>协同计算</span>
            </div>
            <div className={styles.step_cell_content}>
              数据集持有方参与协同计算，并完成计算任务。
            </div>
          </div>
        </div>
      </div>
    </ContentLayout>
  );
};

export default Space;
