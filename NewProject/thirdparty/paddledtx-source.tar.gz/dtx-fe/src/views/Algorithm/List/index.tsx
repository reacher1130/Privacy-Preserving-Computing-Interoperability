import React, {useEffect, useState, ReactNode} from 'react';
import styles from './index.less';
import {useNavigate} from 'react-router-dom';
import {NavKeys, useCurrentNav} from '@/slice/sider';
import type {TablePaginationConfig} from 'antd/es/table';
import Content from '@/components/Content';
import {tdRender} from '@/components/Table/ToolTip';
import Empty from '@components/Empty';

import {
  Algorithm,
  AlgorithmListResponse,
  getAlgorithmList,
  AlgorithmDownloadResponse,
  downLoadAlgorithm,
} from '@/libs/api';
import Table from '@/components/Table';

const {Column} = Table;

const AlgorithmTable: React.FC = () => {
  const pageSize = 10;
  const [loading, setLoading] = useState(false);
  const [pagination, setPagination] = useState<TablePaginationConfig>({
    current: 1,
    pageSize,
  });
  const handleTableChange = (pagination: TablePaginationConfig) => {
    setPagination({
      ...pagination,
    });
  };
  const [data, setData] = useState<AlgorithmListResponse['data']>();
  const getList = () => {
    getAlgorithmList({})
      .then(resp => {
        if (+resp.code === 0) {
          const data = resp.data;
          setData(data);
        }
      })
      .catch(err => {
        console.error(err);
      });
  };

  const [currentItem, setCurrentItem] = useState<Algorithm>();
  const [resps, setResps] = useState<AlgorithmDownloadResponse>();
  const downLoad: (record: Algorithm) => void = record => {
    setCurrentItem(record);
    downLoadAlgorithm(
      {
        name: record.name,
        version: record.version,
      },
      {
        headers: {
          'Content-Type': 'application/octet-stream',
        },
        responseType: 'blob',
      }
    )
      .then(resp => {
        const blob = new Blob([resp], {type: 'application/octet-stream'});
        const URL = window.URL || window.webkitURL;
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        a.download = `${record.file}`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      })
      .catch(err => {
        console.error(err);
      });
  };

  useEffect(() => {
    getList();
  }, []);
  const navigate = useNavigate();
  return (
    <Table
      className={styles.list}
      pagination={pagination}
      dataSource={data?.list}
      loading={loading}
      locale={{emptyText: <Empty msg="暂无数据" />}}
      onChange={handleTableChange}
      rowKey={record => `${record.name}_${Math.random() * 100}`}
    >
      <Column
        title="序号"
        dataIndex="name"
        key="id"
        render={(_: any, recode: Algorithm, index: number) =>
          (pagination.current - 1) * pageSize + index + 1
        }
      />
      <Column
        title="算法名称"
        dataIndex="name"
        key="name"
        render={tdRender({maxWidth: 180})}
      />
      <Column title="算法版本" dataIndex="version" key="version" />
      <Column title="算法类型" dataIndex="type" key="type" />
      <Column
        title="存证hash"
        dataIndex="hash"
        key="hash"
        render={tdRender({maxWidth: 180})}
      />
      <Column
        title="操作"
        key="status"
        render={(_: any, record: Algorithm) => (
          <div className={styles.operate}>
            <span
              className={styles.opname}
              onClick={() =>
                navigate(
                  `/algorithm/detail?name=${record.name}&version=${record.version}`
                )
              }
            >
              查看详情
            </span>
            <span
              className={styles.opname}
              onClick={() => {
                downLoad(record);
              }}
            >
              下载算法
            </span>
          </div>
        )}
      />
    </Table>
  );
};

export default function AlgorithmList() {
  useCurrentNav(NavKeys.algorithmList);
  return (
    <Content>
      <AlgorithmTable />
    </Content>
  );
}
