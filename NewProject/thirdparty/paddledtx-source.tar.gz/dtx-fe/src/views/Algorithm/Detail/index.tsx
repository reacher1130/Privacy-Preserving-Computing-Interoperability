import React, {useEffect, useState} from 'react';
import styles from './index.less';
import {useNavigate, useSearchParams} from 'react-router-dom';
import {NavKeys, useCurrentNav} from '@/slice/sider';
import {Row, Col} from 'antd';
import Content from '@/components/Content';
import TextCopy from '@/components/TextCopy';

import {
  AlgorithmDetailResponse,
  getAlgorithmDetail,
  AlgorithmDownloadResponse,
  downLoadAlgorithm,
} from '@/libs/api';

const STORAGE_METHOD = {
  local: '本地存储',
};

type StorageType = typeof STORAGE_METHOD | {[key: string]: string};

export default function Computing() {
  useCurrentNav(NavKeys.algorithmList);
  const paths = [
    {url: '/algorithm/list', name: '算法列表'},
    {url: '', name: '算法详情'},
  ];
  const [resp, setResp] = useState<AlgorithmDetailResponse['data']>();
  const [search, setSearch] = useSearchParams();
  const name = search.get('name');
  const version = search.get('version');
  const getDetail = () => {
    getAlgorithmDetail({name, version})
      .then(resp => {
        if (+resp.code === 0) {
          const data = resp.data;
          setResp(data);
        }
      })
      .catch(err => {
        console.error(err);
      });
  };
  useEffect(() => {
    getDetail();
  }, []);

  const downLoad: () => void = () => {
    downLoadAlgorithm(
      {
        name,
        version,
      },
      {
        headers: {
          'Content-Type': 'application/octet-stream',
        },
        responseType: 'blob',
      }
    )
      .then(resp => {
        const blob = new Blob([resp], {type: 'application/octet-stream'});
        const URL = window.URL || window.webkitURL;
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        a.download = `${name}.zip`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      })
      .catch(err => {
        console.error(err);
      });
  };

  return (
    <Content paths={paths}>
      <Row className={styles.detailRow}>
        <Col className={styles.col}>算法名称：</Col>
        <Col className={styles.col}>{resp?.name}</Col>
      </Row>
      <Row className={styles.detailRow}>
        <Col className={styles.col}>算法版本：</Col>
        <Col className={styles.col}>{resp?.version}</Col>
      </Row>
      <Row className={styles.detailRow}>
        <Col className={styles.col}>算法文件：</Col>
        <Col className={styles.col}>
          {resp?.file}
          <span onClick={downLoad} className={styles.downloadAlgorithmFile}>
            下载
          </span>
        </Col>
      </Row>
      <Row className={styles.detailRow}>
        <Col className={styles.col}>存储方式：</Col>
        <Col className={styles.col}>
          {STORAGE_METHOD[resp?.storage as keyof StorageType]}
        </Col>
      </Row>
      <Row className={styles.detailRow}>
        <Col className={styles.col}>算法描述：</Col>
        <Col className={styles.col}>{resp?.desc}</Col>
      </Row>
      <Row className={styles.detailRow}>
        <Col className={styles.col}>存证hash：</Col>
        <Col className={styles.col}>
          {resp?.hash ? <TextCopy content={resp?.hash} /> : '--'}
        </Col>
      </Row>
    </Content>
  );
}
