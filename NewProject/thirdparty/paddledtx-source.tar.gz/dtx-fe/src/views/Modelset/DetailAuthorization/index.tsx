import React, {useEffect, useState} from 'react';
import styles from './index.less';
import {useParams} from 'react-router-dom';
import {NavKeys, useCurrentNav} from '@/slice/sider';
import {Row, Col} from 'antd';
import Content from '@/components/Content';
import dayjs, {Dayjs} from 'dayjs';

import {
  ModelsetAuthorizationDetailReponse,
  modelsetAuthorizationDetail,
} from '@/libs/api';

const AUTHORIZATION_STATUS = {
  Unapproved: '申请中',
  Rejected: '已驳回',
  Approved: '已授权',
};
type StatusType = typeof AUTHORIZATION_STATUS | {[key: string]: string};

const AUTH_TYPE = {
  Use: '使用',
};

type AuthType = typeof AUTH_TYPE | {[key: string]: string};

export default function DetailAuthorization() {
  useCurrentNav(NavKeys.modelsetAuthorization);
  const paths = [
    {url: '/modelset/authorization', name: '模型资源授权'},
    {url: '', name: '申请授权详情'},
  ];
  const [resp, setResp] =
    useState<ModelsetAuthorizationDetailReponse['data']>();
  const {authID} = useParams();
  const getDetail = () => {
    modelsetAuthorizationDetail({authID})
      .then(resp => {
        if (+resp.code === 0) {
          const data = resp.data;
          setResp(data);
        }
      })
      .catch(err => {
        console.error(err);
      });
  };

  useEffect(() => {
    getDetail();
  }, []);

  return (
    <Content paths={paths}>
      <Row className={styles.authorizationDetailRow}>
        <Col className={styles.col}>授权类型：</Col>
        <Col className={styles.col}>
          {AUTH_TYPE[resp?.authType as keyof AuthType]}
        </Col>
      </Row>
      <Row className={styles.authorizationDetailRow}>
        <Col className={styles.col}>授权状态：</Col>
        <Col className={styles.col}>
          <span className={styles[resp?.status]}>
            {AUTHORIZATION_STATUS[resp?.status as keyof StatusType]}
          </span>
        </Col>
      </Row>
      <Row className={styles.authorizationDetailRow}>
        <Col className={styles.col}>申请时间：</Col>
        <Col className={styles.col}>
          {resp?.createTime
            ? dayjs.unix(resp?.createTime).format('YYYY-MM-DD HH:mm:ss')
            : '--'}
        </Col>
      </Row>
      <Row className={styles.authorizationDetailRow}>
        <Col className={styles.col}>授权时间：</Col>
        <Col className={styles.col}>
          {resp?.approvalTime
            ? dayjs.unix(resp?.approvalTime).format('YYYY-MM-DD HH:mm:ss')
            : '--'}
        </Col>
      </Row>
      <Row className={styles.authorizationDetailRow}>
        <Col className={styles.col}>授权ID：</Col>
        <Col className={styles.col}>{resp?.authID}</Col>
      </Row>
      <Row className={styles.authorizationDetailRow}>
        <Col className={styles.col}>授权对象ID：</Col>
        <Col className={styles.col}>{resp?.resourceID}</Col>
      </Row>
      <Row className={styles.authorizationDetailRow}>
        <Col className={styles.col}>授权对象名称：</Col>
        <Col className={styles.col}>
          {resp?.resourceName ? resp?.resourceName : '--'}
        </Col>
      </Row>
      <Row className={styles.authorizationDetailRow}>
        <Col className={styles.col}>申请机构名称：</Col>
        <Col className={styles.col}>
          {resp?.applierName ? resp?.applierName : '--'}
        </Col>
      </Row>
      <Row className={styles.authorizationDetailRow}>
        <Col className={styles.col}>申请机构DID：</Col>
        <Col className={styles.col}>
          {resp?.applierDID ? resp?.applierDID : '--'}
        </Col>
      </Row>
      <Row className={styles.authorizationDetailRow}>
        <Col className={styles.col}>申请机构区块链地址：</Col>
        <Col className={styles.col}>{resp?.applier ? resp?.applier : '--'}</Col>
      </Row>
      <Row className={styles.authorizationDetailRow}>
        <Col className={styles.col}>授权机构名称：</Col>
        <Col className={styles.col}>
          {resp?.authorizerName ? resp?.authorizerName : '--'}
        </Col>
      </Row>
      <Row className={styles.authorizationDetailRow}>
        <Col className={styles.col}>授权机构DID：</Col>
        <Col className={styles.col}>
          {resp?.authorizerDID ? resp?.authorizerDID : '--'}
        </Col>
      </Row>
      <Row className={styles.authorizationDetailRow}>
        <Col className={styles.col}>授权机构区块链地址：</Col>
        <Col className={styles.col}>
          {resp?.authorizer ? resp?.authorizer : '--'}
        </Col>
      </Row>
    </Content>
  );
}
