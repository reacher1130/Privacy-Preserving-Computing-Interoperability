import React, {PropsWithChildren, useEffect, useState} from 'react';
import {useNavigate, Link} from 'react-router-dom';
import {message, Popover} from 'antd';
import {useSelector, useDispatch} from 'react-redux';
import {PlusOutlined} from '@ant-design/icons';
import styles from './style.less';
import AddSpaceForm from './AddSpaceForm';
import {NavKeys, useCurrentNav} from '@/slice/sider';
import Select from '@/components/Select';
import Content from '@/components/Content';
import {
  updateList,
  updatePageNo,
  InitialType as ModelsetInitialType,
} from '@/slice/modelset';
// import DateRange from '@/components/TimeRange';
import DateRange from '@/components/DateRange';
import Button from '@/components/Button';
import ModalBox from '@/components/Modal';
import Table from '@/components/Table';
import dayjs, {Dayjs} from 'dayjs';
import {tdRender} from '@/components/Table/ToolTip';
import Question from '@/components/Question';
import ErrorCode from '@/libs/errorCode';
import ExpiredTimeText from '@/components/ExpireTimeText';
import DotStatus from '@/components/DotStatus';

import {
  Modelset,
  ModelsetListResponse,
  fetchModelsetList,
  deleteModelset,
  publishModelset,
  offlineModelset,
  onlineModelset,
  ModelsetSpaceListResponse,
  getModelsetSpaceList,
} from '@/libs/api';
import {PwD} from '../PermissonWrap';
import {PermissionValue} from '@/pages/Account/PermissionCreator';
const ALL_SPACE = '全部空间';
const ALL_STATUS = 0;

export interface MineProps {
  name?: string;
}

const statusList = [
  {
    value: 0,
    label: '全部状态',
  },
  {
    value: 2,
    label: '已新增',
  },
  {
    value: 3,
    label: '已发布',
  },
  {
    value: 6,
    label: '已下线',
  },
];

interface MineHeaderProps extends PropsWithChildren {
  onSpaceChange?: (space: string) => void;
  onStatusChange?: (status: number | undefined) => void;
  // onStartChange?: (time: TimeType) => void;
  // onEndChange?: (time: TimeType) => void;
  onTimeRangeChange: (range: {startTime: number; endTime: number}) => void;
  space?: string;
  status?: number;
}
interface TimeType {
  value?: number;
  dateString?: string;
}
const MineHeader: React.FC<MineHeaderProps> = (props: MineHeaderProps) => {
  const {onSpaceChange, onTimeRangeChange, space, onStatusChange, status} =
    props;
  // 初始化空间选项值
  const [showAdd, setShowAdd] = useState(false);
  const [spaceList, setSpaceList] = useState<ModelsetSpaceListResponse['data']>(
    []
  );
  const close: (e?: any) => void = () => {
    setShowAdd(false);
  };

  const navigate = useNavigate();
  const getSpaceList = () => {
    getModelsetSpaceList().then(resp => {
      if (+resp.code === 0) {
        const list = resp.data;
        list.unshift(ALL_SPACE);
        setSpaceList(resp.data);
      }
    });
  };
  useEffect(() => {
    getSpaceList();
  }, []);
  return (
    <>
      <div className={styles.header}>
        <div className={styles.search_container}>
          <div className={styles.grid}>
            <Select
              onChange={onSpaceChange}
              placeholder="全部空间"
              optsList={spaceList}
              value={space || spaceList[0]}
            />
          </div>
          <div className={styles.grid}>
            <Select
              onChange={onStatusChange}
              placeholder="全部状态"
              optsList={statusList}
              value={status || ALL_STATUS}
            />
          </div>
          <div className={styles.grid}>
            <DateRange allowClear onChange={onTimeRangeChange} />
          </div>
        </div>
        <div className={styles.button_container}>
          <div className={styles.grid}>
            <PwD rP={PermissionValue.Write}>
              <Button
                onClick={() => setShowAdd(true)}
                type="primary"
                icon={<PlusOutlined />}
              >
                新增资源空间
              </Button>
            </PwD>
          </div>
          <div className={styles.grid}>
            <PwD rP={PermissionValue.Write}>
              <Button
                type="primary"
                icon={<PlusOutlined />}
                onClick={() => navigate('/modelset/create')}
              >
                新增模型资源
              </Button>
            </PwD>
          </div>
        </div>
      </div>
      <ModalBox
        open={showAdd}
        title="新增资源空间"
        hideCancelBtn
        hideOkBtn
        onCancel={() => {
          setShowAdd(false);
        }}
      >
        <AddSpaceForm close={close} />
      </ModalBox>
    </>
  );
};

export default function Mine() {
  const dispatch = useDispatch();
  useCurrentNav(NavKeys.modelsetMine);
  const columns = [
    {
      title: '模型资源',
      dataIndex: 'id',
      key: 'id',
      render: (_: any, record: Modelset) => {
        return <div style={{maxWidth: '30px'}}>{record?.id}</div>;
      },
    },
    {
      title: '任务ID',
      dataIndex: 'taskID',
      key: 'taskID',
      render: tdRender({maxWidth: 160}),
    },
    {
      title: '模型资源名称',
      dataIndex: 'resourceName',
      key: 'resourceName',
    },
    {
      title: '资源空间',
      dataIndex: 'namespace',
      key: 'namespace',
    },
    {
      title: '资源状态',
      dataIndex: 'status',
      key: 'status',
      render: (_: any, record: Modelset) => {
        switch (_) {
          case 2:
            return (
              <DotStatus type="green">
                已新增
                <Question
                  content="仅支持标签方将已训练完成的模型新增为模型资源"
                  style={{marginLeft: '5px'}}
                />
              </DotStatus>
            );
          case 3:
            return (
              <DotStatus type="green">
                已发布
                <Question
                  content="已发布上链，不支持删除链上模型资源"
                  style={{marginLeft: '5px'}}
                />
              </DotStatus>
            );
          case 6:
            return (
              <DotStatus type="orange">
                已下线
                <Question
                  content="模型资源已下线，不再为使用方提供服务，如需恢复服务可重新上线"
                  style={{marginLeft: '5px'}}
                />
              </DotStatus>
            );
          case 9:
            return (
              <DotStatus type="orange">
                已过期
                <Question
                  content="模型资源已过期，不再为使用方提供服务，如需恢复服务可重新上线"
                  style={{marginLeft: '5px'}}
                />
              </DotStatus>
            );
          default:
            break;
        }
      },
    },
    {
      title: '存证hash',
      dataIndex: 'tx_id',
      key: 'tx_id',
      render: tdRender({maxWidth: 160}),
    },

    {
      title: '过期时间',
      dataIndex: 'expireTime',
      key: 'expireTime',
      render: (_: any, record: Modelset) => {
        return (
          <div style={{maxWidth: '200px'}}>
            <ExpiredTimeText time={record?.expireTime} />
          </div>
        );
      },
    },
    {
      title: '操作',
      key: 'action',
      dataIndex: 'resourceID',
      render: (resourceID: string, record: Modelset) => {
        return (
          <>
            <Link
              to={`/modelset/detail/${record.resourceID}`}
              className={styles.operate}
            >
              详情
            </Link>
            <PwD rP={PermissionValue.Write}>
              {record.status === 6 && (
                <span
                  className={styles.operate}
                  onClick={() => onlineModel(record.resourceID)}
                >
                  上线
                </span>
              )}
              {record.status === 3 && (
                <span
                  className={styles.operate}
                  onClick={() => offlineModel(record.resourceID)}
                >
                  下线
                </span>
              )}
              {record.status === 2 && (
                <span
                  className={styles.operate}
                  onClick={() => publishModel(record.resourceID)}
                >
                  发布
                </span>
              )}
              {record.status !== 3 && record.status !== 6 && (
                <span
                  className={styles.operate}
                  onClick={() => deleteModel(record.resourceID)}
                >
                  删除
                </span>
              )}
            </PwD>
          </>
        );
      },
    },
  ];
  const pageSize = 10;
  const {list, currentPageNo} = useSelector<
    {Modelset: ModelsetInitialType},
    ModelsetInitialType
  >(state => state.Modelset);
  const [pageNo, setPageNo] = useState(currentPageNo);
  const [resp, setResp] = useState<ModelsetListResponse['data']>({
    total: 0,
    list: [],
  });
  const [messageApi, contextHolder] = message.useMessage();

  const [modalInfo, setModalInfo] = useState({
    title: '',
    content: '',
    open: false,
    onOk: () => {},
  });
  const resetModalInfo = () =>
    setModalInfo({
      open: false,
      title: '',
      content: '',
      onOk: () => {},
    });

  const [space, setSpace] = useState(undefined);
  const [status, setStatus] = useState(undefined);
  const [startTime, setStart] = useState<number>();
  const [endTime, setEnd] = useState<number>();

  const spaceChange: (space: string) => void = space => {
    dispatch(updatePageNo(1));
    if (space === ALL_SPACE) {
      space = undefined;
    }
    setSpace(space);
  };
  const statusChange: (status: number | undefined) => void = status => {
    dispatch(updatePageNo(1));
    // setPageNo(1);
    if (status === ALL_STATUS) {
      status = undefined;
    }
    setStatus(status);
  };
  const timeRangeChange: (range: {
    startTime: number;
    endTime: number;
  }) => void = range => {
    dispatch(updatePageNo(1));
    setStart(range.startTime);
    setEnd(range.endTime);
  };

  const getList = () => {
    fetchModelsetList({
      pageNo: currentPageNo,
      pageSize,
      namespace: space,
      status,
      startTime: startTime,
      endTime: endTime,
    }).then(resp => {
      if (+resp.code === 0) {
        const list = resp?.data?.list;
        dispatch(updateList({list, currentPageNo}));
        setResp({
          total: resp.data.total,
          list,
        });
      } else {
        // 错误提示 后续增加统一的code判断方法，参照后端错误列表
        messageApi.error('系统错误请稍后重试');
      }
    });
  };

  useEffect(() => {
    getList();
  }, [currentPageNo, space, startTime, endTime, status]);

  const [resourceID, setResourceID] = useState('');
  const onDelete: (resourceID: string) => void = resourceID => {
    deleteModelset({resourceID})
      .then(resp => {
        resetModalInfo();
        if (+resp.code === 0) {
          messageApi.success('删除成功');
          // 更新列表
          getList();
        } else {
          messageApi.error(ErrorCode[resp.code] || '删除失败');
        }
      })
      .catch(err => {
        messageApi.error('网络异常，请稍后再试');
        console.error(err);
      });
  };
  const onPublish: (resourceID: string) => void = resourceID => {
    publishModelset({resourceID})
      .then(resp => {
        resetModalInfo();
        if (+resp.code === 0) {
          messageApi.success('发布成功');
          // 更新列表
          getList();
        } else {
          messageApi.error(ErrorCode[resp.code] || '发布失败');
        }
      })
      .catch(err => {
        messageApi.error('网络异常，请稍后再试');
        console.error(err);
      });
  };
  const onOnline: (resourceID: string) => void = resourceID => {
    onlineModelset({resourceID})
      .then(resp => {
        resetModalInfo();
        if (+resp.code === 0) {
          messageApi.success('上线成功');
          // 更新列表
          getList();
        } else {
          messageApi.error(ErrorCode[resp.code] || '上线失败');
        }
      })
      .catch(err => {
        messageApi.error('网络异常，请稍后再试');
        console.error(err);
      });
  };
  const onOffline: (resourceID: string) => void = resourceID => {
    offlineModelset({resourceID})
      .then(resp => {
        resetModalInfo();
        if (+resp.code === 0) {
          messageApi.success('下线成功');
          // 更新列表
          getList();
        } else {
          messageApi.error(ErrorCode[resp.code] || '下线失败');
        }
      })
      .catch(err => {
        messageApi.error('网络异常，请稍后再试');
        console.error(err);
      });
  };
  const deleteModel: (resourceID: string) => void = resourceID => {
    setResourceID(resourceID);
    setModalInfo({
      open: true,
      title: '删除模型资源',
      content:
        '模型资源删除后不可恢复，发布到链上的相关模型资源也将不可使用，是否确认删除',
      onOk: () => onDelete(resourceID),
    });
  };

  const publishModel: (resourceID: string) => void = resourceID => {
    setResourceID(resourceID);
    setModalInfo({
      open: true,
      title: '发布模型资源',
      content:
        '将模型资源发布到目录链上，已发布的模型资源不允许删除，且不能重复发布，是否确认发布',
      onOk: () => onPublish(resourceID),
    });
  };

  const onlineModel: (resourceID: string) => void = resourceID => {
    setResourceID(resourceID);
    setModalInfo({
      open: true,
      title: '上线模型资源',
      content: '模型资源上线，是否确认上线',
      onOk: () => onOnline(resourceID),
    });
  };

  const offlineModel: (resourceID: string) => void = resourceID => {
    setResourceID(resourceID);
    setModalInfo({
      open: true,
      title: '下线模型资源',
      content: '模型资源下线，是否确认下线',
      onOk: () => onOffline(resourceID),
    });
  };

  return (
    <Content>
      <MineHeader
        space={space}
        onSpaceChange={spaceChange}
        status={status}
        onStatusChange={statusChange}
        onTimeRangeChange={timeRangeChange}
      />
      {contextHolder}
      <Table
        className={styles.list}
        columns={columns}
        pagination={{
          total: resp.total,
          current: currentPageNo,
          pageSize,
          onChange(page = 1) {
            dispatch(updatePageNo(page));
          },
        }}
        dataSource={list}
        rowKey={record => {
          return record.id + Date.now();
        }}
      />
      <ModalBox
        open={modalInfo?.open}
        title={modalInfo?.title}
        onCancel={() => resetModalInfo()}
        onOk={modalInfo?.onOk}
      >
        {modalInfo?.content}
      </ModalBox>
    </Content>
  );
}
