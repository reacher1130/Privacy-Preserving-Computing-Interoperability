import React, {PropsWithChildren, useEffect, useState} from 'react';
import {Form, Input, Space, message} from 'antd';
import {useSelector, useDispatch} from 'react-redux';
import styles from './index.less';
import Button from '@/components/Button';
import NumberCounter from '@/components/Counter';
import {
  Modelset,
  addModelsetSpace,
  fetchModelsetList,
  AddModelsetSpaceRequest,
  modelsetNamespaceReplicaLimit,
} from '@/libs/api';
import {updateList, InitialType as ModelsetInitialType} from '@/slice/modelset';
import ErrorCode from '@/libs/errorCode';

interface AddSpaceFormProps extends PropsWithChildren {
  close: (e?: any) => void;
}
const {TextArea} = Input;

const AddSpaceForm: React.FC<AddSpaceFormProps> = (
  props: AddSpaceFormProps
) => {
  const [form] = Form.useForm();
  const formItemLayout = {
    labelCol: {span: 3},
    wrapperCol: {span: 21},
  };
  const buttonItemLayout = {
    wrapperCol: {span: 21, offset: 3},
  };
  const dispatch = useDispatch();
  const [messageApi, contextHolder] = message.useMessage();
  const {list, currentPageNo: pageNo} = useSelector<
    {Modelset: ModelsetInitialType},
    ModelsetInitialType
  >(state => state.Modelset);
  const pageSize = 10;

  const [submitting, setSubmitting] = useState(false);

  const getList = () => {
    fetchModelsetList({pageNo, pageSize})
      .then(resp => {
        if (+resp.code === 0) {
          dispatch(updateList({list: list as Modelset[], pageNo}));
        } else {
          messageApi.error('系统错误请稍后重试');
        }
      })
      .catch(err => {
        console.error(err);
      });
  };

  // const [replicaLimit, setReplicaLimit] = useState(0);
  // useEffect(() => {
  //     modelsetNamespaceReplicaLimit().then(resp => {
  //         if (resp.code === '0') {
  //             setReplicaLimit(resp.data);
  //         }
  //         else {
  //             messageApi.error(ErrorCode[resp.code]);
  //         }
  //     }, console.error);
  // }, []);

  const addSpace: (parms: AddModelsetSpaceRequest) => void = ({
    name,
    replica = 2,
    description = '',
  }) => {
    addModelsetSpace({name, replica, description})
      .then(resp => {
        if (+resp.code === 0) {
          messageApi.success('新增模型资源空间成功');
          getList();
        } else {
          // 错误提示 后续增加统一的code判断方法，参照后端错误列表
          const msg = ErrorCode[resp.code] || '新增模型资源空间失败';
          messageApi.error(msg);
        }
        setSubmitting(false);
      })
      .catch(err => {
        messageApi.error('系统错误请稍后重试');
        console.error(err);
        setSubmitting(false);
      });
  };

  let timer: number | null = null;

  const onFinish = (values: any) => {
    // 提交数据, 请求创建新的资源空间, 请求成功后更新列表，注意分页
    // console.log(values);
    if (submitting) {
      return false;
    }
    setSubmitting(true);
    addSpace(values);
    timer = window.setTimeout(() => {
      form.resetFields();
      props.close?.();
    }, 3000);
  };
  useEffect(() => {
    return () => {
      timer && window.clearTimeout(timer);
      timer = null;
    };
  }, []);
  const countChange: (info: {
    value: string;
    count: number;
    maxLength?: number;
  }) => string = info => {
    const {count, maxLength} = info;
    return `${count} / ${maxLength}`;
  };
  return (
    <>
      {contextHolder}
      <Form
        {...formItemLayout}
        layout="horizontal"
        form={form}
        className={styles.form}
        onFinish={onFinish}
        onValuesChange={console.log}
      >
        <Form.Item
          label="名称"
          name="name"
          className={styles.formItem}
          rules={[
            {
              required: true,
              message: '请输入名称',
            },
            {
              min: 4,
              max: 20,
              message: '请输入名称，4到20个字符',
            },
          ]}
        >
          <Input placeholder="请输入名称" autoComplete="off" />
        </Form.Item>
        {/* <Form.Item
                    label="文件副本数量"
                    name="replica"
                    rules={[{required: true}]}
                    initialValue={1}
                    extra={`当前有${replicaLimit}个存储节点，副本数不能大于存储节点数量`}
                >
                    <NumberCounter max={replicaLimit} min={1} disabled={replicaLimit === 0} />
                </Form.Item> */}
        <Form.Item
          label="简介"
          name="description"
          rules={[
            // {
            //     required: true,
            //     message: '请输入简介',
            // },
            {
              max: 140,
              message: '简介限制在140字以内，请精简内容',
            },
          ]}
        >
          <TextArea
            maxLength={140}
            showCount={{formatter: countChange}}
            placeholder="请输入简介"
            className={styles.inputTextarea}
            autoComplete="off"
          />
        </Form.Item>
        <Form.Item {...buttonItemLayout} style={{textAlign: 'right'}}>
          <Space size="middle">
            <Button
              htmlType="button"
              onClick={() => {
                props.close?.();
                form.resetFields();
              }}
            >
              取消
            </Button>
            <Button htmlType="submit" type="primary">
              确认
            </Button>
          </Space>
        </Form.Item>
      </Form>
    </>
  );
};

export default AddSpaceForm;
