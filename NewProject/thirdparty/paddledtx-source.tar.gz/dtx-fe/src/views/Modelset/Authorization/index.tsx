/* eslint-disable react/jsx-no-bind */
import React, {PropsWithChildren, useEffect, useState, memo} from 'react';
import {message, Input, Tabs} from 'antd';
import type {TablePaginationConfig} from 'antd/es/table';
import cx from 'classnames';
import {useNavigate} from 'react-router';
import dayjs from 'dayjs';
import type {TabsProps} from 'antd';
import Content from '@/components/Content';
import ModalBox from '@/components/Modal';
import SingleDatePicker from '@/components/SingleDatePicker';
import {NavKeys, useCurrentNav} from '@/slice/sider';
import {tdRender} from '@/components/Table/ToolTip';
import Empty from '@components/Empty';
import ErrorCode from '@/libs/errorCode';
import DotStatus, {DotStatusProps} from '@/components/DotStatus';

import {
  ModelsetAuthorizationPart,
  ModelsetAuthorizationListResponse,
  modelsetAuthorizationList,
  modelsetAuthorizationPass,
  modelsetAuthorizationReject,
  AuthStatus,
} from '@/libs/api';
import {PermissionValue} from '@/pages/Account/PermissionCreator';
import Table from '@/components/Table';
import {PwD} from '../PermissonWrap';
import styles from './index.less';

export interface AuthorizationProps {}
type AuthorizationType = React.FC<AuthorizationProps>;

const {Column} = Table;

const AUTHORIZATION_STATUS = {
  Unapproved: '申请中',
  Rejected: '已驳回',
  Approved: '已授权',
};

type StatusType = typeof AUTHORIZATION_STATUS | {[key: string]: string};

const AUTH_TYPE = {
  Use: '使用',
};

type AuthType = typeof AUTH_TYPE | {[key: string]: string};

interface AuthTableProps extends PropsWithChildren {
  authType: string;
}

const AuthorizationTable: React.FC<AuthTableProps> = (
  props: AuthTableProps
) => {
  const navigate = useNavigate();
  const [showGrant, setShowGrant] = useState(false);
  const [showReject, setShowReject] = useState(false);
  const [record, setRecord] = useState<ModelsetAuthorizationPart>();
  const [timeStamp, setTimeStamp] = useState<number | undefined>();
  const [error, setError] = useState('');
  const [rejectReason, setRejectReason] = useState('');
  const [rejectStep, setRejectStep] = useState(1);
  const [messageApi, contextHolder] = message.useMessage();

  const {authType} = props;
  const pageSize = 10;
  const [loading, setLoading] = useState(false);
  const [pagination, setPagination] = useState<TablePaginationConfig>({
    current: 1,
    pageSize,
  });
  const handleTableChange = (pagination: TablePaginationConfig) => {
    setPagination({
      ...pagination,
    });
  };

  const [data, setData] = useState<ModelsetAuthorizationListResponse['data']>();
  const getList = () => {
    modelsetAuthorizationList({type: authType})
      .then(resp => {
        if (+resp.code === 0) {
          const data = resp?.data;
          setData(data);
        }
      })
      .catch(err => {
        console.error(err);
      });
  };

  useEffect(() => {
    getList();
  }, []);
  // 点击授权
  const onGrantClick: (record: ModelsetAuthorizationPart) => void = record => {
    setShowGrant(true);
    setRecord(record);
  };

  // 授权
  const toGrant = () => {
    if (!timeStamp) {
      setError('请设置授权到期时间');
      return false;
    }
    setShowGrant(false);
    const {authID} = record;
    modelsetAuthorizationPass({authID, status: 'pass', expireTime: timeStamp})
      .then(resp => {
        if (+resp.code === 0) {
          messageApi.success('授权成功');
          getList();
        } else {
          const msg = ErrorCode[resp.code] || '授权失败';
          messageApi.error(msg);
        }
      })
      .catch(err => {
        console.error(err);
        messageApi.error('授权失败');
      });
  };

  const onTimeChange = (timeStamp: number) => {
    setTimeStamp(Math.floor(timeStamp / 1000));
    setError('');
  };

  // 点击驳回
  const onRejectClick: (record: ModelsetAuthorizationPart) => void = record => {
    setShowReject(true);
    setRecord(record);
  };

  // 驳回
  const toRject = () => {
    if (rejectReason?.length === 0) {
      setError('请输入驳回理由');
      return false;
    }
    if (rejectStep === 1) {
      setRejectStep(2);
      return false;
    }
    if (rejectStep === 2) {
      setShowReject(false);
      const {authID} = record;
      modelsetAuthorizationReject({
        authID,
        status: 'reject',
        reason: rejectReason,
      })
        .then(resp => {
          if (+resp.code === 0) {
            messageApi.success('驳回成功');
            getList();
          } else {
            const msg = ErrorCode[resp.code] || '驳回失败';
            messageApi.error(msg);
          }
        })
        .catch(err => {
          console.error(err);
          messageApi.error('驳回失败');
        });
    }
  };

  const onReasonChange: React.ChangeEventHandler<
    HTMLTextAreaElement
  > = event => {
    setRejectReason(event.target.value);
    setError('');
  };

  useEffect(() => {
    setError('');
    setRejectReason('');
    setRejectStep(1);
  }, [showGrant, showReject]);

  return (
    <>
      <Table
        className={styles.list}
        pagination={pagination}
        dataSource={data?.list}
        loading={loading}
        locale={{emptyText: <Empty msg="暂无数据" />}}
        onChange={handleTableChange}
        rowKey={record => `${record.authID}_${Math.random() * 100}`}
      >
        <Column
          title="授权ID"
          dataIndex="authID"
          key="authID"
          render={tdRender({maxWidth: 180})}
        />
        <Column
          title="授权对象ID"
          dataIndex="resourceID"
          key="resourceID"
          render={tdRender({maxWidth: 180})}
        />
        <Column
          title="授权类型"
          dataIndex="authType"
          key="authType"
          render={authType => (
            <span>{AUTH_TYPE[authType as keyof AuthType]}</span>
          )}
        />
        <Column
          title="授权对象名称"
          dataIndex="resourceName"
          key="resourceName"
          render={tdRender({maxWidth: 180})}
        />
        <Column
          title="申请时间"
          dataIndex="createTime"
          key="createTime"
          render={createTime =>
            createTime
              ? dayjs.unix(createTime).format('YYYY-MM-DD HH:mm:ss')
              : '--'
          }
        />
        <Column
          title="授权到期时间"
          dataIndex="expireTime"
          key="expireTime"
          render={expireTime =>
            expireTime
              ? dayjs.unix(expireTime).format('YYYY-MM-DD HH:mm:ss')
              : '--'
          }
        />
        <Column
          title="授权状态"
          dataIndex="status"
          key="status"
          render={(status: AuthStatus) => {
            let className: DotStatusProps['type'] = null;
            switch (status) {
              case AuthStatus.Approved:
                className = 'green';
                break;
              case AuthStatus.Unapproved:
                className = 'blue';
                break;
              case AuthStatus.Rejected:
                className = 'orange';
            }
            return (
              <DotStatus type={className}>
                {AUTHORIZATION_STATUS[status]}
              </DotStatus>
            );
          }}
        />
        <Column
          title="操作"
          key="operate"
          render={(_: any, record: ModelsetAuthorizationPart) => {
            return (
              <div className={styles.operate}>
                <span
                  className={styles.opname}
                  onClick={() =>
                    navigate(`/modelset/authorization/detail/${record?.authID}`)
                  }
                >
                  查看详情
                </span>
                <PwD rP={PermissionValue.Write}>
                  {authType === 'auth' &&
                    record.status !== 'Approved' &&
                    record.status !== 'Rejected' && (
                      <span
                        className={styles.opname}
                        onClick={() => onGrantClick(record)}
                      >
                        授权
                      </span>
                    )}
                  {authType === 'auth' &&
                    record.status !== 'Approved' &&
                    record.status !== 'Rejected' && (
                      <span
                        className={styles.opname}
                        onClick={() => onRejectClick(record)}
                      >
                        驳回
                      </span>
                    )}
                </PwD>
              </div>
            );
          }}
        />
      </Table>
      <ModalBox
        open={showGrant}
        title="过期时间"
        width={483}
        onCancel={() => {
          setShowGrant(false);
        }}
        onOk={toGrant}
      >
        <div className={styles.grantRow}>
          <div className={cx(styles.col, styles.label)}>
            <i>*</i> 授权过期时间：
          </div>
          <div className={styles.col}>
            <SingleDatePicker
              onChange={onTimeChange}
              placeholder="请选择过期时间"
              disabledDate={SingleDatePicker.disabledFromNow}
            />
          </div>
        </div>
        {error && (
          <div className={styles.authorizationError}>请设置授权到期时间</div>
        )}
      </ModalBox>
      <ModalBox
        open={showReject}
        title="申请驳回"
        width={320}
        onCancel={() => {
          setShowReject(false);
        }}
        onOk={toRject}
      >
        {rejectStep === 2 && (
          <div className={styles.rejectNote}>
            确定将该申请驳回么？操作不支持撤销
          </div>
        )}
        {rejectStep === 1 && (
          <div className={styles.rejectRow}>
            <div className={cx(styles.col, styles.label)}>
              <i>*</i> 驳回理由：
            </div>
            <div className={styles.col}>
              <Input.TextArea
                maxLength={200}
                placeholder="请输入驳回理由"
                autoSize={false}
                onChange={onReasonChange}
                value={rejectReason}
              />
            </div>
          </div>
        )}
        {error && (
          <div className={styles.modelsetAuthRejectError}>请输入驳回理由</div>
        )}
      </ModalBox>
      {contextHolder}
    </>
  );
};

const AuthorizationTableMemo = memo(AuthorizationTable);

const Authorization: AuthorizationType = props => {
  useCurrentNav(NavKeys.modelsetAuthorization);
  const [authType, setAuthType] = useState('apply');

  const items: TabsProps['items'] = [
    {
      key: 'apply',
      label: '我的申请',
      children: <AuthorizationTableMemo authType={authType} />,
    },
    {
      key: 'auth',
      label: '我的授权',
      children: <AuthorizationTableMemo authType={authType} />,
    },
  ];

  const onTabChange = (key: string) => {
    setAuthType(key);
  };
  return (
    <Content>
      <Tabs defaultActiveKey="apply" items={items} onChange={onTabChange} />
    </Content>
  );
};

export default Authorization;
