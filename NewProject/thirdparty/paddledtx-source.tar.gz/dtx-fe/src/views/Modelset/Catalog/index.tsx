import React, {Children, ReactNode, useEffect, useState, useRef} from 'react';
import {useSearchParams} from 'react-router-dom';
import styles from './style.less';
import Content from '@/components/Content';
import {CarryOutOutlined, DownOutlined, LinkOutlined} from '@ant-design/icons';
import {Tree, Row, Col, message, Select} from 'antd';
import type {DataNode} from 'antd/es/tree';
import Button from '@/components/Button';
import ModalBox from '@/components/Modal';
import {NavKeys, useCurrentNav} from '@/slice/sider';
import dayjs, {Dayjs} from 'dayjs';
import TextCopy from '@/components/TextCopy';
import ErrorCode from '@/libs/errorCode';
import Table from '@/components/Table';

import {
  modelNamespaceOrgStat,
  ModelsetCatalogFile,
  ModelsetCatalogListResponse,
  getModelsetCatalogList,
  ModelsetCatalogDetailResponse,
  getModelsetCatalogDetail,
  modelsetCatalogApply,
} from '@/libs/api';
import {PwD} from '../PermissonWrap';
import {PermissionValue} from '@/pages/Account/PermissionCreator';

const {Column} = Table;
const {DirectoryTree} = Tree;

type TreeNode = {
  title: string | ReactNode;
  key: string;
  icon?: ReactNode;
  parentId: string | undefined;
  children?: any[];
  isLeaf?: boolean;
  selectable?: boolean;
};

export default function () {
  useCurrentNav(NavKeys.modelsetSpace);
  let [searchParams, setSearchParams] = useSearchParams();
  const queryId = searchParams.get('resourceID'); // 当前选中查看的资源ID
  const [orgData, setOrgData] = useState(null); // 机构下拉列表
  const [orgID, setOrgID] = useState(searchParams.get('orgID') || ''); // 当前机构id
  const first = useRef(!!queryId);
  const defaultKey = useRef('');
  const [resourceID, setResourceID] = useState(queryId);

  useEffect(() => {
    setResourceID(queryId);
  }, [queryId]);

  const [treeData, setTreeData] = useState<DataNode[]>();
  const [detail, setDetail] = useState<ModelsetCatalogDetailResponse['data']>();

  const rootEvent: (
    data: ModelsetCatalogListResponse['data'],
    key: string
  ) => void = (data, key) => {
    const val = data[key];
    if (val && val.length === 0) {
      setDetail(undefined);
    }
  };
  function transObjToArr(
    catalogData: ModelsetCatalogListResponse['data']
  ): TreeNode[] {
    const keys = Object.keys(catalogData);
    let list: TreeNode[] = [];
    keys.forEach((key, index) => {
      list.push({
        title: key,
        parentId: undefined,
        key: `${index}`,
        selectable: false,
      });
      const item: ModelsetCatalogFile[] = catalogData[key];
      if (item.length) {
        item.forEach((node, dex) => {
          // if (index === 0 && dex === 0) {
          //     // 初始化请求参数
          //     setResourceID(node.fileID);
          // }
          // list.push({
          //     title: (<span onClick={() => setResourceID(node.fileID)}>{node.fileName}</span>),
          //     parentId: `${index}`,
          //     key: `${index}-${dex}`,
          //     isLeaf: true,
          // });
          if (!first.current) {
            console.log(first.current, node);
            first.current = true;
            setResourceID(node.fileID);
          }

          list.push({
            title: node.fileName,
            parentId: `${index}`,
            isLeaf: true,
            icon: <LinkOutlined />,
            key: `${index}_${node.fileID}`,
          });
        });
      }
    });
    return list;
  }

  function convert(data: TreeNode[]): DataNode[] {
    const tree: DataNode[] = [];
    let map: {[key: string]: any} = {};
    data.forEach(item => {
      item.children = [];
      map[item.key] = item;
    });
    data.forEach(item => {
      if (item.parentId) {
        if (resourceID && item.key.includes(resourceID)) {
          defaultKey.current = item.key;
        } else if (!defaultKey.current) {
          defaultKey.current = item.key;
        }
        map[item.parentId].children.push(item);
      } else {
        tree.push(item);
      }
    });
    return tree;
  }

  const getList = (orgName?: string) => {
    getModelsetCatalogList({orgName})
      .then(resp => {
        if (+resp.code === 0) {
          const list = transObjToArr(resp.data);
          const tree: DataNode[] = convert(list);
          setTreeData(tree);
        }
      })
      .catch(err => {
        console.error(err);
      });
  };

  const getOrgsList = () => {
    modelNamespaceOrgStat().then(resp => {
      if (+resp.code === 0) {
        const orgData = resp.data.list.map(v => {
          return {
            value: v.orgID,
            label: v.orgName,
          };
        });
        orgData.unshift({
          value: '',
          label: '全部',
        });
        if (orgID) {
          getList(orgData.find(o => o.value === orgID).label);
        } else {
          getList();
        }
        setOrgData(orgData);
      }
    });
  };

  useEffect(() => {
    getOrgsList();
  }, [orgID]);

  const getDetail = () => {
    getModelsetCatalogDetail({resourceID})
      .then(resp => {
        if (+resp.code === 0) {
          setDetail(resp.data);
        }
      })
      .catch(err => {
        console.error(err);
      });
  };

  useEffect(() => {
    resourceID && getDetail();
  }, [resourceID]);

  const [relateData, setRelateData] = useState([]);
  useEffect(() => {
    const relateList = [
      {
        name: `${detail?.orgName ? detail?.orgName : '--'}`,
        role: '标签方（即训练任务发起方）',
      },
      {
        name: `${detail?.partner ? detail?.partner : '--'}`,
        role: '协同方（即训练任务参与方）',
      },
    ];
    setRelateData(relateList);
    return () => {};
  }, [JSON.stringify(detail)]);

  const [showApply, setShowApply] = useState(false);
  const [messageApi, contextHolder] = message.useMessage();

  const toApply = () => {
    setShowApply(false);
    modelsetCatalogApply({resourceID, authType: 'Use'})
      .then(resp => {
        if (+resp.code === 0) {
          messageApi.success('申请成功');
        } else {
          const msg = ErrorCode[resp.code] || '申请失败';
          messageApi.error(msg);
        }
      })
      .catch(err => {
        console.error(err);
        messageApi.error('系统错误请稍后重试');
      });
  };
  const getNum = (min: number, max: number) =>
    Math.floor(Math.random() * (max - min + 1)) + min;
  const paths = [
    {url: '/modelset/space', name: '模型资源空间'},
    {url: '', name: '模型资源目录'},
  ];
  return (
    <Content paths={paths}>
      <div className={styles.catalogFlexbox}>
        <div className={styles.catalogCol}>
          {orgData ? (
            <Select
              className={styles.orgSelect}
              options={orgData}
              defaultValue={orgID || ''}
              style={{display: 'block', marginRight: '10px'}}
              onChange={value => {
                if (value) {
                  setSearchParams({orgID: value});
                } else {
                  setSearchParams({});
                }
                first.current = false;
                defaultKey.current = '';
                setResourceID(null);
                setOrgID(value);
              }}
            />
          ) : (
            ''
          )}
          {treeData && (
            <DirectoryTree
              onSelect={([selectedKeys]) => {
                console.log(selectedKeys);
                const [head, ...tail] = selectedKeys.toString().split('_');
                const key = tail.join('_');
                setResourceID(key);
                setSearchParams({resourceID: key, orgID});
                defaultKey.current = selectedKeys as string;
              }}
              defaultExpandAll
              selectedKeys={[defaultKey.current]}
              switcherIcon={<DownOutlined />}
              treeData={treeData}
              className={styles.tree}
            />
          )}
        </div>
        <div className={styles.catalogCol}>
          <div className={styles.title}>
            <strong>{detail?.name}</strong>
          </div>
          <div className={styles.info}>
            {/* {resourceID && detail && !detail?.fromOwn && (
                            <div className={styles.operateBox}>
                                <PwD rP={PermissionValue.Write}>
                                    <Button
                                        className={styles.btn}
                                        type="primary"
                                        onClick={() => setShowApply(true)}
                                    >
                                        申请使用
                                    </Button>
                                </PwD>
                            </div>
                        )} */}
            {resourceID && (
              <div className={styles.operateBox}>
                <PwD rP={PermissionValue.Write}>
                  <Button
                    className={styles.btn}
                    type="primary"
                    onClick={() => setShowApply(true)}
                    disabled={detail?.fromOwn}
                  >
                    申请使用
                  </Button>
                </PwD>
              </div>
            )}
            <Row className={styles.detailRow}>
              <Col className={styles.col}>任务ID：</Col>
              <Col className={styles.col}>
                {detail?.taskID ? <TextCopy content={detail?.taskID} /> : '--'}
              </Col>
            </Row>
            <Row className={styles.detailRow}>
              <Col className={styles.col}>标签方：</Col>
              <Col className={styles.col}>
                {detail?.orgName ? detail?.orgName : '--'}
              </Col>
            </Row>
            <Row className={styles.detailRow}>
              <Col className={styles.col}>模型名称：</Col>
              <Col className={styles.col}>
                {detail?.name ? detail?.name : '--'}
              </Col>
            </Row>
            <Row className={styles.detailRow}>
              <Col className={styles.col}>资源描述：</Col>
              <Col className={styles.col}>
                {detail?.description ? detail?.description : '--'}
              </Col>
            </Row>
            <Row className={styles.detailRow}>
              <Col className={styles.col}>发布时间：</Col>
              <Col className={styles.col}>
                {detail?.publishTime
                  ? dayjs.unix(detail.publishTime).format('YYYY-MM-DD HH:mm:ss')
                  : '--'}
              </Col>
            </Row>
            <Row className={styles.detailRow}>
              <Col className={styles.col}>过期时间：</Col>
              <Col className={styles.col}>
                {detail?.expireTime
                  ? dayjs.unix(detail.expireTime).format('YYYY-MM-DD HH:mm:ss')
                  : '--'}
              </Col>
            </Row>
          </div>
          <Table
            className={styles.list}
            pagination={false}
            dataSource={relateData}
            rowKey={record =>
              `${record.name}_${getNum(1, 50)}_${getNum(51, 100)}`
            }
          >
            <Column title="模型资源关联数据方" dataIndex="name" key="name" />
            <Column title="角色" dataIndex="role" key="role" />
          </Table>
          <div className={styles.title} style={{marginTop: '32px'}}>
            <strong>模型资源使用流程</strong>
          </div>
          <div className={styles.flows}>
            <Row>
              <Col className={styles.flow}>
                <div className={styles.step}>第一步</div>
                <div className={styles.title}>申请模型资源权限</div>
                <div className={styles.desc}>
                  1、打开模型资源空间 2、申请需要使用的模型资源
                  3、等待模型资源持有方授权 4、授权通过
                </div>
              </Col>
              <Col className={styles.flow}>
                <div className={styles.step}>第二步</div>
                <div className={styles.title}>使用模型资源预测</div>
                <div className={styles.desc}>
                  1、打开任务列表 2、新建预测任务 3、选择预测数据集
                  4、选择已获得使用授权的模型预测
                </div>
              </Col>
            </Row>
          </div>
        </div>
      </div>
      <ModalBox
        open={showApply}
        title="确认申请"
        width={420}
        onCancel={() => {
          setShowApply(false);
        }}
        onOk={toApply}
      >
        请确认本模型的使用权限，申请提交后可进入『模型资源授权』页面，在授权列表开始查看
      </ModalBox>
      {contextHolder}
    </Content>
  );
}
