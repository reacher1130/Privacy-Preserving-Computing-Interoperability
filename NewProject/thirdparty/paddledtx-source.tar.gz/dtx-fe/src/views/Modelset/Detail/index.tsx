import React, {PropsWithChildren, useEffect, useState} from 'react';
import {useNavigate, useParams} from 'react-router-dom';
import cx from 'classnames';
import styles from './index.less';
import {NavKeys, useCurrentNav} from '@/slice/sider';
import Content from '@/components/Content';
import {Row, Col} from 'antd';
import dayjs from 'dayjs';
import TextCopy from '@/components/TextCopy';

import {ModelsetDetailResponse, fetchModelsetDetail} from '@/libs/api';

export default function Detail() {
  useCurrentNav(NavKeys.modelsetMine);
  const paths = [
    {url: '/modelset/mine', name: '我的模型资源'},
    {url: '', name: '模型资源详情'},
  ];
  const [resp, setResp] = useState<ModelsetDetailResponse['data']>();
  const {resourceID} = useParams();

  const getDetail = () => {
    fetchModelsetDetail({resourceID})
      .then(resp => {
        if (+resp.code === 0) {
          const data = resp.data;
          setResp(data);
        }
      })
      .catch(err => {
        console.error(err);
      });
  };

  useEffect(() => {
    getDetail();
  }, []);
  return (
    <Content paths={paths}>
      <Row className={styles.modesetDetailRow}>
        <Col className={styles.col}>资源名称：</Col>
        <Col className={styles.col}>
          {resp?.resourceName ? resp?.resourceName : '--'}
        </Col>
      </Row>
      <Row className={styles.modesetDetailRow}>
        <Col className={styles.col}>任务ID：</Col>
        <Col className={styles.col}>
          {resp?.resourceID ? <TextCopy content={resp?.resourceID} /> : '--'}
        </Col>
      </Row>
      <Row className={styles.modesetDetailRow}>
        <Col className={styles.col}>创建时间：</Col>
        <Col className={styles.col}>
          {resp?.expireTime
            ? dayjs.unix(resp?.createTime).format('YYYY-MM-DD HH:mm:ss')
            : '--'}
        </Col>
      </Row>
      <Row className={styles.modesetDetailRow}>
        <Col className={styles.col}>过期时间：</Col>
        <Col className={styles.col}>
          {resp?.expireTime
            ? dayjs.unix(resp?.expireTime).format('YYYY-MM-DD HH:mm:ss')
            : '--'}
        </Col>
      </Row>
      <Row className={styles.modesetDetailRow}>
        <Col className={styles.col}>所属资源空间：</Col>
        <Col className={styles.col}>
          {resp?.namespace ? resp?.namespace : '--'}
        </Col>
      </Row>
      <Row className={styles.modesetDetailRow}>
        <Col className={styles.col}>存储方式：</Col>
        <Col className={styles.col}>
          {resp?.storageType === 1
            ? '本地存储'
            : resp?.storageType === 0
              ? 'XDB去中心化存储'
              : '--'}
        </Col>
      </Row>
      <Row className={styles.modesetDetailRow}>
        <Col className={styles.col}>资源信息描述：</Col>
        <Col className={styles.col}>
          {resp?.description ? resp?.description : '--'}
        </Col>
      </Row>
      <Row className={styles.modesetDetailRow}>
        <Col className={styles.col}>存证hash：</Col>
        <Col className={styles.col}>
          {resp?.tx_id ? <TextCopy content={resp?.tx_id} /> : '--'}
        </Col>
      </Row>
    </Content>
  );
}
