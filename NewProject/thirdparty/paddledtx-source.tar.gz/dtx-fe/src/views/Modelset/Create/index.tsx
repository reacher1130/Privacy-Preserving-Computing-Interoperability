import React, {PropsWithChildren, useEffect, useState} from 'react';
import {useNavigate} from 'react-router-dom';
import {Form, Input, Space, message, Radio} from 'antd';
import {useDispatch} from 'react-redux';
import cx from 'classnames';
import styles from './index.less';
import {NavKeys, useCurrentNav} from '@/slice/sider';
import Select from '@/components/Select';
import Content from '@/components/Content';
import Button from '@/components/Button';
import DatePicker from '@/components/SingleDatePicker';
import ErrorCode from '@/libs/errorCode';

import {
  Modelset,
  createModelset,
  CreateModelsetRequest,
  ModelsetTaskResponse,
  getModelsetTaskList,
  ModelsetSpaceListResponse,
  getModelsetSpaceList,
} from '@/libs/api';
import {
  updatePageNo,
  InitialType as ModelsetInitialType,
} from '@/slice/modelset';

type CreateFormProps = PropsWithChildren;
const {TextArea} = Input;

const CreateForm: React.FC<CreateFormProps> = () => {
  const [form] = Form.useForm();
  const formItemLayout = {
    labelCol: {
      span: 6,
    },
    wrapperCol: {
      span: 18,
    },
  };
  const buttonItemLayout = {
    wrapperCol: {span: 14, offset: 6},
  };
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [messageApi, contextHolder] = message.useMessage();

  const [taskList, setTaskList] = useState<ModelsetTaskResponse['data']>([]);

  const getTaskList = () => {
    getModelsetTaskList()
      .then(resp => {
        if (+resp.code === 0) {
          const taskList = resp.data;
          setTaskList(taskList);
        }
      })
      .catch(err => {
        console.error(err);
      });
  };

  useEffect(() => {
    getTaskList();
  }, []);

  const [spaceList, setSpaceList] = useState<ModelsetSpaceListResponse['data']>(
    []
  );

  const getSpaceList = () => {
    getModelsetSpaceList().then(resp => {
      if (+resp.code === 0) {
        setSpaceList(resp.data);
      }
    });
  };

  useEffect(() => {
    getSpaceList();
  }, []);

  let submitting = false;

  const createModel: (parms: CreateModelsetRequest) => void = params => {
    createModelset(params)
      .then(resp => {
        if (+resp.code === 0) {
          message.success('创建模型资源成功');
          dispatch(updatePageNo(1));
          navigate('/modelset/mine');
        } else {
          // 错误提示 后续增加统一的code判断方法，参照后端错误列表
          const msg = ErrorCode[resp.code] || '创建失败';
          messageApi.error(msg);
        }
        submitting = true;
      })
      .catch(err => {
        messageApi.error('系统错误请稍后重试');
        console.error(err);
        submitting = true;
      });
  };

  const onFinish = (values: any) => {
    if (submitting) {
      return false;
    }
    submitting = true;
    // 提交数据, 请求创建新的资源空间, 请求成功后更新列表，注意分页
    values.expireTime = Math.floor(values.expireTime / 1000);
    // console.log(values);
    createModel(values);
    // form.resetFields();
  };
  const countChange: (info: {
    value: string;
    count: number;
    maxLength?: number;
  }) => string = info => {
    const {count, maxLength} = info;
    return `${count} / ${maxLength}`;
  };
  return (
    <>
      {contextHolder}
      <Form
        {...formItemLayout}
        layout="horizontal"
        form={form}
        className={styles.form}
        onFinish={onFinish}
        onValuesChange={console.log}
      >
        <Form.Item
          label="请选择任务ID"
          name="taskID"
          className={styles.formItem}
          initialValue={undefined}
          rules={[
            {
              required: true,
              message: '请选择任务ID',
            },
          ]}
        >
          <Select optsList={taskList} placeholder="请选择任务ID" />
        </Form.Item>
        <Form.Item
          label="过期时间"
          name="expireTime"
          className={styles.formItem}
          initialValue={undefined}
          rules={[
            {
              required: true,
              message: '请设置过期时间',
            },
            {
              validator(rule, value) {
                const now = new Date();
                if (value && value < now) {
                  return Promise.reject('过期时间不能早于当前时间');
                }
                return Promise.resolve(value);
              },
            },
          ]}
        >
          <DatePicker placeholder="请设置过期时间" />
        </Form.Item>
        <Form.Item
          label="模型服务名称"
          name="modelName"
          className={styles.formItem}
          rules={[
            {
              required: true,
              min: 4,
              max: 20,
              message: '请输入名称，4到20个字符',
            },
          ]}
        >
          <Input placeholder="请输入模型服务名称" autoComplete="off" />
        </Form.Item>
        <Form.Item
          label="资源空间"
          name="namespace"
          className={styles.formItem}
          initialValue={undefined}
          rules={[
            {
              required: true,
              message: '请选资源空间',
            },
          ]}
        >
          <Select optsList={spaceList} placeholder="请选择资源空间" />
        </Form.Item>
        <Form.Item
          label="存储方式"
          name="storageType"
          initialValue={0}
          required
        >
          <Radio.Group disabled className={styles.radioStorage}>
            <Radio value={0}>XDB去中心化存储</Radio>
          </Radio.Group>
        </Form.Item>
        <Form.Item
          label="资源信息描述"
          name="description"
          rules={[
            {
              required: true,
              max: 140,
              min: 10,
              message: '资源信息描述限制10到140个字符',
            },
          ]}
        >
          <TextArea
            maxLength={140}
            showCount={{formatter: countChange}}
            placeholder="请输入资源信息描述"
            className={styles.inputTextarea}
            autoComplete="off"
          />
        </Form.Item>
        <Form.Item {...buttonItemLayout} className={styles.formItem}>
          <Space size="middle">
            <Button htmlType="submit" type="primary">
              确认
            </Button>
            <Button
              htmlType="button"
              onClick={() => navigate('/modelset/mine')}
            >
              取消
            </Button>
          </Space>
        </Form.Item>
      </Form>
    </>
  );
};

export default function Create() {
  useCurrentNav(NavKeys.modelsetMine);
  const paths = [
    {url: '/modelset/mine', name: '我的模型资源'},
    {url: '', name: '新增模型资源'},
  ];
  return (
    <Content paths={paths}>
      <CreateForm />
    </Content>
  );
}
