import {Middleware, Reducer, configureStore} from '@reduxjs/toolkit';
import TaskApi from '@/slice/task/api';
import DatasetApi from '@/slice/dataset/api';
import RoleApi from '@/slice/role/api';
import SiderSlice from '../slice/sider';
import {UserInfoSlice} from '../slice/user';
import {ModelsetSlice} from '../slice/modelset';

type ReducerMap = Record<string, Reducer>;
const reducers: ReducerMap = {
  UserInfo: UserInfoSlice.reducer,
  Sider: SiderSlice.reducer,
  Modelset: ModelsetSlice.reducer,
  DatasetApi: DatasetApi.reducer,
  TaskApi: TaskApi.reducer,
  RoleApi: RoleApi.reducer,
};
const rootReducers = Object.keys(reducers).reduce(
  (acc, reducerName: string) => {
    acc[reducerName] = reducers[reducerName];
    return acc;
  },
  {} as ReducerMap
);
const middleware: Middleware[] = [
  DatasetApi.middleware,
  TaskApi.middleware,
  RoleApi.middleware,
];

export default configureStore({
  devTools: process.env.NODE_ENV === 'development',
  middleware: getDefaultMiddleware => getDefaultMiddleware().concat(middleware),
  reducer: rootReducers,
});
