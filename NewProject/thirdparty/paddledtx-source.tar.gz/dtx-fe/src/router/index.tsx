import React from 'react';
import {Navigate, RouteObject, createBrowserRouter} from 'react-router-dom';
import Dataset from '@/pages/Dataset';
import Modelset from '@/pages/Modelset';
import Operation from '@/pages/Operation';
import Algorithm from '@/pages/Algorithm';
import Account from '@/pages/Account';
import Login from '@pages/Login';
import Register from '@pages/Register';
import Logout from '@pages/Logout';
import Task from '@/pages/Task';
import constants from '@/libs/constants';
import PermissionCreator from '@/pages/Account/PermissionCreator';

let conf: RouteObject[] = [
  {
    path: '/',
    element: <Navigate to={'/dataset'} />,
  },
  {
    path: '/dataset/*',
    element: <Dataset />,
  },
  {
    path: '/modelset/*',
    element: <Modelset />,
  },
  {
    path: '/task/*',
    element: <Task />,
  },
  {
    path: '/algorithm/*',
    element: <Algorithm />,
  },
  {
    path: '/operation/*',
    element: <Operation />,
  },
  {
    path: '/account/*',
    element: <Account />,
  },
];
conf.forEach(r => {
  r.element = <PermissionCreator>{r.element}</PermissionCreator>;
});

// 这些path不受 权限 登录 控制
conf = conf.concat([
  {
    path: '/login',
    element: <Login />,
  },
  {
    path: '/logout',
    element: <Logout />,
  },
  {
    path: '/register',
    element: <Register />,
  },
]);
export default createBrowserRouter(conf, {basename: constants.baseUrl});
