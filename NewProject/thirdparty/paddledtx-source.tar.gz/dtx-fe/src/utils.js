/**
 * @file utils
 * Created by wuhan01 on 2018/12/4.
 */

import React from 'react';
import Decimal from 'decimal.js-light';
import constants from '@libs/constants';

const crypto = require('crypto');
if (!window.crypto) {
  window.crypto = window.msCrypto; // xupersdk不方便改动，此处兼容IE11
}

if (!String.prototype.trim) {
  String.prototype.trim = function () {
    return this.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '');
  };
}

export function format(value, fixed = true, precision = 2, valuePrecision) {
  /* eslint-disable */
  try {
    let val = parseFloat(value);
    if (valuePrecision) {
      val = parseFloat(
        (value * Math.pow(0.1, valuePrecision)).toFixed(valuePrecision)
      );
    }
    if (precision) {
      val =
        Math.round(val * Math.pow(10, precision)) * Math.pow(0.1, precision);
    }
    let v = precision
      ? parseFloat(val).toFixed(precision).toString().split('.')
      : val.toString().split('.');

    /* eslint-disable no-confusing-arrow, no-trailing-spaces, newline-per-chained-call */
    return `${v[0]
      .split('')
      .reverse()
      .map((val, idx) =>
        !((idx + 1) % 3) && idx !== 0 && idx !== v[0].length - 1
          ? `,${val}`
          : val
      )
      .reverse()
      .join('')}${fixed && v[1] ? `.${v[1]}` : ''}`;
  } catch (error) {
    throw error;
  }
}

export function throttle(fn, delay) {
  let timer = null;
  return function () {
    const context = this;
    const args = arguments;
    clearTimeout(timer);

    timer = setTimeout(function () {
      fn.apply(context, args);
    }, delay);
  };
}

export function parseUrl(url) {
  if (url) {
    var index = url.indexOf('?');
    url = index >= 0 ? url.substring(index, url.length) : '';
  }
  var query = url || location.search;
  /* eslint-disable no-useless-escape */
  var reg = /([^&=\?]+)=?([^&]*)/g;
  /* eslint-enable no-useless-escape */
  var params = {};
  var match = reg.exec(query);
  var key;
  var value;

  while (match) {
    key = match[1];
    value = match[2];
    params[key] = value;
    match = reg.exec(query);
  }
  return params;
}

// 将时间戳time改为2019/03/02 12:23:45格式
export function formatDate(time) {
  let timeStr = +time || +new Date();
  let date = new Date(timeStr + 8 * 3600 * 1000);
  return date.toJSON().substr(0, 19).replace('T', ' ');
}

// date formate like 2021-12-13T09:14:31Z, after formated 2021-12-13 17:14:31
export function formatDateBy(date) {
  const time = {
    year: date.getFullYear(),
    month: date.getMonth() + 1,
    day: date.getDate(),
    hours: date.getHours(),
    minutes: date.getMinutes(),
    seconds: date.getSeconds(),
  };
  let {year, month, day, hours, minutes, seconds} = time;
  month = month >= 10 ? month : `0${month}`;
  day = day >= 10 ? day : `0${day}`;
  hours = hours >= 10 ? hours : `0${hours}`;
  minutes = minutes >= 10 ? minutes : `0${minutes}`;
  seconds = seconds >= 10 ? seconds : `0${seconds}`;
  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}

// 文本复制
export function copyText(node) {
  if (document.selection) {
    // IE
    let range = document.body.createTextRange();
    range.moveToElementText(document.getElementById('selectable'));
    range.select();
    document.execCommand('Copy');
  } else if (window.getSelection) {
    let range = document.createRange();
    range.selectNodeContents(node);

    let selection = document.getSelection();
    selection.removeAllRanges();
    selection.addRange(range);
    document.execCommand('Copy');
    selection.removeAllRanges();
  }
}

function selectText(textbox, startIndex, stopIndex) {
  // ie
  if (textbox.createTextRange) {
    var range = textbox.createTextRange();
    range.collapse(true);
    // 起始光标
    range.moveStart('character', startIndex);
    // 结束光标
    range.moveEnd('character', stopIndex - startIndex);
    range.select();
  } else {
    // firefox/chrome
    textbox.setSelectionRange(startIndex, stopIndex);
    textbox.focus();
  }
}

/**
 * 文本赋值
 * @param cpStr 复制的内容
 */
export function copyTextByText(cpStr) {
  // 数字没有 .length 不能执行selectText 需要转化成字符串
  let textString = cpStr.toString();
  let input = document.querySelector('#copy-input');
  if (!input) {
    input = document.createElement('input');
    input.id = 'copy-input';
    // 防止ios聚焦触发键盘事件
    input.readOnly = 'readOnly';
    input.style.position = 'absolute';
    input.style.left = '-1000px';
    input.style.zIndex = '-1000';
    document.body.appendChild(input);
  }

  input.value = textString;
  // ios必须先选中文字且不支持 input.select();
  selectText(input, 0, textString.length);
  if (document.execCommand('copy')) {
    document.execCommand('copy');
  }
  input.blur();
}

export function hasBalance(balance) {
  if (typeof balance !== 'string' && !(balance instanceof String)) {
    // 尽量传入字符串，否则，传入本身不精确，该库使用没有意义
    console.warn('Keep your input accurate or use string instead.');
  }
  if (+balance === 0 || balance === '') {
    return false;
  } else {
    return true;
  }
}

/**
 * 金额正规化，带逗号展示
 * @param {number} value 金额
 * @param {number} power 幂次，value被预提的幂
 * @param {number} precision 精度，小数点后几位
 */
export function normalizeMoney(value, power = 0, precision = 2) {
  try {
    let PRECISION = 100; // 有效数字上限
    if (typeof value !== 'string' && !(value instanceof String)) {
      // 尽量传入字符串，否则，传入本身不精确，该库使用没有意义
      console.warn('Keep your input accurate or use string instead.');
    } else {
      PRECISION = Math.max(value.length, PRECISION);
    }
    Decimal.precision < PRECISION && Decimal.set({precision: PRECISION});
    let money = new Decimal(value)
      .dividedBy(Math.pow(10, power))
      .toFixed(precision);
    let parts = money.split('.');
    return (
      parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',') +
      (parts[1] ? `.${parts[1]}` : '')
    );
  } catch (e) {
    console.warn(e);
    return '';
  }
}

/**
 * 解析返回错误信息
 * @param {Object} error 接口返回
 * @param {number} code 错误码
 * @return 对应文案
 */
export function parseRespError(error = {}, message) {
  return error.msgFriendly
    ? error.msg
    : message
      ? message
      : '系统出现故障，请联系管理员';
}

/**
 * 复合函数，从右往左
 * compose(foo, bar)(...args) => foo(bar(...args))
 */
export function compose() {
  const funcs = Array.from(arguments);
  return function () {
    let args = Array.from(arguments);
    return funcs.reduceRight(function (result, fn) {
      return [fn.apply(this, result)];
    }, args)[0];
  };
}

/**
 * 复合组件，左边为parent，右边为child
 * FooBar = compound(Foo, Bar)
 * <FooBar props><Inner /></FooBar> => <Foo props><Bar props><Inner /></Bar></Foo>
 */
export function compound() {
  const components = Array.from(arguments);
  return components.reduceRight((Compound, Component) => {
    return class extends React.Component {
      render() {
        return (
          <Component {...this.props}>
            <Compound {...this.props} />
          </Component>
        );
      }
    };
  });
}

/**
 * Xuper金额过滤(去除小数部分末尾0)
 * @param {number|string} balance 金额
 * @return {string|*}
 */
export function xuperBalanceFilter(balance) {
  try {
    if (+balance === 0) {
      return balance === '' ? '-' : '0';
    }
    // 是否存在小数点
    let reg = /\./g.test(balance);
    if (reg) {
      let integer_part = balance.toString().split('.')[0];
      let decimal_part = balance.toString().split('.')[1];
      // 小数部分是否都是0
      let reg2 = /^0*$/g.test(decimal_part);
      if (reg2) {
        return integer_part;
      }
      decimal_part = decimal_part.replace(/0*$/g, '');
      return integer_part + '.' + decimal_part;
    }
    return balance;
  } catch (e) {
    console.warn(e);
    return '-';
  }
}

// 正规化金额并去末尾0
export const trimNormalizedMoney = compose(xuperBalanceFilter, normalizeMoney);

/**
 * 使promise可取消
 *
 * @export
 * @param {*} promise promise
 * @returns
 */
export function makeCancelable(promise) {
  let hasCanceled = false;
  const wrappedPromise = new Promise((resolve, reject) => {
    let e = new Error('canceled');
    e.canceled = true;
    promise.then(
      val => (hasCanceled ? reject(e) : resolve(val)),
      error => (hasCanceled ? reject(e) : reject(error))
    );
  });
  return {
    promise: wrappedPromise,
    cancel() {
      hasCanceled = true;
    },
  };
}

/**
 * 类似_.get
 *
 * @export
 * @param {*} object
 * @param {*} path
 * @param {*} defaultValue
 * @returns
 */
export function getProp(object, path, defaultValue) {
  const keys = Array.isArray(path) ? path : path.split('.');
  return keys.reduce(
    (obj, key) => (obj && obj[key] !== undefined ? obj[key] : defaultValue),
    object
  );
}

/**
 * aes 加密
 * @params data 待加密数据
 * @params key 必须为16位私钥
 * return {string}
 */
export function encryption(data, key, iv) {
  let ivs = iv || '';
  let clearEncoding = 'utf8';
  let cipherEncoding = 'base64';
  let cipherChunks = [];
  let cipher = crypto.createCipheriv('aes-128-ecb', key, ivs);
  cipher.setAutoPadding(true);
  cipherChunks.push(cipher.update(data, clearEncoding, cipherEncoding));
  cipherChunks.push(cipher.final(cipherEncoding));
  return cipherChunks.join('');
}
export function decryption(data, key, iv) {
  if (!data) {
    return '';
  }
  iv = iv || '';
  let clearEncoding = 'utf8';
  let cipherEncoding = 'base64';
  let cipherChunks = [];
  let decipher = crypto.createDecipheriv('aes-128-ecb', key, iv);
  decipher.setAutoPadding(true);
  cipherChunks.push(decipher.update(data, cipherEncoding, clearEncoding));
  cipherChunks.push(decipher.final(clearEncoding));
  return cipherChunks.join('');
}

/**
 * 获取cookie
 */
export function getCookieValue(a) {
  var b = document.cookie.match('(^|[^;]+)\\s*' + a + '\\s*=\\s*([^;]+)');
  return b ? b.pop() : '';
}

function randomFun() {
  return Math.random();
}

export function generateUUID() {
  var ret = '',
    value;
  for (var i = 0; i < 32; i++) {
    value = (randomFun() * 16) | 0;
    // Insert the hypens
    if (i > 4 && i < 21 && !(i % 4)) {
      ret += '-';
    }
    // Add the next random character
    ret += (i === 12 ? 4 : i === 16 ? (value & 3) | 8 : value).toString(16);
  }
  return ret;
}

let uuidRegex =
  /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
export function isUUID(uuid) {
  return uuidRegex.test(uuid);
}

export function formatNum(num) {
  num = num + '';
  const len = num.length;
  if (len <= 3) {
    return num;
  }
  const count = len % 3 === 0 ? Math.floor(len / 3) - 1 : Math.floor(len / 3);
  let str = '';
  for (let i = 0; i < count; i++) {
    const start = len - (i + 1) * 3;
    const end = start + 3;
    const subStr = num.substring(start, end);
    str = ',' + subStr + str;
  }
  str = num.substring(0, len - count * 3) + str;
  return str;
}

export function getUrlPrefix() {
  const location = window.location;
  const prefix = `${location.protocol}//${location.host}`;
  // const prefix = 'http://10.152.20.49:8085';
  return prefix;
}

export function isRequestUrl(url) {
  /* eslint-disable no-useless-escape */
  const reg =
    /^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\*\+,;=.]+$/;
  /* eslint-enable no-useless-escape */
  const isUrl = reg.test(url);
  return isUrl;
}
