import {ReactComponentLike} from 'prop-types';
import React from 'react';
import {
  Location,
  NavigateFunction,
  Params,
  useLocation,
  useNavigate,
  useParams,
} from 'react-router-dom';

export interface PropsWithRouter {
  router: {
    location: Location;
    navigate: NavigateFunction;
    params: Params<string>;
  };
}

function withRouter<T>(
  Component: React.ComponentType<T>
): React.ComponentType<T> {
  function ComponentWithRouterProp(props: T) {
    let location = useLocation();
    let navigate = useNavigate();
    let params = useParams();
    return <Component {...props} router={{location, navigate, params}} />;
  }

  return ComponentWithRouterProp;
}

export default withRouter;
