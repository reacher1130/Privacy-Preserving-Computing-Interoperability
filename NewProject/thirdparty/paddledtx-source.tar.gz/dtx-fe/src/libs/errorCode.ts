const ErrorCode: Record<string, string> = {
  '20001': '系统错误，请稍后再试', // internal error
  '20002': '配置错误，请联系管理员', // encoding error
  '20003': '参数错误，请联系管理员', // parameter error
  '20004': '目标不存在。', // target not found
  '20005': '编码错误，请联系管理员', // encoding error
  '20006': '配置解析错误。', // unmarshal error
  '20007': '签名错误', // signature error

  '20008': '未授权', // not authorized
  '20009': '配置有重复', // duplicate item
  '20010': '签名验证错误', // signature verification failed
  '20011': '加密错误', // cryptography computation error
  '20012': '资源过期', // target expired

  '30001': '读取区块链信息错误', // errors occurred when reading data from blockchain
  '30002': '写入区块区块链信息错误', // errors occurred when writing

  ParamsErr: '参数错误',
  SignErr: '签名错误',
  QueryFailedErr: '查询失败',
  ExistedDataErr: '数据已存在',
  InternalError: '系统错误',
  DuplicateErr: '请勿重复操作',
  NamespaceExisted: '命名空间已存在',
  MetaFeaturesCheckErr: '特征文件不包含原有特征',

  // user error code
  UserExisted: '用户已存在',
  UserNotExisted: '用户不存在',
  ErrorLogin: '登录信息错误',
  WrongPassword: '密码错误',
  NotAdmin: '非管理员无法操作',

  // role error code
  RoleExisted: '角色已存在',
  RoleNotExisted: '角色不存在',
  NoAuthority: '未授权',
  RoleHasBinds: '角色被绑定，不能被删除',

  // resource
  StatusErr: '资源状态错误',
  ResourceNotExisted: '资源不存在',
  DataTypeNotExisted: '数据类型不存在',
  ReqInProcessErr: '申请审核正在处理中，请稍后',

  // task error code
  TaskExisted: '任务已存在',
  TaskConfirming: '任务正在确认，请稍后',
  TaskNotExisted: '任务不存在',
  TaskTypeError: '任务类型错误',
  TaskParamError: '任务配置错误',
  TaskPublished: '任务发布失败',
  TaskNotPublished: '任务未发布',
  TaskStatusError: '任务状态错误',

  // Algorithm
  AlgorithmNotExisted: '算法不存在',

  InternalServerError: '系统错误',

  // Task params error
  EmptyModelResourceID: '预测任务缺少模型ID',
  EmptyTrainParamsForTrainTask: '训练任务缺少训练参数配置',
  EmptyLabelForTrainTask: '训练任务缺少标签特征',
  EmptyLabelNameForLogicTrain: '逻辑回归训练任务缺少目标值',
  NotEnoughDataResourceNum: '数据集数量不足',
  DuplicateDataResourceIDs: '数据集重复',
  DataAndExeNodeNumNotMatch: '数据集和计算节点数量不匹配',
  DuplicateExecutorNodes: '计算节点重复',
  EmptyPsiLabel: 'psi特征名称为空',
  PsiLabelAndDataNumberNotMatch: 'psi特征数和数据集数量不匹配',
  FeatEngAndDataNumberNotMatch: '特征工程配置和数据集数量不匹配',
  PsiLabelNotExist: 'psi特征名称不存在',
  DataContainDuplicateLabels: '数据集包含重复标签特征',
  ParseFeatureEngFailed: '特征工程参数解析失败',
  CheckFeatureEngFailed: '特征工程校验失败',
  LabelNotExistForTrainTask: '标签特征不存在',
  ExecutorNodeNotOnline: '计算节点已下线',
};

export default ErrorCode;
