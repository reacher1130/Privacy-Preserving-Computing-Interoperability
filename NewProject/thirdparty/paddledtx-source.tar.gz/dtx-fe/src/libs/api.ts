// eslint-disable-next-line import/named
import {AxiosRequestConfig} from 'axios';
import CryptoJS, {MD5 as md5} from 'crypto-js';
import {BaseResponse} from '@/slice/commonApi';
import store from '@/store';
import {UserInfoSlice, UserInitialStateType} from '@/slice/user';
import request from './request';

export function encryptAES(
  s: string,
  key: CryptoJS.lib.WordArray,
  iv: CryptoJS.lib.WordArray
): string {
  const encrypted = CryptoJS.AES.encrypt(s, key, {
    iv,
    mode: CryptoJS.mode.CBC, // CBC算法
    padding: CryptoJS.pad.Pkcs7, // 使用pkcs7 进行padding 后端需要注意
  });

  return encrypted.toString();
}

export function decryptAES(
  s: string,
  key: CryptoJS.lib.WordArray,
  iv: CryptoJS.lib.WordArray
): string {
  const decrypted = CryptoJS.AES.decrypt(s, key, {
    iv,
    mode: CryptoJS.mode.CBC, // CBC算法
    padding: CryptoJS.pad.Pkcs7, // 使用pkcs7 进行padding 后端需要注意
  });

  return decrypted.toString(CryptoJS.enc.Utf8);
}

/**
 * 用户接口模型
 */
export interface XuperKey {
  Curvname: 'P-256';
  X: string;
  Y: string;
  D?: string;
}
export interface Account {
  role: string;
  username: string;
  mnemonic: string;
  privateKey: string;
  address: string;
  createTime: string;
  orgId: string;
  orgDID: string;
  orgName: string;
  orgPubKey: string;
}
export interface UserAccess {
  username: Account['username'];
  password: string;
}

export type AccountMain = Pick<
  Account,
  'username' | 'mnemonic' | 'address' | 'createTime' | 'privateKey'
>;

// 登录
export interface UserLoginRequest extends UserAccess {
  pubkey?: string;
}
export interface LoginResponse extends BaseResponse {
  data: Account;
}
export const login = (params: UserLoginRequest) => {
  const {password} = params;
  params.password = md5(password).toString();
  const sKey = CryptoJS.enc.Utf8.parse(params.password);
  return request.post<LoginResponse>('user/login', {...params}).then(resp => {
    let userKey: XuperKey = null;
    let data = resp.data;
    try {
      const de = decryptAES(data.privateKey, sKey, sKey);
      userKey = JSON.parse(de);
      store.dispatch(
        UserInfoSlice.actions.updateUser({
          address: data.address,
          username: data.username,
          mnemonic: data.mnemonic,
          createTime: data.createTime,
          role: data.role || 'default',
          'X-User-PriKey': userKey.D.toString(),
          'X-User-Pubkey': {
            Curvname: 'P-256',
            X: userKey.X.toString(),
            Y: userKey.Y.toString(),
          },
        } as UserInitialStateType['user'])
      );
    } catch (e) {
      console.error('private parse error', resp.data?.privateKey);
      return Promise.reject(e);
    }
    return resp;
  });
};
// 注册
export interface UserRegisterRequest extends UserAccess {
  pubkey?: string;
}
export interface UserRegisterResponse extends BaseResponse {
  data: Pick<
    Account,
    'username' | 'mnemonic' | 'address' | 'createTime' | 'privateKey'
  >;
}
export const register = (params: UserRegisterRequest) => {
  const {password} = params;
  params.password = md5(password).toString();
  return request.post<UserRegisterResponse>('user/register', {...params});
};

// 重置密码
export interface UserResetPwdRequest {
  newpwd: string;
  password: string;
  username: string;
}
export type UserResetPwdResponse = BaseResponse;
export const resetPwd = (params: UserResetPwdRequest) => {
  const {password, newpwd} = params;
  params.password = md5(password).toString();
  params.newpwd = md5(newpwd).toString();
  return request.post<UserResetPwdResponse>('user/resetpwd', {...params});
};

// 用户信息
export interface UserInfoResponse extends BaseResponse {
  data: Account;
}
export const userInfo = () => {
  return request.get<UserInfoResponse>('user/info');
};

export interface PagingRequeset {
  pageNo: number;
  pageSize: number;
}

/**
 * 数据集接口模型
 * https://ku.baidu-int.com/knowledge/HFVrC7hq1Q/8GOwDrlpm3/i0rOOkVgkb/e40e882ed33847
 */

export interface Meta {
  name: string;
  type: string;
  description: string;
  statistics: {
    avg: string;
    mode: string;
    median: string;
    max: string;
    min: string;
  };
}

export interface Dataset {
  id: number;
  resourceID: string;
  resourceName: string;
  name: string;
  expireTime: number;
  filePath: string;
  fileVersion: string;
  version?: string;
  metaPath: string;
  namespace: string;
  storageType: number;
  description: string;
  status: number;
  tx_id: string;
  createTime: number;
  metaInfo: Meta[];
}

export enum DatasetStatus {
  Parsing,
  Saving,
  Saved,
  Published,
  ParseFail,
  SaveFail,
  Offline,
  UpdateFail,
  Expired = 9,
}
// 数据集列表
export interface DatasetListResquest {
  pageNo: number;
  pageSize: number;
  namespace?: string;
  status?: DatasetStatus;
  startTime?: number;
  endTime?: number;
}

export interface DatasetListResponse extends BaseResponse {
  data: {
    total: number;
    list: Dataset[];
  };
}

export const fetchDataList = (params: DatasetListResquest) => {
  return request.get<DatasetListResponse>('data/list', {...params});
};

// 创建数据集
export type CreateDatasetRequest = Pick<
  Dataset,
  | 'name'
  | 'expireTime'
  | 'description'
  | 'filePath'
  | 'fileVersion'
  | 'namespace'
  | 'metaPath'
  | 'storageType'
>;

export interface DatasetUploadFileRequest {
  file: File;
  fileName: string;
}
export interface DatasetUploadFileResponse extends BaseResponse {
  data: {
    filePath: string;
  };
}
export const datasetUploadFile = (params: DatasetUploadFileRequest) => {
  const formData = new FormData();
  formData.append('file', params.file, params.fileName);
  formData.append('fileName', params.fileName);
  return request.post<DatasetUploadFileResponse>('data/fileupload', formData);
};
export interface CreateDatasetResponse extends BaseResponse {
  data: Pick<Dataset, 'resourceID'>;
}

export const createDataset = (params: CreateDatasetRequest) => {
  return request.post<CreateDatasetResponse>('data/create', {...params});
};

// 数据集详情
export interface DatasetDetailRequest {
  resourceID: string;
}

export interface DatasetDetailResponse extends BaseResponse {
  data: Dataset;
}

export const fetchDatasetDetail = (params: DatasetDetailRequest) => {
  const {resourceID} = params;
  let payload: any = {resourceID};
  const id = parseInt(resourceID, 10);
  if (id) {
    payload = {id};
  }
  return request.get<DatasetDetailResponse>('data/detail', {...payload});
};

// 发布数据集
export interface PublishDatasetlRequest {
  id: number;
}

export type PublishDatasetResponse = BaseResponse;

export const publishDataset = (params: PublishDatasetlRequest) => {
  return request.post<PublishDatasetResponse>('data/publish', {...params});
};

// 更新数据集
export type UpdateDatasetRequest = {
  id: number;
} & Pick<Dataset, 'expireTime' | 'filePath' | 'fileVersion' | 'metaPath'>;

export interface UpdateDatasetResponse extends BaseResponse {
  fileID: string;
}

export const updateDataset = (params: UpdateDatasetRequest) => {
  return request.post<UpdateDatasetResponse>('data/update', {...params});
};

// 维护资源特征详情
// https://ku.baidu-int.com/knowledge/HFVrC7hq1Q/8GOwDrlpm3/i0rOOkVgkb/e40e882ed33847#anchor-82bc8450-eefe-11ed-850f-ab9fb4a1b931
export type UpdateDatasetMetaRequest = {
  resourceID: string;
} & Pick<Dataset, 'metaInfo'>;

export type UpdateDatasetMetaResponse = BaseResponse;

export const updateDatasetMeta = (params: UpdateDatasetMetaRequest) => {
  const {resourceID} = params;
  let payload: any = {metaInfo: params.metaInfo, resourceID};
  const id = parseInt(resourceID, 10);
  if (id) {
    payload = {metaInfo: params.metaInfo, id};
  }
  return request.post<UpdateDatasetMetaResponse>('data/meta/update', {
    ...payload,
  });
};

// 删除数据集
export interface DeleteDatasetRequest {
  id: number;
}

export type DeleteDatasetResponse = BaseResponse;

export const deleteDataset = (params: DeleteDatasetRequest) => {
  return request.post<DeleteDatasetResponse>('data/delete', {...params});
};

// 下线数据集
export interface offlineDatasetRequest {
  id: number;
}

export type offlineDatasetMetaResponse = BaseResponse;

export const offlineDataset = (params: offlineDatasetRequest) => {
  return request.post<offlineDatasetMetaResponse>('data/offline', {...params});
};

// 上线数据集
export interface onlineDatasetRequest {
  id: number;
}

export type onlineDatasetMetaResponse = BaseResponse;

export const onlineDataset = (params: onlineDatasetRequest) => {
  return request.post<onlineDatasetMetaResponse>('data/online', {...params});
};

// 新增数据集空间
export interface CreateDatasetNamespaceRquest {
  name: string;
  replica: number;
  description?: string;
}

export type CreateDatasetNamespaceResponse = BaseResponse;

export const createDatasetNamespace = (
  params: CreateDatasetNamespaceRquest
) => {
  return request.post<CreateDatasetNamespaceResponse>('data/ns/add', {
    ...params,
  });
};

export type DatasetNamespaceList = string[];

// 获取数据集空间列表
export interface DatasetNamespaceListRequest {}
export interface DatasetNamespace extends BaseResponse {
  data: DatasetNamespaceList;
}

export const datasetNamespaceList = () => {
  return request.get<DatasetNamespace>('data/ns/simplelist');
};

export interface DatasetNamespaceCatalogFile {
  fileName: Dataset['name'];
  fileID: Dataset['resourceID'];
}
export interface DatasetNamespaceCatalogResponse extends BaseResponse {
  data: {
    [p: string]: DatasetNamespaceCatalogFile[];
  };
}

export const datasetNamespaceCatalog = (params: {orgName?: string}) => {
  return request.get<DatasetNamespaceCatalogResponse>('data/ns/list', {
    ...params,
  });
};

export interface DatasetCatalogFileDetailRequest {
  resourceID: string;
}
export interface DatasetCatalogFileDetailResponse extends BaseResponse {
  data: {
    name: string; // 文件名称
    owner: string; // 归属者公钥
    orgName: string; // 归属者名称
    fileID: string; // 文件ID
    totalNumber: number; // 样本总数
    size: number; // 体积
    description: string;
    fromOwn: boolean; // 是否为我方数据
    features: string[]; // 已经申请可使用字段
    metaInfo: Array<{
      name: string; // 特征列名称
      type: string; // 特征数据类型
      description: string; // 特征列描述
      dataInfo: Record<string, any>;
    }>;
    expireTime: number; // 到期时间
    publishTime: number; // 发布时间
  };
}
export const fetchDatasetCatalogFileDetail = (
  params: DatasetCatalogFileDetailRequest
) => {
  return request.get<DatasetCatalogFileDetailResponse>(
    'data/ns/resource/detail',
    {...params}
  );
};
/**
 * 模型接口模型
 * https://ku.baidu-int.com/knowledge/HFVrC7hq1Q/8GOwDrlpm3/i0rOOkVgkb/oUFzHGbe7swxUm#anchor-b1a88de0-ee63-11ed-850f-ab9fb4a1b931
 */

export interface Modelset {
  id: number;
  resourceID: string;
  resourceName: string;
  taskID: string;
  namespace: string;
  storageType: number;
  resourcePath: string;
  status: number;
  tx_id: number;
  description: string;
  expireTime: number;
  publicTime: number;
  createTime: number;
  updateTime: number;
  version: string;
}

// 模型资源列表
export interface ModelsetListResquest extends PagingRequeset {
  namespace?: string;
  status?: number;
  startTime?: number;
  endTime?: number;
}

export interface ModelsetListResponse extends BaseResponse {
  data: {
    total: number;
    list: Modelset[];
  };
}

export const fetchModelsetList = (params: ModelsetListResquest) => {
  return request.get<ModelsetListResponse>('model/list', {...params});
};

// 模型资源空间列表
export interface ModelsetSpaceListResponse extends BaseResponse {
  data: string[];
}

export const getModelsetSpaceList = () => {
  return request.get<ModelsetSpaceListResponse>('model/ns/simplelist');
};

// 模型关联任务查询
export interface ModelsetTaskResponse extends BaseResponse {
  data: string[];
}

export const getModelsetTaskList = () => {
  return request.get<ModelsetTaskResponse>('model/tasklist');
};

// 创建模型
export type CreateModelsetRequest = {
  modelID: string;
  modelName: string;
} & Pick<Modelset, 'expireTime' | 'namespace' | 'storageType' | 'description'>;

export interface CreateModelsetResponse extends BaseResponse {
  data: Pick<Modelset, 'resourceID'>;
}

export const createModelset = (params: CreateModelsetRequest) => {
  return request.post<CreateModelsetResponse>('model/create', {...params});
};

// 模型资源详情
export interface ModelsetDetailRequest {
  resourceID: string;
}

export interface ModelsetDetailResponse extends BaseResponse {
  data: Modelset;
}

export const fetchModelsetDetail = (params: ModelsetDetailRequest) => {
  return request.get<ModelsetDetailResponse>('model/detail', {...params});
};

// 发布模型资源
export interface PublishModelsetlRequest {
  resourceID: string;
}

export type PublishModelsetResponse = BaseResponse;

export const publishModelset = (params: PublishModelsetlRequest) => {
  return request.post<PublishModelsetResponse>('model/publish', {...params});
};

// 删除模型资源
export interface DeleteModelsetRequest {
  resourceID: string;
}

export type DeleteModelsetMetaResponse = BaseResponse;

export const deleteModelset = (params: DeleteModelsetRequest) => {
  return request.post<DeleteModelsetMetaResponse>('model/delete', {...params});
};

// 下线模型资源
export interface OfflineModelsetRequest {
  resourceID: string;
}

export type OfflineModelsetResponse = BaseResponse;

export const offlineModelset = (params: OfflineModelsetRequest) => {
  return request.post<OfflineModelsetResponse>('model/offline', {...params});
};

// 上线模型资源
export interface OnlineModelsetRequest {
  resourceID: string;
}

export type OnlineModelsetResponse = BaseResponse;

export const onlineModelset = (params: OnlineModelsetRequest) => {
  return request.post<OnlineModelsetResponse>('model/online', {...params});
};

// 新增模型资源空间
export type AddModelsetSpaceRequest = {
  name: string;
  replica: number;
} & Pick<Modelset, 'description'>;

export type AddModelsetSpaceResponse = BaseResponse;

export const addModelsetSpace = (params: AddModelsetSpaceRequest) => {
  return request.post<AddModelsetSpaceResponse>('model/ns/add', {...params});
};

// 模型资源目录列表
export type ModelsetCatalogTree = {
  fileName: string;
  fileID: string;
  title: string;
};

export type ModelsetCatalogFile = {
  fileName: string;
  fileID: string;
};

export type ModelsetCatalogSpace = {
  [key: string]: ModelsetCatalogFile[];
};

export interface ModelsetCatalogListResponse extends BaseResponse {
  data: ModelsetCatalogSpace;
}

export const getModelsetCatalogList = (params: {orgName?: string}) => {
  return request.get<ModelsetCatalogListResponse>('model/ns/list', {...params});
};

// 模型资源目录详情
export type ModelsetCatalogStatistics = {
  avg: string;
  mode: string;
  median: string;
  max: string;
  min: string;
};

export type ModelsetCatalogMetaInfo = {
  name: string;
  type: string;
  description: string;
  dataInfo: ModelsetCatalogStatistics;
};

export type ModelsetCatalogResource = {
  name: string;
  owner: string;
  partner: string;
  fromOwn: boolean;
  fileID: string;
  totalNumber: number;
  orgName: string;
  description: string;
  taskID: string;
  metaInfo: ModelsetCatalogMetaInfo[];
  expireTime: number;
  publishTime: number;
};

export interface ModelsetCatalogDetailRequest {
  resourceID: string;
}

export interface ModelsetCatalogDetailResponse extends BaseResponse {
  data: ModelsetCatalogResource;
}

export const getModelsetCatalogDetail = (
  params: ModelsetCatalogDetailRequest
) => {
  return request.get<ModelsetCatalogDetailResponse>(
    'model/ns/resource/detail',
    {...params}
  );
};

// 模型资源目录申请
export interface ModelsetCatalogApplyRequest {
  resourceID: string;
  authType: string;
}

export type ModelsetCatalogApplyResponse = BaseResponse;

export const modelsetCatalogApply = (params: ModelsetCatalogApplyRequest) => {
  return request.post<ModelsetCatalogApplyResponse>('model/auth/apply', {
    ...params,
  });
};

// 模型授权
export type ModelsetAuthorization = {
  authID: string;
  resourceID: string;
  createTime: number;
  expireTime: number;
  status: string;
  authType: string;
  applier: string;
  applierDID: string;
  applierName: string;
  authorizer: string;
  authorizerDID: string;
  authorizerName: string;
  resourceName: string;
  features: string;
  rejectReason: string;
  approvalTime: number;
};

// 模型授权列表
export type ModelsetAuthorizationListRequest = {
  type: string;
};

export type ModelsetAuthorizationPart = Pick<
  ModelsetAuthorization,
  'authID' | 'resourceID' | 'createTime' | 'expireTime' | 'status'
>;

export interface ModelsetAuthorizationListResponse extends BaseResponse {
  data: {
    total: number;
    list: ModelsetAuthorizationPart[];
  };
}

export const modelsetAuthorizationList = (
  params: ModelsetAuthorizationListRequest
) => {
  return request.get<ModelsetAuthorizationListResponse>('model/auth/list', {
    ...params,
  });
};

// 模型授权详情
export type ModelsetAuthorizationDetailRequest = {
  authID: string;
};

export interface ModelsetAuthorizationDetailReponse extends BaseResponse {
  data: ModelsetAuthorization;
}

export const modelsetAuthorizationDetail = (
  params: ModelsetAuthorizationDetailRequest
) => {
  return request.get<ModelsetAuthorizationDetailReponse>('model/auth/detail', {
    ...params,
  });
};

// 模型授权通过
export type ModelsetAuthorizationPassRequest = {
  authID: string;
  status: string;
  expireTime: number;
};

export type ModelsetAuthorizationPassReponse = BaseResponse;

export const modelsetAuthorizationPass = (
  params: ModelsetAuthorizationPassRequest
) => {
  return request.post<ModelsetAuthorizationPassReponse>('model/auth/operate', {
    ...params,
  });
};

// 模型授权驳回
export type ModelsetAuthorizationRejectRequest = {
  authID: string;
  status: string;
  reason: string;
};

export type ModelsetAuthorizationRejectReponse = BaseResponse;

export const modelsetAuthorizationReject = (
  params: ModelsetAuthorizationRejectRequest
) => {
  return request.post<ModelsetAuthorizationRejectReponse>(
    'model/auth/operate',
    {...params}
  );
};

/**
 * 算法管理
 * https://ku.baidu-int.com/knowledge/HFVrC7hq1Q/8GOwDrlpm3/i0rOOkVgkb/MSC5p4A5TBz7vb
 */
export interface Algorithm {
  name: string;
  version: string;
  hash: string;
  file: string;
}

// 算法列表
export interface AlgorithmListRequest {}

export interface AlgorithmListResponse extends BaseResponse {
  data: {
    total: number;
    list: Algorithm[];
  };
}

export const getAlgorithmList = (params: AlgorithmListRequest) => {
  return request.get<AlgorithmListResponse>('algo/list');
};

// 算法详情
export interface AlgorithmDetailRequest {
  name: string;
  version: string;
}
export interface AlgorithmInfo extends Algorithm {
  file: string;
  storage: string;
  desc: string;
}

export interface AlgorithmDetailResponse extends BaseResponse {
  data: AlgorithmInfo;
}

export const getAlgorithmDetail = (params: AlgorithmDetailRequest) => {
  return request.get<AlgorithmDetailResponse>('algo/detail', {...params});
};

// 下载算法
export interface AlgorithmDownloadRequest {
  name: string;
  version: string;
}

export type AlgorithmDownloadResponse = BlobPart;

export const downLoadAlgorithm = (
  params: AlgorithmDownloadRequest,
  config: AxiosRequestConfig
) => {
  return request.get<AlgorithmDownloadResponse>(
    'algo/download',
    {...params},
    {...config}
  );
};

/**
 * 运维管理
 * https://ku.baidu-int.com/knowledge/HFVrC7hq1Q/8GOwDrlpm3/i0rOOkVgkb/5zSiRH5SMp_ZgA
 */
export interface Node {
  name: string;
  host: string;
  status: string;
}

export interface Operation {
  mnemonic: string;
  contractName: string;
  nodeList: Node[];
}

// 区块链网络列表
export interface BlockchainListResquest {}

export interface BlockchainListResponse extends BaseResponse {
  data: Operation;
}

export const getBlockchainList = (params: BlockchainListResquest) => {
  return request.get<BlockchainListResponse>('op/blockchain/netInfo', {
    ...params,
  });
};

// 存储网络 文件概览
export interface StorageOverview {
  sysHealth?: string;
  filesHealthRate?: number;
  nodeHealthRate?: number;
  nodeNum?: number;
  greenNodeNum?: number;
  yellowNodeNum?: number;
  redNodeNum?: number;
  nsNum?: number;
  fileNum?: number;
  fileExpiredNum?: number;
  greenFileNum?: number;
  yellowFileNum?: number;
  redFileNum?: number;
}

export interface StorageOverviewResquest {}

export interface StorageOverviewResponse extends BaseResponse {
  data: StorageOverview;
}

export const getStorageOverview = (params: StorageOverviewResquest) => {
  return request.get<StorageOverviewResponse>('op/xdb/netInfo', {...params});
};

// 存储网络，查询节点列表
export interface AllNode extends Node {
  nodeID?: string;
  storageName?: string;
  dataownerName?: string;
}
export interface StorageAllNode {
  storageNodeList: AllNode[];
  dataNodeList: AllNode[];
}
export interface StorageNodeListResquest {}

export interface StorageNodeListResponse extends BaseResponse {
  data: StorageAllNode;
}

export const getStorageNodeList = (params: StorageNodeListResquest) => {
  return request.get<StorageNodeListResponse>('op/xdb/nodeInfo', {...params});
};

/** 运维管理 计算网络
 *
 */

// 计算网络 概览信息
export interface ComputingOverview {
  totalTasks: number;
  waitingTasks: number;
  failedTasks: number;
  runningTasks: number;
  successTasks: number;
  health: number;
}

export interface ComputingOverviewResquest {}

export interface ComputingOverviewResponse extends BaseResponse {
  data: ComputingOverview;
}

export const getComputingOverview = (params: ComputingOverviewResquest) => {
  return request.get<ComputingOverviewResponse>('op/dai/taskInfo', {...params});
};

// 计算网络 概览信息
export interface ComputingNode extends Node {
  grpcHost: string;
  nodeID: string;
  registerTime: string;
}

export interface ComputingNodeListResquest {}

export interface ComputingNodesData {
  health: number;
  nodes: ComputingNode[];
}
export interface ComputingNodeListResponse extends BaseResponse {
  data: ComputingNodesData;
}

export const getComputingNodeList = (params: ComputingNodeListResquest) => {
  return request.get<ComputingNodeListResponse>('op/dai/netInfo', {...params});
};

/**
 * 账户管理接口
 * https://ku.baidu-int.com/knowledge/HFVrC7hq1Q/8GOwDrlpm3/i0rOOkVgkb/lNBqBWwHJDwROA#anchor-c7a90520-0e66-11ee-9d3c-4926ec404c6d
 *
 */

export interface RoleRights {
  [key: string]: string;
  permission: string;
  data: string;
  service: string;
  task: string;
  algorithm: string;
  op: string;
}

export interface RoleRightsTbItem {
  name: string;
  enName: string;
  view: number;
  modify: number;
}

export interface RoleParams {
  rolename: string;
  authority: RoleRights;
}

// 角色创建
export interface CreateRoleRequest {
  rolename: string;
  authority: string;
}

export interface CreateRoleResponse extends BaseResponse {}

export const createRole = (params: CreateRoleRequest) => {
  return request.post<CreateRoleResponse>('permission/role/create', {
    ...params,
  });
};

// 角色修改
export interface ModifyRoleRequest {
  rolename: string;
  authority: string;
}

export interface ModifyRoleResponse extends BaseResponse {}

export const modifyRole = (params: ModifyRoleRequest) => {
  return request.post<ModifyRoleResponse>('permission/role/modify', {
    ...params,
  });
};

// 删除角色
export interface DeleteRoleRequest {
  rolename: string;
}

export interface DeleteRoleResponse extends BaseResponse {}

export const deleteRole = (params: DeleteRoleRequest) => {
  return request.get<ModifyRoleResponse>('permission/role/delete', {...params});
};

// 角色列表
export interface RoleListResponseMeta extends RoleParams {
  createTime: number;
}
export interface RoleListResponse extends BaseResponse {
  data: RoleListResponseMeta[];
}

export const getRoleList = () => {
  return request.get<RoleListResponse>('permission/role/list');
};

// 角色(权限)查询
export interface RoleRightsRequest {
  rolename: string;
}

export interface RoleRightsResponse extends BaseResponse {}

export const getRoleRights = (params: RoleRightsRequest) => {
  return request.post<RoleRightsResponse>('permission/role/get', {...params});
};

// 角色绑定
export interface RoleBindRequest {
  rolename: string;
  username: string;
}

export interface RoleBindResponse extends BaseResponse {}

export const bindRole = (params: RoleBindRequest) => {
  return request.post<RoleBindResponse>('permission/role/bind', {...params});
};

// 权限管理列表
export interface AccountListType {
  username: string;
  rolename: string;
  bindTime: number;
  createTime: number;
}
export interface AccountListResponse extends BaseResponse {
  data: AccountListType[];
}

export const getAccountList = () => {
  return request.get<AccountListResponse>('permission/bind/list');
};

// 创建任务
export interface TaskCreateRequest {
  id?: number;
  name: string;
  desc: string;
  type: string;
  params: Record<string, any>;
  canvasInfo: string;
}

export interface TaskCreateResponse extends BaseResponse {
  data: TaskDetailResponse['data'];
}
export const createTask = (params: TaskCreateRequest) => {
  if (params.id) {
    return request.post<TaskCreateResponse>('task/update', {...params});
  }
  return request.post<TaskCreateResponse>('task/create', {...params});
};

// 复制任务
export interface TaskCopyRequest {
  id: number;
}

export type TaskCopyResponse = BaseResponse;
export const copyTask = (params: TaskCopyRequest) => {
  return request.post<TaskCopyResponse>('task/clone', {...params});
};

// 发布任务
export interface TaskPublishRequest {
  id: number;
}

export type TaskPublishResponse = BaseResponse;
export const publishTask = (params: TaskPublishRequest) => {
  return request.post<TaskPublishResponse>('task/publish', {...params});
};

// 启动任务
export interface TaskStartRequest {
  id: number;
}

export type TaskStartResponse = BaseResponse;
export const startTask = (params: TaskStartRequest) => {
  return request.post<TaskStartResponse>('task/start', {...params});
};

export interface TaskDeleteRequest {
  id: number;
}

export type TaskDeleteResponse = BaseResponse;
export const deleteTask = (params: TaskDeleteRequest) => {
  return request.post<TaskDeleteResponse>('task/delete', {...params});
};

// 任务列表
export enum TaskStatus {
  Edit,
  Ready,
  Processing,
  Finished,
  Failed,
}
export interface TaskItem {
  name: string;
  id: string;
  type: 'train' | 'predict';
  status: TaskStatus;
  desc: string;
  createTime: number;
  updateTime: number;
}
export interface TaskListRequest {
  pageNo?: number;
  pageSize?: number;
  name?: string;
}

export interface TaskListResponse extends BaseResponse {
  data: {
    total: number;
    list: TaskItem[];
  };
}
export const fetchTaskList = (
  params: TaskListRequest = {
    pageNo: 1,
    pageSize: 10,
  }
) => {
  params = Object.entries(params).reduce(
    (sum, [k, v]) => {
      if (v !== undefined && v !== null && v !== '') {
        sum[k] = v;
      }
      return sum;
    },
    {} as Record<string, any>
  );
  return request.get<TaskListResponse>('task/list', {...params});
};

export interface TaskDetailRequest {
  id: number;
}

export interface TaskDetailResponse extends BaseResponse {
  data: {
    id: number;
    name: string;
    taskID: string;
    type: string;
    params: string;
    status: TaskStatus;
    errMsg: string;
    canvasInfo: string;
    desc: string;
    createBy: string;
    creatorName: string;
    createTime: number;
    updateTime: number;
  };
}

export const fetchTaskDetail = (params: TaskDetailRequest) => {
  return request.get<TaskDetailResponse>('task/detail', {...params});
};
// 海南住建厅 - 房企融资授信
// http://172.16.22.221:8084/api/v1/v1/enterprise-evaluating/search
export const searchEnterprise = (params: any) => {
  return request.get('enterprise-evaluating/search', {...params});
};

// 获取任务日志
export interface TaskLogRequest {
  id: number;
}

export interface TaskLogResponse extends BaseResponse {
  data: string;
}

export const fetchTaskLog = (params: TaskLogRequest) => {
  return request.get<TaskLogResponse>('task/log', {...params});
};

// 指定名称任务是否存在
export interface TaskExistsRequest {
  name: string;
}

export interface TaskExistsResponse extends Pick<BaseResponse, 'code' | 'msg'> {
  data: number;
}

export const fetchTaskExists = (params: TaskExistsResponse) => {
  return request.get<TaskExistsResponse>('task/exists', {...params});
};

// 静态模型评估结果详情

// 线性回归
export interface LinearEvalResult {
  taskID: string;
  multiClassCaseMetricScores: never;
  binaryClassCaseMetricScores: never;
  regressionCaseMetricScores: {
    // RMSEs: {
    //     // 如下是十折交叉验证，随机划分只有"0"
    //     '0': 4.073049681327262;
    //     '1': 6.839674624138285;
    //     '2': 5.094802570220692;
    //     '3': 4.696714369888934;
    //     '4': 3.530764900087261;
    //     '5': 12.78819206913343;
    //     '6': 24.325779036419874;
    //     '7': 3.7535831971039317;
    //     '8': 4.030847807147657;
    //     '9': 3.919127550471353;
    // };
    RMSEs: Record<string, number>;
    // meanRMSE: 7.305253580593868; // rmse平均值
    meanRMSE: number;
    // stdDevRMSE: 6.5926228765271855; // rmse的标准差
    stdDevRMSE: number;
  };
}

// 逻辑回归
export interface LogicEvalResult {
  // "binaryClassCaseMetricScores":{
  //     "caseType":1,
  //     "avgAccuracy":1,
  //     "avgPrecision":1,
  //     "avgF1Score":1,
  //     "avgAUC":0.8071428571428572,
  //     "metricsPerFold":[ //包含每折交叉验证的评估值
  //         "0":{
  //             "accuracy":1,
  //             "precision":1,
  //             "recall":1,
  //             "F1Score":1,
  //             "AUC":1,
  //             "ROC":[
  //                 {
  //                     "p":[
  //                         0,
  //                         0,
  //                         1.8779772212246777
  //                     ]
  //                 },
  //                 {
  //                     "p":[
  //                         1,
  //                         1,
  //                         0.020380934322157946
  //                     ]
  //                 }
  //                 ...
  //             ]
  //         },
  //         ...
  //     ]
  // }
  taskID: string;
  regressionCaseMetricScores: never;
  multiClassCaseMetricScores: never;
  binaryClassCaseMetricScores: {
    avgRecall: string;
    caseType: number;
    avgAccuracy: number;
    avgPrecision: number;
    avgF1Score: number;
    avgAUC: number;
    metricsPerFold: Array<
      Record<
        string,
        {
          accuracy: number;
          precision: number;
          reccall: number;
          F1Score: number;
          AUC: number;
          ROC: Array<{
            p: number[];
          }>;
        }
      >
    >;
  };
}

// 决策树回归
export interface DTCEvalResult {
  // "multiClassCaseMetricScores":{
  //     "caseType":2,
  //     "avgAccuracy":0.7699999999999999,
  //     "avgPrecision":0.7790918248418248,
  //     "avgRecall":0.7699999999999999,
  //     "avgF1Score":0.7707411409735248,
  //     "avgAUC":0.8051867854367855,
  //     "metricsPerFold":{
  //         "0":{
  //             "overallAccuracy":0.76,
  //             "overallPrecision":0.7743589743589743,
  //             "overallRecall":0.76,
  //             "overallF1Score":0.7623376623376622,
  //             "overallAUC":0.8333333333333333,
  //             "reports":{
  //                 "class1":{
  //                     "points":[
  //                         {
  //                             "p":[
  //                                 0,
  //                                 0,
  //                                 1.9322033898305084
  //                             ]
  //                         },
  //                         {
  //                             "p":[
  //                                 0.2,
  //                                 0.6,
  //                                 0.9322033898305084
  //                             ]
  //                         }
  //                         ...
  //                     ]
  //                     "auc":0.8333333333333333
  //                 },
  //                 "class2":{
  //                     "points":[
  //                         {
  //                             "p":[
  //                                 0,
  //                                 0,
  //                                 1.9322033898305084
  //                             ]
  //                         }
  //                         ...
  //                     ]
  //                     "auc":0.8333333333333334
  //                 }
  //             }
  //         },
  //         ...
  //     }
  // }
  taskID: string;
  regressionCaseMetricScores: never;
  binaryClassCaseMetricScores: never;
  multiClassCaseMetricScores: Record<
    string,
    {
      caseType: number;
      avgAccuracy: number;
      avgPrecision: number;
      avgRecall: number;
      avgF1Score: number;
      avgAUC: number;
      metricsPerFold: Record<
        string,
        {
          overallAccuracy: number;
          overallPrecision: number;
          overallRecall: number;
          overallF1Score: number;
          overallAUC: number;
          reports: Record<
            string,
            {
              points: Array<{
                p: number[];
              }>;
            }
          >;
        }
      >;
    }
  >;
}
export interface TaskEvalResRequest {
  id: number;
}

export interface TaskEvalResponse extends BaseResponse {
  data: LinearEvalResult | LogicEvalResult | DTCEvalResult;
}

export const fetchTaskEvalResult = (params: TaskEvalResRequest) => {
  return request.get<TaskEvalResponse>('task/eval/res', {...params});
};

// 计算节点列表

export interface FetchExecutorListRequest {
  resourceID: string;
}

export interface FetchExecutorListResponse {
  data: string[];
}

export const fetchExecutorList = (params: FetchExecutorListRequest) => {
  return request.get<FetchExecutorListResponse>('task/executors', {...params});
};

// 新增计算节点
export interface ExecutorNodeCreateRequest {
  executorID: number; //节点序号，从2开始，系统安装时默认安装一个节点
  executorName: string; //计算节点名称
  orgID: number; //机构序号
  replicas: number; //服务副本数量
  containerPort: number; //容器端口
  paddleFLAddress: number; //查询结果状态
  httpPort: number; // 查询结果（非原始）
}
export const createExecutorNode = (params: ExecutorNodeCreateRequest) => {
  return request.post<BaseResponse>('op/dai/newExecutorNode', {...params});
};
//删除计算节点
export interface DeleteExecutorNodeRequest {
  executorName: string;
}
export const deleteExecutorNode = (params: DeleteExecutorNodeRequest) => {
  return request.post<BaseResponse>('op/dai/deleteExecutorNode', {...params});
};
//修改计算节点
export interface ModifyExecutorNodeRequest {
  executorName: string;
  replicas: number;
}
export const ModifyExecutorNode = (params: ModifyExecutorNodeRequest) => {
  return request.post<BaseResponse>('op/dai/modifyExecutorNode', {...params});
};

// 新增数据节点
export interface DataOwnerNodeCreateRequest {
  dataownerID: number; //节点序号，从2开始，系统安装时默认安装一个节点
  dataownerName: string; //计算节点名称
  replicas: number; //服务副本数量
}
export const createDataOwnerNode = (params: DataOwnerNodeCreateRequest) => {
  return request.post<BaseResponse>('op/dai/newDataownerNode', {...params});
};
//删除数据节点
export interface DeleteDataOwnerNodeRequest {
  dataownerName: string;
}
export const deleteDataOwnerNode = (params: DeleteDataOwnerNodeRequest) => {
  return request.post<BaseResponse>('op/dai/deleteDataownerNode', {...params});
};
//修改数据节点
export interface ModifyDataOwnerNodeRequest {
  dataownerName: string;
  replicas: number;
}
export const modifyDataOwnerNode = (params: ModifyDataOwnerNodeRequest) => {
  return request.post<BaseResponse>('op/dai/modifyDataownerNode', {...params});
};

// 新增存储节点
export interface StorageNodeCreateRequest {
  storageID: number; //节点序号，从2开始，系统安装时默认安装一个节点
  storageName: string; //计算节点名称
  replicas: number; //服务副本数量
}
export const createStorageNode = (params: StorageNodeCreateRequest) => {
  return request.post<BaseResponse>('op/dai/newStorageNode', {...params});
};
//删除存储节点
export interface DeleteStorageNodeRequest {
  storageName: string;
}
export const deleteStorageNode = (params: DeleteStorageNodeRequest) => {
  return request.post<BaseResponse>('op/dai/deleteStorageNode', {...params});
};
//修改存储节点
export interface ModifyStorageNodeRequest {
  storageName: string;
  replicas: number;
}
export const modifyStorageNode = (params: ModifyStorageNodeRequest) => {
  return request.post<BaseResponse>('op/dai/modifyStorageNode', {...params});
};

// 数据集查看权限申请
export interface DatasetLookAuthRequest {
  resourceID: string;
}

export interface DatasetLookAuthResponse extends BaseResponse {
  data: {
    authID: string;
  };
}

export const datasetLookAuth = (params: DatasetLookAuthRequest) => {
  return request.post<DatasetLookAuthResponse>('data/auth/apply', {
    ...params,
    authType: 'Look',
  });
};

// 数据集使用权限申请
export interface DatasetUseAuthRequest {
  resourceID: string;
  keys: string[];
}

export interface DatasetUseAuthResponse extends BaseResponse {
  data: {
    authID: string;
  };
}

export const datasetUseAuth = (params: DatasetUseAuthRequest) => {
  return request.post<DatasetUseAuthResponse>('data/auth/apply', {
    ...params,
    authType: 'Use',
  });
};

// 数据集授权
export interface DatasetAuthOperateRequest {
  authID: string;
  status: string;
  reason?: string;
  expireTime?: number;
}

export type DatasetAuthOperateResponse = BaseResponse;

export const datasetAuthOperate = (params: DatasetAuthOperateRequest) => {
  return request.post<DatasetAuthListResponse>('data/auth/operate', {
    ...params,
  });
};

// 数据集申请列表
export enum AuthStatus {
  Approved = 'Approved',
  Unapproved = 'Unapproved',
  Rejected = 'Rejected',
}
export interface DatasetAuthItem {
  authID: string; // 授权ID
  resourceID: string; // 授权对象ID
  name: string; // 授权对象名称
  createTime: number; // 授权申请时间
  expireTime: number; // 授权到期时间
  status: AuthStatus; // 授权状态
  rejectReason: string; // 拒绝原因
}
export interface DatasetAuthListRequest {
  type?: 'apply' | 'auth';
  pageNo: number;
  pageSize: number;
}

export interface DatasetAuthListResponse extends BaseResponse {
  data: {
    list: DatasetAuthItem[];
    total: number;
  };
}
export const datasetAuthList = (params: DatasetAuthListRequest) => {
  return request.get<DatasetAuthListResponse>('data/auth/list', {...params});
};

// 数据集授权详情
// 模型授权
export type DatasetAuthorization = {
  authID: string;
  resourceID: string;
  name: string;
  createTime: number;
  expireTime: number;
  status: string;
  authType: string;
  applier: string;
  authorizer: string;
  authorizerDID: string;
  features: string[];
  rejectReason: string;
  approvalTime: number;
  applierDID: string;
  resourceName: string;
  applierName: string;
  authorizerName: string;
};
export interface DatasetAuthorizationDetailRequest {
  authID: string;
}

export interface DatasetAuthorizationDetailReponse extends BaseResponse {
  data: DatasetAuthorization;
}

export const datasetAuthorizationDetail = (
  params: DatasetAuthorizationDetailRequest
) => {
  return request.get<DatasetAuthorizationDetailReponse>('data/auth/detail', {
    ...params,
  });
};

export interface DatasetPublishedListRequest {
  pageNo: number;
  pageSize: number;
}

export interface DatasetPublishedListResponse extends BaseResponse {
  data: {
    list: Dataset[];
    total: number;
  };
}

export const datasetPublishedList = (params: DatasetPublishedListRequest) => {
  return request
    .get<DatasetPublishedListResponse>('data/list/published', {...params})
    .then(resp => {
      if (resp.code === '0') {
        resp.data.list = resp.data.list.map(l => {
          if ('resourceId' in l) {
            return {
              ...l,
              resourceID: l.resourceId as string,
            };
          }
          return l;
        });
      }
      return Promise.resolve(resp);
    });
};

export interface DatasetApprovedListRequest {
  pageNo: number;
  pageSize: number;
}

export interface DatasetApprovedListResponse extends BaseResponse {
  data: {
    list: Dataset[];
    total: number;
  };
}

export const datasetApprovedList = (params: DatasetApprovedListRequest) => {
  return request
    .get<DatasetApprovedListResponse>('data/list/approved', {...params})
    .then(resp => {
      if (resp.code === '0') {
        resp.data.list = resp.data.list.map(l => {
          if ('resourceId' in l) {
            return {
              ...l,
              resourceID: l.resourceId as string,
            };
          }
          return l;
        });
      }
      return Promise.resolve(resp);
    });
};

export interface ModelPublishedListRequest {
  pageNo: number;
  pageSize: number;
}

export interface ModelPublishedListResponse extends BaseResponse {
  data: {
    list: Modelset[];
    total: number;
  };
}

export const modelPublishedList = (params: ModelPublishedListRequest) => {
  return request
    .get<ModelPublishedListResponse>('model/list/published', {...params})
    .then(resp => {
      if (resp.code === '0') {
        resp.data.list = resp.data.list.map(l => {
          if ('resourceId' in l) {
            return {
              ...l,
              resourceID: l.resourceId as string,
            };
          }
          return l;
        });
      }
      return Promise.resolve(resp);
    });
};

export interface ModelApprovedListRequest {
  pageNo: number;
  pageSize: number;
}

export interface ModelApprovedListResponse extends BaseResponse {
  data: {
    list: Modelset[];
    total: number;
  };
}

export const modelApprovedList = (params: ModelApprovedListRequest) => {
  return request
    .get<ModelApprovedListResponse>('model/list/approved', {...params})
    .then(resp => {
      if (resp.code === '0') {
        resp.data.list = resp.data.list.map(l => {
          if ('resourceId' in l) {
            return {
              ...l,
              resourceID: l.resourceId as string,
            };
          }
          return l;
        });
      }
      return Promise.resolve(resp);
    });
};

export interface DatasetNamespaceOrgStatListItem {
  orgName: string;
  orgID: string;
  countNamespace: number;
  countResource: number;
  countExecutor: number;
  holdingRation: number;
}
export interface DatasetNamespaceOrgStatResponse extends BaseResponse {
  data: {
    totalResource: number;
    totalOrgs: number;
    totalExes: number;
    totalNamespace: number;
    list: DatasetNamespaceOrgStatListItem[];
  };
}
export const datasetNamespaceOrgStat = () => {
  return request.get<DatasetNamespaceOrgStatResponse>('data/ns/orgStat');
};

export interface ModelsetNamespaceOrgStatResponse extends BaseResponse {
  data: {
    totalResource: number;
    totalOrgs: number;
    totalExes: number;
    totalNamespace: number;
    list: DatasetNamespaceOrgStatListItem[];
  };
}
export const modelNamespaceOrgStat = () => {
  return request.get<ModelsetNamespaceOrgStatResponse>('model/ns/orgStat');
};

// 资源空间最大副本数
export interface DatasetNamespaceReplicaLimitResponse extends BaseResponse {
  data: number;
}

export const datasetNamespaceReplicaLimit = () => {
  return request.get<DatasetNamespaceReplicaLimitResponse>(
    'data/ns/replicaLimit'
  );
};
export interface ModelsetNamespaceReplicaLimitResponse extends BaseResponse {
  data: number;
}

export const modelsetNamespaceReplicaLimit = () => {
  return request.get<ModelsetNamespaceReplicaLimitResponse>(
    'model/ns/replicaLimit'
  );
};

export interface GetJumpTokenResponse extends BaseResponse {
  data: {
    token: string;
  };
}
// 跳转baas获取token
export const getJumpToken = () => {
  return request.get<GetJumpTokenResponse>('baas/gettoken');
};
