/**
 * @file 用户信息存储
 *
 */
/* eslint-disable fecs-camelcase */

import _ from 'lodash';
import Cookies from 'js-cookie';
import {encryption} from '@/utils';
import constants from '@libs/constants';
import {Account, XuperKey} from './api';
const {SAFE_KEY} = constants.data;

export interface User {
  createTime: string;
  username: string;
  name: string;
  address: string;
}

class Auth {
  static keyName = 'unicom_dtx_user_profile';
  _account: Account = null;
  xuperKey: XuperKey = null;
  constructor() {
    // const accountListStr = localStorage.getItem(Auth.keyName) || '{}';
    // const accountListStore = JSON.parse(accountListStr);
    // this.account = accountListStore;
  }
  get account() {
    return this._account;
  }

  set account(info: Account) {
    this._account = info;
    if (!info) {
      this.xuperKey = null;
      return;
    }
    let xuperKey: XuperKey = null;
    try {
      xuperKey = JSON.parse(info.privateKey);
    } catch (e) {
      console.error(e);
      xuperKey = {
        Curvname: 'P-256',
        X: '',
        Y: '',
        D: '',
      };
    }
    this.xuperKey = xuperKey;
  }
  cacheAccount(userInfo: Account) {
    this.account = userInfo;
    localStorage.setItem(Auth.keyName, JSON.stringify(userInfo));
  }

  logout() {
    localStorage.removeItem(Auth.keyName);
    this.account = null;
  }

  loggedin() {
    if (this.account?.address) {
      return true;
    }
    const accountJSON = localStorage.getItem(Auth.keyName) || '{}';
    const account: Account = JSON.parse(accountJSON);
    if (account.address) {
      this.account = account;
      return true;
    }
    return false;
  }

  getAccount() {
    if (this.account?.address) {
      return this.account;
    }
    const accountJSON = localStorage.getItem(Auth.keyName) || '{}';
    const account: Account = JSON.parse(accountJSON);
    if (account.address) {
      this.account = account;
      return account;
    }
  }

  accountPrivateKey(): XuperKey {
    return {...this.xuperKey};
  }

  accountPublicKey(): XuperKey {
    const xuperKey = this.xuperKey;
    return {
      Curvname: xuperKey.Curvname,
      X: xuperKey.X,
      Y: xuperKey.Y,
    };
  }

  accountAddress() {
    return this.account.address;
  }
}

export default new Auth();
