import axios, {AxiosError, AxiosRequestConfig, AxiosResponse} from 'axios';
import {BN} from 'bn.js';
import {ec as EC} from 'elliptic';
import sha256 from 'sha256';
import dayjs from 'dayjs';
import {generateUUID} from '@/utils';
import store from '@/store';

export function sign(privkey: string, msg: string) {
  // const D = new BN(privkey, 'hex');
  const D = new BN(privkey);
  let ec = new EC('p256');
  let key = ec.keyFromPrivate(D.toArray());
  msg = sha256(msg);
  const sigBytes = key.sign(msg);
  return (
    sigBytes.r.toString('hex').padStart(64, '0') +
    sigBytes.s.toString('hex').padStart(64, '0')
  );
}

export const generateMessage = (payload: Record<string, any>): string => {
  let keys = Object.keys(payload);
  keys.sort();
  const s = keys.reduce((sum, k) => {
    const v = payload[k];
    if (typeof v === 'object') {
      return `${sum}${k}=${JSON.stringify(k)}`;
    }
    if (typeof v === 'undefined') {
      return sum;
    }
    return `${sum}${k}=${v?.toString() ?? ''}`;
  }, '');
  return s;
};

export enum Method {
  POST = 'POST',
  DELETE = 'DELETE',
  PUT = 'PUT',
  GET = 'GET',
  PATCH = 'PATCH',
}
export const request = axios.create({
  baseURL: '/dtx/v1',
});
request.interceptors.request.use(config => {
  const {method, headers, url} = config;
  const userInfo = store.getState().UserInfo;
  const {user} = userInfo;
  const demoAuthDisabled =
    (globalThis as typeof globalThis & {__DTX_DEMO_AUTH_DISABLED__?: boolean})
      .__DTX_DEMO_AUTH_DISABLED__ === true;
  headers['X-Request-Id'] || headers.set('X-Request-Id', generateUUID());
  if (demoAuthDisabled && !user['X-User-PriKey']) {
    return config;
  }
  if (!url.includes('user/login') && !url.includes('user/register')) {
    const timeStamp = dayjs().unix();
    let signMsg = '';
    if (method.toUpperCase() === Method.GET) {
      let p = config.params;
      signMsg = generateMessage(p);
    } else if (config.data instanceof FormData) {
      let p = config.data;
      signMsg = `fileName=${p.get('fileName')}`;
    } else {
      let p = config.data;
      signMsg = JSON.stringify(p);
    }
    // let p = (method.toUpperCase() === Method.GET ? config.params : config.data) ?? {};
    // const msg = generateMessage(p);
    const authorization = sign(
      userInfo.user['X-User-PriKey'],
      signMsg + timeStamp.toString()
    );
    headers['X-User-Pubkey'] ||
      headers.set('X-User-Pubkey', JSON.stringify(user['X-User-Pubkey']));
    headers.Authorization ||
      headers.set('Authorization', `auth-v1/${timeStamp}/${authorization}`);
  }
  return config;
});

const parseResponse = <T>(resp: AxiosResponse<T>) => resp.data;
const fail = <T>(err: AxiosError) => {
  console.error(err);
  return Promise.resolve({
    code: err?.code?.toString(),
    data: err?.response?.data,
    msg: err?.message,
  } as T);
};

export default {
  post: <T>(
    url: string,
    payload?: Record<string, any> | FormData,
    config?: AxiosRequestConfig
  ) => {
    return request({
      ...config,
      url,
      method: Method.POST,
      data: payload,
    }).then(resp => parseResponse<T>(resp), fail<T>);
  },
  get: <T>(
    url: string,
    payload?: Record<string, any>,
    config?: AxiosRequestConfig
  ) => {
    payload = {
      _: new Date().getTime(),
      ...payload,
    };
    return request({
      ...config,
      url,
      method: Method.GET,
      params: payload,
    }).then(resp => parseResponse<T>(resp), fail<T>);
  },
};
