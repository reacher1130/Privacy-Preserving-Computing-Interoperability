import React from 'react';
import {Navigate} from 'react-router-dom';
import store from '@/store';

const demoAuthDisabled = () =>
  (globalThis as typeof globalThis & {__DTX_DEMO_AUTH_DISABLED__?: boolean})
    .__DTX_DEMO_AUTH_DISABLED__ === true;

export default function Guard(Target: React.ComponentType) {
  return function (props: any) {
    const isLogin = !!store.getState().UserInfo.user.address;
    if (!isLogin && !demoAuthDisabled()) {
      return <Navigate to="/login" />;
    }
    return <Target {...props} />;
  };
}
