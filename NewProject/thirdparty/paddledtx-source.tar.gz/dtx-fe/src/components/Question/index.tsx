import React, {CSSProperties} from 'react';
import {Popover} from 'antd';
import styles from './index.less';
import {QuestionCircleOutlined} from '@ant-design/icons';
import cx from 'classnames';

export interface QuestionProps {
  content: string;
  questionClass?: string;
  style?: CSSProperties;
}

const Question: React.FC<QuestionProps> = props => {
  const {content, questionClass, style} = props;
  return (
    <Popover content={content} overlayClassName={styles.overlayClass}>
      <span className={cx(styles.questionIcon, questionClass)} style={style}>
        <QuestionCircleOutlined />
      </span>
    </Popover>
  );
};

export default Question;
