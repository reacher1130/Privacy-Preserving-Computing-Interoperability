/**
 * @file 加载态转圈摘出
 *
 */

import React, {CSSProperties} from 'react';
import {LoadingOutlined} from '@ant-design/icons';
import {Spin} from 'antd';
import cx from 'classnames';

export interface LoadingProps {
  tip?: string;
  loadingClass?: string;
  minHeight?: CSSProperties['minHeight'];
}
const Loading: React.FC<LoadingProps> = props => {
  let {tip = 'Loading...', loadingClass, minHeight = '420px'} = props;
  return (
    <div className={cx(loadingClass)} style={{minHeight}}>
      <Spin
        size="large"
        indicator={<LoadingOutlined style={{fontSize: 24}} spin />}
        tip={tip}
        style={{
          left: '50%',
          top: '50%',
          position: 'absolute',
          transform: 'translate(-50%, -50%)',
        }}
      />
    </div>
  );
};

export default Loading;
