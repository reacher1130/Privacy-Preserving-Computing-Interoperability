/**
 * @file Input组件
 *
 */

import React from 'react';
import {Input as AntdInput, InputProps} from 'antd';
import cx from 'classnames';
import {PasswordProps} from 'antd/es/input';
import styles from './index.less';

interface CustomInputProps extends InputProps {
  className?: string;
}
interface CustomPasswordProps extends PasswordProps {
  className?: string;
}
class Input extends React.Component<CustomInputProps> {
  static Password: typeof InputPassword;
  render() {
    const {className, ...antdProps} = this.props;
    return (
      <AntdInput
        {...antdProps}
        className={cx(styles.customInputClass, className)}
      />
    );
  }
}

const InputPassword = (props: CustomPasswordProps) => {
  const {className, ...antdProps} = props;
  return (
    <AntdInput.Password
      {...antdProps}
      className={cx(styles.customInputClass, className)}
    />
  );
};

Input.Password = InputPassword;

export default Input;
