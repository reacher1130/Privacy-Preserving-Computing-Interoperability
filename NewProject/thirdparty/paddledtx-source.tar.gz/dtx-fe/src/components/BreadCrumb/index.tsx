import React, {PropsWithChildren} from 'react';
import {useNavigate} from 'react-router-dom';
import arrowIcon from '@pub/images/arrow_right.svg';
import Icon from '@ant-design/icons';
import cx from 'classnames';
import styles from './index.less';

export interface BreadCrumbProps extends PropsWithChildren {
  paths?: Array<{url: string; name: string}>;
}
export default function BreadCrumb(props: BreadCrumbProps) {
  const {paths = []} = props;
  const len = paths.length;
  const navigate = useNavigate();
  return len > 0 ? (
    <div className={styles.BreadCrumbBox}>
      <div className={styles.inner}>
        {paths.map((path, index) => {
          return (
            <span
              className={cx(
                styles.crumbBox,
                index === len - 1 && styles.crumbBoxLast
              )}
              key={index}
            >
              {index === len - 1 ? (
                <span>{path.name}</span>
              ) : (
                <a
                  onClick={() => navigate(path.url)}
                  className={styles.crumbLink}
                >
                  {path.name}
                </a>
              )}
              {index === len - 1 ? null : (
                <Icon className={styles.crumbArrow} component={arrowIcon} />
              )}
            </span>
          );
        })}
      </div>
    </div>
  ) : null;
}
