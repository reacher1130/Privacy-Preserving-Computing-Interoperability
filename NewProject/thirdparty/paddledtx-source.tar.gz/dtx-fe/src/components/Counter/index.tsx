/**
 * @file 计数选择器
 *
 */

import React, {PropsWithChildren} from 'react';

import cx from 'classnames';
import Icon from '@ant-design/icons';

import minusIcon from '@pub/images/minus.svg';
import plusIcon from '@pub/images/plus.svg';
import styles from './index.less';

export interface NumberCountProps extends PropsWithChildren {
  min?: number;
  max?: number;
  step?: number;
  className?: string;
  onChange?: (e: number) => void;
  size?: string;
  initialValues?: number;
  value?: number;
  disabled?: boolean;
}

export default class NumberCounter extends React.Component<NumberCountProps> {
  static defaultProps: NumberCountProps = {
    initialValues: 0,
    step: 1,
    value: 0,
    onChange: () => void {},
  };

  get canDecrease() {
    if (!this.props.min) {
      return true;
    }
    return this.props.value > this.props.min;
  }

  get canIncrease() {
    if (!this.props.max) {
      return true;
    }
    return this.props.value < this.props.max;
  }
  render() {
    let {step, className, value} = this.props;
    let decrementClassName = cx([
      styles.decrement,
      {[styles.disabled]: !this.canDecrease},
    ]);
    let incrementClassName = cx([
      styles.increment,
      {[styles.disabled]: !this.canIncrease},
    ]);
    return (
      <div
        className={cx(
          styles.counter,
          className,
          this.props.size && styles.larger
        )}
      >
        <span
          className={decrementClassName}
          onClick={() => this.handleChange(value - step, !this.canDecrease)}
        >
          <Icon className={styles.icon} component={minusIcon} />
        </span>
        <input
          className={styles.number}
          type="text"
          value={value}
          onChange={e => this.handleChange(+e.target.value)}
          disabled={this.props.disabled}
        />
        <span
          className={incrementClassName}
          onClick={() => this.handleChange(value + step, !this.canIncrease)}
        >
          <Icon className={styles.icon} component={plusIcon} />
        </span>
      </div>
    );
  }

  handleChange(num: number, disabled?: boolean) {
    if (disabled) {
      return;
    }
    const {onChange} = this.props;
    let countNum: number = num;
    if (this.props.min) {
      countNum = Math.min(num || 0, this.props.min);
    }
    if (this.props.max) {
      countNum = Math.min(num || 0, this.props.max);
    }
    onChange?.(countNum);
  }
}
