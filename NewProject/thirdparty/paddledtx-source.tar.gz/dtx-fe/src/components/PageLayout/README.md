# PageLayout 背景设置

## 背景图片
已从 secretpad 复制了以下背景图片：
- `backgroubd-bg.png` - 默认背景图片
- `bg.png` - 中心背景图片

## 使用方法

### 1. 默认背景（homeBg）
```tsx
<PageLayout>
  <YourContent />
</PageLayout>
```

### 2. 指定背景类型
```tsx
<PageLayout backgroundType="centerBg">
  <YourContent />
</PageLayout>
```

### 3. 动态切换背景
```tsx
import { backgroundService } from '@/services/background.service';

// 切换到中心背景
backgroundService.setBgClassName('centerBg');

// 切换到默认背景
backgroundService.setBgClassName('homeBg');
```

## 背景样式
- `background-size: cover` - 背景图片覆盖整个容器
- `background-position: center` - 背景图片居中
- `background-repeat: no-repeat` - 背景图片不重复

## 文件位置
- 背景图片：`src/assets/`
- 背景服务：`src/services/background.service.ts`
- 样式文件：`src/components/PageLayout/index.less`
