/**
 * @file (index)
 * Created by wuhan01 on 2019-04-10.
 */
/* global PLATFORM_LOGO */

import React from 'react';
import cx from 'classnames';
import {Link, NavLink} from 'react-router-dom';
// import constants from '@libs/constants';

// styles

// component
import {Popover} from 'antd';
import Icon from '@ant-design/icons';

// assets
import IMG_Exit from '@pub/images/exit.svg';
import IMG_Account from '@pub/images/account_manage_icon.svg';
import IMG_USER from '@pub/images/user_icon.svg';

import ARROW_DOWN from '@pub/images/arrow_down.svg';
import PageLogo from '@pub/images/pagelogo.svg';
import styles from './index.less';

import withRouter, {PropsWithRouter} from '@/libs/withRouter';

export interface NavItem {
  to: string;
  label: string;
}
export interface UserAddressData {
  pri: string;
  pub: string;
}
export interface HeaderProps {
  user?: UserAddressData & {
    role: string;
  };
}
export interface HeaderState {
  userInfoModalDisplay: boolean;
}

class Header extends React.Component<
  HeaderProps & PropsWithRouter,
  HeaderState
> {
  state = {
    userInfoModalDisplay: false,
  };

  onAccountClick() {
    this.props.router.navigate('/account/mine');
  }

  userDom() {
    return (
      <div className={styles.userInfoList}>
        <div className={styles.infoItem}>
          <a className={styles.link} onClick={this.onAccountClick.bind(this)}>
            <Icon component={IMG_Account} className={styles.exitConsoleIcon} />
            账户信息
          </a>
        </div>
        <div className={styles.infoItem}>
          <Link
            to="/logout"
            className={styles.link}
            onClick={() => localStorage.removeItem('UNICOM_DEMO_USER')}
          >
            <Icon component={IMG_Exit} className={styles.exitConsoleIcon} />
            退出登录
          </Link>
        </div>
      </div>
    );
  }

  renderUser() {
    return (
      <Popover
        overlayClassName={styles.userMenuOverLayer}
        placement="bottomRight"
        content={this.userDom()}
        getPopupContainer={() => document.getElementById('userInfoMenuBox')}
        overlayStyle={{width: '138px', wordBreak: 'break-all'}}
      >
        <span className={styles.userHeaderIcon} id="userInfoMenuBox">
          <Icon className={cx(styles.userImg)} component={IMG_USER} />
          <Icon className={cx(styles.downIcon)} component={ARROW_DOWN} />
        </span>
      </Popover>
    );
  }

  render() {
    const {location} = this.props.router;
    return (
      <div className={styles.topHeaderBox}>
        <div className={styles.antdHeader}>
          <div className={styles.logoBox}>
            <Link to="/dataset/space" className={styles.logoLinkBox}>
              <Icon component={PageLogo} className={styles.headerLogoImg} />
              <span className={styles.logoText}>隐私计算平台</span>
            </Link>
          </div>
          <div className={styles.infoBox}>
            {this.props.user.role === 'provider' ||
            this.props.user.role === 'user' ? (
              <a
                download="go-sdk.tar"
                href="/"
                className={styles.sdkLink}
              >
                下载sdk
              </a>
            ) : (
              ''
            )}
            <span className={styles.roleText}>
              {this.props.user.role}
            </span>
            <div>{this.renderUser()}</div>
          </div>
        </div>
        <div className={styles.headerShadowBox}></div>
      </div>
    );
  }
}

export default withRouter<HeaderProps>(Header);
