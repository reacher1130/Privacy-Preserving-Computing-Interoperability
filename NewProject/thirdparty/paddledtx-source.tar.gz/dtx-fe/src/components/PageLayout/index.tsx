/**
 * @file index.tsx
 * @author zhangguopeng(@baidu.com)
 * @created 2023-07-06 13:41:36
 */

import React, {PropsWithChildren, useState, useEffect} from 'react';
import {Layout} from 'antd';
import {
  PermissionType,
  PermissionValue,
} from '@/pages/Account/PermissionCreator';
import Header from './Header';
import SiderNav, {MenuItem} from './Sider';
import {backgroundService} from '@/services/background.service';
import styles from './index.less';

const {Content} = Layout;

export type PageLayoutProps = PropsWithChildren;

const menuList: MenuItem[] = [
  {
    path: '/dataset',
    title: '数据资源管理',
    key: 'dataset',
    roleType: PermissionType.Dataset,
    rolePermisson: PermissionValue.Read,
    subItems: [
      {
        path: '/dataset/space',
        title: '数据资源空间',
        key: 'datasetSpace',
        roleType: PermissionType.Dataset,
        rolePermisson: PermissionValue.Read,
      },
      {
        path: '/dataset/mine',
        title: '我的数据资源',
        key: 'datasetMine',
        roleType: PermissionType.Dataset,
        rolePermisson: PermissionValue.Read,
      },
      {
        path: '/dataset/authorization',
        title: '数据资源授权',
        key: 'datasetAuthorization',
        roleType: PermissionType.Dataset,
        rolePermisson: PermissionValue.Read,
      },
    ],
  },
  {
    path: '/modelset',
    title: '模型资源管理',
    key: 'modelset',
    roleType: PermissionType.Modelset,
    rolePermisson: PermissionValue.Read,
    subItems: [
      {
        path: '/modelset/space',
        title: '模型资源空间',
        key: 'modelsetSpace',
        roleType: PermissionType.Modelset,
        rolePermisson: PermissionValue.Read,
      },
      {
        path: '/modelset/mine',
        title: '我的模型资源',
        key: 'modelsetMine',
        roleType: PermissionType.Modelset,
        rolePermisson: PermissionValue.Read,
      },

      {
        path: '/modelset/authorization',
        title: '模型资源授权',
        key: 'modelsetAuthorization',
        roleType: PermissionType.Modelset,
        rolePermisson: PermissionValue.Read,
      },
    ],
  },
  {
    path: '/task',
    title: '任务管理',
    key: 'task',
    roleType: PermissionType.Task,
    rolePermisson: PermissionValue.Read,
    subItems: [
      {
        path: '/task/list',
        title: '任务列表',
        key: 'taskList',
        roleType: PermissionType.Task,
        rolePermisson: PermissionValue.Read,
      },
    ],
  },
  {
    path: '/algorithm',
    title: '算法管理',
    key: 'algorithm',
    roleType: PermissionType.Algorithm,
    rolePermisson: PermissionValue.Read,
    subItems: [
      {
        path: '/algorithm/list',
        title: '算法列表',
        key: 'algorithmList',
        roleType: PermissionType.Algorithm,
        rolePermisson: PermissionValue.Read,
      },
    ],
  },
  {
    path: '/operation',
    title: '运维管理',
    key: 'operation',
    roleType: PermissionType.Op,
    rolePermisson: PermissionValue.Read,
    subItems: [
      {
        path: '/operation/blockchain',
        title: '区块链网络',
        key: 'operationBlockchain',
        roleType: PermissionType.Op,
        rolePermisson: PermissionValue.Read,
      },
      {
        path: '/operation/storage',
        title: '存储网络',
        key: 'operationStorage',
        roleType: PermissionType.Op,
        rolePermisson: PermissionValue.Read,
      },
      {
        path: '/operation/computing',
        title: '计算网络',
        key: 'operationComputing',
        roleType: PermissionType.Op,
        rolePermisson: PermissionValue.Read,
      },
    ],
  },
  {
    path: '/account',
    title: '账户管理',
    key: 'account',
    subItems: [
      {
        path: '/account/mine',
        title: '我的账户',
        key: 'accountMine',
      },
      {
        path: '/account/role',
        title: '角色管理',
        key: 'accountRole',
        roleType: PermissionType.Permission,
        rolePermisson: PermissionValue.Write,
      },
      {
        path: '/account/rights',
        title: '权限管理',
        key: 'accountRights',
        roleType: PermissionType.Permission,
        rolePermisson: PermissionValue.Write,
      },
    ],
  },
];
interface PageLayoutExtraProps {
  title?: string;
  backgroundType?: 'homeBg' | 'centerBg';
  collapsed?: boolean;
}
export default function PageLayout(
  props: PageLayoutProps & PageLayoutExtraProps
) {
  const {title, backgroundType = 'homeBg', collapsed = false} = props;
  const [currentBg, setCurrentBg] = useState(backgroundType);

  useEffect(() => {
    setCurrentBg(backgroundType);
    backgroundService.setBgClassName(backgroundType);
  }, [backgroundType]);

  return (
    <Layout className={`${styles.page_layout} ${styles[currentBg]}`}>
      <Header
        // nav={props.nav}
        user={{pri: '{}', pub: '{}', role: ''}}
      />
      <Layout className={styles.main_layout}>
        <SiderNav 
          menuList={menuList} 
          className={collapsed ? styles.fold : styles.unfold}
        />
        <Content className={styles.page_layout_content}>
          {props.children}
        </Content>
      </Layout>
    </Layout>
  );
}
