/* eslint-disable react/jsx-no-bind */
/**
 * @file index.tsx
 * @author zhangguopeng(@baidu.com)
 * @created 2023-07-06 18:29:41
 */

import {Layout, Menu} from 'antd';
import React from 'react';
import {useNavigate} from 'react-router-dom';
import Icon from '@ant-design/icons';

import {useDispatch, useSelector} from 'react-redux';
import BLOCK_CHAIN_ICON from '@pub/images/blockchain_icon.svg';
import CONTRACT_BASE_ICON from '@pub/images/contract_base_icon.svg';
import CONSOLE_COMP_ICON from '@pub/images/console_comp_icon.svg';
import GOVERN_ICON from '@pub/images/govern_icon.svg';
import MONITOR_OP_ICON from '@pub/images/monitor_op_icon.svg';
import ACCOUNT_ICON from '@pub/images/account_manage_icon.svg';
import siderSlice, {
  SelectedKeys,
  InitialType as SiderInitialType,
} from '@/slice/sider';
import CollapsedButton from '@/components/CollapsedButton';
import {
  PermissionKeys,
  PermissionValue,
  usePermissionWithRule,
} from '@/pages/Account/PermissionCreator';
import styles from './index.less';

const icons = [
  BLOCK_CHAIN_ICON,
  CONTRACT_BASE_ICON,
  CONSOLE_COMP_ICON,
  GOVERN_ICON,
  MONITOR_OP_ICON,
  ACCOUNT_ICON,
];
export interface SiderNavSubMenuItemProps {
  isThirdMenu?: boolean;
  disabled?: boolean;
  path: string;
  title: string;
  key?: string;
  roleType?: PermissionKeys;
  rolePermisson?: PermissionValue;
}
export interface MenuItem {
  path?: string;
  key?: string;
  disabled?: boolean;
  icon?: any;
  title?: string;
  subItems?: SiderNavSubMenuItemProps[];
  roleType?: PermissionKeys;
  rolePermisson?: PermissionValue;
}
export interface SiderNavProps {
  width?: number;
  menuList: MenuItem[];
  className?: string;
}
export default function SiderNav(props: SiderNavProps) {
  const {menuList, width, className} = props;
  const {collapsed, selectedKeys} = useSelector<
    {Sider: SiderInitialType},
    SiderInitialType
  >(state => state.Sider);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const checkRole = usePermissionWithRule();
  return (
    <Layout.Sider
      className={`${styles.sider} ${className || ''}`}
      width={width ?? 208}
      collapsed={collapsed}
      collapsedWidth={60}
    >
      {menuList.length > 0 && (
        <Menu
          mode="inline"
          inlineIndent={24}
          defaultOpenKeys={collapsed ? [] : menuList.map(m => m.key)}
          selectedKeys={selectedKeys}
          onSelect={({selectedKeys}) =>
            dispatch(
              siderSlice.actions.updateSeletedKeys({
                selectedKeys: selectedKeys as SelectedKeys[],
              })
            )
          }
          style={{
            borderRight: 0,
            flex: 1,
            backgroundColor: '#fff' || 'transparent',
          }}
          items={menuList
            .filter(item => {
              if (!item.roleType) {
                return item;
              }
              return checkRole(item.roleType, item.rolePermisson);
            })
            .map((item, index) => {
              // const path = item.path;
              if (item.subItems && item.subItems.length === 0) {
                return {
                  icon: icons[index],
                  label: item.title,
                  key: item.key,
                  disabled: item.disabled,
                  className: styles.firstLayerLink,
                };
              }

              return {
                label: item.title,
                key: item.key,
                disabled: item.disabled,
                icon: <Icon component={icons[index]} />,
                className: styles.menuItem,
                children:
                  item.subItems &&
                  item.subItems
                    .filter(item => {
                      if (!item.roleType) {
                        return item;
                      }
                      return checkRole(item.roleType, item.rolePermisson);
                    })
                    .map(item => {
                      return {
                        label: item.title,
                        key: item.key,
                        disabled: item.disabled,
                        className: styles.submenuLink,
                        onClick: () => {
                          navigate(item.path);
                        },
                      };
                    }),
              };
            })}
        />
      )}
      {
        <CollapsedButton
          toggleCollapsed={() => dispatch(siderSlice.actions.updateCollapse())}
          collapsed={collapsed}
        />
      }
    </Layout.Sider>
  );
}
