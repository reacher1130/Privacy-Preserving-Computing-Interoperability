import React, {ReactNode} from 'react';
import {Typography, ConfigProvider} from 'antd';
import zh_CN from 'antd/lib/locale/zh_CN';
import styles from './index.less';
// import {CopyOutlined } from '@ant-design/icons’;
import {CopyOutlined} from '@ant-design/icons';

const {Paragraph} = Typography;

export interface TextCopyProps {
  content: string | number;
}

const TextCopy: React.FC<TextCopyProps> = props => {
  const {content} = props;
  return (
    <ConfigProvider locale={zh_CN}>
      <Paragraph
        copyable={{
          icon: [
            <CopyOutlined style={{color: 'rgb(7, 175, 190)'}} />,
            <CopyOutlined style={{color: 'rgb(7, 175, 190)'}} />,
          ],
          tooltips: [
            <div className={styles.beforeCopy} key="0">
              复制
            </div>,
            <div className={styles.afterCopy} key="1">
              复制成功
            </div>,
          ],
        }}
      >
        {content}
      </Paragraph>
    </ConfigProvider>
  );
};

export default TextCopy;
