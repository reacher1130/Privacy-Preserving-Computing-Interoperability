import React, {PropsWithChildren} from 'react';
import styles from './index.less';

export interface TextListType {
  title: string;
  desc: string;
  key?: string | number;
}

interface TextListProps extends PropsWithChildren {
  list: TextListType[];
}

export default function TextList(props: TextListProps) {
  const {list = []} = props;
  return list.length > 0
    ? list.map((item, index) => {
        return (
          <div className={styles.textArea} key={index}>
            <div className={styles.title}>{item.title}</div>
            <div className={styles.desc}>{item.desc}</div>
          </div>
        );
      })
    : null;
}
