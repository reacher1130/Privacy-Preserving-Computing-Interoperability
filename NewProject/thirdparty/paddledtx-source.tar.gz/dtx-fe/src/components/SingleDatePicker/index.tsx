/**
 * @file 日期时间选择
 *
 */
import React from 'react';
import {DatePicker} from 'antd';
import locale from 'antd/lib/date-picker/locale/zh_CN';
import dayjs, {Dayjs} from 'dayjs';
import styles from './index.less';

interface TimeProps {
  placeholder?: string;
  value?: number | undefined | null;
  onChange?: (params: number | undefined | null) => void;
  disabledDate?: (current: Dayjs) => boolean;
}

interface TimeState {
  value: Dayjs;
}

export default class DatePick extends React.Component<TimeProps, TimeState> {
  wrapRef = React.createRef<HTMLDivElement>();
  state: TimeState = {
    value: undefined,
  };

  static getDerivedStateFromProps(props: {value: any}) {
    let v = props.value;
    if (typeof v === 'number') {
      v = dayjs(v);
    }
    return {
      value: v,
    };
  }

  static disabledFromNow = (current: Dayjs) => {
    return current && current < dayjs();
  };

  onChange = (value: Dayjs, dateString: string) => {
    this.setState({value});
    const {onChange, value: val} = this.props;
    let timestramp = dateString ? +new Date(dateString) : null;
    if (dateString && !timestramp) {
      const dateStr = dateString.replace(/-/g, '/');
      timestramp = dateStr ? +new Date(dateStr) : null;
    }
    onChange?.(timestramp);
  };

  render() {
    const {value} = this.state;
    const {placeholder = '请选择结束时间'} = this.props;
    // const minWidth = 318;
    return (
      <div className={styles.ant_budget_row} ref={this.wrapRef}>
        <DatePicker
          rootClassName={styles.single_date_picker}
          style={{width: '100%'}}
          popupClassName={styles.dateDropBox}
          showTime
          locale={locale}
          format="YYYY-MM-DD HH:mm:ss"
          value={value}
          placeholder={placeholder}
          onChange={this.onChange}
          popupStyle={{width: '460px'}}
          disabledDate={this.props.disabledDate ?? (() => false)}
          getPopupContainer={() => this.wrapRef.current}
        />
      </div>
    );
  }
}
