/**
 * @file 日期时间选择
 * ''
 * @createTime 2021.12.16
 * @description 日期范围选择器不支持某一天内的时间范围选择，用2个datepicker实现
 *
 */
import React from 'react';
import {Row, Col, DatePicker} from 'antd';
import locale from 'antd/lib/date-picker/locale/zh_CN';
import {Dayjs} from 'dayjs';
import styles from './style.less';

export interface TimeRangeProps {
  value?: [Dayjs, Dayjs];
  startChange?: (params: {value: number | null; dateString: string}) => void;
  endChange?: (params: {value: number | null; dateString: string}) => void;
  onChange?: (startTime?: Dayjs, endTime?: Dayjs) => void;
}

export interface TimeRangeState {
  endOpen: boolean;
  startValue: Dayjs;
  endValue: Dayjs;
}
export default class TimeRange extends React.Component<
  TimeRangeProps,
  TimeRangeState
> {
  state: TimeRangeState = {
    startValue: null,
    endValue: null,
    endOpen: false,
  };

  static getDerivedStateFromProps(props: TimeRangeProps) {
    if (props.value) {
      return {
        startValue: props.value[0],
        endValue: props.value[1],
      };
    }
    return {};
  }

  disabledStartDate = (startValue: Dayjs) => {
    const {endValue} = this.state;
    if (!startValue || !endValue) {
      return false;
    }
    const end = endValue.valueOf();
    const start = startValue.valueOf();
    // return start > end || start < (end - (24 * 3600 * 1000 * 2));
    return start > end;
  };

  disabledEndDate = (endValue: Dayjs) => {
    const {startValue} = this.state;
    if (!endValue || !startValue) {
      return false;
    }
    const end = endValue.valueOf();
    const start = startValue.valueOf();
    // return end <= start || end > (start + (24 * 3600 * 1000 * 2));
    return end <= start;
  };

  onChange = (field: string, value: Dayjs) => {
    this.setState({
      ...this.state,
      [field]: value,
    });
  };

  onStartChange = (_value: Dayjs, dateString: string) => {
    this.onChange('startValue', _value);
    const value = _value?.valueOf();
    const {startChange, onChange} = this.props;
    startChange && startChange({value, dateString});
    onChange && onChange(this.state.startValue, this.state.endValue);
  };

  onEndChange = (_value: Dayjs, dateString: string) => {
    this.onChange('endValue', _value);
    const value = _value?.valueOf();
    const {endChange, onChange} = this.props;
    endChange && endChange({value, dateString});
    onChange && onChange(this.state.startValue, this.state.endValue);
  };

  handleStartOpenChange = (open: boolean) => {
    if (!open) {
      this.setState({endOpen: true});
    }
  };

  handleEndOpenChange = (open: boolean) => {
    this.setState({endOpen: open});
  };

  render() {
    const {startValue, endValue, endOpen} = this.state;
    return (
      <Row justify="start" className={styles.ant_budget_row}>
        <Col>
          <DatePicker
            // disabledDate={this.disabledStartDate}
            showTime
            locale={locale}
            format="YYYY-MM-DD HH:mm:ss"
            value={startValue}
            placeholder="开始日期"
            onChange={this.onStartChange}
            onOpenChange={this.handleStartOpenChange}
          />
        </Col>
        <Col className={styles.endTimeStyle}>
          <DatePicker
            disabledDate={this.disabledEndDate}
            showTime
            locale={locale}
            format="YYYY-MM-DD HH:mm:ss"
            value={endValue}
            placeholder="结束日期"
            onChange={this.onEndChange}
            open={endOpen}
            onOpenChange={this.handleEndOpenChange}
          />
        </Col>
      </Row>
    );
  }
}
