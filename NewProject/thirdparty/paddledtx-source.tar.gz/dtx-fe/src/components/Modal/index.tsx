import React, {useState, useEffect, ReactNode, CSSProperties} from 'react';
import {Button, ButtonProps, Modal} from 'antd';
import {PlusOutlined} from '@ant-design/icons';
import styles from './index.less';

interface ModalProps {
  okText?: string;
  cancelText?: string;
  open: boolean;
  title?: string;
  content?: ReactNode;
  style?: CSSProperties;
  width?: string | number;
  wrapClassName?: string;
  hideCancelBtn?: boolean;
  hideOkBtn?: boolean;
  okButtonProps?: ButtonProps;
  cancelButtonProps?: ButtonProps;
  Component?: React.PureComponent;
  onOk?: () => void;
  onCancel?: () => void;
}

const hideButtonClass = styles.hideButton;
const ModalBox: React.FC<ModalProps & React.PropsWithChildren> = props => {
  const {
    open = false,
    title = '',
    onOk,
    onCancel,
    style,
    width,
    wrapClassName,
    okText = '确认',
    cancelText = '取消',
    cancelButtonProps = {},
    okButtonProps = {},
    hideCancelBtn = false,
    hideOkBtn = false,
  } = props;
  const [isShow, setShow] = useState(open);
  useEffect(() => {
    setShow(open);
  }, [open]);
  const cancelBtnProps = hideCancelBtn
    ? {className: hideButtonClass, ...cancelButtonProps}
    : cancelButtonProps;
  const okBtnProps = hideOkBtn
    ? {className: hideButtonClass, ...okButtonProps}
    : okButtonProps;

  return (
    <>
      <Modal
        title={title}
        centered
        open={isShow}
        style={style}
        width={width}
        wrapClassName={wrapClassName}
        destroyOnClose
        okText={okText}
        cancelText={cancelText}
        cancelButtonProps={cancelBtnProps}
        okButtonProps={okBtnProps}
        onOk={onOk}
        onCancel={onCancel}
        maskClosable={false}
        className={styles.modalBox}
      >
        <div className={styles.modalContent}>{props.children}</div>
      </Modal>
    </>
  );
};

export default ModalBox;
