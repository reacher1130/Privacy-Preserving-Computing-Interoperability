/* eslint-disable import/named */
import {DatasetUploadFileResponse} from '@/libs/api';
import {Col, Row} from 'antd';
import useFormInstance from 'antd/es/form/hooks/useFormInstance';
import Upload, {
  UploadChangeParam,
  UploadFile,
  UploadProps,
} from 'antd/es/upload';
import React, {
  PropsWithChildren,
  useCallback,
  useEffect,
  useState,
} from 'react';
import Button from '../Button';
import {UploadOutlined} from '@ant-design/icons';

export interface UploaderProps extends PropsWithChildren, UploadProps {
  onChange?: (file: UploadChangeParam<UploadFile<any>>) => void;
}
const Uploader: React.FC<UploaderProps> = props => {
  const {onChange, ...params} = props;
  const [file, setFile] = useState(null);
  const InternalOnChange: UploadProps['onChange'] = useCallback(({file}) => {
    setFile(file);
  }, []);

  useEffect(() => {
    if (file) {
      onChange?.(file?.response ?? null);
    }
  }, [file]);
  delete (params as any).value;
  return (
    <Row gutter={8}>
      <Col span={10}>
        <Upload onChange={InternalOnChange} {...params}>
          <Button icon={<UploadOutlined />}>上传文件</Button>
        </Upload>
      </Col>
      <Col span={12} style={{lineHeight: '32px'}}>
        支持{props.accept}文件
      </Col>
    </Row>
  );
};

export default Uploader;
