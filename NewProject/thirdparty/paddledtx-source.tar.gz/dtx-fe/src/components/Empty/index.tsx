/**
 * @file index
 * Created by qilinlin on 2019/04/28
 * Modify by qilinlin on 2020/10/30
 * Add another class EmptyBox that usefull for many pages
 */

import React, {ReactElement} from 'react';
import {Link} from 'react-router-dom';
import classnames from 'classnames';
import {PlusOutlined} from '@ant-design/icons';
import {Button, Popover} from 'antd';
import EmptyIcon from '@pub/images/empty.png';
import EmptyImg from '@pub/images/data_empty.png';
import classes from './style.less';

// export class EmptyBox extends React.Component {
//     render() {
//         /**
//          * title: 标题文案
//          * showBtn: 是否展示按钮
//          * btnTitle: 按钮文案
//          * showIcon: 是否展示 `+` Icon
//          * target_url: 按钮跳转链接
//          * isDisabled: 是否置灰
//          */
//         let {
//             title,
//             showBtn = false,
//             btnTitle = null,
//             showImg = true,
//             showIcon = false,
//             target_url = '/',
//             isDisabled = false,
//             hasPop = false,
//             popText = '',
//         } = this.props;
//         return (
//             <div className={classnames(classes.empty, this.props.className)}>
//                 {showImg && (
//                     <img src={EmptyIcon} alt="" className={classes.img} />
//                 )}
//                 <div className={classes.title}>{title}</div>
//                 {showBtn ? (
//                     hasPop ? (
//                         <Popover content={popText} placement="top">
//                             <Button
//                                 type={'primary'}
//                                 className={classes.btn}
//                                 disabled={isDisabled}
//                             >
//                                 {showIcon ? <PlusOutlined /> : null}
//                                 {btnTitle}
//                             </Button>
//                         </Popover>
//                     ) : (
//                         <Link to={target_url}>
//                             <Button
//                                 type={'primary'}
//                                 className={classes.btn}
//                                 disabled={isDisabled}
//                             >
//                                 {showIcon ? <PlusOutlined /> : null}
//                                 {btnTitle}
//                             </Button>
//                         </Link>
//                     )
//                 ) : null}
//             </div>
//         );
//     }
// }

export interface EmptyProps {
  desc?: string;
  msg?: string;
  showIcon?: boolean;
  IconComponent?: ReactElement;
  emptyClass?: string;
  msgClass?: string;
  showBtn?: boolean;
  btnText?: string;
  btnDisabled?: boolean;
  onBtnClick?: () => void;
}
const Empty: React.FC<EmptyProps> = props => {
  const msgClass = props.msgClass;
  const {
    desc,
    msg = '暂无数据',
    showBtn = false,
    btnText = '',
    showIcon = false,
    btnDisabled = false,
    IconComponent = <PlusOutlined />,
    emptyClass,
  } = props;
  return (
    <div className={classnames(classes.xchainPageListNoData, emptyClass)}>
      <div className={classes.NoDataImg}>
        {/* <span className={classnames(classes.noDataMsg, msgClass)}>{msg}</span> */}
        <img src={EmptyImg} className={classes.img} alt="" />
        <div className={classnames(classes.msg, msgClass)}>{msg}</div>
      </div>
      {showBtn ? (
        <Button
          type={'primary'}
          className={classnames(classes.btn, btnDisabled && classes.disabled)}
          disabled={btnDisabled}
          onClick={() => {
            props.onBtnClick();
          }}
        >
          {showIcon ? IconComponent : null}
          {btnText}
        </Button>
      ) : null}
      {desc ? desc : null}
    </div>
  );
};
export default Empty;
