/**
 * @file 跨链事件中心下拉菜单状态
 *
 * @time 2020/10/23
 */

import React, {ReactNode} from 'react';
import Icon from '@ant-design/icons';
import {Select, SelectProps} from 'antd';
import cx from 'classnames';
import {SizeType} from 'antd/es/config-provider/SizeContext';
import DropdownIcon from '@pub/images/dropdown.svg';
import styles from './style.less';

export type SelectStatusItemProps = Array<
  Record<string, string | number | boolean> | string | number | boolean
>;
export interface SelectStatusProps {
  optsList: SelectStatusItemProps;
  onChange?: (p: Parameters<SelectProps['onChange']>[0]) => void;
  selectBoxClass?: string;
  size?: SizeType;
  disabled?: boolean;
  placeholder?: string;
  value?: any;
  optsValueKey?: string; // 定义选项值的key
  optsNameKey?: string; // 定义选项显示的key
  optsNameKeyAppend?: string; // 定义选项显示的key
  allowClear?: boolean;
}

export type SelectStatusState = Pick<
  SelectStatusProps,
  'optsList' | 'value' | 'optsValueKey' | 'optsNameKey' | 'optsNameKeyAppend'
> & {
  isChange: boolean;
};

class SelectStatus extends React.Component<
  SelectStatusProps,
  SelectStatusState
> {
  static defaultProps: SelectStatusProps = {
    optsList: [],
    optsValueKey: 'value', // 定义选项值的key
    optsNameKey: 'label', // 定义选项显示的key
    optsNameKeyAppend: '', // 定义选项显示的key
  };

  constructor(props: SelectStatusProps) {
    super(props);
    this.state = {
      isChange: false,
      optsList: [],
      value: undefined,
    };
  }

  static getDerivedStateFromProps(props: SelectStatusProps) {
    const {optsList, value, optsValueKey, optsNameKey, optsNameKeyAppend} =
      props;
    return {
      value,
      optsList,
      optsValueKey,
      optsNameKey,
      optsNameKeyAppend,
    };
  }

  onChange(status: Parameters<SelectProps['onChange']>[0]) {
    this.setState({isChange: true});
    this.props.onChange && this.props.onChange(status);
  }

  render() {
    const {
      isChange,
      optsList,
      value,
      optsValueKey,
      optsNameKey,
      optsNameKeyAppend,
    } = this.state;
    const {selectBoxClass} = this.props;
    return (
      <div className={cx(styles.selectBox, selectBoxClass)}>
        <Select
          size={this.props.size}
          allowClear={this.props.allowClear}
          disabled={this.props.disabled}
          placeholder={this.props.placeholder}
          value={value}
          popupClassName={styles['dropdown-overlay']}
          suffixIcon={
            <Icon
              className={styles['dropdown-icon']}
              component={DropdownIcon}
            />
          }
          getPopupContainer={el => el.parentElement}
          className={cx(
            styles['form-select'],
            styles.selectDefault,
            isChange && styles.selectChangeColor
          )}
          onChange={this.onChange.bind(this)}
        >
          {optsList.map(item => {
            // if item value is string or number, trans item to object with key and value
            if (typeof item !== 'object') {
              const itemBak = item;
              item = {
                [optsNameKey]: itemBak,
                [optsValueKey]: itemBak,
              };
            }
            let optsName = item[optsNameKey];
            const optsAppendName = optsNameKeyAppend
              ? item[optsNameKeyAppend]
              : '';
            optsName = optsAppendName
              ? `${optsName}(${optsAppendName})`
              : optsName;
            return (
              <Select.Option
                key={item[optsValueKey] as string | number}
                value={item[optsValueKey]}
                disabled={item?.disabled}
              >
                {optsName as ReactNode}
              </Select.Option>
            );
          })}
        </Select>
      </div>
    );
  }
}
export default SelectStatus;
