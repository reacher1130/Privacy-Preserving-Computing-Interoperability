/**
 * @file (index)
 *
 */

import React from 'react';

import cx from 'classnames';

import Icon from '@ant-design/icons';

import {Button} from 'antd';
import ICON_UNFLOD from '@pub/images/unflod.svg';
import ICON_FLOD from '@pub/images/flod.svg';
import styles from './style.less';

export interface CollapseProps {
  collapsed: boolean;
  toggleCollapsed: (e: any) => void;
  className?: string;
}

const CollapsedButton = (props: CollapseProps) => {
  return (
    <Button
      className={cx(styles.button, props.className)}
      onClick={props.toggleCollapsed}
    >
      {props.collapsed ? (
        <Icon component={ICON_UNFLOD} style={{color: '#333'}} />
      ) : (
        <Icon component={ICON_FLOD} style={{color: '#333'}} />
      )}
      {props.collapsed ? null : <span className={styles.tip}>收起</span>}
    </Button>
  );
};

export default CollapsedButton;
