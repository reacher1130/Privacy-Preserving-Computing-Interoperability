import React, {PropsWithChildren} from 'react';
import cx from 'classnames';
import styles from './style.less';

export interface TitleProps extends PropsWithChildren {
  titleClass?: string;
  title?: string;
}
export default function Title(props: TitleProps) {
  const {title = '', titleClass, children} = props;
  return title.length > 0 ? (
    <div className={cx(styles.titleBox, titleClass)}>
      <div className={styles.title}>{title}</div>
      <div className={styles.children}>{children}</div>
    </div>
  ) : null;
}
