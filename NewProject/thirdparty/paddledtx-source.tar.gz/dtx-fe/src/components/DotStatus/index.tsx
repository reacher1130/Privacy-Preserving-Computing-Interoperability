import React, {PropsWithChildren} from 'react';
import styles from './index.less';

export interface DotStatusProps extends PropsWithChildren {
  type: 'green' | 'gray' | 'orange' | 'blue';
  className?: string;
}
const DotStatus: React.FC<DotStatusProps> = props => {
  const {type = 'green', className = ''} = props;
  const rootClassName = [styles.dot_status, className].join(' ').trim();
  return (
    <div className={rootClassName}>
      <span className={[styles.icon, styles[`icon_${type}`]].join(' ')} />
      <span className={styles.icon_text}>{props.children}</span>
    </div>
  );
};

export default DotStatus;
