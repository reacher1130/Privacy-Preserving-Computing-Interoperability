/**
 * @file alert提示框
 *
 */

import React, {CSSProperties, useEffect, useState} from 'react';
import {Alert, AlertProps as AntdAlertProps} from 'antd';
import classes from './style.less';

export interface AlertProps {
  time?: number;
  isAutoClose?: boolean;
  showIcon?: boolean;
  styleObj?: Pick<CSSProperties, 'top' | 'transform'>;
  message?: string;
  type?: AntdAlertProps['type'];
  isShow?: boolean;
  autoCloseCallBack?: (e?: any) => void;
}
export default function AlertTip(props: AlertProps) {
  let showTimer: number | null = null;

  const [isShow, setIsShow] = useState(false);

  const {
    styleObj = {top: '106px', transform: 'translate(-50%, `106px`)'},
    message = '',
    type = 'warning',
    showIcon = true,
    time = 1500,
    isAutoClose = true,
    autoCloseCallBack,
  } = props;

  useEffect(() => {
    setIsShow(props.isShow);
    if (isAutoClose) {
      showTimer = window.setTimeout(() => {
        setIsShow(props.isShow);
        autoCloseCallBack && autoCloseCallBack();
        !autoCloseCallBack && setIsShow(false);
        window.clearTimeout(showTimer);
        showTimer = null;
      }, time);
    }
    return () => {
      showTimer && window.clearTimeout(showTimer);
      showTimer = null;
    };
  }, [props.isShow]);

  return isShow ? (
    <div className={classes.alertBox} style={styleObj}>
      <Alert message={message} type={type} showIcon={showIcon} />
    </div>
  ) : null;
}
