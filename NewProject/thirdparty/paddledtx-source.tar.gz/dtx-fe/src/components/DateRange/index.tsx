/**
 * @file 时间范围选择，可能含搜索，重构摘自旧版
 */

import React from 'react';
import {Row, Col, DatePicker} from 'antd';
import locale from 'antd/lib/date-picker/locale/zh_CN';

import dayjs, {Dayjs} from 'dayjs';
import styles from './style.less';

export interface OnChangeRange {
  startTime: number;
  endTime: number;
}
export interface DateRangeProps {
  onChange?: (range: OnChangeRange) => void;
  allowClear: boolean;
}
export type DateRangeState = OnChangeRange;
export default class DateRange extends React.Component<
  DateRangeProps,
  DateRangeState
> {
  state: DateRangeState = {
    startTime: null,
    endTime: null,
  };

  onChange(dates: Dayjs[]) {
    let range = dates?.length
      ? {
          startTime: dates[0].startOf('day').unix(),
          endTime: dates[1].endOf('day').unix(),
        }
      : {
          startTime: null,
          endTime: null,
        };
    this.setState(range);
    this.props.onChange?.(range);
  }

  render() {
    return (
      <Row justify="start" className={styles.ant_budget_row}>
        <Col>
          <DatePicker.RangePicker
            format="YYYY/MM/DD"
            allowClear={this.props.allowClear}
            size="small"
            locale={locale}
            onChange={this.onChange.bind(this)}
            separator="-"
            presets={[
              {
                label: '昨天',
                value: [
                  dayjs().startOf('day').subtract(1, 'days'),
                  dayjs().endOf('day').subtract(1, 'days'),
                ],
              },
              {
                label: '今天',
                value: [dayjs().startOf('day'), dayjs()],
              },
              {
                label: '最近七天',
                value: [dayjs().startOf('day').subtract(6, 'days'), dayjs()],
              },
              {
                label: '最近30天',
                value: [dayjs().startOf('day').subtract(29, 'days'), dayjs()],
              },
            ]}
            className={styles.ant_rangePicker}
            popupClassName={styles.ant_wallet_eject}
            style={{width: 'auto'}}
          />
        </Col>
      </Row>
    );
  }
}
