/**
 * @file index.tsx
 */

import React, {PropsWithChildren, ReactElement} from 'react';
import {Layout} from 'antd';
import BreadCrumb, {BreadCrumbProps} from '@/components/BreadCrumb';
import styles from './style.less';

const {Content} = Layout;

interface ContentLayoutProps extends PropsWithChildren {
  paths?: BreadCrumbProps['paths'];
  desc?: string | ReactElement;
  className?: string;
}

const ContentLayout: React.FC<ContentLayoutProps> = props => {
  const {paths, desc, className = ''} = props;
  return (
    <Content className={styles.page_layout_content}>
      <BreadCrumb paths={paths} />
      {desc && <div className={styles.descContent}>{desc}</div>}
      <div className={[styles.mainContent, className].join(' ').trim()}>
        {props.children}
      </div>
    </Content>
  );
};

export default ContentLayout;
