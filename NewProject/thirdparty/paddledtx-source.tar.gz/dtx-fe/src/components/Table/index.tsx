/**
 * @file 表格
 *
 * @time 2023/03/21
 */

import React from 'react';
import zh_CN from 'antd/es/locale/zh_CN';
import {
  Table as AntdTable,
  ConfigProvider,
  TableProps as AntdTableProps,
} from 'antd';
import cx from 'classnames';
import Empty from '@components/Empty';
import Loading from '@components/Loading';
import styles from './index.less';

export interface TableProps {
  leftContent?: React.ReactElement;
  rightContent?: React.ReactElement;
  loading?: boolean;
  emptyText?: string;
}
// eslint-disable-next-line max-len
export default class Table<
  RecordType extends Record<string, any>,
> extends React.Component<TableProps & AntdTableProps<RecordType>> {
  static Column: typeof AntdTable.Column;
  renderPaginationItem(
    _: number,
    type: string,
    originalElement: React.ReactNode
  ) {
    if (type === 'jump-prev' || type === 'jump-next') {
      return <span style={{fontSize: '14px', color: '#666666'}}>...</span>;
    }
    return originalElement;
  }

  render() {
    const {leftContent, rightContent, loading} = this.props;
    const pagination =
      this.props.pagination === false
        ? false
        : {
            showTotal: (total: number) => `共${total}条`,
            showSizeChanger: false,
            showQuickJumper: false,
            hideOnSinglePage: true,
            itemRender: this.renderPaginationItem.bind(this),
            ...this.props.pagination,
          };
    return (
      <div className={styles.customTableWrapper}>
        {(!!leftContent || !!rightContent) && (
          <div className={styles.tableHeaderClass}>
            <div className={styles.leftContentClass}>
              {this.props.leftContent}
            </div>
            <div className={styles.rightContentClass}>
              {this.props.rightContent}
            </div>
          </div>
        )}
        <ConfigProvider locale={zh_CN}>
          {loading && <Loading />}
          {!loading && (
            <AntdTable
              {...this.props}
              bordered
              pagination={pagination}
              locale={{
                emptyText: <Empty msg={this.props.emptyText || '暂无数据'} />,
              }}
              className={cx(styles.customList, this.props.className)}
            >
              {this.props.children}
            </AntdTable>
          )}
        </ConfigProvider>
      </div>
    );
  }
}

Table.Column = AntdTable.Column;
