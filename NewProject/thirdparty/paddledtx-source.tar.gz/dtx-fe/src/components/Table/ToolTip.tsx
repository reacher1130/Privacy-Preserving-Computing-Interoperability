import React, {ReactNode} from 'react';
import {truncate} from 'lodash';
import {Tooltip, Typography} from 'antd';
import {CopyOutlined, CheckOutlined} from '@ant-design/icons';
import {BlockProps} from 'antd/es/typography/Base';
import styles from './ToolTip.less';

export interface ToolTipProps {
  content: string;
  copyable?: boolean;
}
export interface ToolTipPropsWithWidth extends ToolTipProps {
  maxWidth: number;
  maxLen?: never;
}
export interface ToolTipPropsWithLength extends ToolTipProps {
  maxWidth?: never;
  maxLen: number;
}
export const ToolTip: React.FC<
  ToolTipPropsWithWidth | ToolTipPropsWithLength
> = props => {
  const {content = '', maxLen, maxWidth, copyable = true} = props;
  let children: ReactNode = null;
  if (maxLen) {
    children = truncate(content, {length: maxLen});
  } else {
    children = (
      <div className={styles.tooltipWrap} style={{maxWidth: `${maxWidth}px`}}>
        {content}
      </div>
    );
  }
  let c: BlockProps['copyable'] = false;
  if (copyable) {
    c = {
      text: content,
      icon: [
        <CopyOutlined style={{color: 'rgb(7, 175, 190)'}} />,
        <CheckOutlined style={{color: 'rgb(7, 175, 190)'}} />,
      ],
      tooltips: false,
      format: 'text/plain',
    };
  }
  return (
    <Tooltip
      placement="top"
      rootClassName={styles.tooltipCustom}
      title={
        <Typography.Paragraph copyable={c} className={styles.tipP}>
          {content}
        </Typography.Paragraph>
      }
      className={styles.nowrap}
    >
      <span className={styles.nowrap}>{children}</span>
    </Tooltip>
  );
};

export interface TdRenderPropsWithLength {
  maxLen: number;
  maxWidth?: never;
}
export interface TdRenderPropsWithWidth {
  maxLen?: never;
  maxWidth: number;
}
function TdRender(options: TdRenderPropsWithLength | TdRenderPropsWithWidth) {
  return function (content: string) {
    const {maxLen, maxWidth} = options;
    if (maxLen) {
      return content ? <ToolTip content={content} maxLen={maxLen} /> : '--';
    }
    return content ? <ToolTip content={content} maxWidth={maxWidth} /> : '--';
  };
}

export const tdRender = TdRender;
