import {ConfigProvider, App as AntdApp} from 'antd';
import React from 'react';

function AntdConfigProvider(props: React.PropsWithChildren) {
  return (
    <ConfigProvider
      theme={{
        token: {
          borderRadius: 6,
          colorPrimary: '#0068fa',
          colorPrimaryHover: '#004D9E',
          controlOutline: '#0068fa',
          controlOutlineWidth: 0,
          colorText: 'rgba(0, 0, 0, 0.65)',
          fontSize: 14,
          fontSizeHeading1: 24,
          fontSizeHeading2: 20,
          fontSizeHeading3: 16,
          fontSizeHeading4: 14,
          fontSizeHeading5: 12,
          lineHeight: 1.5715,
          fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"',
        },
        components: {
          Menu: {
            itemHoverBg: 'transparent',
            itemSelectedBg: 'transparent',
            subMenuItemBg: 'transparent',
            itemSelectedColor: '#333',
            itemBorderRadius: 0,
            subMenuItemBorderRadius: 0,
          },
          Button: {
            borderRadius: 6,
            fontSize: 12,
            controlHeight: 32,
            paddingContentHorizontal: 15,
            colorText: 'rgba(0, 0, 0, 0.65)',
            colorPrimary: '#0068fa',
            colorPrimaryHover: '#004D9E',
            colorPrimaryActive: '#004D9E',
          },
          Select: {
            paddingXXS: 0,
            borderRadius: 6,
            fontSize: 12,
            controlHeight: 32,
            colorText: 'rgba(0, 0, 0, 0.65)',
            colorTextPlaceholder: 'rgba(0, 0, 0, 0.25)',
            colorBorder: '#e6e8eb',
            colorPrimaryHover: '#0068fa',
            colorPrimary: '#0068fa',
          },
          DatePicker: {
            fontSize: 12,
          },
          Table: {
            fontSize: 12,
            colorText: 'rgba(0, 0, 0, 0.85)',
            fontWeightStrong: 500,
            colorTextHeading: 'rgba(0, 0, 0, 0.88)',
            lineHeight: 1.67,
          },
          Form: {
            fontSize: 12,
            marginLG: 16,
          },
          Typography: {
            colorText: 'rgba(0, 0, 0, 0.65)',
            colorTextSecondary: 'rgba(0, 0, 0, 0.45)',
            colorTextTertiary: 'rgba(0, 0, 0, 0.25)',
          },
          List: {
            colorText: 'rgba(0, 0, 0, 0.65)',
            colorTextSecondary: 'rgba(0, 0, 0, 0.45)',
            colorTextTertiary: 'rgba(0, 0, 0, 0.25)',
          },
          Input: {
            borderRadius: 6,
            fontSize: 12,
            colorText: 'rgba(0, 0, 0, 0.65)',
            colorTextPlaceholder: 'rgba(0, 0, 0, 0.25)',
            colorBorder: '#e6e8eb',
            colorPrimaryHover: '#0068fa',
            colorPrimary: '#0068fa',
          },
        },
      }}
    >
      <AntdApp>{props.children}</AntdApp>
    </ConfigProvider>
  );
}

export default React.memo(AntdConfigProvider);
