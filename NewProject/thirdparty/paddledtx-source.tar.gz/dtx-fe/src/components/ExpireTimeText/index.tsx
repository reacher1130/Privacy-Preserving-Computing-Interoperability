import React from 'react';
import {WarningOutlined} from '@ant-design/icons';
import {Tooltip} from 'antd';
import dayjs from 'dayjs';
import styles from './index.less';

export interface ExpiredTimeTextProps {
  time: number;
  warningClassName?: string;
}
const ExpiredTimeText: React.FC<ExpiredTimeTextProps> = props => {
  const {time} = props;
  const warningClassName = props.warningClassName || styles.warningText;
  const e = time * 1000 - new Date().getTime();
  if (e < 1000 * 60 * 5) {
    const t = e < 0 ? '已过期' : '即将过期';
    return (
      <span className={warningClassName}>
        {time ? dayjs.unix(time).format('YYYY-MM-DD HH:mm:ss') : '-'}
        <Tooltip title={t} trigger="click">
          <WarningOutlined className={styles.warningIconMarginLeft} />
        </Tooltip>
      </span>
    );
  }
  return (
    <span>{time ? dayjs.unix(time).format('YYYY-MM-DD HH:mm:ss') : '-'}</span>
  );
};

export default ExpiredTimeText;
