import React from 'react';
import {Button as AntdButton} from 'antd';
import cx from 'classnames';
import {ButtonProps} from 'antd/lib/button';
import styles from './style.less';

export default function Button(props: ButtonProps & {className?: string}) {
  return (
    <AntdButton
      {...props}
      className={cx(styles.customButtonClass, props.className)}
    >
      {props.children}
    </AntdButton>
  );
}
