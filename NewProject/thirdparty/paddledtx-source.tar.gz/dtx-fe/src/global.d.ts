declare module '*.less' {
  const content: Record<string, string | undefined>;
  export default content;
}

declare interface KeyboardEvent extends UIEvent {
  data: string;
}
declare module '*.png';
declare module '*.jpeg';
declare module '*.svg';

interface SWAN_OPTIONS {
  title?: string;
  content?: string;
  path?: string;
  imageUrl?: string;
  success?: (res: any) => void;
  fail?: (err: any) => void;
  complete?: () => void;
}
interface SWAN {
  smartprogram: boolean;
  openShare: (options?: SWAN_OPTIONS) => void;
}

declare let swan: SWAN;
