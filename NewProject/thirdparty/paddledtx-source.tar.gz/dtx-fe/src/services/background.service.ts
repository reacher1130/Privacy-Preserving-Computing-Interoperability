/**
 * 背景服务类 - 用于管理页面背景
 */
export class BackgroundService {
  // 背景类名
  bgClassName = 'homeBg';

  // 背景配置
  backgroundConfig = {
    homeBg: {
      backgroundImage: "url('../../assets/backgroubd-bg.png')",
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      backgroundRepeat: 'no-repeat'
    },
    centerBg: {
      backgroundImage: "url('../../assets/bg.png')",
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      backgroundRepeat: 'no-repeat'
    }
  };

  /**
   * 设置背景类名
   * @param name 背景类名
   */
  public setBgClassName(name: string) {
    this.bgClassName = name;
  }

  /**
   * 获取当前背景配置
   */
  public getCurrentBackground() {
    return this.backgroundConfig[this.bgClassName as keyof typeof this.backgroundConfig] || this.backgroundConfig.homeBg;
  }
}

// 导出单例实例
export const backgroundService = new BackgroundService();
