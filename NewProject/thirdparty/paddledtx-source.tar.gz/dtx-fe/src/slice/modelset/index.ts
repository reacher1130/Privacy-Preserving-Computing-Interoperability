import {PayloadAction, createSlice} from '@reduxjs/toolkit';
import {useEffect} from 'react';
import {useDispatch} from 'react-redux';
import {Modelset} from '@/libs/api';

const list: Array<Partial<Modelset>> = [];

const initialState = {
  currentPageNo: 1,
  list,
};
export type InitialType = typeof initialState;
export const ModelsetSlice = createSlice({
  name: 'Modeset',
  initialState,
  reducers: {
    updateList(state, action) {
      const payload = action.payload;
      const {list, pageNo} = payload;
      state.list = [...list];
      pageNo && (state.currentPageNo = pageNo);
    },

    updatePageNo(state, action) {
      const payload = action.payload;
      state.currentPageNo = payload;
    },
  },
});
export const {updateList, updatePageNo} = ModelsetSlice.actions;
export default ModelsetSlice.reducer;
