import request from '@/libs/request';
import {createApi, fetchBaseQuery} from '@reduxjs/toolkit/query/react';

const RoleApi = createApi({
  reducerPath: 'RoleApi',
  baseQuery: fetchBaseQuery({baseUrl: '/dtx/v1/permission/role'}), // 这里的 baseUrl 是你的后端 API 的基础 URL
  tagTypes: ['role'],
  endpoints: builder => ({
    getRoleByRolename: builder.query({
      // query: (rolename: string) => `get?rolename=${rolename}`,
      queryFn: async (rolename: string, {signal}) => {
        try {
          const resp: any = await request.get(
            'permission/role/get',
            {
              rolename,
            },
            {
              signal,
            }
          );
          return {
            data: {
              ...resp.data,
              data: Object.entries(resp.data as Record<string, string>)
                .map(([k, v]: string[]) => {
                  return [k, parseInt(v !== '' ? v : '00', 2)];
                })
                .reduce(
                  (sum, current: [string, number]) => {
                    sum[current[0]] = current[1];
                    return sum;
                  },
                  {} as Record<string, number>
                ),
            },
          };
        } catch (error) {
          return {error};
        }
      },
      // transformResponse(baseQueryReturnValue: any) {
      //     const r = (baseQueryReturnValue.data as Record<string, string>);
      //     baseQueryReturnValue.data = Object.entries(r).map(
      //         ([k, v]: string[]) => {
      //             return [k, parseInt(v !== '' ? v : '00', 2)];
      //         }
      //     ).reduce((sum, current: [string, number]) => {
      //         sum[current[0]] = current[1];
      //         return sum;
      //     }, ({} as Record<string, number>));
      //     return baseQueryReturnValue;
      // },
      providesTags: (result, error, arg) => [{type: 'role', id: arg}],
    }),
  }),
});

export default RoleApi;
