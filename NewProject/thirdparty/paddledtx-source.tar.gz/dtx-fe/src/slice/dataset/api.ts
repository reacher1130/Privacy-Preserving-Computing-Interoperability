import request, {generateMessage} from '@/libs/request';
import {createApi, fetchBaseQuery} from '@reduxjs/toolkit/query/react';

const datasetApi = createApi({
  reducerPath: 'DatasetApi',
  baseQuery: fetchBaseQuery({baseUrl: '/dtx/v1/data'}), // 这里的 baseUrl 是你的后端 API 的基础 URL
  endpoints: builder => ({
    getDatasetFileDetail: builder.query({
      queryFn: async (resourceID: string, {signal}) => {
        try {
          const resp: any = await request.get(
            'data/ns/resource/detail',
            {
              resourceID,
            },
            {
              signal,
            }
          );

          return {
            data: resp,
          };
        } catch (error) {
          return {error};
        }
      },
    }),
  }),
});

export default datasetApi;
