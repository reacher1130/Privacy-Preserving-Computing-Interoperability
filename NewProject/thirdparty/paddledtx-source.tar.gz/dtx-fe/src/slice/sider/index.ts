import {PayloadAction, createSlice} from '@reduxjs/toolkit';
import {useEffect} from 'react';
import {useDispatch} from 'react-redux';

export enum NavKeys {
  datasetMine = 'datasetMine',
  datasetCatalog = 'datasetCatalog',
  datasetSpace = 'datasetSpace',
  datasetAuthorization = 'datasetAuthorization',
  modelsetMine = 'modelsetMine',
  modelsetCatalog = 'modelsetCatalog',
  modelsetSpace = 'modelsetSpace',
  modelsetAuthorization = 'modelsetAuthorization',
  modelsetCreate = 'modelsetCreate',
  modelsetDetail = 'modelsetDetail',
  taskList = 'taskList',
  algorithmList = 'algorithmList',
  operationBlockchain = 'operationBlockchain',
  operationStorage = 'operationStorage',
  operationComputing = 'operationComputing',
  accountMine = 'accountMine',
  accountRole = 'accountRole',
  accountRights = 'accountRights',
}
export type SelectedKeys = keyof typeof NavKeys;
const initialState = {
  collapsed: false,
  selectedKeys: [''],
};
export type InitialType = typeof initialState;
const siderSlice = createSlice({
  name: 'Sider',
  initialState,
  reducers: {
    updateCollapse(state) {
      state.collapsed = !state.collapsed;
    },
    updateSeletedKeys(
      state,
      action: PayloadAction<{selectedKeys: SelectedKeys[]}>
    ) {
      state.selectedKeys = action.payload.selectedKeys;
    },
  },
});

export default siderSlice;
export const useCurrentNav = (currentNav: SelectedKeys) => {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(
      siderSlice.actions.updateSeletedKeys({selectedKeys: [currentNav]})
    );
  }, []);
};
