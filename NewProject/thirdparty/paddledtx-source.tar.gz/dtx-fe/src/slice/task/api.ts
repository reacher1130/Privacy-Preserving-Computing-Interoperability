import request from '@/libs/request';
import {createApi, fetchBaseQuery} from '@reduxjs/toolkit/query/react';

const TaskApi = createApi({
  reducerPath: 'TaskApi',
  baseQuery: fetchBaseQuery({baseUrl: '/dtx/v1/task'}), // 这里的 baseUrl 是你的后端 API 的基础 URL
  tagTypes: ['executors'],
  endpoints: builder => ({
    getDatasetFileExecutor: builder.query({
      // query: (resourceID: string) => `executors?resourceID=${resourceID}`,
      queryFn: async (resourceID: string, {signal}) => {
        try {
          const resp: any = await request.get(
            'task/executors',
            {
              resourceID,
            },
            {
              signal,
            }
          );

          return {
            data: resp,
          };
        } catch (error) {
          return {error};
        }
      },
      providesTags: (result, error, arg) => [{type: 'executors', id: arg}],
    }),
  }),
});

export default TaskApi;
