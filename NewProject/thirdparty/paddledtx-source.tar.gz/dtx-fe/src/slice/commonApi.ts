export interface BaseResponse {
  code: string;
  data: Record<string, any> | number | string;
  msg?: string;
}

export interface ResponseFail extends BaseResponse {
  code: string;
  data: unknown;
  msg: string;
}
