import {PayloadAction, createSlice} from '@reduxjs/toolkit';
import {cloneDeep} from 'lodash';
import {XuperKey, decryptAES, encryptAES} from '@/libs/api';
import CryptoJS from 'crypto-js';

export enum RolePermissionType {
  ReadOnly = 0b01,
  WriteOnly = 0b10,
  ReadWrite = 0b11,
}

const initialState = {
  user: {
    address: '',
    createTime: '',
    username: '',
    mnemonic: '',
    'X-User-Pubkey': null as Pick<XuperKey, 'Curvname' | 'X' | 'Y'>,
    'X-User-PriKey': null as XuperKey['D'],
    role: '',
  },
};
export type UserInitialStateType = typeof initialState;

const unicom_dtx_user_profile = 'unicom_dtx_user_profile';
const storageKey = CryptoJS.enc.Utf8.parse('unicom-dtx'.padStart(16, '0'));
function profileSetStorage(profile: UserInitialStateType) {
  profile = cloneDeep(profile);
  delete profile.user.mnemonic;
  (profile.user as any).s = profile.user['X-User-PriKey'];
  delete profile.user['X-User-PriKey'];
  localStorage.setItem(
    unicom_dtx_user_profile,
    encryptAES(JSON.stringify(profile), storageKey, storageKey)
  );
}
function profileGetStorage(): UserInitialStateType {
  let storeJSON = localStorage.getItem(unicom_dtx_user_profile);
  let s: any = initialState;
  if (storeJSON) {
    try {
      s = JSON.parse(decryptAES(storeJSON, storageKey, storageKey));
      if (s.user) {
        s.user.role ? s.user.role : 'default';
        s.user['X-User-PriKey'] = s.user.s;
        delete s.user.s;
      }
    } catch (e) {
      console.error('parse local user profile error', e);
      localStorage.removeItem(unicom_dtx_user_profile);
    }
  }
  return s;
}
let initial: UserInitialStateType = initialState;
// const storeJSON = localStorage.getItem(unicom_dtx_user_profile);
// if (storeJSON) {
//     try {
//         initial = JSON.parse(storeJSON);
//         if (initial.user) {
//             initial.user.role ? initial.user.role : 'default';
//         }
//     }
//     catch (e) {
//         console.error('parse local user profile error', e);
//     }
// }

initial = profileGetStorage();
export const UserInfoSlice = createSlice({
  name: 'userInfo',
  initialState: initial,
  reducers: {
    updateUser: (
      state,
      action: PayloadAction<Partial<UserInitialStateType['user']>>
    ) => {
      state.user = {
        ...state.user,
        ...action.payload,
      };
      profileSetStorage(state);
      // localStorage.setItem(unicom_dtx_user_profile, JSON.stringify(state));
    },
    cleanUser: state => {
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      state.user = {...initialState.user};
      localStorage.removeItem(unicom_dtx_user_profile);
    },
  },
});

export default UserInfoSlice.reducer;
export const {updateUser} = UserInfoSlice.actions;
