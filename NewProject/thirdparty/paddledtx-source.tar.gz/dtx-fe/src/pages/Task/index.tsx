/**
 * @file 区块链组件
 *
 */

import React, {ComponentType} from 'react';
import {useSelector} from 'react-redux';
import {Navigate, Outlet, useRoutes} from 'react-router-dom';
import PageLayout from '@/components/PageLayout';
import {UserInitialStateType} from '@/slice/user';
import {demoAuthDisabled} from '../Account/PermissionCreator';

function createView(
  C: Promise<{default: ComponentType}>
): () => React.JSX.Element {
  return () => {
    const E = React.lazy(() => C);
    return (
      <React.Suspense>
        <E />
      </React.Suspense>
    );
  };
}
function Task() {
  const userAddress = useSelector(
    (state: {UserInfo: UserInitialStateType}) => state.UserInfo
  ).user.address;
  const isLogin = demoAuthDisabled() || !!userAddress;

  return useRoutes([
    {
      element: isLogin ? (
        <PageLayout>
          <Outlet />
        </PageLayout>
      ) : (
        <Navigate to="/login" />
      ),
      children: [
        {
          index: true,
          element: <Navigate to={'list'} />,
        },
        {
          path: 'list',
          // element: <List />,
          Component: createView(import('@/views/Task/List')),
        },
        {
          path: 'create',
          Component: createView(import('@/views/Task/Create')),
        },
        {
          path: 'detail/:id?',
          Component: createView(import('@/views/Task/Detail')),
        },
      ],
    },
  ]);
}
export default Task;
