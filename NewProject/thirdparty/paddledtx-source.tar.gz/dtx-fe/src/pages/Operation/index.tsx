/**
 * @file 运维管理
 *
 */

import React from 'react';
import {Navigate, Outlet, useRoutes} from 'react-router-dom';
import auth from '@libs/auth';
import withRouter, {PropsWithRouter} from '@libs/withRouter';
import PageLayout from '@/components/PageLayout';
import Guard from '@/libs/guard';
import Blockchain from '@/views/Operation/Blockchain';
import Storage from '@/views/Operation/Storage';
import Computing from '@/views/Operation/Computing';

interface OperationManagerProps {}
function OperationManager(props: OperationManagerProps) {
  return useRoutes([
    {
      element: (
        <PageLayout>
          <Outlet />
        </PageLayout>
      ),
      children: [
        {
          index: true,
          element: <Navigate to={'blockchain'} />,
        },
        {
          path: 'blockchain',
          element: <Blockchain />,
        },
        {
          path: 'storage',
          element: <Storage />,
        },
        {
          path: 'computing',
          element: <Computing />,
        },
      ],
    },
  ]);
}
const OperationManagerWithRouter = withRouter<OperationManagerProps>(
  Guard(OperationManager)
);
export default OperationManagerWithRouter;
