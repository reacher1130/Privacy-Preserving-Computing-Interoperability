/**
 * @file 算法管理
 *
 */

import React from 'react';
import {useSelector} from 'react-redux';
import {Navigate, Outlet, useRoutes} from 'react-router-dom';
import PageLayout from '@/components/PageLayout';
import List from '@/views/Algorithm/List';
import Detail from '@/views/Algorithm/Detail';
import {UserInitialStateType} from '@/slice/user';
import {demoAuthDisabled} from '../Account/PermissionCreator';

function Algorithm() {
  const userAddress = useSelector(
    (state: {UserInfo: UserInitialStateType}) => state.UserInfo
  ).user.address;
  const isLogin = demoAuthDisabled() || !!userAddress;

  return useRoutes([
    {
      element: isLogin ? (
        <PageLayout>
          <Outlet />
        </PageLayout>
      ) : (
        <Navigate to="/login" />
      ),
      children: [
        {
          index: true,
          element: <Navigate to={'list'} />,
        },
        {
          path: 'list',
          element: <List />,
        },
        {
          path: 'detail',
          element: <Detail />,
        },
      ],
    },
  ]);
}
export default Algorithm;
