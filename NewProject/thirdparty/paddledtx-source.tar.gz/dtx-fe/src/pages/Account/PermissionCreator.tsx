import React, {
  Children,
  PropsWithChildren,
  ReactElement,
  ReactNode,
  cloneElement,
  useEffect,
} from 'react';
import {Spin} from 'antd';
import {useSelector} from 'react-redux';
import {Navigate} from 'react-router-dom';
import {UserInitialStateType} from '@/slice/user';
import RoleApi from '@/slice/role/api';
import store from '@/store';
import styles from './PermissionCreator.less';

export enum PermissionValue {
  Default = 0b00,
  Read = 0b01,
  Write = 0b10,
  ReadWrite = Read | Write,
}

export type PermissionKeys =
  | 'algorithm'
  | 'data'
  | 'op'
  | 'permission'
  | 'service'
  | 'task';
export enum PermissionType {
  Algorithm = 'algorithm',
  Dataset = 'data',
  Op = 'op',
  Permission = 'permission',
  Modelset = 'service',
  Task = 'task',
}

const {useLazyGetRoleByRolenameQuery, useGetRoleByRolenameQuery} = RoleApi;
export const demoAuthDisabled = () =>
  (globalThis as typeof globalThis & {__DTX_DEMO_AUTH_DISABLED__?: boolean})
    .__DTX_DEMO_AUTH_DISABLED__ === true;

const PermissionCreator: React.FC<React.PropsWithChildren> = props => {
  const {children} = props;
  const user = useSelector<
    {UserInfo: UserInitialStateType},
    UserInitialStateType
  >(state => state.UserInfo).user;
  const [fetchMethod, {isUninitialized, isLoading}] =
    useLazyGetRoleByRolenameQuery();
  useEffect(() => {
    if (user.role) {
      fetchMethod(user.role, true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user.role]);
  if (!user.address && !demoAuthDisabled()) {
    return <Navigate to={'/login'} />;
  }
  // The local demo deliberately has no account/role service.  Do not leave
  // the native shell on the role-query spinner when authentication is
  // disabled; the guarded pages must remain clickable for protocol demos.
  if (demoAuthDisabled()) {
    return children;
  }
  return isUninitialized || isLoading ? (
    <div className={styles.loadingOutter}>
      <div className={styles.loadingInner}>
        <Spin />
      </div>
    </div>
  ) : (
    children
  );
};

export default PermissionCreator;

export const usePermission = () => {
  const user = useSelector<
    {UserInfo: UserInitialStateType},
    UserInitialStateType
  >(state => state.UserInfo).user;
  const role = useGetRoleByRolenameQuery(user.role).data?.data || {};
  if (demoAuthDisabled()) {
    return {
      algorithm: PermissionValue.ReadWrite,
      data: PermissionValue.ReadWrite,
      op: PermissionValue.ReadWrite,
      permission: PermissionValue.ReadWrite,
      service: PermissionValue.ReadWrite,
      task: PermissionValue.ReadWrite,
    };
  }
  return role;
};
export const withPermission = function <T>(Target: React.FC<T>) {
  return function (props: T): ReactElement<T & {role: any}> {
    const role = usePermission();
    return <Target {...props} role={role} />;
  };
};

export const getPermissionFromCache = () => {
  const rootState = store.getState();
  const rolename = rootState['UserInfo'].user.role;
  return (
    rootState['RoleApi'].queries[`getRoleByRolename("${rolename}")`]?.data
      ?.data ?? {}
  );
};

export const usePermissionWithRule = () => {
  const roles = usePermission();
  return (type: PermissionKeys, value: PermissionValue) => {
    const role = roles[type];
    if (role >= value) {
      return true;
    }
    return false;
  };
};

export enum PermissionFobiddenType {
  hidden,
  disabled,
  custom,
}
export interface PermissionProps extends PropsWithChildren {
  roleType: PermissionKeys;
  rolePermisson: PermissionValue;
  forbiddenStyle?: {
    type: PermissionFobiddenType;
    custom?: ReactNode;
    className?: string;
  };
}
export const Permission: React.FC<PermissionProps> = props => {
  const {
    roleType,
    rolePermisson,
    forbiddenStyle = {} as PermissionProps['forbiddenStyle'],
  } = props;
  const {type = 'hidden', custom = '', className = ''} = forbiddenStyle;
  const role = usePermissionWithRule()(roleType, rolePermisson);
  if (role) {
    return props.children;
  }
  if (type === PermissionFobiddenType.hidden) {
    return <></>;
  } else if (type === PermissionFobiddenType.disabled) {
    return (
      <>
        {Children.map(props.children, (child: ReactElement) => {
          if (!child) {
            return <></>;
          }
          const classNames = [child?.props?.className ?? '', className]
            .join(' ')
            .trim();

          return cloneElement(child, {
            ...child?.props,
            className: classNames,
            disabled: true,
          });
        })}
      </>
    );
  }
  return custom;
};
