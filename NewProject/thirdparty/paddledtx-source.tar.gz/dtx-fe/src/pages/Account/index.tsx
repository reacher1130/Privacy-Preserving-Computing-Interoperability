/**
 * @file 算法管理
 *
 */

import React from 'react';
import {useSelector} from 'react-redux';
import {Navigate, Outlet, useRoutes} from 'react-router-dom';
import PageLayout from '@/components/PageLayout';
import Mine from '@/views/Account/Mine';
import Role from '@/views/Account/Role';
import Rights from '@/views/Account/Rights';
import {UserInitialStateType} from '@/slice/user';
import {demoAuthDisabled} from './PermissionCreator';

function Account() {
  const userAddress = useSelector(
    (state: {UserInfo: UserInitialStateType}) => state.UserInfo
  ).user.address;
  const isLogin = demoAuthDisabled() || !!userAddress;
  return useRoutes([
    {
      element: isLogin ? (
        <PageLayout>
          <Outlet />
        </PageLayout>
      ) : (
        <Navigate to="/login" />
      ),
      children: [
        {
          index: true,
          element: <Navigate to={'mine'} />,
        },
        {
          path: 'mine',
          element: <Mine />,
        },
        {
          path: 'role',
          element: <Role />,
        },
        {
          path: 'rights',
          element: <Rights />,
        },
      ],
    },
  ]);
}
export default Account;
