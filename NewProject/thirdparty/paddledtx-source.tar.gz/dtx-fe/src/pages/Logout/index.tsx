/**
 * @file 退出
 *
 */

import React from 'react';
import {Navigate} from 'react-router-dom';
import {useDispatch} from 'react-redux';
import {UserInfoSlice} from '@/slice/user';

export interface StateType {
  UserInfo: any;
  Sider: any;
}

function Logout() {
  const dispatch = useDispatch();
  dispatch(UserInfoSlice.actions.cleanUser());
  return <Navigate to="/login" />;
}

export default Logout;
