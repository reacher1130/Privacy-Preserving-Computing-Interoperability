/**
 * @file 区块链组件
 *
 */

import React from 'react';
import {Navigate, Outlet, useRoutes} from 'react-router-dom';
import PageLayout from '@/components/PageLayout';
import Mine from '@/views/Dataset/Mine';
import Catalog from '@/views/Dataset/Catalog';
import Detail from '@/views/Dataset/Detail';
import Authorization from '@/views/Dataset/Authorization';
import Create from '@/views/Dataset/Create';
import DetailAuthorization from '@/views/Dataset/DetailAuthorization';
import {
  PermissionType,
  PermissionValue,
  usePermissionWithRule,
} from '../Account/PermissionCreator';
import Space from '@/views/Dataset/Space';

function Dataset() {
  let children = [
    {
      index: true,
      element: <Navigate to="/dataset/space" />,
      roleType: PermissionType.Dataset,
      rolePermission: PermissionValue.Read,
    },
    {
      path: 'mine',
      element: <Mine />,
      roleType: PermissionType.Dataset,
      rolePermission: PermissionValue.Read,
    },
    {
      path: 'detail/:resourceID?',
      element: <Detail />,
      roleType: PermissionType.Dataset,
      rolePermission: PermissionValue.Read,
    },
    {
      path: 'space',
      element: <Space />,
      roleType: PermissionType.Dataset,
      rolePermission: PermissionValue.Read,
    },
    {
      path: 'catalog',
      element: <Catalog />,
      roleType: PermissionType.Dataset,
      rolePermission: PermissionValue.Read,
    },
    {
      path: 'authorization',
      element: <Authorization />,
      roleType: PermissionType.Dataset,
      rolePermission: PermissionValue.Read,
    },
    {
      path: 'create',
      element: <Create />,
      roleType: PermissionType.Dataset,
      rolePermission: PermissionValue.Write,
    },
    {
      path: 'update/:resourceID',
      element: <Create />,
      roleType: PermissionType.Dataset,
      rolePermission: PermissionValue.Write,
    },
    {
      path: 'authorization/detail/:authID?',
      element: <DetailAuthorization />,
      roleType: PermissionType.Dataset,
      rolePermission: PermissionValue.Read,
    },
  ];
  const check = usePermissionWithRule();
  let element = useRoutes([
    {
      element: (
        <PageLayout>
          <Outlet />
        </PageLayout>
      ),
      children: children.filter(child => {
        return check(child.roleType, child.rolePermission);
      }),
    },
  ]);
  const hasDatasetPermisson = usePermissionWithRule()(
    PermissionType.Dataset,
    PermissionValue.Read
  );
  if (hasDatasetPermisson) {
    return element;
  }
  return <Navigate to="/account/mine" />;
}
export default Dataset;
