/**
 * @file board index.js
 *
 */
import React from 'react';
import {createRoot} from 'react-dom/client';
import {RouterProvider} from 'react-router-dom';
import 'normalize.css';

// eslint-disable-next-line import/extensions
import '@pub/css/base.less';
import {Provider} from 'react-redux';
import dayjs from 'dayjs';
import store from '@store';
import router from '@/router';
import AntdConfigProvider from '@/components/AntdConfigProvider';
import 'dayjs/locale/zh-cn';

dayjs.locale('zh-cn');

const root = createRoot(document.querySelector('#root'));
function App() {
  return (
    <Provider store={store}>
      <AntdConfigProvider>
        <RouterProvider router={router} />
      </AntdConfigProvider>
    </Provider>
  );
}
root.render(<App />);
