/**
 * @file 登陆功能页
 *
 */

import React, {PropsWithChildren} from 'react';
import {Link, Navigate} from 'react-router-dom';
import {Input, Button, Form} from 'antd';
import CustomInput from '@components/CustomInput';
import cx from 'classnames';
import auth, {User} from '@libs/auth';

import styles from './style.less';
//  import LOGIN_BG_BLUE from '@pub/images/login_bg_blue.png';
import LOGIN_BG from '@pub/images/login_bg.png';
import LOGO_ICON from '@pub/images/LOGO@2x.png';

import constants from '@libs/constants';
import {updateUser, UserInitialStateType} from '@/slice/user';
import IMG_LOGO from '@pub/images/logo.png';
import {connect, DispatchProp} from 'react-redux';
import withRouter, {PropsWithRouter} from '@libs/withRouter';

import {
  UserAccess,
  AccountMain,
  LoginResponse,
  login,
  Account,
  getRoleRights,
} from '@/libs/api';
import {AnyAction} from '@reduxjs/toolkit';
import store from '@/store';

const ErrorMessage = {
  UserExisted: '用户已存在',
  UserNotFound: '用户不存在',
  ErrorLoginCode: '用户名或密码错误',
  WrongPassword: '密码错误',
  UserNameError: '注册用户名输入不正确',
  PasswordError: '注册密码输入不正确',
};

type ErrorType = typeof ErrorMessage;

interface LoginProps extends PropsWithChildren {}
interface LoginState {
  submitting: boolean;
  input: string;
  user: Account | null;
  error: string;
  isLogin: boolean;
}

class Login extends React.Component<
  LoginProps &
    PropsWithRouter &
    DispatchProp & {userInfo: UserInitialStateType},
  LoginState
> {
  state: LoginState = {
    submitting: false,
    input: '',
    user: null,
    error: '',
    isLogin: false,
  };
  componentDidUpdate() {
    if (this.props.userInfo.user.address) {
      this.props.router.navigate('/dataset/space');
    }
  }
  changeValues() {
    this.setState({error: ''});
  }
  render() {
    const {error} = this.state;
    const bgImg = LOGIN_BG;
    return (
      <div className={styles.loginContainer}>
        <div className={cx(styles.leftBox)}>
          <div className={styles.loginBgBox}>
            <img src={bgImg} className={styles.loginbgImg} />
          </div>
          <div className={styles.leftInner}>
            <div className={styles.logoBox}>
              {/* <Link to="/">
                                <img src={IMG_LOGO} height={26} />
                            </Link> */}
            </div>
            <div className={styles.instructBox}>
              <div className={styles.title}>隐私计算平台</div>
            </div>
          </div>
        </div>
        <div className={styles.rightBox}>
          <div className={styles.box}>
            <div className={styles.logoIcon}>
              <img src={LOGO_ICON} />
            </div>
            <div className={styles.title}>登录</div>
            {
              <Form
                className={styles.loginFormClass}
                onValuesChange={this.changeValues.bind(this)}
                onFinish={this.onFinish.bind(this)}
              >
                <Form.Item
                  name="username"
                  label=""
                  rules={[
                    {
                      required: true,
                      message: '请输入账户名',
                    },
                  ]}
                >
                  <CustomInput
                    className={styles.loginAccount}
                    placeholder="请输入账户名"
                  />
                </Form.Item>
                <Form.Item
                  name="password"
                  label=""
                  rules={[
                    {
                      required: true,
                      message: '请输入密码',
                    },
                  ]}
                >
                  <CustomInput.Password
                    className={styles.loginAccount}
                    placeholder="请输入密码"
                  />
                </Form.Item>
                <div className={styles.error}>{this.state.error}</div>
                <Button
                  className={cx(styles.login, error && styles.marginSmall, {
                    [styles.submitting]: this.state.submitting,
                  })}
                  type="primary"
                  htmlType="submit"
                >
                  登录
                </Button>
              </Form>
            }
            <div>
              <Link className={styles.signup} to="/register">
                注册新账户
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  onError() {
    this.setState({
      submitting: false,
      error: '抱歉，您输入的助记词有误，请重新确认',
    });
  }

  buildAccount(data: Account) {
    try {
      const user = {
        ...data,
      };
      this.setState({user, submitting: false});
    } catch (e) {
      console.error(e.message);
      this.onError();
    }
  }
  // 账密体系登录
  async onFinish(values: UserAccess) {
    try {
      this.setState({submitting: true});
      await login({...values});
    } catch (err) {
      console.error(err);
      const msg: string = ErrorMessage[err.message as keyof ErrorType];
      this.setState({
        submitting: false,
        error: msg || '账户名或密码错误',
      });
    }
  }
}

export default withRouter<LoginProps>(
  connect((state: any) => {
    return {userInfo: state.UserInfo};
  })(Login)
);
