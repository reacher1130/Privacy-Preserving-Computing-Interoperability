/**
 * @file 区块链组件
 *
 */

import React from 'react';
import {Navigate, Outlet, useRoutes} from 'react-router-dom';
import PageLayout from '@/components/PageLayout';
import Mine from '@/views/Modelset/Mine';
import Catalog from '@/views/Modelset/Catalog';
import Authorization from '@/views/Modelset/Authorization';
import DetailAuthorization from '@/views/Modelset/DetailAuthorization';
import Create from '@/views/Modelset/Create';
import Detail from '@/views/Modelset/Detail';
import Space from '@/views/Modelset/Space';
import {
  PermissionType,
  PermissionValue,
  usePermissionWithRule,
} from '../Account/PermissionCreator';

function Modelset() {
  const children = [
    {
      index: true,
      element: <Navigate to={'mine'} />,
    },
    {
      path: 'mine',
      element: <Mine />,
      roleType: PermissionType.Modelset,
      rolePermission: PermissionValue.Read,
    },
    {
      path: 'catalog',
      element: <Catalog />,
      roleType: PermissionType.Modelset,
      rolePermission: PermissionValue.Read,
    },
    {
      path: 'space',
      element: <Space />,
      roleType: PermissionType.Modelset,
      rolePermission: PermissionValue.Read,
    },
    {
      path: 'authorization',
      element: <Authorization />,
      roleType: PermissionType.Modelset,
      rolePermission: PermissionValue.Read,
    },
    {
      path: 'authorization/detail/:authID?',
      element: <DetailAuthorization />,
      roleType: PermissionType.Modelset,
      rolePermission: PermissionValue.Read,
    },
    {
      path: 'create',
      element: <Create />,
      roleType: PermissionType.Modelset,
      rolePermission: PermissionValue.Write,
    },
    {
      path: 'detail/:resourceID?',
      element: <Detail />,
      roleType: PermissionType.Modelset,
      rolePermission: PermissionValue.Read,
    },
  ];
  const check = usePermissionWithRule();
  return useRoutes([
    {
      element: (
        <PageLayout>
          <Outlet />
        </PageLayout>
      ),
      children: children.filter(child => {
        return check(child.roleType, child.rolePermission);
      }),
    },
  ]);
}
export default Modelset;
