/**
 * @file 账密注册
 *
 * @time 2023/03/27
 */

import React, {PropsWithChildren} from 'react';

import {message, Steps, Form, Button, Input} from 'antd';
import {connect, DispatchProp} from 'react-redux';
import withRouter, {PropsWithRouter} from '@libs/withRouter';
import Title from '@components/Title';
import Alert, {AlertProps} from '@components/Alert';
import {UserAccess, UserRegisterResponse, register} from '@/libs/api';
import {User} from '@libs/auth';
import {updateUser} from '@/slice/user';
import styles from './style.less';

const ErrorMessage = {
  UserExisted: '用户已存在',
  UserNotFound: '用户不存在',
  ErrorLoginCode: '用户名或密码错误',
  WrongPassword: '密码错误',
  UserNameError: '注册用户名输入不正确',
  PasswordError: '注册密码输入不正确',
};

type ErrorType = typeof ErrorMessage;

const steps = [
  {
    title: '注册新账户',
    disabled: true,
  },
  {
    title: '登录平台',
    disabled: true,
  },
];

interface RegisterProps extends PropsWithChildren {}
interface RegisterState {
  currentStep: number;
  loading: boolean;
  alert: AlertProps;
  user: User | null;
}

class Register extends React.Component<
  RegisterProps & PropsWithRouter & DispatchProp,
  RegisterState
> {
  constructor(props: RegisterProps & PropsWithRouter & DispatchProp) {
    super(props);
    this.state = {
      currentStep: 0,
      loading: false,
      user: null,
      alert: {
        isShow: false,
        message: '',
        type: 'warning',
      },
    };
  }

  changeStep(current: number) {
    this.setState({currentStep: current});
    if (current === 1) {
      setTimeout(() => {
        this.props.dispatch(updateUser(this.state.user));
      }, 1000);
    }
  }

  async onFinish(values: UserAccess) {
    try {
      const resp: UserRegisterResponse = await register({...values});
      if (+resp.code === 0) {
        message.success('注册成功');
        this.props.router.navigate('/login');
      } else {
        throw new Error(resp.code);
      }
    } catch (err) {
      console.error(err);
      this.setState({
        alert: {
          isShow: true,
          type: 'warning',
          message: ErrorMessage[err.message as keyof ErrorType] || '注册失败',
        },
      });
    }
  }

  autoCloseCallBack() {
    const {alert} = this.state;
    if (alert.type === 'success') {
      this.changeStep(1);
    }
    this.setState({alert: {isShow: false}});
  }

  onEnter() {
    this.props.router.navigate('/dataset');
  }

  render() {
    const {currentStep, alert} = this.state;
    return (
      <div className={styles.container}>
        <Steps
          items={steps}
          current={currentStep}
          size="small"
          className={styles.steps}
        />
        <div className={styles.card}>
          {currentStep === 0 && (
            <div className={styles.content}>
              <Title title="注册新账户" />
              <Form
                className={styles.registerFormClass}
                onFinish={this.onFinish.bind(this)}
              >
                <Form.Item
                  name="username"
                  validateFirst={true}
                  rules={[
                    {
                      required: true,
                      message: '请输入账户名称',
                    },
                    {
                      pattern: /^[_a-zA-Z0-9\u4e00-\u9fa5]*$/,
                      message: '支持中英文、数字、下划线',
                    },
                    {
                      min: 2,
                      message: '账户名称最短2位',
                    },
                    {
                      max: 16,
                      message: '账户名称最长16位',
                    },
                  ]}
                >
                  <Input
                    className={styles.registerInput}
                    placeholder="账户名支持2-16位中英文、数字、下划线"
                  />
                </Form.Item>
                <Form.Item
                  name="password"
                  validateFirst={true}
                  rules={[
                    {
                      required: true,
                      message: '请输入账户密码',
                    },
                    {
                      pattern:
                        /((?=.*\d)(?=.*\D)|(?=.*[a-zA-Z])(?=.*[^a-zA-Z]))(?!^.*[\u4E00-\u9FA5].*$)^\S{8,14}$/,
                      message:
                        '8~14位字符，至少包含字母/数字以及标点符号中的2种',
                    },
                  ]}
                >
                  <Input.Password
                    className={styles.registerInput}
                    placeholder="密码支持8-14位，至少含字母、数字、标点中的2种"
                  />
                </Form.Item>
                <Button
                  htmlType="submit"
                  type="primary"
                  className={styles.registerBtn}
                >
                  确认注册
                </Button>
              </Form>
              {alert.isShow && (
                <Alert
                  {...alert}
                  autoCloseCallBack={this.autoCloseCallBack.bind(this)}
                />
              )}
            </div>
          )}
          {currentStep === 1 && (
            <div className={styles.content}>
              <div style={{marginBottom: '24px'}}>
                新账户注册成功，点击登录平台
              </div>
              <Button type="primary" onClick={this.onEnter.bind(this)}>
                进入平台
              </Button>
            </div>
          )}
        </div>
      </div>
    );
  }
}

export default withRouter<RegisterProps>(connect(state => state)(Register));
