const webpack = require('webpack');
const {merge} = require('webpack-merge');

const commonConf = require('./webpack.common.js');
const extensions = require('./webpack.extensions.js');

const HtmlWebpackPlugin = require('html-webpack-plugin');
const {CleanWebpackPlugin} = require('clean-webpack-plugin');

const PORT = 8082;

// const htmlPluginArr = pagesInfo => {
//     return pagesInfo.map( pageInfo =>
//         new HtmlWebpackPlugin({
//             inject: true,
//             template: './src/public/index.html',
//             filename: `${pageInfo.name}.html`,
//             chunks: [`${pageInfo.name}`],
//             title: `${pageInfo.title}`,
//             bodyHtmlSnippet: '<div id="root"></div>',
//             meta: {
//                 viewport: 'width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no, viewport-fit=cover'
//             },
//             links: [
//                 ...extensions.icons(false)
//             ]
//         })
//     );
// };

module.exports = merge(commonConf, {
  mode: 'development',
  output: {
    publicPath: '/',
  },
  devServer: {
    historyApiFallback: {
      rewrites: [{from: /^\/$/, to: '/dtx/console/dataset/mine'}],
    },
    open: ['/dtx/console/dataset/mine'],
    devMiddleware: {
      writeToDisk: true,
    },
    static: extensions.paths.buildPath,
    compress: true,
    host: '0.0.0.0',
    port: PORT,
    allowedHosts: 'all',
    client: {
      logging: 'info',
      overlay: {
        // 有报错发生，直接覆盖浏览器视窗，显示错误
        errors: false,
        warnings: false,
      },
    },
    proxy: {
      '/dtx/v1/': {
        target: 'http://127.0.0.1:18088', // 刘海潮本地
      },
    },
  },
  devtool: 'eval-source-map',
  plugins: [
    new webpack.HotModuleReplacementPlugin(),
    new webpack.DefinePlugin({
      NODE_ENV: 'development',
    }),
    // ...htmlPluginArr(extensions.pagesInfo)
    new HtmlWebpackPlugin({
      inject: true,
      template: './src/public/index.html',
      filename: 'index.html',
      chunks: ['index'],
      title: '隐私计算平台',
      bodyHtmlSnippet: '<div id="root"></div>',
      meta: {
        viewport: [
          'width=device-width',
          'initial-scale=1',
          'maximum-scale=1',
          'user-scalable=no',
          'shrink-to-fit=no viewport-fit=cover',
        ].join(','),
      },
      links: [...extensions.icons(false)],
    }),
    new CleanWebpackPlugin(),
  ],
});
