const fs = require('fs');
const path = require('path');
const currentPath = process.cwd();

const packageInfo = require(path.join(currentPath, 'package.json'));

const projectName = packageInfo.name;
const staticPath = path.join('static', projectName);
const buildPath = path.join(currentPath, 'build');
const nodeModulesPath = path.join(currentPath, 'node_modules');
const srcPath = path.join(currentPath, 'src');
const publicPath = path.join(currentPath, 'public');

exports.paths = {
  modulesPathMatch: /(node_modules|bower_compontents)/,
  projectName,
  currentPath,
  srcPath,
  buildPath,
  nodeModulesPath,
  modulesPath: [srcPath, nodeModulesPath],
  publicPath,
  staticPath: 'static',
  staticJsPath: path.join(staticPath, 'js'),
  staticCssPath: path.join(staticPath, 'css'),
  staticImgPath: path.join(staticPath, 'image'),
  staticAssetsPath: path.join(staticPath, 'assets'),
  staticHtmlPath: path.join(staticPath, 'page'),
};

const join = (...paths) => {
  return path.join.apply(null, paths);
};

exports.icons = isProd => [
  {
    rel: 'icon',
    type: 'image/png',
    sizes: '32x32',
    href: 'static/favicon-32x32.png',
  },
  {
    rel: 'icon',
    type: 'image/png',
    sizes: '16x16',
    href: 'static/favicon-16x16.ico',
  },
  {
    rel: 'apple-touch-icon',
    sizes: '180x180',
    href: 'static/apple-touch-icon.png',
  },
];

// 页面信息
exports.pagesInfo = [
  {
    name: 'dashboard',
    title: 'dtx',
  },
];

/**
 * @return {Object} {
    asset: './src/pages/Asset/index.js',
    consensus: './src/pages/Consensus/index.js',
    guide: './src/pages/Guide/index.js'
    }
 */

exports.getEntrys = pagesInfo => {
  const info = pagesInfo || this.pagesInfo;
  const entrys = info.reduce((acc, pageInfo) => {
    const {name} = pageInfo;
    const nameStr =
      name.slice(0, 1).toUpperCase() + name.slice(1).toLowerCase();
    acc[name] = `./src/pages/${nameStr}/index.js`;
    return acc;
  }, {});
  return entrys;
};

/**
 * export -> path join function
 * @param {...string} paths join path
 * @return {*} path string
 */
exports.join = join;
