/* eslint-disable import/order */
const path = require('path');

const cwd = process.cwd();
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const extensions = require('./webpack.extensions');

const paths = extensions.paths;
const webpack = require('webpack');
const NodePolyfillPlugin = require('node-polyfill-webpack-plugin');
const fs = require('fs');
const lessToJs = require('less-vars-to-js');

const globalVars = lessToJs(
  fs.readFileSync(path.join(__dirname, '../src/public/css/theme.less'), 'utf8')
);
const modifyVars = lessToJs(
  fs.readFileSync(path.join(__dirname, '../src/public/css/antd.less'), 'utf8')
);

module.exports = {
  // entry: extensions.getEntrys(),
  entry: {
    index: './src/pages/index.tsx',
  },
  mode: 'development',
  output: {
    filename: path.join(paths.staticJsPath, '[name].[fullhash].bundle.js'),
    path: extensions.paths.buildPath,
    assetModuleFilename: 'static/unicom-dtx/assets/[name].[hash][ext]',
    clean: true,
  },
  target: 'web',
  devtool: 'inline-source-map',
  module: {
    noParse: /@grpc|grpc-js|proto-loader/,
    rules: [
      {
        test: /\.(c|le)ss$/,
        // include: paths.srcPath,
        use: [
          MiniCssExtractPlugin.loader,
          {
            loader: 'css-loader',
            options: {
              modules: {
                localIdentName: '[path][name]-[local]',
              },
              // modules: true
            },
          },
          {
            loader: 'postcss-loader',
            options: {
              postcssOptions: {
                plugins: [['postcss-preset-env']],
              },
            },
          },
          {
            loader: 'less-loader',
            options: {
              lessOptions: {
                modifyVars,
                globalVars,
              },
            },
          },
        ],
      },
      {
        test: /\.(png|jp(e?)g|gif)$/i,
        type: 'asset/resource',
      },
      {
        test: /\.(woff|woff2|eot|ttf|otf)$/i,
        type: 'asset/resource',
      },
      {
        test: /\.(tsx|ts|js|jsx)$/,
        use: 'ts-loader',
        exclude: /node_modules/,
      },
      {
        test: /\.svg$/,
        use: [
          {
            loader: '@svgr/webpack',
            options: {
              typescript: true,
              ext: 'tsx',
              svgoConfig: {
                plugins: [
                  {
                    name: 'preset-default',
                    params: {
                      overrides: {
                        // 禁用插件
                        removeViewBox: false,
                      },
                    },
                  },
                ],
              },
            },
          },
        ],
      },
    ],
  },
  resolve: {
    extensions: ['.tsx', '.ts', '.js', '.jsx', '.css', '.less'],
    alias: {
      '@': path.join(cwd, 'src'),
      '@pub': path.join(cwd, 'src/public'),
      '@libs': path.join(cwd, 'src/libs'),
      '@components': path.join(cwd, 'src/components'),
      '@views': path.join(cwd, 'src/views'),
      '@pages': path.join(cwd, 'src/pages'),
      '@reducers': path.join(cwd, 'src/reducers'),
      '@store': path.join(cwd, 'src/store'),
      '@images': path.join(cwd, 'src/public/images'),
    },
  },
  plugins: [
    new MiniCssExtractPlugin({
      filename: path.join(paths.staticCssPath, '[name].[fullhash].css'),
      ignoreOrder: true,
    }),
    new webpack.ProvidePlugin({
      Buffer: ['buffer', 'Buffer'],
    }),
    new NodePolyfillPlugin({
      excludeAliases: ['console'],
    }),
  ],
};
