#!/usr/bin/env bash

set -e

#export PATH=$NODEJS_16_10_0_BIN:$PATH

is_test=$1

MOD_NAME=${PWD##*/}

echo "node $(node -v)"
echo "npm $(npm -v)"

#rm -rf dist output build
rm -rf output

npm install
npm run build

mkdir output

cd ./build
mkdir -p dist/views/
mkdir -p dist/static/
mv static/unicom-dtx/page/* dist/views/
mv static/* dist/static/

tar -zcf ../output/static-$MOD_NAME.tar.gz ./dist/{views,static}

cd ..

echo "build success"
