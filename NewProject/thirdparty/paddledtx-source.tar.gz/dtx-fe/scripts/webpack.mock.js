/**
 * @file webpack conf of mock server (webpack.mock)
 *
 */

const webpack = require('webpack');
const {merge} = require('webpack-merge');
const devConf = require('./webpack.dev.js');
const mockData = require('../mock');

const conf = merge(devConf, {
  devServer: {
    proxy: {
      '/xbaas/v1': {
        bypass: function (req, res) {
          if (req.url.indexOf('/xbaas/v1/') > -1) {
            const data = mockData(req.path.replace(/\/xbaas\/v1/, ''));
            let result = null;
            try {
              result = JSON.parse(data);
            } catch (e) {
              result = data;
            }
            res.send(result).end();
          }
        },
      },
    },
  },
  plugins: [
    new webpack.DefinePlugin({
      ENV: JSON.stringify('mock'),
    }),
  ],
});

module.exports = conf;
