/**
 * @file webpack.prod
 * Created by qilinlin on 2022/04/01
 */

/*eslint-disable fecs-camelcase*/

const {merge} = require('webpack-merge');
const commonConf = require('./webpack.common.js');

const HtmlWebpackPlugin = require('html-webpack-plugin');
const TerserPlugin = require('terser-webpack-plugin');
const CssMinimizerPlugin = require('css-minimizer-webpack-plugin');

module.exports = merge(commonConf, {
  mode: 'production',
  output: {
    clean: true,
    publicPath: '/',
    assetModuleFilename: 'static/unicom-dtx/assets/[name].[hash].[ext]',
  },
  optimization: {
    runtimeChunk: 'single',
    splitChunks: {
      chunks: 'initial',
      minSize: 0,
      cacheGroups: {
        default: false,
        vendors: false,
        vendor: {
          test: /[\\/]node_modules[\\/]/,
          chunks: 'initial',
          priority: 10,
          name: 'vendor',
        },
      },
    },
    minimize: true,
    minimizer: [
      new TerserPlugin({
        parallel: true,
        terserOptions: {
          output: {
            comments: false,
          },
        },
      }),
      new CssMinimizerPlugin(),
    ],
  },
  plugins: [
    new HtmlWebpackPlugin({
      template: './src/public/index.html',
      filename: './static/unicom-dtx/page/index.html',
      appMountId: 'root',
      title: '隐私计算平台',
    }),
  ],
});
