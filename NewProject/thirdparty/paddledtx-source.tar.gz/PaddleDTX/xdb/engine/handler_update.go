// Copyright (c) 2021 PaddlePaddle Authors. All Rights Reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package engine

import (
	"bytes"
	"context"
	"io"
	"time"

	"github.com/PaddlePaddle/PaddleDTX/crypto/core/ecdsa"
	"github.com/PaddlePaddle/PaddleDTX/crypto/core/hash"
	"github.com/sirupsen/logrus"

	"github.com/PaddlePaddle/PaddleDTX/xdb/blockchain"
	"github.com/PaddlePaddle/PaddleDTX/xdb/engine/common"
	"github.com/PaddlePaddle/PaddleDTX/xdb/engine/copier"
	"github.com/PaddlePaddle/PaddleDTX/xdb/engine/encryptor"
	"github.com/PaddlePaddle/PaddleDTX/xdb/engine/slicer"
	"github.com/PaddlePaddle/PaddleDTX/xdb/engine/types"
	"github.com/PaddlePaddle/PaddleDTX/xdb/errorx"
	util "github.com/PaddlePaddle/PaddleDTX/xdb/pkgs/strings"
)

// Update update a file and push file slices to new selected storage nodes
func (e *Engine) Update(ctx context.Context, opt types.UpdateOptions,
	r io.Reader) (resp types.UpdateResponse, err error) {
	ctx, cancel := context.WithCancel(ctx)
	defer cancel()

	var errOccurred error

	// check key match
	if err := e.verifyUserID(opt.User); err != nil {
		return resp, err
	}
	// verify token
	msg, err := util.GetSigMessage(opt)
	if err != nil {
		return resp, errorx.Internal(err, "failed to get the message to sign for upload files")
	}
	if err := verifyUserToken(opt.User, opt.Token, hash.HashUsingSha256([]byte(msg))); err != nil {
		return resp, errorx.Wrap(err, "failed to verify token")
	}

	pubkey := ecdsa.PublicKeyFromPrivateKey(e.monitor.challengingMonitor.PrivateKey)
	opt.User = pubkey.String()

	// check file existence
	file, err := e.chain.GetFileByID(opt.FileID)
	if err != nil {
		return resp, errorx.New(errorx.ErrCodeNotFound, "file not found")
	}
	if opt.ExpireTime == 0 {
		opt.ExpireTime = file.ExpireTime
	}

	// find file namespace info
	ns, err := e.chain.GetNsByName(pubkey[:], file.Namespace)
	if err != nil {
		return resp, errorx.Wrap(err, "failed to get ns from blockchain")
	}

	nodes, err := common.GetHealthNodes(e.chain)
	if err != nil {
		return resp, err
	}
	if len(nodes) < ns.Replica {
		return resp, errorx.Internal(err, "available healthy nodes smaller than replica")
	}
	nodesMap := common.ToNodeHsMap(nodes)

	logger.WithFields(logrus.Fields{
		"file_id":       file.ID,
		"file_name":     file.Name,
		"ns_total_file": ns.FileTotalNum,
		"exp_time":      time.Unix(0, opt.ExpireTime).Format("2006-01-02 15:04:05"),
	}).Info("update file")

	// encrypt file first
	cipher, err := e.encryptor.Encrypt(r, &encryptor.EncryptOptions{FileID: file.ID})
	if err != nil {
		logger.WithError(err).Error("file encryption failed")
		return resp, errorx.NewCode(err, errorx.ErrCodeCrypto, "file encryption failed")
	}
	r = bytes.NewReader(cipher.CipherText)
	originalLen := len(cipher.CipherText) - 16

	// Slice. sliceQueue will be closed when slicer get EOF
	sliceOpts := slicer.SliceOptions{}
	sliceQueue := e.slicer.Slice(ctx, r, &sliceOpts, func(err error) {
		logger.WithError(err).Error("slicing stopped")
		cancel()
	})

	// Find nodes for slices.
	// Both sliceMetaQueue and locatedSliceQueue will be closed when sliceQueue is closed
	sliceMetaQueue := make(chan slicer.SliceMeta, 10)
	locatedSliceQueue := make(chan copier.LocatedSlice, defaultLocatorAmount*2)
	go e.locateRoutine(ctx, ns.Replica, nodes, sliceQueue, locatedSliceQueue, sliceMetaQueue, func(err error) {
		logger.WithError(err).Error("slice location stopped")
		errOccurred = err
		cancel()
	})
	var sliceMetas []slicer.SliceMeta
	go func() {
		for s := range sliceMetaQueue {
			sliceMetas = append(sliceMetas, s)
		}
	}()

	// Encrypt. encryptedSliceQueue will be closed when locatedSliceQueue is closed
	encryptedSliceQueue := make(chan encryptor.EncryptedSlice, 10)
	go e.encryptRoutine(ctx, file.ID, locatedSliceQueue, encryptedSliceQueue, func(err error) {
		logger.WithError(err).Error("slice encryption stopped")
		errOccurred = err
		cancel()
	})

	// get challenge config
	ca, pairingConf := e.challenger.GetChallengeConf()

	// Setup challenging materials && Distribute
	// both finishedQueue and failedQueue will be closed when encryptedSliceQueue is closed
	finishedQueue := make(chan finishWrittenSlice, 10)
	failedQueue := make(chan encryptor.EncryptedSlice, 10)
	go e.distributeRoutine(ctx, nodesMap, encryptedSliceQueue, finishedQueue, failedQueue, opt.User)
	var finishedEncSlices []encryptor.EncryptedSlice
	var storIndexes []string
	for m := range finishedQueue {
		finishedEncSlices = append(finishedEncSlices, m.eSlice)
		storIndexes = append(storIndexes, m.storIndex)
	}

	// retry push
	var failedSlices []encryptor.EncryptedSlice
	for f := range failedQueue {
		failedSlices = append(failedSlices, f)
	}
	finishedQueue2 := make(chan finishWrittenSlice, 10)
	failedQueue2 := make(chan encryptor.EncryptedSlice, 10)
	e.retryRoutine(ctx, failedSlices, finishedQueue2, failedQueue2, nodesMap, opt.User)
	for m := range finishedQueue2 {
		finishedEncSlices = append(finishedEncSlices, m.eSlice)
		storIndexes = append(storIndexes, m.storIndex)
	}
	var failedTwice []encryptor.EncryptedSlice
	for m := range failedQueue2 {
		failedTwice = append(failedTwice, m)
	}

	// if push fails again, push to another node
	finishedQueue3 := e.pushToOtherNode(ctx, opt.User, file.ID,
		failedTwice, finishedEncSlices, nodes, func(err error) {
			logger.WithError(err).Error("pushToOtherNode failed")
			errOccurred = err
			cancel()
		})

	// check writing error
	if errOccurred != nil {
		return resp, errorx.Wrap(errOccurred, "error occurred in writing")
	}

	// all pushed slice info
	for _, m := range finishedQueue3 {
		finishedEncSlices = append(finishedEncSlices, m.eSlice)
		storIndexes = append(storIndexes, m.storIndex)
	}

	// generate and save merkle challenge material for each slice and storage node
	if ca == types.MerkleChallengeAlgorithm {
		if err := e.generateAndSaveMerkle(finishedEncSlices, file.ID, opt.ExpireTime); err != nil {
			return resp, err
		}
	}

	// Write meta info to blockchain
	chainFile, err := e.packChainUpdateFile(opt, ca, sliceMetas, originalLen, finishedEncSlices, storIndexes, pairingConf)
	if err != nil {
		return resp, errorx.Wrap(err, "failed to pack chain file")
	}
	// generate and push pairing based challenge material for each slice and storage node
	// slice index is required in calculation, which is obtained after packChainFile
	if ca == types.PairingChallengeAlgorithm {
		if err := common.AddSlicesNewPairingChallenge(ctx, pairingConf, e.copier, finishedEncSlices, chainFile, e.chain, opt.User,
			e.monitor.challengingMonitor.RequestInterval.Nanoseconds(), time.Now().UnixNano(), opt.ExpireTime, nil, logger); err != nil {
			return resp, err
		}
	}

	// sign file info
	updateFileOpt := blockchain.UpdateFileOptions{
		File: chainFile,
	}
	// get the message to sign
	msg, err = util.GetSigMessage(updateFileOpt)
	if err != nil {
		return resp, errorx.Internal(err, "failed to get the message to sign for update files")
	}
	sig, err := ecdsa.Sign(e.monitor.challengingMonitor.PrivateKey, hash.HashUsingSha256([]byte(msg)))
	if err != nil {
		return resp, errorx.Wrap(err, "failed to sign File")
	}
	updateFileOpt.Signature = sig[:]
	if err := e.chain.UpdateFile(&updateFileOpt); err != nil {
		return resp, errorx.Wrap(err, "failed to update file to blockchain")
	}

	logger.WithField("file_id", file.ID).Debug("file updated")
	resp.FileID = file.ID
	return resp, nil
}
