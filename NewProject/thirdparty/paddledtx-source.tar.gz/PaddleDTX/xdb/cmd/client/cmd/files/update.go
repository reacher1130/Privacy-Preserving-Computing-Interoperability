// Copyright (c) 2021 PaddlePaddle Authors. All Rights Reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package files

import (
	"context"
	"fmt"
	"os"
	"strings"
	"time"

	"github.com/spf13/cobra"

	httpclient "github.com/PaddlePaddle/PaddleDTX/xdb/client/http"
	"github.com/PaddlePaddle/PaddleDTX/xdb/pkgs/file"
)

// updateCmd represents the command to update file into xuper db
var updateCmd = &cobra.Command{
	Use:   "update",
	Short: "update file into XuperDB",
	Run: func(cmd *cobra.Command, args []string) {
		client, err := httpclient.New(host)
		if err != nil {
			fmt.Printf("err：%v\n", err)
			return
		}

		f, err := os.OpenFile(input, os.O_RDONLY, 0600)
		if err != nil {
			fmt.Printf("err：%v\n", err)
			return
		}
		defer f.Close()

		var stamp int64
		if len(expireTime) != 0 {
			exp, err := time.ParseInLocation(timeTemplate, expireTime, time.Local)
			if err != nil {
				fmt.Printf("err：%v\n", err)
				return
			}
			stamp = exp.UnixNano()
		}

		if privateKey == "" {
			privateKeyBytes, err := file.ReadFile(keyPath, file.PrivateKeyFileName)
			if err != nil {
				fmt.Printf("Read privateKey failed, err: %v\n", err)
				return
			}
			privateKey = strings.TrimSpace(string(privateKeyBytes))
		}

		opt := httpclient.UpdateOptions{
			PrivateKey:  privateKey,
			FileID:      fileID,
			ExpireTime:  stamp,
			Description: description,
			Extra:       extra,
		}

		resp, err := client.Update(context.Background(), f, opt)
		if err != nil {
			fmt.Printf("err：%v\n", err)
			return
		}

		fmt.Println("updated:", resp.FileID)
	},
}

func init() {
	rootCmd.AddCommand(updateCmd)

	updateCmd.Flags().StringVarP(&privateKey, "privkey", "k", "", "private key")
	updateCmd.Flags().StringVarP(&keyPath, "keyPath", "", "./ukeys", "key path")
	updateCmd.Flags().StringVarP(&input, "input", "i", "", "input file path")
	updateCmd.Flags().StringVarP(&fileID, "id", "", "", "file id to update")
	updateCmd.Flags().StringVarP(&description, "description", "d", "", "new file description")
	updateCmd.Flags().StringVarP(&expireTime, "expireTime", "e", "", "new expire time, example '2021-06-10 12:00:00'")
	updateCmd.Flags().StringVar(&extra, "ext", "", "new file extra info")

	updateCmd.MarkFlagRequired("input")
	updateCmd.MarkFlagRequired("fileID")
}
