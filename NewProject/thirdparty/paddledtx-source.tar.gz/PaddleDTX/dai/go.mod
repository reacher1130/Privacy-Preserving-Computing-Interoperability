module github.com/PaddlePaddle/PaddleDTX/dai

go 1.16

require (
	baidu/blockchain/dtx-manager v0.0.0
	github.com/PaddlePaddle/PaddleDTX/crypto v0.0.0
	github.com/PaddlePaddle/PaddleDTX/xdb v0.0.0
	github.com/cjqpker/slidewindow v1.0.2
	github.com/docker/docker v1.4.2-0.20191101170500-ac7306503d23
	github.com/docker/go-connections v0.4.1-0.20180821093606-97c2040d34df
	github.com/golang/protobuf v1.5.2
	github.com/google/uuid v1.2.0
	github.com/grpc-ecosystem/grpc-gateway v1.16.0
	github.com/hyperledger/fabric v1.4.4
	github.com/hyperledger/fabric-sdk-go v1.0.0-beta1
	github.com/jmoiron/sqlx v1.2.0
	github.com/lestrrat-go/file-rotatelogs v2.4.0+incompatible
	github.com/mattn/go-sqlite3 v2.0.3+incompatible
	github.com/sirupsen/logrus v1.8.1
	github.com/spf13/cobra v1.1.3
	github.com/spf13/viper v1.7.1
	github.com/xuperchain/xuper-sdk-go v0.0.0-20210430070222-16051cc40b09
	github.com/xuperchain/xuperchain v0.0.0-20210208123615-2d08ff11de3e
	golang.org/x/net v0.0.0-20210917221730-978cfadd31cf
	google.golang.org/genproto v0.0.0-20211208223120-3a66f561d7aa
	google.golang.org/grpc v1.41.0
)

replace github.com/go-kit/kit => github.com/go-kit/kit v0.8.0

replace github.com/PaddlePaddle/PaddleDTX/crypto => icode.baidu.com/baidu/blockchain/PaddleDTX/crypto v0.0.0-20230919100906-465d90e55758

replace github.com/PaddlePaddle/PaddleDTX/xdb => icode.baidu.com/baidu/blockchain/PaddleDTX/xdb v0.0.0-20230718120820-c5cc27df817c

replace baidu/blockchain/dtx-manager => icode.baidu.com/baidu/blockchain/dtx-manager v0.0.0-20230817102931-c7ed25ba994f

replace github.com/xuperchain/crypto v0.0.0-20211221122406-302ac826ac90 => github.com/xuperchain/crypto v0.0.0-20200701044454-40fff89406a7

replace github.com/jbenet/go-temp-err-catcher v0.0.0-20150120210811-aac704a3f4f2 => github.com/jbenet/go-temp-err-catcher v0.1.0
