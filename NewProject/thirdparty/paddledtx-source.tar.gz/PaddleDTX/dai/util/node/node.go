// Copyright (c) 2021 PaddlePaddle Authors. All Rights Reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package node

import (
	"time"
)

const (
	/* Define time period to check executor node health */
	ExecutorNodeHealthTimeDur     = 7 // days
	HeartBeatFreq                 = time.Minute
	DefaultHearBeatRate           = 0.85
	HeartBeatPerDay               = 1440
	ExecutorNodeHealthBoundGood   = 0.85
	ExecutorNodeHealthBoundMedium = 0.6

	// Define the status of the executor node health
	ExecutorNodeHealthGood   = "Green"
	ExecutorNodeHealthMedium = "Yellow"
	ExecutorNodeHealthBad    = "Red"
)

func GetHeartBeatStats(now, regTime int64) (int64, int64) {
	// yesterday
	end := TodayBeginning(now) - int64(24*time.Hour)
	// seven days ago
	start := end - int64((ExecutorNodeHealthTimeDur-1)*24*time.Hour)
	if start < regTime {
		start = regTime
		end = now
	}
	return start, end
}

func TodayBeginning(timestamp int64) int64 {
	t := time.Unix(0, timestamp)
	dayTime := time.Date(t.Year(), t.Month(), t.Day(), 0, 0, 0, 0, t.UTC().Location())
	return dayTime.UnixNano()
}

func GetHeartbeatMaxNum(start, end, regTime int64) int {
	heartBeatMax := ExecutorNodeHealthTimeDur * HeartBeatPerDay
	// if register time is not enough 7 days, max heart beat num is from reg to now
	if start == regTime {
		heartBeatMax = int((end - start) / int64(HeartBeatFreq))
	}
	return heartBeatMax
}
