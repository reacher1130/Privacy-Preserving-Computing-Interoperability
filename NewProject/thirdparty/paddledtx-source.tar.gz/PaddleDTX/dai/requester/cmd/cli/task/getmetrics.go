// Copyright (c) 2021 PaddlePaddle Authors. All Rights Reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package task

import (
	"fmt"
	"sort"
	"strings"
	"time"

	"github.com/spf13/cobra"

	"github.com/PaddlePaddle/PaddleDTX/dai/blockchain"
	pbCom "github.com/PaddlePaddle/PaddleDTX/dai/protos/common"
	requestClient "github.com/PaddlePaddle/PaddleDTX/dai/requester/client"
	"github.com/PaddlePaddle/PaddleDTX/dai/util/file"
)

// getEvalMetricsCmd
var getEvalMetricsCmd = &cobra.Command{
	Use:   "getmetrics",
	Short: "get the training task's evaluation metrics by id",
	Run: func(cmd *cobra.Command, args []string) {
		client, err := requestClient.GetRequestClient(configPath)
		if err != nil {
			fmt.Printf("GetRequestClient failed: %v\n", err)
			return
		}
		if privateKey == "" {
			privateKeyBytes, err := file.ReadFile(keyPath, file.PrivateKeyFileName)
			if err != nil {
				fmt.Printf("Read privateKey failed, err: %v\n", err)
				return
			}
			privateKey = strings.TrimSpace(string(privateKeyBytes))
		}
		task, re, lre, err := client.GetEvalMetricsById(privateKey, id)
		if err != nil {
			fmt.Printf("Get task evaluation results failed：%v\n", err)
			return
		}
		fmt.Printf("TaskID: %s\nTaskStatus: %s\nAlgorithm: %v\n\n", task.TaskID, task.Status, blockchain.VlAlgorithmListValue[task.AlgoParam.Algo])
		if task.AlgoParam.EvalParams != nil && task.AlgoParam.EvalParams.Enable && task.Status == blockchain.TaskFinished {
			fmt.Printf("ModelEvaluationRule: %s\n",
				task.AlgoParam.EvalParams.EvalRule)
			if task.AlgoParam.EvalParams.EvalRule == pbCom.EvaluationRule_ErRandomSplit {
				fmt.Printf("PercentageToLeaveOutAsValidation: %d\n\n",
					task.AlgoParam.EvalParams.RandomSplit.PercentLO)
			} else if task.AlgoParam.EvalParams.EvalRule == pbCom.EvaluationRule_ErCrossVal {
				fmt.Printf("Shuffled: %t\nFolds: %d\n\n",
					task.AlgoParam.EvalParams.Cv.Shuffle, task.AlgoParam.EvalParams.Cv.Folds)
			} else if task.AlgoParam.EvalParams.EvalRule == pbCom.EvaluationRule_ErLOO {
				fmt.Print("\n")
			}
		}

		// print evaluation metric scores
		if re != nil {
			// print binary class metric scores
			if re.BinaryClassCaseMetricScores != nil {
				bRes := re.BinaryClassCaseMetricScores
				fmt.Printf("AvgAccuracy: %v\nAvgPrecision: %v\nAvgRecall: %v\nAvgF1Score: %v\nAvgAUC: %v \n\n",
					bRes.AvgAccuracy, bRes.AvgPrecision, bRes.AvgRecall, bRes.AvgF1Score, bRes.AvgAUC)
				var keys []int
				for k := range bRes.MetricsPerFold {
					keys = append(keys, int(k))
				}
				sort.Ints(keys)
				fmt.Println("AUC for each fold: ")
				for _, k := range keys {
					v := bRes.MetricsPerFold[int32(k)]
					fmt.Printf("Folds: %v, Accuracy: %v, Precision: %v, Recall: %v, F1Score: %v, AUC: %v \n",
						k+1, v.Accuracy, v.Precision, v.Recall, v.F1Score, v.AUC)
				}
				fmt.Println()
			}
			// print regression metric scores
			if re.RegressionCaseMetricScores != nil {
				fmt.Printf("MeanRMSE: %v\n", re.RegressionCaseMetricScores.GetMeanRMSE())
				fmt.Printf("StdDevRMSE: %v\n\n", re.RegressionCaseMetricScores.GetStdDevRMSE())

				var keys []int
				rmes := re.RegressionCaseMetricScores.GetRMSEs()
				for k := range rmes {
					keys = append(keys, int(k))
				}
				sort.Ints(keys)
				fmt.Println("RMSE for each fold: ")
				for _, k := range keys {
					fmt.Printf("Folds: %v, RMSE: %v\n", k+1, rmes[int32(k)])
				}
				fmt.Println()
			}
		}
		// if task starts live evaluation
		if task.AlgoParam.LivalParams != nil && task.AlgoParam.LivalParams.Enable {
			fmt.Printf("ModelLiveEvaluationRule: %s\n", pbCom.EvaluationRule_ErRandomSplit.String())
			fmt.Printf("PercentageToLeaveOutAsValidation: %d\n\n",
				task.AlgoParam.LivalParams.RandomSplit.PercentLO)
		}
		// print live evaluation metric scores
		if lre != nil {
			fmt.Println("Live evaluation metric scores: ")
			liveRes := lre.GetLiveEvalMetricScores()
			for _, v := range liveRes {
				looTime := time.Unix(0, v.LoopTime).Format(timeTemplate)
				if v.Rmse > 0 && v.Accuracy == 0 {
					fmt.Printf("LoopTime: %v, LoopRound: %v, Rmse: %v \n", looTime, v.LoopRound, v.Rmse)
				} else {
					fmt.Printf("LoopTime: %v, LoopRound: %v, Accuracy: %v, Precision: %v, Recall: %v, F1Score: %v \n",
						looTime, v.LoopRound, v.Accuracy, v.Precision, v.Recall, v.F1Score)
				}
			}
			fmt.Println()
		}
	},
}

func init() {
	rootCmd.AddCommand(getEvalMetricsCmd)

	getEvalMetricsCmd.Flags().StringVarP(&id, "id", "i", "", "training task id")
	getEvalMetricsCmd.Flags().StringVarP(&privateKey, "privkey", "k", "", "requester private key hex string")
	getEvalMetricsCmd.Flags().StringVarP(&keyPath, "keyPath", "", "./keys", "requester's key path")

	getEvalMetricsCmd.MarkFlagRequired("id")
}
