// Copyright (c) 2021 PaddlePaddle Authors. All Rights Reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package xchain

import (
	"encoding/json"
	"strconv"
	"time"

	xdbblockchain "github.com/PaddlePaddle/PaddleDTX/xdb/blockchain"
	"github.com/PaddlePaddle/PaddleDTX/xdb/errorx"
)

// TODO xdb合约调用
func (x *XChain) GetFileByID(id string) (xdbblockchain.File, error) {
	var f xdbblockchain.File
	args := map[string]string{
		"id":          id,
		"currentTime": strconv.FormatInt(time.Now().UnixNano(), 10),
	}
	mName := "GetFileByID"
	s, err := x.QueryDtxContract(args, mName)
	if err != nil {
		return f, err
	}

	if err = json.Unmarshal(s, &f); err != nil {
		return f, errorx.NewCode(err, errorx.ErrCodeInternal,
			"failed to unmarshal File")
	}

	return f, nil
}

func (x *XChain) ListNodes() (xdbblockchain.Nodes, error) {
	var nodes xdbblockchain.Nodes
	args := map[string]string{}
	mName := "ListNodes"
	s, err := x.QueryDtxContract(args, mName)
	if err != nil {
		return nil, err
	}
	if err = json.Unmarshal(s, &nodes); err != nil {
		return nil, errorx.NewCode(err, errorx.ErrCodeInternal,
			"failed to unmarshal nodes")
	}
	return nodes, nil
}

func (x *XChain) ListFileAuthApplications(opt *xdbblockchain.ListFileAuthOptions) (xdbblockchain.FileAuthApplications, error) {
	var fas xdbblockchain.FileAuthApplications
	if opt == nil {
		return fas, errorx.New(errorx.ErrCodeParam, "missing file authorization options")
	}
	opts, err := json.Marshal(*opt)
	if err != nil {
		return fas, errorx.NewCode(err, errorx.ErrCodeInternal,
			"failed to marshal ListFileAuthOptions")
	}
	args := map[string]string{"opt": string(opts)}
	s, err := x.QueryDtxContract(args, "ListFileAuthApplications")
	if err != nil {
		return fas, err
	}
	if err = json.Unmarshal(s, &fas); err != nil {
		return fas, errorx.NewCode(err, errorx.ErrCodeInternal,
			"failed to unmarshal FileAuthApplications")
	}
	return fas, nil
}

func (x *XChain) GetAuthApplicationByID(authID string) (xdbblockchain.FileAuthApplication, error) {
	var fa xdbblockchain.FileAuthApplication
	if authID == "" {
		return fa, errorx.New(errorx.ErrCodeParam, "missing file authorization id")
	}
	args := map[string]string{"id": authID}
	s, err := x.QueryDtxContract(args, "GetAuthApplicationByID")
	if err != nil {
		return fa, err
	}
	if err = json.Unmarshal(s, &fa); err != nil {
		return fa, errorx.NewCode(err, errorx.ErrCodeInternal,
			"failed to unmarshal FileAuthApplication")
	}
	return fa, nil
}

func (x *XChain) PublishFileAuthApplication(opt *xdbblockchain.PublishFileAuthOptions) error {
	if opt == nil {
		return errorx.New(errorx.ErrCodeParam, "missing publish file authorization options")
	}
	opts, err := json.Marshal(*opt)
	if err != nil {
		return errorx.NewCode(err, errorx.ErrCodeInternal,
			"failed to marshal PublishFileAuthOptions")
	}
	args := map[string]string{"opt": string(opts)}
	_, err = x.InvokeDtxContract(args, "PublishFileAuthApplication")
	return err
}
