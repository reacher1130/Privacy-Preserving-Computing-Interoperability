// Copyright (c) 2021 PaddlePaddle Authors. All Rights Reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package main

import (
	"encoding/json"
	"fmt"
	"log"
	"regexp"
	"time"

	"github.com/PaddlePaddle/PaddleDTX/xdb/errorx"
	util "github.com/PaddlePaddle/PaddleDTX/xdb/pkgs/strings"
	"github.com/xuperchain/xuperchain/core/contractsdk/go/code"

	"github.com/PaddlePaddle/PaddleDTX/dai/blockchain"
	utilNode "github.com/PaddlePaddle/PaddleDTX/dai/util/node"
)

// RegisterExecutorNode registers Executor node
func (x *Xdata) RegisterExecutorNode(ctx code.Context) code.Response {
	var opt blockchain.AddNodeOptions
	// get opt
	p, ok := ctx.Args()["opt"]
	if !ok {
		return code.Error(errorx.New(errorx.ErrCodeParam, "missing param:node"))
	}
	// unmarshal opt
	if err := json.Unmarshal(p, &opt); err != nil {
		return code.Error(errorx.NewCode(err, errorx.ErrCodeInternal,
			"fail to unmarshal AddNodeOptions"))
	}
	// get node
	node := opt.Node
	// marshal node
	s, err := json.Marshal(node)
	if err != nil {
		return code.Error(errorx.NewCode(err, errorx.ErrCodeInternal,
			"fail to marshal Node"))
	}
	// check node.Name, the length of the executor node name is 4-16 characters
	// only support lowercase letters and numbers
	if ok, _ := regexp.MatchString("^[a-z0-9]{4,16}", node.Name); !ok {
		return code.Error(errorx.New(errorx.ErrCodeParam,
			"bad param, nodeName only supports numbers and lowercase letters with a length of 4-16"))
	}

	// get the message to sign
	msg, err := util.GetSigMessage(opt)
	if err != nil {
		return code.Error(errorx.Internal(err, "failed to get the message to sign"))
	}
	// verify sig
	if err := x.checkSign(opt.Signature, node.ID, []byte(msg)); err != nil {
		return code.Error(err)
	}

	// put index-node on xchain, judge if index exists
	index := packNodeIndex(node.ID)
	if _, err := ctx.GetObject([]byte(index)); err == nil {
		return code.Error(errorx.New(errorx.ErrCodeAlreadyExists,
			"duplicated nodeID"))
	}
	if err := ctx.PutObject([]byte(index), s); err != nil {
		return code.Error(errorx.NewCode(err, errorx.ErrCodeWriteBlockchain,
			"fail to put index-Node on xchain"))
	}
	// put index-nodeName on xchain
	index = packNodeNameIndex(node.Name)
	if _, err := ctx.GetObject([]byte(index)); err == nil {
		return code.Error(errorx.New(errorx.ErrCodeAlreadyExists,
			"duplicated nodeName"))
	}
	if err := ctx.PutObject([]byte(index), s); err != nil {
		return code.Error(errorx.NewCode(err, errorx.ErrCodeWriteBlockchain,
			"fail to put index-NodeName on xchain"))
	}

	// put listIndex-node on xchain
	index = packNodeListIndex(node)
	if err := ctx.PutObject([]byte(index), s); err != nil {
		return code.Error(errorx.NewCode(err, errorx.ErrCodeWriteBlockchain,
			"fail to put listIndex-Node on xchain"))
	}
	return code.OK([]byte("added"))
}

// ListExecutorNodes gets all Executor nodes
func (x *Xdata) ListExecutorNodes(ctx code.Context) code.Response {
	var nodes blockchain.ExecutorNodes

	// get data nodes by list_prefix
	prefix := prefixNodeListIndex
	iter := ctx.NewIterator(code.PrefixRange([]byte(prefix)))
	defer iter.Close()

	for iter.Next() {
		var node blockchain.ExecutorNode
		if err := json.Unmarshal(iter.Value(), &node); err != nil {
			return code.Error(errorx.NewCode(err, errorx.ErrCodeInternal,
				"fail to unmarshal node"))
		}
		nodes = append(nodes, node)
	}
	// marshal nodes
	s, err := json.Marshal(nodes)
	if err != nil {
		return code.Error(errorx.NewCode(err, errorx.ErrCodeInternal,
			"fail to marshal nodes"))
	}
	return code.OK(s)
}

// GetExecutorNodeByID gets Executor node by ID
func (x *Xdata) GetExecutorNodeByID(ctx code.Context) code.Response {
	// get id
	nodeID, ok := ctx.Args()["id"]
	if !ok {
		return code.Error(errorx.New(errorx.ErrCodeParam, "missing param:id"))
	}

	// get node by index
	index := packNodeStringIndex(string(nodeID))
	s, err := ctx.GetObject([]byte(index))
	if err != nil {
		return code.Error(errorx.NewCode(err, errorx.ErrCodeNotFound, "node not found"))
	}
	return code.OK(s)
}

// GetExecutorNodeByName gets Executor node by NodeName
func (x *Xdata) GetExecutorNodeByName(ctx code.Context) code.Response {
	// get name
	nodeName, ok := ctx.Args()["name"]
	if !ok {
		return code.Error(errorx.New(errorx.ErrCodeParam, "missing param:name"))
	}

	// get node by index-nodeName
	index := packNodeNameIndex(string(nodeName))
	s, err := ctx.GetObject([]byte(index))
	if err != nil {
		return code.Error(errorx.NewCode(err, errorx.ErrCodeNotFound, "node not found"))
	}
	return code.OK(s)
}

// OnlineExecutorNode set executor node online
func (x *Xdata) OnlineExecutorNode(ctx code.Context) code.Response {
	s, ok := ctx.Args()["opt"]
	if !ok {
		return code.Error(errorx.New(errorx.ErrCodeParam, "missing param:opt"))
	}

	var opt blockchain.OnlineExecutorNodeOpts
	if err := json.Unmarshal(s, &opt); err != nil {
		return code.Error(errorx.NewCode(err, errorx.ErrCodeInternal, "failed to unmarshal OfflineExecutorNode"))
	}

	// get the message to sign
	msg, err := util.GetSigMessage(opt)
	if err != nil {
		return code.Error(errorx.Internal(err, "failed to get the message to sign"))
	}
	if err := x.checkSign(opt.Signature, opt.Id, []byte(msg)); err != nil {
		return code.Error(err)
	}

	// get node by index
	index := packNodeIndex(opt.Id)
	oldn, err := ctx.GetObject([]byte(index))
	if err != nil {
		return code.Error(errorx.NewCode(err, errorx.ErrCodeNotFound, "node not found"))
	}

	// unmarshal node
	var node blockchain.ExecutorNode
	if err := json.Unmarshal(oldn, &node); err != nil {
		return code.Error(errorx.NewCode(err, errorx.ErrCodeInternal,
			"failed to unmarshal node"))
	}

	if !node.Online {
		// change status
		node.Online = true
		// marshal new node
		newn, err := json.Marshal(node)
		if err != nil {
			return code.Error(errorx.NewCode(err, errorx.ErrCodeInternal,
				"failed to marshal node"))
		}
		// put index-node on xchain
		if err := ctx.PutObject([]byte(index), newn); err != nil {
			return code.Error(errorx.NewCode(err, errorx.ErrCodeWriteBlockchain,
				"failed to put index-Node on xchain"))
		}
		// put index-nodeName on xchain
		index = packNodeNameIndex(node.Name)
		if err := ctx.PutObject([]byte(index), newn); err != nil {
			return code.Error(errorx.NewCode(err, errorx.ErrCodeWriteBlockchain,
				"fail to put index-NodeName on xchain"))
		}
		// put listIndex-node on xchain
		index = packNodeListIndex(node)
		if err := ctx.PutObject([]byte(index), newn); err != nil {
			return code.Error(errorx.NewCode(err, errorx.ErrCodeWriteBlockchain,
				"failed to put listIndex-Node on xchain"))
		}
	}

	return code.OK([]byte("OK"))
}

// OfflineExecutorNode set executor node offline
func (x *Xdata) OfflineExecutorNode(ctx code.Context) code.Response {
	s, ok := ctx.Args()["opt"]
	if !ok {
		return code.Error(errorx.New(errorx.ErrCodeParam, "missing param:opt"))
	}

	var opt blockchain.OfflineExecutorNodeOpts
	if err := json.Unmarshal(s, &opt); err != nil {
		return code.Error(errorx.NewCode(err, errorx.ErrCodeInternal, "failed to unmarshal OfflineExecutorNodeOpts"))
	}

	// get the message to sign
	msg, err := util.GetSigMessage(opt)
	if err != nil {
		return code.Error(errorx.Internal(err, "failed to get the message to sign"))
	}
	if err := x.checkSign(opt.Signature, opt.Id, []byte(msg)); err != nil {
		return code.Error(err)
	}

	// get node by index
	index := packNodeIndex(opt.Id)
	oldn, err := ctx.GetObject([]byte(index))
	if err != nil {
		return code.Error(errorx.NewCode(err, errorx.ErrCodeNotFound, "node not found"))
	}

	// unmarshal node
	var node blockchain.ExecutorNode
	if err := json.Unmarshal(oldn, &node); err != nil {
		return code.Error(errorx.NewCode(err, errorx.ErrCodeInternal,
			"failed to unmarshal node"))
	}

	if node.Online {
		// change status
		node.Online = false
		// marshal new node
		newn, err := json.Marshal(node)
		if err != nil {
			return code.Error(errorx.NewCode(err, errorx.ErrCodeInternal,
				"failed to marshal node"))
		}
		// put index-node on xchain
		if err := ctx.PutObject([]byte(index), newn); err != nil {
			return code.Error(errorx.NewCode(err, errorx.ErrCodeWriteBlockchain,
				"failed to put index-Node on xchain"))
		}
		// put index-nodeName on xchain
		index = packNodeNameIndex(node.Name)
		if err := ctx.PutObject([]byte(index), newn); err != nil {
			return code.Error(errorx.NewCode(err, errorx.ErrCodeWriteBlockchain,
				"fail to put index-NodeName on xchain"))
		}
		// put listIndex-node on xchain
		index = packNodeListIndex(node)
		if err := ctx.PutObject([]byte(index), newn); err != nil {
			return code.Error(errorx.NewCode(err, errorx.ErrCodeWriteBlockchain,
				"failed to put listIndex-Node on xchain"))
		}
	}

	return code.OK([]byte("OK"))
}

// ExecutorNodeHeartbeat updates heartbeat of executor node
func (x *Xdata) ExecutorNodeHeartbeat(ctx code.Context) code.Response {
	s, ok := ctx.Args()["opt"]
	if !ok {
		return code.Error(errorx.New(errorx.ErrCodeParam, "invalid arguments. expecting ExecutorNodeHeartbeatOpts"))
	}

	var opt blockchain.ExecutorNodeHeartbeatOpts
	if err := json.Unmarshal(s, &opt); err != nil {
		return code.Error(errorx.NewCode(err, errorx.ErrCodeInternal, "failed to unmarshal ExecutorNodeHeartbeatOpts"))
	}

	// verify sig
	msg, err := util.GetSigMessage(opt)
	if err != nil {
		return code.Error(errorx.Internal(err, "failed to get the message to sign"))
	}
	if err := x.checkSign(opt.Signature, opt.ID, []byte(msg)); err != nil {
		return code.Error(err)
	}

	// update node heartbeat number
	hindex := packHeartBeatIndex(opt.ID, opt.BeginningTime)
	resp, err := ctx.GetObject([]byte(hindex))
	var hb []int64
	if len(resp) == 0 {
		hb = append(hb, opt.CurrentTime)
	} else {
		if err := json.Unmarshal(resp, &hb); err != nil {
			return code.Error(errorx.NewCode(err, errorx.ErrCodeInternal, "failed to unmarshal heartbeat"))
		}
		for _, v := range hb {
			if v == opt.CurrentTime {
				return code.Error(errorx.NewCode(err, errorx.ErrCodeInternal, "heartbeat has been checked of ctime"))
			}
		}
		hb = append(hb, opt.CurrentTime)
	}

	hbc, err := json.Marshal(hb)
	if err != nil {
		return code.Error(errorx.NewCode(err, errorx.ErrCodeInternal, "failed to marshal heartbeat number"))
	}
	if err := ctx.PutObject([]byte(hindex), hbc); err != nil {
		return code.Error(errorx.New(errorx.ErrCodeWriteBlockchain,
			"failed to set index-heartbeat on chain: %s", err))
	}

	return code.OK(nil)
}

// GetExecutorNodeHealth get executor node health status, either green, yellow or red
func (x *Xdata) GetExecutorNodeHealth(ctx code.Context) code.Response {
	s, ok := ctx.Args()["opt"]
	if !ok {
		return code.Error(errorx.New(errorx.ErrCodeParam, "invalid arguments. expecting GetExecutorNodeHealthOpts"))
	}

	var opt blockchain.GetExecutorNodeHealthOpts
	if err := json.Unmarshal(s, &opt); err != nil {
		return code.Error(errorx.NewCode(err, errorx.ErrCodeInternal, "failed to unmarshal GetExecutorNodeHealthOpts"))
	}

	// get executor node
	ctx.Args()["id"] = []byte(fmt.Sprintf("%x", opt.Id))
	resp := x.GetExecutorNodeByID(ctx)
	if resp.Status != code.StatusOK {
		return code.Error(errorx.New(errorx.ErrCodeReadBlockchain,
			"failed to GetExecutorNodeByID: %s", resp.Message))
	}
	var node blockchain.ExecutorNode
	if err := json.Unmarshal(resp.Body, &node); err != nil {
		return code.Error(errorx.NewCode(err, errorx.ErrCodeInternal,
			"failed to unmarshal executor node"))
	}

	// get heartbeat start and end time
	start, end := utilNode.GetHeartBeatStats(opt.CurrentTime, node.RegTime)
	// get max heartbeat number
	heartBeatMax := utilNode.GetHeartbeatMaxNum(start, end, node.RegTime)
	// get real heartbeat number
	heartBeatRate := utilNode.DefaultHearBeatRate
	if heartBeatMax != 0 {
		hearBeatTotal, err := x.getHeartBeatTotalNumByTime(ctx, node.ID, start, end)
		if err != nil {
			return code.Error(errorx.NewCode(err, errorx.ErrCodeInternal,
				"failed to getHeartBeatTotalNumByTime"))
		}
		heartBeatRate = float64(hearBeatTotal) / float64(heartBeatMax)
	}

	log.Printf("executor node[%s] heartbeat rate: %f\n", fmt.Sprintf("%x", node.ID), heartBeatRate)

	// calculate health index
	if heartBeatRate >= utilNode.ExecutorNodeHealthBoundGood {
		return code.OK([]byte(utilNode.ExecutorNodeHealthGood))
	}
	if heartBeatRate < utilNode.ExecutorNodeHealthBoundMedium {
		return code.OK([]byte(utilNode.ExecutorNodeHealthBad))
	}

	return code.OK([]byte(utilNode.ExecutorNodeHealthMedium))
}

func (x *Xdata) getHeartBeatTotalNumByTime(ctx code.Context, id []byte, start, end int64) (int, error) {
	t := start

	var ts []int64
	for t <= end {
		t = utilNode.TodayBeginning(t)
		ts = append(ts, t)
		t += int64(24 * time.Hour)
	}
	heartBeatTotal, err := x.getHeartbeatNum(ctx, id, ts)
	if err != nil && !errorx.Is(err, errorx.ErrCodeNotFound) {
		return 0, err
	}
	return heartBeatTotal, nil
}

// get heart beat number of executor node
func (x *Xdata) getHeartbeatNum(ctx code.Context, id []byte, ts []int64) (int, error) {
	heartBeatTotal := 0

	for _, t := range ts {
		// get heart beat by index
		hindex := packHeartBeatIndex(id, t)
		resp, err := ctx.GetObject([]byte(hindex))
		var hb []int64
		if err != nil {
			return 0, errorx.New(errorx.ErrCodeNotFound, "heartbeat not found")
		}
		if err := json.Unmarshal(resp, &hb); err != nil {
			return 0, errorx.New(errorx.ErrCodeInternal, "failed to unmarshal heart beat list: %s", err)
		}

		heartBeatTotal += len(hb)
	}

	return heartBeatTotal, nil
}
