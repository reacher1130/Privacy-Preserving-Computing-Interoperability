// Copyright (c) 2021 PaddlePaddle Authors. All Rights Reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package xchain

import (
	"encoding/json"

	"github.com/PaddlePaddle/PaddleDTX/xdb/errorx"

	"github.com/PaddlePaddle/PaddleDTX/dai/blockchain"
)

// RegisterExecutorNode registers Executor node to xchain
func (x *XChain) RegisterExecutorNode(opt *blockchain.AddNodeOptions) error {
	opts, err := json.Marshal(*opt)
	if err != nil {
		return errorx.NewCode(err, errorx.ErrCodeInternal,
			"fail to marshal AddNodeOptions")
	}
	args := map[string]string{
		"opt": string(opts),
	}
	mName := "RegisterExecutorNode"
	if _, err = x.InvokeDtxContract(args, mName); err != nil {
		return err
	}
	return nil
}

// ListExecutorNodes gets all Executor nodes from xchain
func (x *XChain) ListExecutorNodes() (blockchain.ExecutorNodes, error) {
	var nodes blockchain.ExecutorNodes
	args := map[string]string{}
	mName := "ListExecutorNodes"
	s, err := x.QueryDtxContract(args, mName)
	if err != nil {
		return nil, err
	}
	if err = json.Unmarshal(s, &nodes); err != nil {
		return nil, errorx.NewCode(err, errorx.ErrCodeInternal,
			"fail to unmarshal executor nodes")
	}
	return nodes, nil
}

// GetExecutorNodeByID gets Executor node by ID
func (x *XChain) GetExecutorNodeByID(id string) (node blockchain.ExecutorNode, err error) {
	args := map[string]string{
		"id": id,
	}
	mName := "GetExecutorNodeByID"
	s, err := x.QueryDtxContract(args, mName)
	if err != nil {
		return node, err
	}
	if err = json.Unmarshal(s, &node); err != nil {
		return node, errorx.NewCode(err, errorx.ErrCodeInternal,
			"fail to unmarshal executor node")
	}
	return node, err
}

// GetExecutorNodeByName gets Executor node by name
func (x *XChain) GetExecutorNodeByName(name string) (node blockchain.ExecutorNode, err error) {
	args := map[string]string{
		"name": name,
	}
	mName := "GetExecutorNodeByName"
	s, err := x.QueryDtxContract(args, mName)
	if err != nil {
		return node, err
	}
	if err = json.Unmarshal(s, &node); err != nil {
		return node, errorx.NewCode(err, errorx.ErrCodeInternal,
			"fail to unmarshal executor node")
	}
	return node, err
}

// OnlineExecutorNode set executor node online
func (x *XChain) OnlineExecutorNode(opt blockchain.OnlineExecutorNodeOpts) error {
	opts, err := json.Marshal(*opt)
	if err != nil {
		return errorx.NewCode(err, errorx.ErrCodeInternal,
			"fail to marshal OnlineExecutorNodeOpts")
	}
	args := map[string]string{
		"opt": string(opts),
	}
	mName := "OnlineExecutorNode"
	if _, err = x.InvokeDtxContract(args, mName); err != nil {
		return err
	}
	return nil
}

// OfflineExecutorNode set executor node offline
func (x *XChain) OfflineExecutorNode(opt blockchain.OfflineExecutorNodeOpts) error {
	opts, err := json.Marshal(*opt)
	if err != nil {
		return errorx.NewCode(err, errorx.ErrCodeInternal,
			"fail to marshal OfflineExecutorNodeOpts")
	}
	args := map[string]string{
		"opt": string(opts),
	}
	mName := "OfflineExecutorNode"
	if _, err = x.InvokeDtxContract(args, mName); err != nil {
		return err
	}
	return nil
}

// ExecutorNodeHeartbeat updates heartbeat of executor node
func (x *XChain) ExecutorNodeHeartbeat(opt *blockchain.ExecutorNodeHeartbeatOpts) error {
	s, err := json.Marshal(*opt)
	if err != nil {
		return errorx.NewCode(err, errorx.ErrCodeInternal, "fail to marshal ExecutorNodeHeartbeatOpts")
	}
	args := map[string]string{
		"opt": string(s),
	}
	mName := "ExecutorNodeHeartbeat"

	if _, err = x.InvokeDtxContract(args, mName); err != nil {
		return err
	}
	return nil
}

// GetExecutorNodeHealth get executor node health status, either green, yellow or red
func (x *XChain) GetExecutorNodeHealth(opt blockchain.GetExecutorNodeHealthOpts) (string, error) {
	s, err := json.Marshal(*opt)
	if err != nil {
		return "", errorx.NewCode(err, errorx.ErrCodeInternal, "fail to marshal GetExecutorNodeHealthOpts")
	}
	args := map[string]string{
		"opt": string(s),
	}
	mName := "GetExecutorNodeHealth"

	resp, err := x.QueryDtxContract(args, mName)
	if err != nil {
		return "", err
	}
	return string(resp), err
}
