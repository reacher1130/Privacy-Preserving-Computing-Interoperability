// Copyright (c) 2021 PaddlePaddle Authors. All Rights Reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package xchain

import (
	"encoding/json"
	"strconv"
	"time"

	dtxmb "baidu/blockchain/dtx-manager/blockchain"
	xdbchain "github.com/PaddlePaddle/PaddleDTX/xdb/blockchain"
	"github.com/PaddlePaddle/PaddleDTX/xdb/errorx"
)

// GetCatalogFileDetailByID returns the catalog view of an XDB file.
//
// The China Unicom XChain deployment uses one combined paddlempc native
// contract.  It exposes the XDB contract methods (GetFileByID and
// ListFileAuthApplications), rather than the Fabric-only dtx-manager method
// names.  Keep the DAI-facing catalog shape here so the requester/executor
// code remains compatible with both the Fabric and XChain backends.
func (x *XChain) GetCatalogFileDetailByID(id string) (dtxmb.CatalogFile, error) {
	var f dtxmb.CatalogFile
	args := map[string]string{
		"id":          id,
		"currentTime": strconv.FormatInt(time.Now().UnixNano(), 10),
	}
	s, err := x.QueryManagerContract(args, "GetFileByID")
	if err != nil {
		return f, err
	}

	var file xdbchain.File
	if err = json.Unmarshal(s, &file); err != nil {
		return f, errorx.NewCode(err, errorx.ErrCodeInternal, "failed to unmarshal XDB file")
	}

	// XDB stores the canonical file record.  The DAI catalog type is a
	// compatibility projection used by the task executor/download path.
	f.FileID = file.ID
	f.StorageType = dtxmb.StorageTypeXdb
	f.Name = file.Name
	f.Description = file.Description
	f.Namespace = file.Namespace
	f.MerkleRoot = file.MerkleRoot
	f.Status = dtxmb.CatalogFileOnlineStatus
	f.Owner = file.Owner
	f.Length = file.Length
	f.PublishTime = file.PublishTime
	f.ExpireTime = file.ExpireTime
	f.Ext = file.Ext

	return f, nil
}

// ListCatalogFileAuth lists authorizations from the XDB state in the
// combined XChain contract and decodes them into the DAI catalog shape.
func (x *XChain) ListCatalogFileAuth(opt *dtxmb.ListCatalogFileAuthOptions) (dtxmb.CatalogFileAuthList, error) {
	var f dtxmb.CatalogFileAuthList
	xdbOpt := xdbchain.ListFileAuthOptions{
		Applier:    opt.Applier,
		Authorizer: opt.Authorizer,
		FileID:     opt.FileID,
		Status:     opt.Status,
		TimeStart:  opt.TimeStart,
		TimeEnd:    opt.TimeEnd,
		Limit:      opt.Limit,
	}
	// The XDB iterator applies both bounds.  DAI callers commonly omit the
	// upper bound, which means "up to now" for an authorization query.
	if xdbOpt.TimeStart == 0 {
		xdbOpt.TimeStart = 1
	}
	if xdbOpt.TimeEnd == 0 {
		xdbOpt.TimeEnd = time.Now().UnixNano()
	}
	opts, err := json.Marshal(xdbOpt)
	if err != nil {
		return f, errorx.NewCode(err, errorx.ErrCodeInternal,
			"failed to marshal XDB ListFileAuthOptions")
	}
	args := map[string]string{
		"opt": string(opts),
	}
	resp, err := x.QueryManagerContract(args, "ListFileAuthApplications")
	if err != nil {
		return f, err
	}
	if err = json.Unmarshal([]byte(resp), &f); err != nil {
		return f, errorx.NewCode(err, errorx.ErrCodeInternal,
			"failed to unmarshal CatalogFileAuthList")
	}
	return f, nil
}
