// Copyright (c) 2021 PaddlePaddle Authors. All Rights Reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package fabric

import (
	"encoding/json"
	"strconv"
	"time"

	dtxmb "baidu/blockchain/dtx-manager/blockchain"
	"github.com/PaddlePaddle/PaddleDTX/xdb/errorx"
)

// GetCatalogFileDetailByID 通过资源id查询资源详情
func (f *Fabric) GetCatalogFileDetailByID(id string) (dtxmb.CatalogFile, error) {
	var file dtxmb.CatalogFile
	args := [][]byte{[]byte(id), []byte(strconv.FormatInt(time.Now().UnixNano(), 10))}
	s, err := f.QueryManagerContract(args, "GetCatalogFileDetailByID")
	if err != nil {
		return file, err
	}

	if err = json.Unmarshal(s, &file); err != nil {
		return file, errorx.NewCode(err, errorx.ErrCodeInternal, "failed to unmarshal Catalog File")
	}

	return file, nil
}

// ListCatalogFileAuth 查询授权申请列表
func (f *Fabric) ListCatalogFileAuth(opt *dtxmb.ListCatalogFileAuthOptions) (dtxmb.CatalogFileAuthList, error) {
	var fas dtxmb.CatalogFileAuthList

	opts, err := json.Marshal(*opt)
	if err != nil {
		return fas, errorx.NewCode(err, errorx.ErrCodeInternal,
			"fail to marshal ListCatalogFileAuthOptions")
	}
	s, err := f.QueryManagerContract([][]byte{opts}, "ListCatalogFileAuth")
	if err != nil {
		return fas, err
	}
	if err = json.Unmarshal(s, &fas); err != nil {
		return fas, errorx.NewCode(err, errorx.ErrCodeInternal,
			"fail to unmarshal CatalogFileAuthList")
	}
	return fas, nil
}
