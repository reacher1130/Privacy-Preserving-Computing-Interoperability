// Copyright (c) 2021 PaddlePaddle Authors. All Rights Reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package fabric

import (
	"encoding/json"
	"strconv"
	"time"

	xdbblockchain "github.com/PaddlePaddle/PaddleDTX/xdb/blockchain"
	"github.com/PaddlePaddle/PaddleDTX/xdb/errorx"
)

func (f *Fabric) GetFileByID(id string) (xdbblockchain.File, error) {
	var file xdbblockchain.File
	args := [][]byte{[]byte(id), []byte(strconv.FormatInt(time.Now().UnixNano(), 10))}
	s, err := f.QueryDtxContract(args, "GetFileByID")
	if err != nil {
		return file, err
	}

	if err = json.Unmarshal(s, &file); err != nil {
		return file, errorx.NewCode(err, errorx.ErrCodeInternal, "failed to unmarshal File")
	}

	return file, nil
}

func (f *Fabric) ListNodes() (xdbblockchain.Nodes, error) {
	var nodes xdbblockchain.Nodes
	s, err := f.QueryDtxContract([][]byte{}, "ListNodes")
	if err != nil {
		return nil, err
	}
	if err = json.Unmarshal(s, &nodes); err != nil {
		return nil, errorx.NewCode(err, errorx.ErrCodeInternal,
			"failed to unmarshal nodes")
	}
	return nodes, nil
}

func (f *Fabric) ListFileAuthApplications(opt *xdbblockchain.ListFileAuthOptions) (xdbblockchain.FileAuthApplications, error) {
	return nil, nil
}

func (f *Fabric) GetAuthApplicationByID(authID string) (xdbblockchain.FileAuthApplication, error) {
	return xdbblockchain.FileAuthApplication{}, nil
}

func (f *Fabric) PublishFileAuthApplication(opt *xdbblockchain.PublishFileAuthOptions) error {
	return nil
}
