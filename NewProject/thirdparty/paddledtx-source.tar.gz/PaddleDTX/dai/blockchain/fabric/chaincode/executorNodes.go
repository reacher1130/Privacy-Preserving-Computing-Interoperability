// Copyright (c) 2021 PaddlePaddle Authors. All Rights Reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package main

import (
	"encoding/json"
	"fmt"
	"log"
	"regexp"
	"time"

	"github.com/PaddlePaddle/PaddleDTX/xdb/errorx"
	util "github.com/PaddlePaddle/PaddleDTX/xdb/pkgs/strings"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	pb "github.com/hyperledger/fabric/protos/peer"

	"github.com/PaddlePaddle/PaddleDTX/dai/blockchain"
	utilNode "github.com/PaddlePaddle/PaddleDTX/dai/util/node"
)

// RegisterExecutorNode registers Executor node
func (x *Xdata) RegisterExecutorNode(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	var opt blockchain.AddNodeOptions
	if len(args) < 1 {
		return shim.Error("invalid arguments. expecting AddNodeOptions")
	}
	// unmarshal opt
	if err := json.Unmarshal([]byte(args[0]), &opt); err != nil {
		return shim.Error(errorx.NewCode(err, errorx.ErrCodeInternal,
			"failed to unmarshal AddNodeOptions").Error())
	}

	// get node
	n := opt.Node
	// marshal node
	s, err := json.Marshal(n)
	if err != nil {
		return shim.Error(errorx.NewCode(err, errorx.ErrCodeInternal,
			"failed to marshal Node").Error())
	}

	// check node.Name, the length of the executor node name is 4-16 characters
	// only support lowercase letters and numbers
	if ok, _ := regexp.MatchString("^[a-z0-9]{4,16}", n.Name); !ok {
		return shim.Error(errorx.New(errorx.ErrCodeParam,
			"bad param, nodeName only supports numbers and lowercase letters with a length of 4-16").Error())
	}

	// get the message to sign
	msg, err := util.GetSigMessage(opt)
	if err != nil {
		return shim.Error(errorx.Internal(err, "failed to get the message to sign").Error())
	}

	// verify sig
	if err := x.checkSign(opt.Signature, n.ID, []byte(msg)); err != nil {
		return shim.Error(err.Error())
	}

	// put index-node on fabric, judge if index exists
	index := packNodeIndex(n.ID)
	if resp := x.GetValue(stub, []string{index}); len(resp.Payload) != 0 {
		return shim.Error(errorx.New(errorx.ErrCodeAlreadyExists,
			"duplicated nodeID").Error())
	}
	if resp := x.SetValue(stub, []string{index, string(s)}); resp.Status == shim.ERROR {
		return shim.Error(errorx.New(errorx.ErrCodeWriteBlockchain,
			"failed to put index-Node on chain: %s", resp.Message).Error())
	}

	// put index-nodeName on fabric
	index = packNodeNameIndex(n.Name)
	if resp := x.GetValue(stub, []string{index}); len(resp.Payload) != 0 {
		return shim.Error(errorx.New(errorx.ErrCodeAlreadyExists,
			"duplicated nodeName").Error())
	}
	if resp := x.SetValue(stub, []string{index, string(s)}); resp.Status == shim.ERROR {
		return shim.Error(errorx.New(errorx.ErrCodeWriteBlockchain, "failed to put index-NodeName on chain: %s",
			resp.Message).Error())
	}

	// put listIndex-node on fabric
	index = packNodeListIndex(n)
	if resp := x.SetValue(stub, []string{index, string(s)}); resp.Status == shim.ERROR {
		return shim.Error(errorx.New(errorx.ErrCodeWriteBlockchain, "failed to put listIndex-Node on chain: %s",
			resp.Message).Error())
	}
	return shim.Success(nil)
}

// ListExecutorNodes gets all Executor nodes
func (x *Xdata) ListExecutorNodes(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	var nodes blockchain.ExecutorNodes
	iterator, err := stub.GetStateByPartialCompositeKey(prefixNodeListIndex, []string{})
	if err != nil {
		return shim.Error(err.Error())
	}
	defer iterator.Close()
	for iterator.HasNext() {
		queryResponse, err := iterator.Next()
		if err != nil {
			return shim.Error(err.Error())
		}

		var node blockchain.ExecutorNode
		if err := json.Unmarshal(queryResponse.Value, &node); err != nil {
			return shim.Error(errorx.NewCode(err, errorx.ErrCodeInternal,
				"failed to unmarshal node").Error())
		}
		nodes = append(nodes, node)
	}

	// marshal nodes
	s, err := json.Marshal(nodes)
	if err != nil {
		return shim.Error(errorx.NewCode(err, errorx.ErrCodeInternal,
			"failed to marshal nodes").Error())
	}
	return shim.Success(s)
}

// GetExecutorNodeByID gets Executor node by ID
func (x *Xdata) GetExecutorNodeByID(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	if len(args) < 1 {
		return shim.Error("invalid arguments. expecting nodeID")
	}
	index := packNodeStringIndex(args[0])
	resp := x.GetValue(stub, []string{index})
	if len(resp.Payload) == 0 {
		return shim.Error(errorx.New(errorx.ErrCodeNotFound, "node not found: %s", resp.Message).Error())
	}
	return shim.Success(resp.Payload)
}

// GetExecutorNodeByName gets Executor node by NodeName
func (x *Xdata) GetExecutorNodeByName(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	if len(args) < 1 {
		return shim.Error("invalid arguments. expecting name")
	}
	index := packNodeNameIndex(args[0])
	resp := x.GetValue(stub, []string{index})
	if len(resp.Payload) == 0 {
		return shim.Error(errorx.New(errorx.ErrCodeNotFound,
			"node not found: %s", resp.Message).Error())
	}
	return shim.Success(resp.Payload)
}

// OnlineExecutorNode set executor node online
func (x *Xdata) OnlineExecutorNode(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	if len(args) < 1 {
		return shim.Error("invalid arguments. expecting OnlineExecutorNodeOpts")
	}

	// unmarshal opt
	var opt blockchain.OnlineExecutorNodeOpts
	if err := json.Unmarshal([]byte(args[0]), &opt); err != nil {
		return shim.Error(errorx.NewCode(err, errorx.ErrCodeInternal,
			"failed to unmarshal OnlineExecutorNodeOpts").Error())
	}

	// verify sig
	msg, err := util.GetSigMessage(opt)
	if err != nil {
		return shim.Error(errorx.Internal(err, "failed to get the message to sign").Error())
	}
	if err := x.checkSign(opt.Signature, opt.Id, []byte(msg)); err != nil {
		return shim.Error(err.Error())
	}

	// get node
	index := packNodeIndex(opt.Id)
	resp := x.GetValue(stub, []string{index})
	if len(resp.Payload) == 0 {
		return shim.Error(errorx.NewCode(err, errorx.ErrCodeInternal,
			"failed to find node on blockchain").Error())
	}
	// unmarshal node
	var node blockchain.ExecutorNode
	if err := json.Unmarshal(resp.Payload, &node); err != nil {
		return shim.Error(errorx.NewCode(err, errorx.ErrCodeInternal,
			"failed to unmarshal node").Error())
	}

	if !node.Online {
		// change status
		node.Online = true
		// marshal new node
		newn, err := json.Marshal(node)
		if err != nil {
			return shim.Error(errorx.NewCode(err, errorx.ErrCodeInternal,
				"failed to marshal node").Error())
		}
		// put index-node on fabric
		if resp := x.SetValue(stub, []string{index, string(newn)}); resp.Status == shim.ERROR {
			return shim.Error(errorx.New(errorx.ErrCodeWriteBlockchain,
				"failed to put index-Node on chain: %s", resp.Message).Error())
		}
		// put index-nodeName on fabric
		index = packNodeNameIndex(node.Name)
		if resp := x.SetValue(stub, []string{index, string(newn)}); resp.Status == shim.ERROR {
			return shim.Error(errorx.New(errorx.ErrCodeWriteBlockchain, "failed to put index-NodeName on chain: %s",
				resp.Message).Error())
		}
		// put listIndex-node on chain
		index = packNodeListIndex(node)
		if resp := x.SetValue(stub, []string{index, string(newn)}); resp.Status == shim.ERROR {
			return shim.Error(errorx.New(errorx.ErrCodeWriteBlockchain,
				"failed to put listIndex-Node on chain: %s", resp.Message).Error())
		}
	}

	return shim.Success([]byte("OK"))
}

// OfflineExecutorNode set executor node offline
func (x *Xdata) OfflineExecutorNode(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	if len(args) < 1 {
		return shim.Error("invalid arguments. expecting OfflineExecutorNodeOpts")
	}

	// unmarshal opt
	var opt blockchain.OfflineExecutorNodeOpts
	if err := json.Unmarshal([]byte(args[0]), &opt); err != nil {
		return shim.Error(errorx.NewCode(err, errorx.ErrCodeInternal,
			"failed to unmarshal OfflineExecutorNodeOpts").Error())
	}

	// verify sig
	msg, err := util.GetSigMessage(opt)
	if err != nil {
		return shim.Error(errorx.Internal(err, "failed to get the message to sign").Error())
	}
	if err := x.checkSign(opt.Signature, opt.Id, []byte(msg)); err != nil {
		return shim.Error(err.Error())
	}

	// get node
	index := packNodeIndex(opt.Id)
	resp := x.GetValue(stub, []string{index})
	if len(resp.Payload) == 0 {
		return shim.Error(errorx.NewCode(err, errorx.ErrCodeInternal,
			"failed to find node on blockchain").Error())
	}
	// unmarshal node
	var node blockchain.ExecutorNode
	if err := json.Unmarshal(resp.Payload, &node); err != nil {
		return shim.Error(errorx.NewCode(err, errorx.ErrCodeInternal,
			"failed to unmarshal node").Error())
	}

	if node.Online {
		// change status
		node.Online = false
		// marshal new node
		newn, err := json.Marshal(node)
		if err != nil {
			return shim.Error(errorx.NewCode(err, errorx.ErrCodeInternal,
				"failed to marshal node").Error())
		}
		// put index-node on fabric
		index := packNodeIndex(node.ID)
		if resp := x.SetValue(stub, []string{index, string(newn)}); resp.Status == shim.ERROR {
			return shim.Error(errorx.New(errorx.ErrCodeWriteBlockchain,
				"failed to put index-Node on chain: %s", resp.Message).Error())
		}
		// put index-nodeName on fabric
		index = packNodeNameIndex(node.Name)
		if resp := x.SetValue(stub, []string{index, string(newn)}); resp.Status == shim.ERROR {
			return shim.Error(errorx.New(errorx.ErrCodeWriteBlockchain, "failed to put index-NodeName on chain: %s",
				resp.Message).Error())
		}
		// put listIndex-node on chain
		index = packNodeListIndex(node)
		if resp := x.SetValue(stub, []string{index, string(newn)}); resp.Status == shim.ERROR {
			return shim.Error(errorx.New(errorx.ErrCodeWriteBlockchain,
				"failed to put listIndex-Node on chain: %s", resp.Message).Error())
		}
	}

	return shim.Success([]byte("OK"))
}

// ExecutorNodeHeartbeat updates heartbeat of executor node
func (x *Xdata) ExecutorNodeHeartbeat(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	if len(args) < 1 {
		return shim.Error("invalid arguments. expecting ExecutorNodeHeartbeatOpts")
	}
	var opt blockchain.ExecutorNodeHeartbeatOpts
	if err := json.Unmarshal([]byte(args[0]), &opt); err != nil {
		return shim.Error(errorx.NewCode(err, errorx.ErrCodeInternal,
			"failed to unmarshal ExecutorNodeHeartbeatOpts").Error())
	}

	// verify sig
	msg, err := util.GetSigMessage(opt)
	if err != nil {
		return shim.Error(errorx.Internal(err, "failed to get the message to sign").Error())
	}
	if err := x.checkSign(opt.Signature, opt.ID, []byte(msg)); err != nil {
		return shim.Error(err.Error())
	}

	// update node heartbeat number
	hindex := packHeartBeatIndex(opt.ID, opt.BeginningTime)
	resp := x.GetValue(stub, []string{hindex})
	var hb []int64
	if len(resp.Payload) == 0 {
		hb = append(hb, opt.CurrentTime)
	} else {
		if err := json.Unmarshal(resp.Payload, &hb); err != nil {
			return shim.Error(errorx.NewCode(err, errorx.ErrCodeInternal, "failed to unmarshal heartbeat").Error())
		}
		for _, v := range hb {
			if v == opt.CurrentTime {
				return shim.Error(errorx.NewCode(err, errorx.ErrCodeInternal, "heartbeat has been checked of ctime").Error())
			}
		}
		hb = append(hb, opt.CurrentTime)
	}

	hbc, err := json.Marshal(hb)
	if err != nil {
		return shim.Error(errorx.NewCode(err, errorx.ErrCodeInternal, "failed to marshal heartbeat number").Error())
	}
	if resp := x.SetValue(stub, []string{hindex, string(hbc)}); resp.Status == shim.ERROR {
		return shim.Error(errorx.New(errorx.ErrCodeWriteBlockchain,
			"failed to set index-heartbeat on chain: %s", resp.Message).Error())
	}

	return shim.Success(nil)
}

// GetExecutorNodeHealth get executor node health status, either green, yellow or red
func (x *Xdata) GetExecutorNodeHealth(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	if len(args) < 1 {
		return shim.Error("invalid arguments. expecting GetExecutorNodeHealthOpts")
	}
	var opt blockchain.GetExecutorNodeHealthOpts
	if err := json.Unmarshal([]byte(args[0]), &opt); err != nil {
		return shim.Error(errorx.NewCode(err, errorx.ErrCodeInternal,
			"failed to unmarshal GetExecutorNodeHealthOpts").Error())
	}

	// get executor node
	resp := x.GetExecutorNodeByID(stub, []string{fmt.Sprintf("%x", opt.Id)})
	if resp.Status != shim.OK {
		return shim.Error(errorx.New(errorx.ErrCodeReadBlockchain,
			"failed to GetExecutorNodeByID: %s", resp.Message).Error())
	}
	var node blockchain.ExecutorNode
	if err := json.Unmarshal(resp.Payload, &node); err != nil {
		return shim.Error(errorx.NewCode(err, errorx.ErrCodeInternal,
			"failed to unmarshal executor node").Error())
	}

	// get heartbeat start and end time
	start, end := utilNode.GetHeartBeatStats(opt.CurrentTime, node.RegTime)
	// get max heartbeat number
	heartBeatMax := utilNode.GetHeartbeatMaxNum(start, end, node.RegTime)
	// get real heartbeat number
	heartBeatRate := utilNode.DefaultHearBeatRate
	if heartBeatMax != 0 {
		hearBeatTotal, err := x.getHeartBeatTotalNumByTime(stub, node.ID, start, end)
		if err != nil {
			return shim.Error(errorx.NewCode(err, errorx.ErrCodeInternal,
				"failed to getHeartBeatTotalNumByTime").Error())
		}
		heartBeatRate = float64(hearBeatTotal) / float64(heartBeatMax)
	}
	log.Printf("executor node[%s] heartbeat rate: %f\n", fmt.Sprintf("%x", node.ID), heartBeatRate)

	// calculate health index
	if heartBeatRate >= utilNode.ExecutorNodeHealthBoundGood {
		return shim.Success([]byte(utilNode.ExecutorNodeHealthGood))
	}
	if heartBeatRate < utilNode.ExecutorNodeHealthBoundMedium {
		return shim.Success([]byte(utilNode.ExecutorNodeHealthBad))
	}

	return shim.Success([]byte(utilNode.ExecutorNodeHealthMedium))
}

func (x *Xdata) getHeartBeatTotalNumByTime(stub shim.ChaincodeStubInterface, id []byte, start, end int64) (int, error) {
	t := start

	var ts []int64
	for t <= end {
		t = utilNode.TodayBeginning(t)
		ts = append(ts, t)
		t += int64(24 * time.Hour)
	}
	heartBeatTotal, err := x.getHeartbeatNum(stub, id, ts)
	if err != nil && !errorx.Is(err, errorx.ErrCodeNotFound) {
		return 0, err
	}
	return heartBeatTotal, nil
}

// get heart beat number of executor node
func (x *Xdata) getHeartbeatNum(stub shim.ChaincodeStubInterface, id []byte, ts []int64) (int, error) {
	hearBeatTotal := 0

	for _, t := range ts {
		// get heart beat by index
		hindex := packHeartBeatIndex(id, t)
		resp := x.GetValue(stub, []string{hindex})

		var hb []int64
		if len(resp.Payload) == 0 {
			log.Printf("executor node[%s] beginnigTime: %d, heartbeat not found\n", fmt.Sprintf("%x", id), t)
			continue
		}
		if err := json.Unmarshal(resp.Payload, &hb); err != nil {
			return 0, errorx.New(errorx.ErrCodeInternal, "failed to unmarshal heart beat list: %s", resp.Message)
		}

		hearBeatTotal += len(hb)
	}

	return hearBeatTotal, nil
}
