// Copyright (c) 2021 PaddlePaddle Authors. All Rights Reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package evidence

import (
	"bufio"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/sirupsen/logrus"
)

var (
	// time format, used to save log timestamp
	TimeFormat = "2006-01-02 15:04:05"

	// log file path
	logPath = "./logs"

	// uuid length, used to parse taskID
	uuidLen = 36
)

// TaskHook used to save each task's log in different file, for log retrieving
type TaskHook struct{}

// Levels remain all levels log
func (h *TaskHook) Levels() []logrus.Level {
	return logrus.AllLevels
}

// Fire parse log message and save task log in corresponding file
func (h *TaskHook) Fire(entry *logrus.Entry) error {
	taskID := parseTaskIDByLogMsg(entry.Message)
	if len(taskID) == 0 {
		return nil
	}

	path := filepath.Join(logPath, taskID)
	if _, err := os.Stat(path); err != nil {
		if _, err := os.Create(path); err != nil {
			panic(err)
		}
	}

	file, err := os.OpenFile(path, os.O_WRONLY|os.O_APPEND, 0666)
	if err != nil {
		panic(err)
	}
	defer file.Close()

	write := bufio.NewWriter(file)

	write.WriteString(time.Now().Format(TimeFormat) + " " + entry.Message + "\n")
	write.Flush()

	return nil
}

// parse taskID for train task log message
func parseTaskIDByLogMsg(msg string) string {
	s1 := strings.Split(msg, "audit-task[")
	if len(s1) < 2 {
		return ""
	}
	s2 := strings.Split(s1[1], "]")
	if len(s2) < 2 {
		return ""
	}
	taskID := s2[0]
	if len(taskID) != uuidLen {
		return ""
	}
	return taskID
}
