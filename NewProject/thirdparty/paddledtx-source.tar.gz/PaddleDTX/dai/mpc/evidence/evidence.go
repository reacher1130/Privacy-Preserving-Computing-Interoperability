// Copyright (c) 2021 PaddlePaddle Authors. All Rights Reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package evidence

import (
	"encoding/json"
	"time"

	"github.com/google/uuid"

	"github.com/PaddlePaddle/PaddleDTX/dai/blockchain"
	pbDtcVl "github.com/PaddlePaddle/PaddleDTX/dai/protos/mpc/learners/decision_tree_class_vl"
	pbTask "github.com/PaddlePaddle/PaddleDTX/dai/protos/task"
)

var (
	// TaskEvidencePool contains multiple mpc task evidence which will be published to blockchain
	TaskEvidencePool chan blockchain.Evidence

	// PoolSize defines the size of TaskEvidencePool
	// todo: default pool size
	PoolSize = 10000

	// RoundInterval is round interval to save linear/logistic task evidence
	RoundInterval = 50
)

type LinearRegVlTrainLog struct {
	Round  uint64
	Thetas []float64
	Cost   float64
}

type LinearRegVlPredictLog struct {
	Result []float64
}

type LogRegVlTrainLog struct {
	Round  uint64
	Thetas []float64
	Cost   float64
}

type LogRegVlPredictLog struct {
	Result []float64
}

type DtcVlTrainLog struct {
	Result []byte
}

type DtcVlPredictLog struct {
	StepResult map[int32]*pbDtcVl.PredStepResult
	Result     map[int]string
}

// SaveLinRegVlTrainEvidence save linear regression train task evidence
func SaveLinRegVlTrainEvidence(taskID string, round uint64, thetas []float64, cost float64, stopped bool) {
	if TaskEvidencePool == nil {
		return
	}

	l := LinearRegVlTrainLog{
		Round:  round,
		Thetas: thetas,
		Cost:   cost,
	}

	// TODO: save hash?
	s, _ := json.Marshal(l)
	evd := &pbTask.Evidence{
		Id:      uuid.NewString(),
		Title:   taskID,
		Type:    blockchain.EvidenceTypeProcess,
		Content: s,
		Time:    time.Now().UnixNano(),
	}
	if stopped {
		evd.Type = blockchain.EvidenceTypeResult
	}

	TaskEvidencePool <- evd
}

// SaveLinRegVlPredictEvidence save linear regression predict task evidence
func SaveLinRegVlPredictEvidence(taskID string, predictRes []float64, stopped bool) {
	if TaskEvidencePool == nil {
		return
	}

	l := LinearRegVlPredictLog{
		Result: predictRes,
	}

	// TODO: save hash?
	s, _ := json.Marshal(l)
	evd := &pbTask.Evidence{
		Id:      uuid.NewString(),
		Title:   taskID,
		Type:    blockchain.EvidenceTypeProcess,
		Content: s,
		Time:    time.Now().UnixNano(),
	}
	if stopped {
		evd.Type = blockchain.EvidenceTypeResult
	}

	TaskEvidencePool <- evd
}

// SaveLogRegVlTrainEvidence save logistic regression train task evidence
func SaveLogRegVlTrainEvidence(taskID string, round uint64, thetas []float64, cost float64, stopped bool) {
	if TaskEvidencePool == nil {
		return
	}

	l := LogRegVlTrainLog{
		Round:  round,
		Thetas: thetas,
		Cost:   cost,
	}

	// TODO: save hash?
	s, _ := json.Marshal(l)
	evd := &pbTask.Evidence{
		Id:      uuid.NewString(),
		Title:   taskID,
		Type:    blockchain.EvidenceTypeProcess,
		Content: s,
		Time:    time.Now().UnixNano(),
	}
	if stopped {
		evd.Type = blockchain.EvidenceTypeResult
	}

	TaskEvidencePool <- evd
}

// SaveLogRegVlPredictEvidence save logistic regression predict task evidence
func SaveLogRegVlPredictEvidence(taskID string, predictRes []float64, stopped bool) {
	if TaskEvidencePool == nil {
		return
	}

	l := LogRegVlPredictLog{
		Result: predictRes,
	}

	// TODO: save hash?
	s, _ := json.Marshal(l)
	evd := &pbTask.Evidence{
		Id:      uuid.NewString(),
		Title:   taskID,
		Type:    blockchain.EvidenceTypeProcess,
		Content: s,
		Time:    time.Now().UnixNano(),
	}
	if stopped {
		evd.Type = blockchain.EvidenceTypeResult
	}

	TaskEvidencePool <- evd
}

// SaveDtcTrainEvidence save classification decision tree train task evidence
func SaveDtcTrainEvidence(taskID string, result []byte) {
	if TaskEvidencePool == nil {
		return
	}

	l := DtcVlTrainLog{
		Result: result,
	}

	// TODO: save hash?
	s, _ := json.Marshal(l)
	evd := &pbTask.Evidence{
		Id:      uuid.NewString(),
		Title:   taskID,
		Type:    blockchain.EvidenceTypeResult,
		Content: s,
		Time:    time.Now().UnixNano(),
	}

	TaskEvidencePool <- evd
}

// SaveDtcPredictEvidence save classification decision tree predict task evidence
func SaveDtcPredictEvidence(taskID string, stepResult map[int32]*pbDtcVl.PredStepResult, result map[int]string, stopped bool) {
	if TaskEvidencePool == nil {
		return
	}

	l := DtcVlPredictLog{
		StepResult: stepResult,
		Result:     result,
	}

	// TODO: save hash?
	s, _ := json.Marshal(l)
	evd := &pbTask.Evidence{
		Id:      uuid.NewString(),
		Title:   taskID,
		Type:    blockchain.EvidenceTypeProcess,
		Content: s,
		Time:    time.Now().UnixNano(),
	}
	if stopped {
		evd.Type = blockchain.EvidenceTypeResult
	}

	TaskEvidencePool <- evd
}
