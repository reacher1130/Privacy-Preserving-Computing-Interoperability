// Copyright (c) 2021 PaddlePaddle Authors. All Rights Reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package decision_tree_class_vl

import (
	"encoding/json"
	"sync"
	"time"

	"github.com/PaddlePaddle/PaddleDTX/xdb/errorx"
	"github.com/golang/protobuf/proto"
	"github.com/sirupsen/logrus"

	"github.com/PaddlePaddle/PaddleDTX/dai/crypto/vl/dtc"
	"github.com/PaddlePaddle/PaddleDTX/dai/crypto/vl/feat_eng"
	"github.com/PaddlePaddle/PaddleDTX/dai/errcodes"
	"github.com/PaddlePaddle/PaddleDTX/dai/mpc/evidence"
	"github.com/PaddlePaddle/PaddleDTX/dai/mpc/psi"
	pbCom "github.com/PaddlePaddle/PaddleDTX/dai/protos/common"
	pb "github.com/PaddlePaddle/PaddleDTX/dai/protos/mpc"
	pbDtcVl "github.com/PaddlePaddle/PaddleDTX/dai/protos/mpc/learners/decision_tree_class_vl"
)

var (
	logger = logrus.WithField("module", "mpc.models.decision_tree_class_vl")
)

// PSI is for vertical learning,
// initialized at the beginning of training by Learner
type PSI interface {
	// EncryptSampleIDSet to encrypt local IDs
	EncryptSampleIDSet() ([]byte, error)

	// SetReEncryptIDSet sets re-encrypted IDs from other party,
	// and tries to calculate final re-encrypted IDs
	// returns True if calculation is Done, otherwise False if still waiting for others' parts
	// returns Error if any mistake happens
	SetReEncryptIDSet(party string, reEncIDs []byte) (bool, error)

	// ReEncryptIDSet to encrypt encrypted IDs for other party
	ReEncryptIDSet(party string, encIDs []byte) ([]byte, error)

	// SetOtherFinalReEncryptIDSet sets final re-encrypted IDs of other party
	SetOtherFinalReEncryptIDSet(party string, reEncIDs []byte) error

	// IntersectParts tries to calculate intersection with all parties' samples
	// returns True with final result if calculation is Done, otherwise False if still waiting for others' samples
	// returns Error if any mistake happens
	// You'd better call it when SetReEncryptIDSet returns Done or SetOtherFinalReEncryptIDSet finishes
	IntersectParts() (bool, [][]string, []string, error)
}

// RpcHandler used to request remote mpc-node
type RpcHandler interface {
	StepPredict(req *pb.PredictRequest, peerName string) (*pb.PredictResponse, error)

	// StepPredictWithRetry sends prediction message to remote mpc-node
	// retries 2 times at most
	// interSec indicates the interval between retry requests, in seconds
	StepPredictWithRetry(req *pb.PredictRequest, peerName string, times int, inteSec int64) (*pb.PredictResponse, error)
}

// ResultHandler handles final result which is successful or failed
// Should be called when prediction finished
type ResultHandler interface {
	SaveResult(*pbCom.PredictTaskResult)
}

type modelStatusType uint8

const (
	modelStatusStartPSI modelStatusType = iota
	modelStatusEndPSI
	modelStatusStartPredict
	modelStatusEndPredict
)

// Model was trained out by a Learner,
// and participates in the multi-parts-calculation during prediction process
// If input different parts of a sample into Models on different mpc-nodes, you'll get final predicting result after some time of multi-parts-calculation
type Model struct {
	id          string
	algo        pbCom.Algorithm
	address     string   // address indicates local mpc-node
	parties     []string // parties are other models who participates in MPC, assigned with mpc-node address usually
	params      *pbCom.PredictParams
	model       *dtc.TrainModels
	samplesFile []byte                      // sample file content for prediction
	samples     map[int32]map[string]string // map sample id to attributes
	psi         PSI
	rpc         RpcHandler    // rpc is used to request remote mpc-node
	rh          ResultHandler // rh handles final result which is successful or failed
	fileRows    [][]string    // fileRows returned by psi.IntersectParts
	intersect   []string      // intersect returned by psi.IntersectParts

	selfReady  bool // if self finished psi and ready to predict
	otherReady bool // if other party finished psi and ready to predict

	outcomes     map[int]string // final result, map sample id to class
	outcomesLeaf map[int]string // final result, map sample id to leaf node id

	procMutex sync.Mutex
	status    modelStatusType
}

// Advance does calculation with local parts of samples and communicates with other nodes in cluster to predict outcomes
// payload could be resolved by Model trained out by specific algorithm and samples
// We'd better call the method asynchronously avoid blocking the main go-routine
func (model *Model) Advance(payload []byte) (*pb.PredictResponse, error) {
	m := &pbDtcVl.PredictMessage{}
	err := proto.Unmarshal(payload, m)
	if err != nil {
		return nil, errorx.New(errcodes.ErrCodeParam, "failed to Unmarshal payload: %s", err.Error())
	}

	return model.advance(m)
}

// advance handles all kinds of message
func (model *Model) advance(message *pbDtcVl.PredictMessage) (*pb.PredictResponse, error) {
	mType := message.Type

	handleError := func(err error) {
		logger.WithField("error", err.Error()).Warning("failed to predict")
		res := &pbCom.PredictTaskResult{TaskID: model.id, ErrMsg: err.Error()}
		model.rh.SaveResult(res)
	}

	var ret *pb.PredictResponse
	switch mType {
	case pbDtcVl.MessageType_MsgPsiEnc: // local message
		encIDs, err := model.psi.EncryptSampleIDSet()
		if err != nil {
			go handleError(err)
			return nil, err
		}

		go func() {
			m := &pbDtcVl.PredictMessage{
				Type: pbDtcVl.MessageType_MsgPsiAskReEnc,
				VlPsiReEncIDsReq: &pb.VLPsiReEncIDsRequest{
					EncIDs: encIDs,
				},
			}
			model.advance(m)
		}()

	case pbDtcVl.MessageType_MsgPsiAskReEnc: // local message
		newMess := &pbDtcVl.PredictMessage{
			Type:             pbDtcVl.MessageType_MsgPsiReEnc,
			VlPsiReEncIDsReq: message.VlPsiReEncIDsReq,
		}
		reM, err := model.sendMessageWithRetry(newMess, model.parties[0])
		if err != nil {
			go handleError(err)
			return nil, err
		}

		done, err := model.psi.SetReEncryptIDSet(model.parties[0], reM.VlPsiReEncIDsResp.ReEncIDs)
		if err != nil {
			go handleError(err)
			return nil, err
		}

		if done {
			go func() {
				m := &pbDtcVl.PredictMessage{
					Type: pbDtcVl.MessageType_MsgPsiIntersect,
				}
				model.advance(m)
			}()
		}

	case pbDtcVl.MessageType_MsgPsiReEnc:
		reEncIDs, err := model.psi.ReEncryptIDSet(message.From, message.VlPsiReEncIDsReq.EncIDs)
		if err != nil {
			go handleError(err)
			return nil, err
		}

		retM := &pbDtcVl.PredictMessage{
			Type: pbDtcVl.MessageType_MsgPsiReEnc,
			To:   message.From,
			From: model.address,
			VlPsiReEncIDsResp: &pb.VLPsiReEncIDsResponse{
				TaskID:   model.id,
				ReEncIDs: reEncIDs,
			},
		}
		payload, err := proto.Marshal(retM)
		if err != nil {
			err = errorx.New(errcodes.ErrCodeInternal, "failed to Marshal payload: %s", err.Error())
			go handleError(err)
			return nil, err
		}

		ret = &pb.PredictResponse{
			TaskID:  model.id,
			Payload: payload,
		}

		err = model.psi.SetOtherFinalReEncryptIDSet(message.From, reEncIDs)
		if err != nil {
			go handleError(err)
		} else {
			go func() {
				m := &pbDtcVl.PredictMessage{
					Type: pbDtcVl.MessageType_MsgPsiIntersect,
				}
				model.advance(m)
			}()
		}

	case pbDtcVl.MessageType_MsgPsiIntersect: // local message
		model.procMutex.Lock()
		defer model.procMutex.Unlock()

		done, newRows, intersect, err := model.psi.IntersectParts()
		if err != nil {
			go handleError(err)
			return nil, err
		}

		if done && model.status == modelStatusStartPSI {
			// add audit log
			logger.Infof("audit-task[%s] used features: %v", model.id, append(newRows[0], model.params.IdName))
			logger.Infof("audit-task[%s] PSI intersects: %v", model.id, intersect)

			model.fileRows = newRows
			model.intersect = intersect
			model.status = modelStatusEndPSI
			model.setSamples()

			model.selfReady = true

			// notice other party that psi was finished
			mr := &pbDtcVl.PredictMessage{
				Type: pbDtcVl.MessageType_MsgPredictNoticeReady,
			}
			go model.advance(mr)

			mh := &pbDtcVl.PredictMessage{
				Type: pbDtcVl.MessageType_MsgPredictHup,
			}
			go model.advance(mh)
		}

	case pbDtcVl.MessageType_MsgPredictNoticeReady: // local message
		m := &pbDtcVl.PredictMessage{
			Type: pbDtcVl.MessageType_MsgPredictReady,
		}
		if _, err := model.sendMessageWithRetry(m, model.parties[0]); err != nil {
			go handleError(err)
			return nil, err
		}

	case pbDtcVl.MessageType_MsgPredictReady:
		model.procMutex.Lock()
		defer model.procMutex.Unlock()

		ret = &pb.PredictResponse{
			TaskID: model.id,
		}
		model.otherReady = true
		m := &pbDtcVl.PredictMessage{
			Type: pbDtcVl.MessageType_MsgPredictHup,
		}
		go model.advance(m)

	case pbDtcVl.MessageType_MsgPredictHup: // local message
		model.procMutex.Lock()
		defer model.procMutex.Unlock()

		// if all parties finished psi, start prediction
		if model.selfReady && model.otherReady {
			model.status = modelStatusStartPredict
			// the party with root node predicts first
			rootKey := dtc.GetTreeNodeKey(0, 0)
			if n, v := model.model.NodesMap[rootKey]; v && n.SplitValue != nil {
				newMsg := &pbDtcVl.PredictMessage{
					Type:        pbDtcVl.MessageType_MsgPredictLocal,
					PredStepRes: nil,
				}
				go model.advance(newMsg)
			}
		}

	case pbDtcVl.MessageType_MsgPredictInfo:
		ret = &pb.PredictResponse{
			TaskID: model.id,
		}
		newMsg := &pbDtcVl.PredictMessage{
			Type:        pbDtcVl.MessageType_MsgPredictLocal,
			PredStepRes: message.PredStepRes,
		}
		go model.advance(newMsg)

	case pbDtcVl.MessageType_MsgPredictLocal: // local message
		res, err := model.predictLocalPart(message.PredStepRes)
		if err != nil {
			go handleError(err)
			return nil, err
		}

		// save task processing evidence if not final result
		go func() {
			if len(res) != 0 {
				evidence.SaveDtcPredictEvidence(model.id, res, nil, false)
			}
		}()

		// 'res' denotes the prediction samples in next step
		// send the samples and corresponding node position to the other party
		// if all samples got prediction results, stop the task
		if len(res) != 0 {
			newMess := &pbDtcVl.PredictMessage{
				Type:        pbDtcVl.MessageType_MsgPredictInfo,
				PredStepRes: res,
			}
			if _, err := model.sendMessageWithRetry(newMess, model.parties[0]); err != nil {
				go handleError(err)
				return nil, err
			}
		} else {
			m := &pbDtcVl.PredictMessage{
				Type: pbDtcVl.MessageType_MsgPredictFinal,
			}
			model.advance(m)
			if _, err := model.sendMessageWithRetry(m, model.parties[0]); err != nil {
				go handleError(err)
				return nil, err
			}
		}

	case pbDtcVl.MessageType_MsgPredictFinal:
		ret = &pb.PredictResponse{
			TaskID: model.id,
		}
		m := &pbDtcVl.PredictMessage{
			Type: pbDtcVl.MessageType_MsgPredictStop,
		}
		go model.advance(m)

	case pbDtcVl.MessageType_MsgPredictStop: // local message
		model.procMutex.Lock()
		defer model.procMutex.Unlock()

		// lock to make sure that calculate and save outcomes for just once
		if model.status != modelStatusEndPredict {
			model.status = modelStatusEndPredict
			if !model.params.TrainResult.IsTagPart {
				go func() {
					logger.WithField("IsTagPart", model.params.TrainResult.IsTagPart).Infof("model[%s] finished prediction", model.id)
					// add audit log
					logger.Infof("audit-task[%s] task stopped", model.id)
					model.rh.SaveResult(&pbCom.PredictTaskResult{
						TaskID:  model.id,
						Success: true,
					})
				}()
			} else {
				outs, err := model.resultToBytes()
				if err != nil {
					go handleError(err)
					return nil, err
				}
				go func() {
					logger.WithField("IsTagPart", model.params.TrainResult.IsTagPart).Infof("model[%s] finished prediction and outcomes are[%v]", model.id, model.outcomes)
					// add audit log
					logger.Infof("audit-task[%s] task stopped", model.id)
					logger.Infof("audit-task[%s] predicted output: %vc", model.id, model.outcomes)
					model.rh.SaveResult(&pbCom.PredictTaskResult{
						TaskID:   model.id,
						Success:  true,
						Outcomes: outs,
					})
				}()

				// save task result evidence
				go func() {
					evidence.SaveDtcPredictEvidence(model.id, nil, model.outcomes, true)
				}()
			}
		}
	}

	logger.WithFields(logrus.Fields{
		"address": model.address,
	}).Infof("model[%s] finished advance. message %s", model.id, message.Type.String())
	return ret, nil
}

// setSamples convert file rows to attributes map, which maps sample id to attribute values
// e,g., sample_0["Age":"63", "Cp":"1.0"...]
func (model *Model) setSamples() {
	dataMap := make(map[int32]map[string]string)
	// first row contains all features
	features := model.fileRows[0]
	for id := 0; id < len(model.fileRows)-1; id++ {
		dataMap[int32(id)] = make(map[string]string)
		for j := 0; j < len(features); j++ {
			dataMap[int32(id)][features[j]] = model.fileRows[id+1][j]
		}
	}
	model.samples = dataMap
	logger.Infof("[%s]got samples map: %v", model.id, model.samples)
}

// predictLocalPart predict locally given current prediction status,
//  which includes sample ids, current node depth&index of each sample
func (model *Model) predictLocalPart(msg map[int32]*pbDtcVl.PredStepResult) (map[int32]*pbDtcVl.PredStepResult, error) {
	// check if this is the first prediction step
	// if so, set all Depth and Index to 0
	if msg == nil {
		msg = make(map[int32]*pbDtcVl.PredStepResult)
		for k := range model.samples {
			msg[k] = &pbDtcVl.PredStepResult{
				Depth: 0,
				Index: 0,
			}
		}
	}

	results, err := dtc.PredictionStep(model.model.NodesMap, model.samples, msg)
	if err != nil {
		logger.Warnf("[%s]PredictionStep err: %v, samples: [%v], stepRes: [%v]", err, model.id, model.samples, msg)
		return nil, err
	}

	// for non-tag party, prediction cannot obtain final results, because leaves are stored in tag party
	if !model.params.TrainResult.IsTagPart {
		return results, nil
	}

	// for tag party, filter samples which have not finished prediction
	ret := model.filterPredResTagPart(results)
	return ret, nil
}

// filterPredResTagPart check if any prediction sample reaches leaf
// save result if yes, otherwise filter these samples to be predicted later by the other party
// this is operated by tag party, non-tag party need not to filter, because all leaves are stored in tag party
func (model *Model) filterPredResTagPart(res map[int32]*pbDtcVl.PredStepResult) map[int32]*pbDtcVl.PredStepResult {
	model.procMutex.Lock()
	defer model.procMutex.Unlock()

	ret := make(map[int32]*pbDtcVl.PredStepResult)
	for k, v := range res {
		if len(v.Result) != 0 {
			model.outcomes[int(k)] = v.Result
			model.outcomesLeaf[int(k)] = dtc.GetTreeNodeKey(uint64(v.Depth), uint64(v.Index))
			continue
		}
		ret[k] = &pbDtcVl.PredStepResult{
			Depth: v.Depth,
			Index: v.Index,
		}
	}
	return ret
}

// resultToBytes convert prediction result to bytes
// this is operated by tag party, because only tag party has the final results
func (model *Model) resultToBytes() ([]byte, error) {
	if len(model.fileRows) != len(model.outcomes)+1 {
		return nil, errorx.New(errcodes.ErrCodeParam, "prediction samples and outcomes numbers are not equal")
	}

	fileRows := make([][]string, len(model.fileRows))
	// first row is [idName, value, leafID], others are prediction results, each row for each sample
	fileRows[0] = []string{model.params.IdName, "value", "leafID"}
	for i := 0; i < len(model.outcomes); i++ {
		fileRows[i+1] = []string{model.intersect[i], model.outcomes[i], model.outcomesLeaf[i]}
	}

	content, err := json.Marshal(fileRows)
	if err != nil {
		return nil, errorx.New(errcodes.ErrCodeEncoding, "encode predict results failed: %s", err.Error())
	}
	return content, nil
}

// sendMessageWithRetry sends message to remote mpc-node
// retries 2 times at most
func (model *Model) sendMessageWithRetry(message *pbDtcVl.PredictMessage, address string) (*pbDtcVl.PredictMessage, error) {
	times := 3

	var m *pbDtcVl.PredictMessage
	var err error
	for i := 0; i < times; i++ {
		if i > 0 {
			time.Sleep(3 * time.Second)
		}
		m, err = model.sendMessage(message, address)
		if err == nil {
			break
		}
	}

	return m, err
}

// sendMessage sends message to remote mpc-node
func (model *Model) sendMessage(message *pbDtcVl.PredictMessage, address string) (*pbDtcVl.PredictMessage, error) {
	message.From = model.address
	message.To = address

	payload, err := proto.Marshal(message)
	if err != nil {
		return nil, errorx.New(errcodes.ErrCodeInternal, "failed to Marshal payload: %s", err.Error())
	}

	predictReq := &pb.PredictRequest{
		TaskID:  model.id,
		Algo:    model.algo,
		Payload: payload,
	}
	resp, err := model.rpc.StepPredict(predictReq, address)
	if err != nil {
		return nil, err
	}

	m := &pbDtcVl.PredictMessage{}
	if len(resp.Payload) != 0 {
		err := proto.Unmarshal(resp.Payload, m)
		if err != nil {
			return nil, errorx.New(errcodes.ErrCodeInternal, "failed to Unmarshal payload[%s] from[%s] and err is[%s] ", string(resp.Payload), address, err.Error())
		}
	}
	return m, nil
}

// NewModel returns a VerticalDecisionTreeClass Model
// id is the assigned id for Model
// samplesFile is sample file content for prediction
// address indicates local mpc-node
// parties are other models who participates in MPC, assigned with mpc-node address usually
// rpc is used to request remote mpc-node
// rh handles final result which is successful or failed
// params are parameters for prediction, including model
// featEngs are feature engineering options for samples file
func NewModel(id string, address string, params *pbCom.PredictParams,
	featEngs []*pbCom.FeatureEngineering, samplesFile []byte,
	parties []string, rpc RpcHandler, rh ResultHandler) (*Model, error) {

	// handle feature engineering to get new sample file
	newSamplesFile, err := feat_eng.ProcessFeatEngs(samplesFile, featEngs)
	if err != nil {
		return nil, err
	}

	p, err := psi.NewVLTwoPartsPSI(address, newSamplesFile, params.GetIdName(), parties)
	if err != nil {
		return nil, err
	}

	// unmarshal the classification tree model
	m := new(dtc.TrainModels)
	if len(params.TrainResult.Model) != 0 {
		if err := json.Unmarshal(params.TrainResult.Model, &m); err != nil {
			return nil, err
		}
	} else {
		logger.Warnf("[%s] empty model", id)
	}

	model := &Model{
		id:           id,
		algo:         pbCom.Algorithm_DECISION_TREE_CLASS_VL,
		samplesFile:  newSamplesFile,
		samples:      make(map[int32]map[string]string),
		address:      address,
		parties:      parties,
		params:       params,
		model:        m,
		outcomes:     make(map[int]string),
		outcomesLeaf: make(map[int]string),
		psi:          p,
		rpc:          rpc,
		rh:           rh,
		status:       modelStatusStartPSI,
	}

	go func() {
		m := &pbDtcVl.PredictMessage{
			Type: pbDtcVl.MessageType_MsgPsiEnc,
		}
		model.advance(m)
	}()

	return model, nil
}
