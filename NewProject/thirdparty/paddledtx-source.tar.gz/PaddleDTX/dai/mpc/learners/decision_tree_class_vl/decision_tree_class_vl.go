// Copyright (c) 2021 PaddlePaddle Authors. All Rights Reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package decision_tree_class_vl

import (
	"sync"
	"time"

	"github.com/PaddlePaddle/PaddleDTX/xdb/errorx"
	"github.com/golang/protobuf/proto"
	"github.com/sirupsen/logrus"

	"github.com/PaddlePaddle/PaddleDTX/dai/crypto/vl/feat_eng"
	"github.com/PaddlePaddle/PaddleDTX/dai/errcodes"
	"github.com/PaddlePaddle/PaddleDTX/dai/mpc/evidence"
	"github.com/PaddlePaddle/PaddleDTX/dai/mpc/psi"
	pbCom "github.com/PaddlePaddle/PaddleDTX/dai/protos/common"
	pb "github.com/PaddlePaddle/PaddleDTX/dai/protos/mpc"
	pbDtcVl "github.com/PaddlePaddle/PaddleDTX/dai/protos/mpc/learners/decision_tree_class_vl"
)

var (
	logger = logrus.WithField("module", "mpc.learners.decision_tree_class_vl")
)

// PSI is for vertical learning,
// initialized at the beginning of training by Learner
type PSI interface {
	// EncryptSampleIDSet to encrypt local IDs
	EncryptSampleIDSet() ([]byte, error)

	// SetReEncryptIDSet sets re-encrypted IDs from other party,
	// and tries to calculate final re-encrypted IDs
	// returns True if calculation is Done, otherwise False if still waiting for others' parts
	// returns Error if any mistake happens
	SetReEncryptIDSet(party string, reEncIDs []byte) (bool, error)

	// ReEncryptIDSet to encrypt encrypted IDs for other party
	ReEncryptIDSet(party string, encIDs []byte) ([]byte, error)

	// SetOtherFinalReEncryptIDSet sets final re-encrypted IDs of other party
	SetOtherFinalReEncryptIDSet(party string, reEncIDs []byte) error

	// IntersectParts tries to calculate intersection with all parties' samples
	// returns True with final result if calculation is Done, otherwise False if still waiting for others' samples
	// returns Error if any mistake happens
	// You'd better call it when SetReEncryptIDSet returns Done or SetOtherFinalReEncryptIDSet finishes
	IntersectParts() (bool, [][]string, []string, error)
}

// RpcHandler used to request remote mpc-node
type RpcHandler interface {
	StepTrain(req *pb.TrainRequest, peerName string) (*pb.TrainResponse, error)

	// StepTrainWithRetry sends training message to remote mpc-node
	// retries 2 times at most
	// inteSec indicates the interval between retry requests, in seconds
	StepTrainWithRetry(req *pb.TrainRequest, peerName string, times int, inteSec int64) (*pb.TrainResponse, error)
}

// ResultHandler handles final result which is successful or failed
// Should be called when learning finished
type ResultHandler interface {
	SaveResult(*pbCom.TrainTaskResult)
}

type learnerStatusType uint8

const (
	learnerStatusStartPSI learnerStatusType = iota
	learnerStatusEndPSI
	learnerStatusStartTrain
	learnerStatusEndTrain
)

type Learner struct {
	id          string
	algo        pbCom.Algorithm
	address     string   // address indicates local mpc-node
	parties     []string // parties are other learners who participates in MPC, assigned with mpc-node address usually
	trainParams *pbCom.TrainParams
	samplesFile []byte // sample file content for training model
	psi         PSI
	procMutex   sync.Mutex
	process     *process      // process of training model
	rpc         RpcHandler    // rpc is used to request remote mpc-node
	rh          ResultHandler // rh handles final result which is successful or failed

	fileRows [][]string // fileRows returned by psi.IntersectParts

	status learnerStatusType
}

func (l *Learner) Advance(payload []byte) (*pb.TrainResponse, error) {
	m := &pbDtcVl.Message{}
	err := proto.Unmarshal(payload, m)
	if err != nil {
		return nil, errorx.New(errcodes.ErrCodeParam, "failed to Unmarshal payload: %s", err.Error())
	}

	return l.advance(m)
}

// getTrainSet returns training set after Sample Alignment
func (l *Learner) getTrainSet() []*pbCom.TrainTaskResult_FileRow {
	var frs []*pbCom.TrainTaskResult_FileRow
	for _, fr := range l.fileRows {
		frs = append(frs, &pbCom.TrainTaskResult_FileRow{Row: fr})
	}
	return frs
}

// advance handles all kinds of message
func (l *Learner) advance(message *pbDtcVl.Message) (*pb.TrainResponse, error) {
	mType := message.Type

	handleError := func(err error) {
		logger.WithField("error", err.Error()).Warning("failed to train out a model")
		res := &pbCom.TrainTaskResult{TaskID: l.id, ErrMsg: err.Error()}
		l.rh.SaveResult(res)
	}

	var ret *pb.TrainResponse
	switch mType {
	case pbDtcVl.MessageType_MsgPsiEnc: // local message
		encIDs, err := l.psi.EncryptSampleIDSet()
		if err != nil {
			go handleError(err)
			return nil, err
		}

		go func() {
			m := &pbDtcVl.Message{
				Type: pbDtcVl.MessageType_MsgPsiAskReEnc,
				VlPsiReEncIDsReq: &pb.VLPsiReEncIDsRequest{
					TaskID: l.id,
					EncIDs: encIDs,
				},
			}
			l.advance(m)
		}()

	case pbDtcVl.MessageType_MsgPsiAskReEnc: // local message
		newMsg := &pbDtcVl.Message{
			Type:             pbDtcVl.MessageType_MsgPsiReEnc,
			VlPsiReEncIDsReq: message.VlPsiReEncIDsReq,
		}
		reM, err := l.sendMessageWithRetry(newMsg, l.parties[0])
		if err != nil {
			go handleError(err)
			return nil, err
		}

		done, err := l.psi.SetReEncryptIDSet(l.parties[0], reM.VlPsiReEncIDsResp.ReEncIDs)
		if err != nil {
			go handleError(err)
			return nil, err
		}

		if done {
			go func() {
				m := &pbDtcVl.Message{
					Type: pbDtcVl.MessageType_MsgPsiIntersect,
				}
				l.advance(m)
			}()
		}

	case pbDtcVl.MessageType_MsgPsiReEnc:
		reEncIDs, err := l.psi.ReEncryptIDSet(message.From, message.VlPsiReEncIDsReq.EncIDs)
		if err != nil {
			go handleError(err)
			return nil, err
		}

		retM := &pbDtcVl.Message{
			Type: pbDtcVl.MessageType_MsgPsiReEnc,
			To:   message.From,
			From: l.address,
			VlPsiReEncIDsResp: &pb.VLPsiReEncIDsResponse{
				TaskID:   l.id,
				ReEncIDs: reEncIDs,
			},
		}
		payload, err := proto.Marshal(retM)
		if err != nil {
			err = errorx.New(errcodes.ErrCodeInternal, "failed to Marshal payload: %s", err.Error())
			go handleError(err)
			return nil, err
		}

		ret = &pb.TrainResponse{
			TaskID:  l.id,
			Payload: payload,
		}

		err = l.psi.SetOtherFinalReEncryptIDSet(message.From, reEncIDs)
		if err != nil {
			go handleError(err)
		} else {
			go func() {
				m := &pbDtcVl.Message{
					Type: pbDtcVl.MessageType_MsgPsiIntersect,
				}
				l.advance(m)
			}()
		}

	case pbDtcVl.MessageType_MsgPsiIntersect: // local message
		l.procMutex.Lock()
		defer l.procMutex.Unlock()

		done, newRows, intersects, err := l.psi.IntersectParts()
		if err != nil {
			go handleError(err)
			return nil, err
		}

		if done && l.status == learnerStatusStartPSI {
			logger.Infof("audit-task[%s] used features: %v", l.id, append(newRows[0], l.trainParams.IdName))
			logger.Infof("audit-task[%s] PSI intersects: %v", l.id, intersects)

			l.fileRows = newRows
			l.status = learnerStatusEndPSI
			go func() {
				m := &pbDtcVl.Message{
					Type: pbDtcVl.MessageType_MsgTrainHup,
				}
				l.advance(m)
			}()
		}

	case pbDtcVl.MessageType_MsgTrainHup: // local message
		l.procMutex.Lock()
		defer l.procMutex.Unlock()

		if l.status == learnerStatusEndPSI {
			l.status = learnerStatusStartTrain
			isRootLeaf, idList, err := l.process.init(l.fileRows)
			if err != nil {
				go handleError(err)
				return nil, err
			}

			if l.process.params.IsTagPart {
				// check if root is leaf, if so, stop training immediately
				if isRootLeaf {
					go func() {
						m := &pbDtcVl.Message{
							Type: pbDtcVl.MessageType_MsgFinishTrain,
						}
						l.advance(m)
					}()
				} else {
					m := &pbDtcVl.Message{
						Type:   pbDtcVl.MessageType_MsgCheckReadyStatus,
						IdList: idList,
					}
					go l.advance(m)
				}
			} else {
				m := &pbDtcVl.Message{
					Type:   pbDtcVl.MessageType_MsgSetReadyStatus,
					IdList: idList,
				}
				if _, err := l.sendMessageWithRetry(m, l.parties[0]); err != nil {
					go handleError(err)
					return nil, err
				}
			}
		}

	case pbDtcVl.MessageType_MsgSetReadyStatus:
		l.process.setOtherPartyReady()
		ret = &pb.TrainResponse{
			TaskID: l.id,
		}
		m := &pbDtcVl.Message{
			Type:   pbDtcVl.MessageType_MsgCheckReadyStatus,
			IdList: message.IdList,
		}
		go l.advance(m)

	case pbDtcVl.MessageType_MsgCheckReadyStatus: // local message
		if l.process.isReadyToTrain() {
			m := &pbDtcVl.Message{
				Type:      pbDtcVl.MessageType_MsgTrainLoop,
				NodeDepth: 0, // start with root node
				NodeIndex: 0,
				IdList:    message.IdList,
			}
			go l.advance(m)
		}

	case pbDtcVl.MessageType_MsgTrainLoop: // local message
		m := &pbDtcVl.Message{
			Type:      pbDtcVl.MessageType_MsgPrepFeatSelect,
			NodeDepth: message.NodeDepth,
			NodeIndex: message.NodeIndex,
			IdList:    message.IdList,
		}
		go l.advance(m)
		if _, err := l.sendMessageWithRetry(m, l.parties[0]); err != nil {
			go handleError(err)
			return nil, err
		}

	case pbDtcVl.MessageType_MsgPrepFeatSelect:
		sampleIDs, err := l.process.prepareForFeatureSelect(message.NodeDepth, message.NodeIndex, message.IdList)
		if err != nil {
			go handleError(err)
			return nil, err
		}
		ret = &pb.TrainResponse{
			TaskID: l.id,
		}

		if !l.process.params.IsTagPart {
			m := &pbDtcVl.Message{
				Type:           pbDtcVl.MessageType_MsgSampleIDs,
				NodeDepth:      message.NodeDepth,
				NodeIndex:      message.NodeIndex,
				SplitSampleIDs: sampleIDs,
			}
			go l.advance(m)
		} else {
			m := &pbDtcVl.Message{
				Type:      pbDtcVl.MessageType_MsgCheckSelectStatus,
				NodeDepth: message.NodeDepth,
				NodeIndex: message.NodeIndex,
			}
			go l.advance(m)
		}

	case pbDtcVl.MessageType_MsgSampleIDs: // local message
		m := &pbDtcVl.Message{
			Type:           pbDtcVl.MessageType_MsgSetSampleIDs,
			NodeDepth:      message.NodeDepth,
			NodeIndex:      message.NodeIndex,
			SplitSampleIDs: message.SplitSampleIDs,
		}
		if _, err := l.sendMessageWithRetry(m, l.parties[0]); err != nil {
			go handleError(err)
			return nil, err
		}

	case pbDtcVl.MessageType_MsgSetSampleIDs:
		l.process.setSampleIDs(message.NodeDepth, message.NodeIndex, message.SplitSampleIDs)
		ret = &pb.TrainResponse{
			TaskID: l.id,
		}
		m := &pbDtcVl.Message{
			Type:      pbDtcVl.MessageType_MsgCheckSelectStatus,
			NodeDepth: message.NodeDepth,
			NodeIndex: message.NodeIndex,
		}
		go l.advance(m)

	case pbDtcVl.MessageType_MsgCheckSelectStatus: // local message
		if l.process.isReadyToSelectFeature(message.NodeDepth, message.NodeIndex) {
			m := &pbDtcVl.Message{
				Type:      pbDtcVl.MessageType_MsgSelectFeature,
				NodeDepth: message.NodeDepth,
				NodeIndex: message.NodeIndex,
			}
			go l.advance(m)
		}

	case pbDtcVl.MessageType_MsgSelectFeature: // local message
		isTagPart, loc, isLeftLeaf, isRightLeaf, leftIDs, rightIDs := l.process.selectFeature(message.NodeDepth, message.NodeIndex)

		m := &pbDtcVl.Message{
			Type:            pbDtcVl.MessageType_MsgNoticeSaveNode,
			NodeDepth:       message.NodeDepth,
			NodeIndex:       message.NodeIndex,
			Location:        loc,
			NodeFromTagPart: isTagPart,
		}
		go l.advance(m)

		// handle left and right leaf, if not leaf, continue feature selection
		if !isLeftLeaf {
			go func() {
				m := &pbDtcVl.Message{
					Type:      pbDtcVl.MessageType_MsgTrainLoop,
					NodeDepth: message.NodeDepth + 1,
					NodeIndex: message.NodeIndex * 2,
					IdList:    leftIDs,
				}
				l.advance(m)
			}()
		}
		if !isRightLeaf {
			go func() {
				m := &pbDtcVl.Message{
					Type:      pbDtcVl.MessageType_MsgTrainLoop,
					NodeDepth: message.NodeDepth + 1,
					NodeIndex: message.NodeIndex*2 + 1,
					IdList:    rightIDs,
				}
				l.advance(m)
			}()
		}

	case pbDtcVl.MessageType_MsgNoticeSaveNode: // local message
		m := &pbDtcVl.Message{
			Type:            pbDtcVl.MessageType_MsgSaveNode,
			NodeDepth:       message.NodeDepth,
			NodeIndex:       message.NodeIndex,
			Location:        message.Location,
			NodeFromTagPart: message.NodeFromTagPart,
		}
		l.advance(m)
		if _, err := l.sendMessageWithRetry(m, l.parties[0]); err != nil {
			go handleError(err)
			return nil, err
		}

	case pbDtcVl.MessageType_MsgSaveNode:
		s, _ := proto.Marshal(message)
		logger.Debugf("learner[%s] MessageType_MsgSaveNode[%s]", l.id, s)
		ifNewNode := l.process.saveNode(message.NodeDepth, message.NodeIndex, message.Location, message.NodeFromTagPart)
		ret = &pb.TrainResponse{
			TaskID: l.id,
		}

		go func() {
			if ifNewNode {
				m := &pbDtcVl.Message{
					Type:            pbDtcVl.MessageType_MsgNoticeUpdateNodeNum,
					NodeDepth:       message.NodeDepth,
					NodeIndex:       message.NodeIndex,
					NodeFromTagPart: message.NodeFromTagPart,
				}
				l.advance(m)
			}
		}()

	case pbDtcVl.MessageType_MsgNoticeUpdateNodeNum: // local message
		m := &pbDtcVl.Message{
			Type:      pbDtcVl.MessageType_MsgUpdateNodeNum,
			NodeDepth: message.NodeDepth,
			NodeIndex: message.NodeIndex,
		}
		if !message.NodeFromTagPart {
			if _, err := l.sendMessageWithRetry(m, l.parties[0]); err != nil {
				go handleError(err)
				return nil, err
			}
		} else {
			l.advance(m)
		}

	case pbDtcVl.MessageType_MsgUpdateNodeNum:
		firstTime := l.process.updateNodeNum(message.NodeDepth, message.NodeIndex)
		ret = &pb.TrainResponse{
			TaskID: l.id,
		}

		go func() {
			if firstTime {
				m := &pbDtcVl.Message{
					Type:      pbDtcVl.MessageType_MsgTrainStatus,
					NodeDepth: message.NodeDepth,
					NodeIndex: message.NodeIndex,
				}
				l.advance(m)
			}
		}()

	case pbDtcVl.MessageType_MsgTrainStatus: // local message
		if l.process.ifStop() {
			if l.process.params.RegParam != 0 {
				nodeKeys := l.process.prune()
				if len(nodeKeys) != 0 {
					m := &pbDtcVl.Message{
						Type:      pbDtcVl.MessageType_MsgDeleteNodes,
						NodeDepth: message.NodeDepth,
						NodeIndex: message.NodeIndex,
						NodeKeys:  nodeKeys,
					}
					if _, err := l.sendMessageWithRetry(m, l.parties[0]); err != nil {
						go handleError(err)
						return nil, err
					}
				}
			}
			go func() {
				m := &pbDtcVl.Message{
					Type: pbDtcVl.MessageType_MsgFinishTrain,
				}
				l.advance(m)
			}()
		}

	case pbDtcVl.MessageType_MsgDeleteNodes:
		l.process.deleteNodes(message.NodeKeys)
		ret = &pb.TrainResponse{
			TaskID: l.id,
		}

	case pbDtcVl.MessageType_MsgFinishTrain: // local message
		m := &pbDtcVl.Message{
			Type: pbDtcVl.MessageType_MsgNoticeTrainModel,
		}
		go l.advance(m)
		if _, err := l.sendMessageWithRetry(m, l.parties[0]); err != nil {
			go handleError(err)
			return nil, err
		}

	case pbDtcVl.MessageType_MsgNoticeTrainModel:
		m := &pbDtcVl.Message{
			Type: pbDtcVl.MessageType_MsgTrainModel,
		}
		go l.advance(m)
		ret = &pb.TrainResponse{
			TaskID: l.id,
		}

	case pbDtcVl.MessageType_MsgTrainModel: // local message
		l.procMutex.Lock()
		defer l.procMutex.Unlock()

		if l.status == learnerStatusStartTrain {
			l.status = learnerStatusEndTrain
			r, err := l.process.getTrainResult()
			if err != nil {
				go handleError(err)
				return nil, err
			}
			logger.Infof("learner[%s] trained out model successfully [%s]", l.id, r)
			// add audit log
			logger.Infof("audit-task[%s] task stopped", l.id)
			logger.Infof("audit-task[%s] trained model: %s", l.id, r)

			res := &pbCom.TrainTaskResult{
				TaskID:   l.id,
				Success:  true,
				Model:    r,
				TrainSet: l.getTrainSet(),
			}
			l.rh.SaveResult(res)

			// save task result evidence
			go func() {
				evidence.SaveDtcTrainEvidence(l.id, r)
			}()
		}
	}

	logger.WithFields(logrus.Fields{
		"address": l.address,
	}).Infof("learner[%s] finished advance . message %s", l.id, message.Type.String())
	return ret, nil
}

// sendMessageWithRetry sends message to remote mpc-node
// retries 2 times at most
func (l *Learner) sendMessageWithRetry(message *pbDtcVl.Message, address string) (*pbDtcVl.Message, error) {
	times := 3

	var m *pbDtcVl.Message
	var err error
	for i := 0; i < times; i++ {
		if i > 0 {
			time.Sleep(3 * time.Second)
		}
		m, err = l.sendMessage(message, address)
		if err == nil {
			break
		}
	}

	return m, err
}

// sendMessage sends message to remote mpc-node
func (l *Learner) sendMessage(message *pbDtcVl.Message, address string) (*pbDtcVl.Message, error) {
	message.From = l.address
	message.To = address

	payload, err := proto.Marshal(message)
	if err != nil {
		return nil, errorx.New(errcodes.ErrCodeInternal, "failed to Marshal payload: %s", err.Error())
	}

	trainReq := &pb.TrainRequest{
		TaskID:  l.id,
		Algo:    l.algo,
		Payload: payload,
	}
	resp, err := l.rpc.StepTrain(trainReq, address)
	if err != nil {
		return nil, err
	}

	m := &pbDtcVl.Message{}
	if len(resp.Payload) != 0 {
		err := proto.Unmarshal(resp.Payload, m)
		if err != nil {
			return nil, errorx.New(errcodes.ErrCodeInternal, "failed to Unmarshal payload[%s] from[%s] and err is[%s] ", string(resp.Payload), address, err.Error())
		}
	}
	return m, nil
}

// NewLearner returns a VerticalClassDecisionTree Learner
// id is the assigned id for Learner
// address indicates local mpc-node
// parties are other learners who participates in MPC, assigned with mpc-node address usually
// rpc is used to request remote mpc-node
// rh handles final result which is successful or failed
// params are parameters for training model
// featEngs are feature engineering options for samples file
// samplesFile contains samples for training model
func NewLearner(id string, address string, params *pbCom.TrainParams, featEngs []*pbCom.FeatureEngineering,
	samplesFile []byte, parties []string, rpc RpcHandler, rh ResultHandler) (*Learner, error) {

	// handle feature engineering to get new sample file
	newSamplesFile, err := feat_eng.ProcessFeatEngs(samplesFile, featEngs)
	if err != nil {
		return nil, err
	}

	p, err := psi.NewVLTwoPartsPSI(address, newSamplesFile, params.GetIdName(), parties)
	if err != nil {
		return nil, err
	}

	l := &Learner{
		id:          id,
		algo:        pbCom.Algorithm_DECISION_TREE_CLASS_VL,
		address:     address,
		parties:     parties,
		psi:         p,
		trainParams: params,
		process:     newProcess(params),

		samplesFile: newSamplesFile,
		rpc:         rpc,
		rh:          rh,
		status:      learnerStatusStartPSI,
	}

	// start training
	go func() {
		m := &pbDtcVl.Message{
			Type: pbDtcVl.MessageType_MsgPsiEnc,
		}
		l.advance(m)
	}()
	return l, nil
}
