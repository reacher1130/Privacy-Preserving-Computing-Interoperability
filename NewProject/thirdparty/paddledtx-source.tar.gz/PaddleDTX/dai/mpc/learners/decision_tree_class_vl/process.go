// Copyright (c) 2021 PaddlePaddle Authors. All Rights Reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package decision_tree_class_vl

import (
	"encoding/hex"
	"encoding/json"
	"fmt"
	"sort"
	"sync"

	"github.com/PaddlePaddle/PaddleDTX/crypto/core/hash"
	mlCom "github.com/PaddlePaddle/PaddleDTX/crypto/core/machine_learning/common"
	dtc_vl "github.com/PaddlePaddle/PaddleDTX/crypto/core/machine_learning/decision_tree/classification/mpc_vertical"
	"github.com/PaddlePaddle/PaddleDTX/xdb/errorx"

	vl_common "github.com/PaddlePaddle/PaddleDTX/dai/crypto/vl/common"
	"github.com/PaddlePaddle/PaddleDTX/dai/crypto/vl/dtc"
	"github.com/PaddlePaddle/PaddleDTX/dai/errcodes"
	pbCom "github.com/PaddlePaddle/PaddleDTX/dai/protos/common"
	pbDtcVl "github.com/PaddlePaddle/PaddleDTX/dai/protos/mpc/learners/decision_tree_class_vl"
)

type process struct {
	params   *pbCom.TrainParams
	fileRows [][]string
	dataSet  *mlCom.DTDataSet

	// if self party is already finished init and ready to train
	selfReady bool
	// if the other part is already finished init and ready to train
	otherPartyReady bool

	// nodeKey -> {feature names, split values, leftNode sampleIDs, rightNode sampleIDs}
	// used for feature selection
	prepMaterial map[string]*dtc.MaterialForFeatureSelect

	// the other party left and right sample ID list
	otherPartySampleIDs map[string][]*pbDtcVl.SplitSampleIDs

	// record if a node is already started feature selection, if so, map value must not be zero
	readyForFeatureSelect map[string]int
	// record if training already stopped, if so, value of trainStop must not be zero
	trainStop int

	// number of tree nodes that are leaf, updated by tag part, used to determine if training should be stopped
	leafNum uint64
	// number of tree nodes that are not leaf, updated by tag part, used to determine if training should be stopped
	nonLeafNum uint64

	// model used to save tree nodes, nodeKey -> node
	model map[string]*dtc_vl.CTreeNode

	mutex sync.Mutex
}

// init initialize Process, after PSI, before training
func (p *process) init(fileRows [][]string) (bool, []uint64, error) {
	// fileRows
	p.fileRows = fileRows

	// read dataset from file rows
	trainDataSet, err := dtc.GetTrainDataSetFromFile(p.fileRows)
	if err != nil {
		return false, nil, errorx.New(errcodes.ErrCodeInternal, "mistake[%s] happened when decision_tree_class_vl GetTrainDataSetFromFile", err.Error())
	}
	p.dataSet = trainDataSet

	// init model
	p.model = make(map[string]*dtc_vl.CTreeNode)

	// init prepMaterial
	p.prepMaterial = make(map[string]*dtc.MaterialForFeatureSelect)

	p.otherPartySampleIDs = make(map[string][]*pbDtcVl.SplitSampleIDs)
	p.readyForFeatureSelect = make(map[string]int)
	p.trainStop = 0

	// get all dataset ids
	var allIds []uint64
	for i := 0; i < len(trainDataSet.Features[0].Sets); i++ {
		allIds = append(allIds, uint64(i))
	}

	// handle root node by tag part, check if root is leaf
	// if so, stop training immediately
	isRootLeaf := false
	if p.params.IsTagPart {
		rootGini := dtc.CalGini(p.dataSet, allIds, nil, p.params.Label)
		stopCond := dtc_vl.StopCondition{
			SampleThreshold: int(p.params.StopCond.SampleThreshold),
			DepthThreshold:  int(p.params.StopCond.DepthThreshold),
			GiniThreshold:   p.params.StopCond.GiniThreshold,
		}

		rootNode := &dtc_vl.CTreeNode{
			SampleIDList: vl_common.UintsToInts(allIds),
			Depth:        0,
			Index:        0,
			Gini:         rootGini,
		}
		nodeKey := dtc.GetTreeNodeKey(0, 0)
		p.model[nodeKey] = rootNode
		if v, result := dtc.DecideTerminate(p.dataSet, allIds, nil, rootGini, 0, 0, p.params.Label, stopCond); v {
			isRootLeaf = true
			p.model[nodeKey].Result = result
		}
	}
	p.selfReady = true

	return isRootLeaf, allIds, nil
}

// setOtherPartyReady set ready status for the other party
// operated by tag party
func (p *process) setOtherPartyReady() {
	p.otherPartyReady = true
}

// isReadyToTrain check if both parties are ready to train
// operated by tag party
func (p *process) isReadyToTrain() bool {
	return p.otherPartyReady && p.selfReady
}

// prepareForFeatureSelect calculate material of a specific node for feature selection
func (p *process) prepareForFeatureSelect(depth, index uint64, idList []uint64) ([]*pbDtcVl.SplitSampleIDs, error) {
	p.mutex.Lock()
	defer p.mutex.Unlock()

	material, err := dtc.PrepForFeatureSelect(p.dataSet, idList, *p.params)
	if err != nil {
		return nil, errorx.New(errcodes.ErrCodeInternal, "mistake[%s] happened when decision_tree_class_vl prepareForFeatureSelect", err.Error())
	}

	// save material to material map
	key := dtc.GetTreeNodeKey(depth, index)
	p.prepMaterial[key] = material

	ids := make([]*pbDtcVl.SplitSampleIDs, len(material.LeftSampleIDs))
	// for non-tag part, return left and right node sample list, which need to be transferred to tag part
	// for Gini calculation and feature selection
	// to protect the data confidentiality, id list order is better to be messed up
	if !p.params.IsTagPart {
		// use dataset as a random noise to avoid list order induction
		randListMap := randIndex(p.dataSet, depth, index, len(material.LeftSampleIDs))
		for i := 0; i < len(material.LeftSampleIDs); i++ {
			samples := &pbDtcVl.SplitSampleIDs{
				LeftIDs:  vl_common.IntsToUints(material.LeftSampleIDs[i]),
				RightIDs: vl_common.IntsToUints(material.RightSampleIDs[i]),
			}
			ids[randListMap[i]] = samples
		}
	}

	return ids, nil
}

// setSampleIDs set left and right split sample IDs of other party
// operated by tag party
func (p *process) setSampleIDs(depth, index uint64, sampleIDs []*pbDtcVl.SplitSampleIDs) {
	p.mutex.Lock()
	defer p.mutex.Unlock()

	nodeKey := dtc.GetTreeNodeKey(depth, index)
	p.otherPartySampleIDs[nodeKey] = sampleIDs
}

// isReadyToSelectFeature check if ready for feature selection, that is, if both parties finished preparation
// operated by tag party
func (p *process) isReadyToSelectFeature(depth, index uint64) bool {
	p.mutex.Lock()
	defer p.mutex.Unlock()

	nodeKey := dtc.GetTreeNodeKey(depth, index)

	if p.readyForFeatureSelect[nodeKey] != 0 {
		logger.Warnf("already started feature selection for depth: %d, index: %d", depth, index)
		return false
	}

	if len(p.otherPartySampleIDs[nodeKey]) != 0 && p.prepMaterial[nodeKey] != nil {
		p.readyForFeatureSelect[nodeKey] += 1
		return true
	}
	return false
}

// selectFeature calculated by tag part
// calculate minimum gini of non-tag part, and minimum gini of tag part
// choose the smaller gini, and then choose the corresponding feature & split value
// return if feature is from tag part, index of feature in list, if left node is leaf, if right node is leaf, left node sample IDs, right node sample IDs
func (p *process) selectFeature(depth, index uint64) (bool, uint64, bool, bool, []uint64, []uint64) {
	p.mutex.Lock()
	defer p.mutex.Unlock()

	nodeKey := dtc.GetTreeNodeKey(depth, index)
	// get other party's split sample IDs
	otherSampleIDs := p.otherPartySampleIDs[nodeKey]

	isFromTagPart := false
	finalIdx := 0

	var finalLeftIDs, finalRightIDs []uint64

	// find minimum Gini of non-tag part
	var minGiniNonTag float64 = 1
	minGiniIdxNonTag := 0
	for i := 0; i < len(otherSampleIDs); i++ {
		giniA := dtc.CalGini(p.dataSet, otherSampleIDs[i].LeftIDs, otherSampleIDs[i].RightIDs, p.params.Label)
		if giniA < minGiniNonTag {
			minGiniNonTag = giniA
			minGiniIdxNonTag = i
		}
	}

	// find minimum Gini of tag part
	var minGiniTag float64 = 1
	minGiniIdxTag := 0

	for i := 0; i < len(p.prepMaterial[nodeKey].LeftSampleIDs); i++ {
		giniB := dtc.CalGini(p.dataSet, vl_common.IntsToUints(p.prepMaterial[nodeKey].LeftSampleIDs[i]),
			vl_common.IntsToUints(p.prepMaterial[nodeKey].RightSampleIDs[i]), p.params.Label)
		if giniB < minGiniTag {
			minGiniTag = giniB
			minGiniIdxTag = i
		}
	}

	// find minimum Gini of both parts
	if minGiniNonTag < minGiniTag {
		finalIdx = minGiniIdxNonTag
		finalLeftIDs = otherSampleIDs[finalIdx].LeftIDs
		finalRightIDs = otherSampleIDs[finalIdx].RightIDs
	} else {
		isFromTagPart = true
		finalIdx = minGiniIdxTag
		finalLeftIDs = vl_common.IntsToUints(p.prepMaterial[nodeKey].LeftSampleIDs[finalIdx])
		finalRightIDs = vl_common.IntsToUints(p.prepMaterial[nodeKey].RightSampleIDs[finalIdx])
	}

	// check child nodes
	// if child node is not a leaf, feature selection is required
	// if child node is a leaf, record the final result and stopped the branch
	giniLeft := dtc.CalGini(p.dataSet, finalLeftIDs, nil, p.params.Label)
	giniRight := dtc.CalGini(p.dataSet, finalRightIDs, nil, p.params.Label)
	fatherSampleIDList := vl_common.IntsToUints(p.model[nodeKey].SampleIDList)
	stopCond := dtc_vl.StopCondition{
		SampleThreshold: int(p.params.StopCond.SampleThreshold),
		DepthThreshold:  int(p.params.StopCond.DepthThreshold),
		GiniThreshold:   p.params.StopCond.GiniThreshold,
	}

	nodeL := &dtc_vl.CTreeNode{
		SampleIDList: vl_common.UintsToInts(finalLeftIDs),
		Depth:        int(depth) + 1,
		Index:        int(index) * 2,
		Gini:         giniLeft,
	}
	nodeKeyL := dtc.GetTreeNodeKey(uint64(nodeL.Depth), uint64(nodeL.Index))
	p.model[nodeKeyL] = nodeL
	// check if left child node is leaf, if so, save final result of the leaf
	if v, resultL := dtc.DecideTerminate(p.dataSet, finalLeftIDs, fatherSampleIDList, nodeL.Gini, p.model[nodeKey].Gini,
		nodeL.Depth, p.params.Label, stopCond); v {
		p.model[nodeKeyL].Result = resultL
	}

	nodeR := &dtc_vl.CTreeNode{
		SampleIDList: vl_common.UintsToInts(finalRightIDs),
		Depth:        int(depth) + 1,
		Index:        int(index)*2 + 1,
		Gini:         giniRight,
	}
	nodeKeyR := dtc.GetTreeNodeKey(uint64(nodeR.Depth), uint64(nodeR.Index))
	p.model[nodeKeyR] = nodeR
	// check if right child node is leaf, if so, save final result of the leaf
	if v, resultR := dtc.DecideTerminate(p.dataSet, finalRightIDs, fatherSampleIDList, nodeR.Gini, p.model[nodeKey].Gini,
		nodeR.Depth, p.params.Label, stopCond); v {
		p.model[nodeKeyR].Result = resultR
	}

	// clean other party's material after feature selection
	delete(p.otherPartySampleIDs, nodeKey)

	return isFromTagPart, uint64(finalIdx), len(nodeL.Result) != 0, len(nodeR.Result) != 0, finalLeftIDs, finalRightIDs
}

// saveNode save tree node of specific depth and index
// find feature name, split value, left node samples and right node samples by location in material
// for tag part, node already exists, save feature and split value
// for non-tag part, create a node, save node depth, node index, feature and split value
//func (p *process) saveNode(depth, index uint64, loc uint64) bool {
func (p *process) saveNode(depth, index uint64, loc uint64, isTagPart bool) bool {
	p.mutex.Lock()
	defer p.mutex.Unlock()

	nodeKey := dtc.GetTreeNodeKey(depth, index)

	// if node to be saved is not from self part, delete prepared material by key
	if p.params.IsTagPart != isTagPart {
		delete(p.prepMaterial, nodeKey)
		return false
	}

	// check if node already been saved
	if p.model[nodeKey] != nil && p.model[nodeKey].SplitValue != nil {
		logger.Warnf("node already saved with node id: %s", nodeKey)
		return false
	}
	// check if training already stopped
	if p.trainStop != 0 {
		logger.Warnf("train already stopped, no need to save node")
		return false
	}

	material := p.prepMaterial[nodeKey]

	// for non-tag part, location has been mixed up for privacy
	// retrieve original location in material list
	if !p.params.IsTagPart {
		loc = uint64(retrieveOriginIdx(p.dataSet, depth, index, len(material.LeftSampleIDs), int(loc)))
	}
	featureName := material.FeatureNames[loc]
	splitValue := material.SplitValues[loc]
	continuous := false
	if _, v := splitValue.(float64); v {
		continuous = true
	}

	if p.model[nodeKey] == nil {
		p.model[nodeKey] = &dtc_vl.CTreeNode{
			Depth:       int(depth),
			Index:       int(index),
			FeatureName: featureName,
			SplitValue:  splitValue,
			Continuous:  continuous,
		}
	} else {
		p.model[nodeKey].FeatureName = featureName
		p.model[nodeKey].SplitValue = splitValue
		p.model[nodeKey].Continuous = continuous
	}

	// clean material after saving node
	delete(p.prepMaterial, nodeKey)

	return true
}

// updateNodeNum update tree leaf number and non-leaf number, used to determine whether to finish the train
// operated by tag part
func (p *process) updateNodeNum(depth, index uint64) bool {
	p.mutex.Lock()
	defer p.mutex.Unlock()

	// check if training already stopped
	if p.trainStop != 0 {
		logger.Warnf("train already stopped, no need to update node number")
		return false
	}

	p.nonLeafNum += 1

	leftNodeKey := dtc.GetTreeNodeKey(depth+1, index*2)
	rightNodeKey := dtc.GetTreeNodeKey(depth+1, index*2+1)
	if len(p.model[leftNodeKey].Result) != 0 {
		p.leafNum += 1
	}
	if len(p.model[rightNodeKey].Result) != 0 {
		p.leafNum += 1
	}

	return true
}

// ifStop check if training should be stopped
// operated by tag part
func (p *process) ifStop() bool {
	p.mutex.Lock()
	defer p.mutex.Unlock()

	// check if training already stopped
	if p.trainStop != 0 {
		logger.Warnf("train already stopped, no need to check status")
		return false
	}

	if dtc.IfStopTraining(p.leafNum, p.nonLeafNum) {
		p.trainStop += 1
		return true
	}
	return false
}

// prune find target nodes and check if they need to be deleted
// operated by tag part, return node key list that should be deleted by non-tag part
func (p *process) prune() []string {
	p.mutex.Lock()
	defer p.mutex.Unlock()

	var delNodeForNonTagPart []string
	for {
		pruned := false

		for id, node := range p.model {
			// leaf node is not target node to prune, skip it
			if len(node.Result) != 0 {
				continue
			}

			leftNodeID := dtc.GetTreeNodeKey(uint64(node.Depth+1), uint64(node.Index*2))
			rightNodeID := dtc.GetTreeNodeKey(uint64(node.Depth+1), uint64(node.Index*2+1))

			// if either child node is not in tag part's model, or is not a leaf, the node is a target node to prune
			if leftNode, v := p.model[leftNodeID]; !v || len(leftNode.Result) == 0 {
				continue
			}
			if rightNode, v := p.model[rightNodeID]; !v || len(rightNode.Result) == 0 {
				continue
			}

			// check if the target node should be deleted
			// if so, delete child nodes and switch the node to leaf
			if dtc.IfPruneNode(p.dataSet, p.model, p.params.Label, node.Depth, node.Index, p.params.RegParam) {
				pruned = true

				delete(p.model, leftNodeID)
				delete(p.model, rightNodeID)

				// record nodes needed to be deleted by non-tag part
				delNodeForNonTagPart = append(delNodeForNonTagPart, id)

				t := dtc.GetMaxLabelType(p.dataSet, node.SampleIDList, p.params.Label)
				p.model[id].FeatureName = ""
				p.model[id].SplitValue = nil
				p.model[id].Result = t
			}
		}
		if !pruned {
			break
		}
	}
	return delNodeForNonTagPart
}

// deleteNodes delete tree nodes by node key
// operated by non-tag part
func (p *process) deleteNodes(keys []string) {
	p.mutex.Lock()
	defer p.mutex.Unlock()

	for _, key := range keys {
		delete(p.model, key)
	}
}

// getTrainResult marshal model to bytes
func (p *process) getTrainResult() ([]byte, error) {
	m, err := dtc.TrainModelsToBytes(p.model)
	if err != nil {
		return nil, err
	}
	res := pbCom.TrainResult{
		Model:     m,
		Label:     p.params.Label,
		IsTagPart: p.params.IsTagPart,
	}
	return json.Marshal(res)
}

// randIndex get a map from old index in a list to new index
// operated by non-tag part
func randIndex(dataset *mlCom.DTDataSet, nodeDepth, nodeIndex uint64, listLen int) map[int]int {
	rand, _ := json.Marshal(dataset)
	s := make([]string, listLen)
	idxStrMap := make(map[int]string)
	newMap := make(map[string]int)
	ret := make(map[int]int)

	for i := 0; i < listLen; i++ {
		msg := []byte(fmt.Sprintf("%d-%d-%d", nodeDepth, nodeIndex, i))
		h := hash.HashUsingSha256(append(rand, msg...))
		s[i] = hex.EncodeToString(h)
		// map old index to string
		idxStrMap[i] = s[i]
	}

	// sort string list, and construct a map from string to new idx
	sort.Strings(s)
	for i := 0; i < listLen; i++ {
		newMap[s[i]] = i
	}

	// from old idx to new idx
	for k, v := range idxStrMap {
		ret[k] = newMap[v]
	}
	return ret
}

// retrieveOriginIdx find original index in the list given converted index
// operated by non-tag part
func retrieveOriginIdx(dataset *mlCom.DTDataSet, nodeDepth, nodeIndex uint64, listLen, newIdx int) int {
	randList := randIndex(dataset, nodeDepth, nodeIndex, listLen)
	originIdx := 0
	for k, v := range randList {
		if v == newIdx {
			originIdx = k
		}
	}
	return originIdx
}

func newProcess(params *pbCom.TrainParams) *process {
	return &process{
		params: params,
	}
}
