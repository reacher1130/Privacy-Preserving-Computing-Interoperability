package psi

import (
	"fmt"
	"github.com/PaddlePaddle/PaddleDTX/dai/errcodes"
	pbCom "github.com/PaddlePaddle/PaddleDTX/dai/protos/common"
	pb "github.com/PaddlePaddle/PaddleDTX/dai/protos/mpc"
	"github.com/PaddlePaddle/PaddleDTX/xdb/errorx"
	"sync"
)

//	type PSI_TASK interface {
//	   NewPsiTask() ([]byte, error)
//	}
type PsiResponse struct {
	Resp *pb.PsiResponse
	Err  error
}

/*算法*/
type PsiAdvance interface {
	Advance(payload []byte) (*pb.PsiResponse, error)
}

type Callback interface {
	StartTask(*pbCom.StartTaskRequest) error

	StopTask(*pbCom.StopTaskRequest) error

	//Psi(*pb.PsiRequest) (*pb.PsiResponse, error)
	CompletePsiTask(*pbCom.PsiTaskResult) error
}

type Psi struct {
	psiLimit   int
	psiTasks   map[string]PsiAdvance
	psiResults sync.Map
	rpcHandler RpcHandler
	callback   Callback
	address    string
}

func (p *Psi) DeletePsiTask(request *pbCom.StopTaskRequest) error {
	logger.WithField("taskId", request.TaskID).Infof("psi task %v ,is stop!!!!!!! \n rspParam is ", request.TaskID, request.Params)
	delete(p.psiTasks, request.TaskID)
	return nil
}

func (p *Psi) Psi(req *pb.PsiRequest, resC chan *PsiResponse) {
	setResult := func(resp *pb.PsiResponse, err error) {
		res := &PsiResponse{Resp: resp, Err: err}
		resC <- res
		close(resC)
	}

	taskId := req.TaskID
	mesg := req.GetPayload()
	if psiTask, ok := p.taskExists(taskId); ok {
		go func() {
			resp, err := psiTask.Advance(mesg)
			setResult(resp, err)
		}()
	} else {
		err := errorx.New(errcodes.ErrCodeParam, "task[%s] not exists ", taskId)
		setResult(nil, err)
	}
}

func (p *Psi) NewPsiTask(req *pbCom.StartTaskRequest) error {
	if p.psiLimit <= len(p.psiTasks) {
		err := errorx.New(errcodes.ErrCodeTooMuchTasks, "the number of tasks reached upper-limit %d", p.psiLimit)
		return err
	}
	taskId := req.TaskID
	if _, ok := p.taskExists(taskId); ok {
		err := errorx.New(errcodes.ErrCodeTaskExists, "task[%s] already exists ", taskId)
		return err
	}

	algo := req.GetParams().GetAlgo()
	params := req.GetParams().GetPsiParams()
	featEngs := req.GetFeatureEngs()
	file := req.GetFile()
	hosts := req.GetHosts()
	//paddleParams := req.GetPaddleFLParams()
	//callback := p.callback
	var psiAdvance PsiAdvance
	var errL error

	if len(file) > 0 {
		psiAdvance, errL = SwichPsiAdvance(taskId, p.address, algo, params, featEngs, file, hosts, p.rpcHandler, p)
	} else {
		errL = fmt.Errorf("psi file is nil")
	}
	if errL != nil {
		return errL
	}

	p.psiTasks[taskId] = psiAdvance
	//p.newEvaluator(req)
	logger.WithField("taskId", taskId).Infof("task stored")

	return nil
}

func (p *Psi) taskExists(taskId string) (PsiAdvance, bool) {
	if l, ok := p.psiTasks[taskId]; ok {
		return l, ok
	} else {
		return nil, false
	}
}

func NewPsi(address string, rh RpcHandler, cb Callback, psiLimit int) *Psi {
	return &Psi{
		address:    address,
		psiLimit:   psiLimit,
		psiTasks:   make(map[string]PsiAdvance, psiLimit),
		callback:   cb,
		rpcHandler: rh,
	}
}

// psiAdvance, errL = SwichPsiAdvance(taskId, p.address, algo, params, featEngs, file, hosts, paddleParams, p.rpcHandler, p)
func SwichPsiAdvance(taskId string, address string, algo pbCom.Algorithm, params *pbCom.PsiParams, featureEngs []*pbCom.FeatureEngineering,
	samplesFile []byte, parties []string, rpc RpcHandler, rh ResultHandler) (PsiAdvance, error) {
	switch params.PsiAlgorithmType {
	case pbCom.PsiAlgorithmType_ECDH_PSI:
		return NewPsiEcdha(taskId, address, algo, params, featureEngs, samplesFile, parties, rpc, rh)
		//todo 补充psi算法
	default:
		return nil, fmt.Errorf("psi algorithm[%s] not supported", params.PsiAlgorithmType)
	}
}

func (p *Psi) SaveResult(result *pbCom.PsiTaskResult) {
	logger.Infof("进入了 psi SaveResult 方法。。。。")
	//stopTask := func() {
	//	logger.WithField("taskId", result.TaskID).Infof("Stop psi task.  and psi result[%t]",
	//		result.Success)
	//
	//	req := &pbCom.StopTaskRequest{
	//		TaskID: result.TaskID,
	//		Params: &pbCom.TaskParams{
	//			TaskType: pbCom.TaskType_PSI,
	//		},
	//	}
	//	p.callback.StopTask(req)
	//}
	logger.Infof("准备调用CompletePsiTask。。。。")
	if err := p.callback.CompletePsiTask(result); err != nil {
		logger.WithField("taskId", result.TaskID).Errorf("failed to CompletePsiTask, and error is[%s]",
			result.Success, err.Error())
	}

	// For training task from user, the result has been saved, stop the task.
	//stopTask()
}
