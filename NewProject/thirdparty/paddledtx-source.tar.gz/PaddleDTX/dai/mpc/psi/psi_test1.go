package psi

import (
	"bytes"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/sha256"
	"encoding/csv"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/PaddlePaddle/PaddleDTX/crypto/client/service/xchain"
	"io/ioutil"
	"math/big"
	"os"
	"sort"
	"sync"
	"testing"
)

func TestVLPsi(t *testing.T) {
	path, _ := os.Getwd()

	vp1Address := "address1"
	vp2Address := "address2"

	vp1SamplesFile := readData(path + "/testdata/dataA.csv")
	vp1SamplesParties := []string{vp2Address}
	vp1, err := NewPSIByPairs(vp1Address, vp1SamplesFile, "id", vp1SamplesParties)
	checkError(err)

	vp2SamplesFile := readData(path + "/testdata/dataB.csv")
	vp2SamplesParties := []string{vp1Address}
	vp2, err := NewPSIByPairs(vp2Address, vp2SamplesFile, "id", vp2SamplesParties)
	checkError(err)

	vp1EnId, err := vp1.EncryptIDSet()
	checkError(err)
	vp2EnId, err := vp2.EncryptIDSet()
	checkError(err)

	vp12ReEnId, err := vp1.ReEncryptIDSet(vp2Address, vp2EnId)
	checkError(err)

	vp21ReEnId, err := vp2.ReEncryptIDSet(vp1Address, vp1EnId)
	checkError(err)

	_, err = vp1.SetReEncryptIDSet(vp2Address, vp21ReEnId)
	checkError(err)

	err = vp1.SetOtherFinalReEncryptIDSet(vp2Address, vp12ReEnId)
	checkError(err)

	vp1b, vp1Row, vp1intersect, err := vp1.IntersectParts()
	checkError(err)

	fmt.Println("vp1 intersect status:", vp1b)
	fmt.Println("vp1 intersect row:", len(vp1Row))
	fmt.Println("vp1 intersect intersect:", len(vp1intersect), vp1intersect)

}

func readData(filename string) []byte {
	file, err := os.Open(filename)
	checkError(err)

	text, err := ioutil.ReadAll(file)
	checkError(err)
	return text
}

func checkError(err error) {
	if err != nil {
		panic(err)
	}
}
func NewPSIByPairs(name string, samplesFile []byte, samplesIdName string, parties []string) (*PsiByPairs, error) {
	if len(parties) <= 0 {
		return nil, errors.New("no parties in PSI")
	}

	p := &PsiByPairs{
		name:          name,
		samplesFile:   samplesFile,
		samplesIdName: samplesIdName,
	}

	p.parties = make(map[string]bool)
	for _, party := range parties {
		p.parties[party] = true
	}

	// create local ecc private key and public key pari for ID encryption
	privkey, err := GeneratePSIKeyPair()
	if err != nil {
		return nil, err
		// return nil, errorx.New(errcodes.ErrCodeInternal, "mistake[%s] happened when PSI GeneratePSIKeyPair", err.Error())
	}

	p.privkey = privkey

	return p, nil
}

func GeneratePSIKeyPair() (*ecdsa.PrivateKey, error) {
	return ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
}

type PsiByPairs struct {
	name          string
	privkey       *ecdsa.PrivateKey // local ecc private key for ID encryption
	samplesFile   []byte            // csv file content subjected to specified form
	samplesIdName string            // feature name for samples ID, used to extract IDs
	parties       map[string]bool   // names of other parties who participate MPC

	// intermediate results
	// see vl_common.psi for more
	ids    []string
	rows   [][]string
	encIDs []byte

	reEncryptIDSetsFromOthers    sync.Map // stores re-encrypted ID-Sets returned by other parties
	finalReEncryptIDSetsOfOthers sync.Map // stores final re-encrypted ID-Sets for other parties
	middleIntersect              sync.Map // stores the intersections of the current and the one other for other parties

	// final results
	done      bool
	newRows   [][]string
	intersect []string
}

var (
	xchainCryptoClient = new(xchain.XchainCryptoClient)
)

func EncryptSampleIDSet(IDSet []string, privateKey *ecdsa.PrivateKey) ([]byte, error) {
	encIDs := new(XchainCryptoClient).PSIEncryptSampleIDSet(IDSet, privateKey)
	//encIDs := xchainCryptoClient.PSIEncryptSampleIDSet(IDSet, privateKey)
	return PSIEncSetToBytes(encIDs)
}

type XchainCryptoClient struct {
}

func (xcc *XchainCryptoClient) PSIEncryptSampleIDSet(sampleID []string, privateKey *ecdsa.PrivateKey) *EncSet {
	return LREncryptSampleIDSet(sampleID, privateKey)
}

func (xcc *XchainCryptoClient) PSIntersect(sampleID []string, reEncSetLocal *EncSet, reEncSetOthers []*EncSet) []string {
	return Intersect(sampleID, reEncSetLocal, reEncSetOthers)
}

type Empty struct{}

var empty Empty

// 样本加密集合
type EncSet struct {
	EncIDs map[string]int
}

type Point struct {
	Curve elliptic.Curve
	X     *big.Int
	Y     *big.Int
}

type ECPoint struct {
	CurveName string
	X, Y      *big.Int
}

// NewPoint 根据坐标和曲线类型构造Point
func NewPoint(curve elliptic.Curve, x, y *big.Int) (*Point, error) {
	if !curve.IsOnCurve(x, y) {
		return nil, errors.New("NewPoint: the given point is not on the elliptic curve")
	}
	return &Point{Curve: curve, X: x, Y: y}, nil
}

func newPoint(curve elliptic.Curve, x, y *big.Int) *Point {
	return &Point{Curve: curve, X: x, Y: y}
}

// ToString 将Point转换为string类型
func (p *Point) ToString() (string, error) {
	// 转换为自定义的数据结构
	point := getECPoint(p)

	// 转换json
	data, err := json.Marshal(point)

	return string(data), err
}

func getECPoint(p *Point) *ECPoint {
	point := new(ECPoint)
	point.CurveName = p.Curve.Params().Name
	point.X = p.X
	point.Y = p.Y

	return point
}

// Add 计算两个点的加法
func (p *Point) Add(p1 *Point) (*Point, error) {
	x, y := p.Curve.Add(p.X, p.Y, p1.X, p1.Y)

	return NewPoint(p.Curve, x, y)
}

// ScalarMult 计算一个点的数乘
func (p *Point) ScalarMult(k *big.Int) *Point {
	x, y := p.Curve.ScalarMult(p.X, p.Y, k.Bytes())
	newP := newPoint(p.Curve, x, y)

	return newP
}

// Equals 判断两个点是否相同
func (p *Point) Equals(p1 *Point) bool {
	if p == nil || p1 == nil {
		return false
	}

	if p.X.Cmp(p1.X) != 0 || p.Y.Cmp(p1.Y) != 0 {
		return false
	}

	return true
}

func HashToCurve(msg []byte, curve elliptic.Curve) (*Point, error) {
	p := curve.Params().P

	timesTried := 1
	for {
		// 计算哈希值 h = SHA-256(msg)
		h := sha256.Sum256(msg)

		// 将哈希值转换为 big.Int
		x := new(big.Int).SetBytes(h[:])

		// 将 x 限制在曲线定义域内
		x.Mod(x, p)

		//		// 检查 x 是否对应于曲线上的一个 x 值
		//		if !isOnCurve(x, curve) {
		//			// 如果不是，重复执行哈希操作，new_msg = h = SHA-256(last_msg)
		//			msg = h[:]
		//			continue
		//		}

		// 计算 y^2 = x^3 + ax + b，其中 a, b 是曲线参数
		ySquared := new(big.Int).Exp(x, big.NewInt(3), p)

		// 根据曲线类别，来判断下参数a的数值
		if curve.Params().Name != "P-256" && curve.Params().Name != "SM2-P-256" {
			err := fmt.Errorf("curve [%v] is not supported yet.", curve.Params().Name)
			return nil, err
		}

		// NIST系列曲线的参数A是-3，先默认是NIST P-256曲线
		A := big.NewInt(-3)
		// SM2曲线的参数a
		if curve.Params().Name == "SM2-P-256" {
			A, _ = new(big.Int).SetString("FFFFFFFEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF00000000FFFFFFFFFFFFFFFC", 16)
		}

		// Compute ax
		//ax := new(big.Int).Mul(curve.Params().A, x)
		ax := new(big.Int).Mul(A, x)

		ySquared.Add(ySquared, ax)
		ySquared.Add(ySquared, curve.Params().B)

		// 计算 y 的平方根
		// 如果y是nil，就说明没找到合适的点
		//
		// 注意：NIST P-256曲线和国密SM2系列曲线的P满足p mod 4 = 3，所以可以使用费马小定理Fermat's Little Theorem 来快速计算平方根
		// Fermat's Little Theorem states that if p is a prime number and x is an integer not divisible by p,
		// then x^(p-1) is congruent to 1 modulo p:
		// x^(p-1) = 1 mod p
		// 因而：
		// 两边都乘以x：x^(p-1) * x^1 = x^(p-1+1) = x^p = x mod p
		// 两边再乘以x：x^(p-1) * x^2 = x^(p-1+2) = x^(p+1) = x^2 mod p
		// 因为p mod 4 = 3，所以p+1 = 4k，也就是说，可以被4整除
		// 两边的指数同时除以4：x^((p+1)/4) = x^(2/4) mod p = x^(1/2) mod p
		// 结论：
		// 假设有限域的范围是p，p为质数且 p mod 4 = 3, 根据费马小定理 a^(p-1) = 1 mod p,
		// 那么对于任意有限域的元素x，其在有限域的平方根y=x^(p+1)/4 mod p
		y := new(big.Int).ModSqrt(ySquared, p)

		// 如果 y^2 = x^3 + ax + b，则返回点 (x, y)
		if y != nil {
			//log.Printf("timesTried when HashToCurve: %d", timesTried)

			//			// Compute y = x^((p+1)/4) mod p
			//			log.Printf("equation p mod 4 is: %s", new(big.Int).Mod(elliptic.P256().Params().P, big.NewInt(4)))
			//
			//			exp := new(big.Int).Add(elliptic.P256().Params().P, big.NewInt(1))
			//			exp.Div(exp, big.NewInt(4))
			//			yTest := new(big.Int).Exp(ySquared, exp, elliptic.P256().Params().P)
			//
			//			// Check if y is really the square root of x
			//			y2 := new(big.Int).Mul(yTest, yTest)
			//			y2.Mod(y2, elliptic.P256().Params().P)
			//			ySquaredTest := new(big.Int).Mod(y2, elliptic.P256().Params().P)
			//			if y2.Cmp(ySquaredTest) != 0 {
			//				log.Printf("equation y = x^((p+1)/4) mod p is not enough for ModSqrt computation: y[%d], yTest[%d]", y, yTest)
			//			}

			//return x, y
			return &Point{Curve: curve, X: x, Y: y}, nil
		}

		// 如果没有找到合适的点，重复执行哈希操作
		msg = h[:]

		timesTried++
	}
}

// 参与方分别对自己的样本特征ID进行计算，通过如下方式获得每个样本特征ID的加密公钥集合：
//
//	Alice: Pub'Ai=HP(ID-Ai)^Prv'A=HashToCurve(ID-Ai)^Prv'A
//	  Bob: Pub'Bi=HP(ID-Bi)^Prv'B=HashToCurve(ID-Bi)^Prv'B
func LREncryptSampleIDSet(sampleID []string, privateKey *ecdsa.PrivateKey) *EncSet {
	curve := privateKey.Curve

	encIDs := make(map[string]int)

	for i := 0; i < len(sampleID); i++ {
		eccPoint, _ := HashToCurve([]byte(sampleID[i]), curve)

		newX, newY := curve.ScalarMult(eccPoint.X, eccPoint.Y, privateKey.D.Bytes())

		id := string(elliptic.Marshal(curve, newX, newY))

		encIDs[id] = i
	}

	encSet := &EncSet{
		EncIDs: encIDs,
	}

	return encSet
}

// 参与方使用自己的公钥对其它方的样本特征ID加密集合进行二次加密，例如：
//
//	Alice: Pub'Bi-A=Pub'Bi^Prv'A=Hash(ID-Bi)*G^Prv'B^Prv'A
//	  Bob: Pub'Ai-B=Pub'Ai^Prv'B=Hash(ID-Ai)*G^Prv'A^Prv'B
func LRReEncryptIDSet(encSet *EncSet, privateKey *ecdsa.PrivateKey) *EncSet {
	curve := privateKey.PublicKey.Curve

	//	var encIDs []*ID
	encIDs := make(map[string]int)

	for idstr, value := range encSet.EncIDs {
		// Pub'Bi^Prv'A
		x, y := elliptic.Unmarshal(curve, []byte(idstr))

		newX, newY := curve.ScalarMult(x, y, privateKey.D.Bytes())

		id := string(elliptic.Marshal(curve, newX, newY))

		encIDs[id] = value
	}

	newEncSet := &EncSet{
		EncIDs: encIDs,
	}

	return newEncSet
}

// 加密样本对齐
func Intersect(sampleID []string, reEncSetLocal *EncSet, reEncSetOthers []*EncSet) []string {
	idSetLocal := reEncSetLocal.EncIDs
	//	idSetOther := reEncSetOther.EncIDs

	//	intersection := make(map[string]Empty)
	var intersection []string

	// 遍历样本集合A
	for id, value := range idSetLocal {
		isExist := false
		for _, reEncSetOther := range reEncSetOthers {
			idSetOther := reEncSetOther.EncIDs

			// 如果A中的元素在B中也存在，那么放入交集中
			_, isExist = idSetOther[id]

			if isExist != true {
				break
			}
		}

		if isExist == true {
			intersection = append(intersection, sampleID[value])
		}
	}

	//	encSet := &EncSet{
	//		EncIDs: intersection,
	//	}
	//
	//	return encSet

	return intersection
}

func PSIEncSetToBytes(set *EncSet) ([]byte, error) {
	encSet := make(map[string]int)
	for key, value := range set.EncIDs {
		newKey := hex.EncodeToString([]byte(key))
		encSet[newKey] = value
	}
	return json.Marshal(encSet)
}

func ReadRowsFromFile(fileContent []byte) ([][]string, error) {
	r := csv.NewReader(bytes.NewReader(fileContent))
	return r.ReadAll()
}

func RetrieveIDsFromFile(fileRows [][]string, idName string) ([]string, error) {
	if fileRows == nil {
		return nil, fmt.Errorf("empty file content")
	}

	// read the first row to get feature nums and ID feature index
	featureNum := len(fileRows[0])
	featureIndex := -1
	for i := 0; i < featureNum; i++ {
		if fileRows[0][i] == idName {
			featureIndex = i
		}
	}
	if featureIndex == -1 {
		return nil, fmt.Errorf("file does not contain sample id: %s", idName)
	}

	// read from all rows to get ID set
	var set []string
	for row := 1; row < len(fileRows); row++ {
		set = append(set, fileRows[row][featureIndex])
	}

	return set, nil
}
func ReadIDsFromFileRows(fileContent []byte, idName string) ([][]string, []string, error) {
	rows, err := ReadRowsFromFile(fileContent)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to read rows from file: %v", err)
	}
	IDs, err := RetrieveIDsFromFile(rows, idName)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to retrieve ID set from file rows: %v", err)
	}
	return rows, IDs, err
}

func (vp *PsiByPairs) readSamples() error {
	rows, IDs, err := ReadIDsFromFileRows(vp.samplesFile, vp.samplesIdName)

	if err != nil {
		return err
	}

	vp.ids = IDs
	vp.rows = rows

	return nil
}

func (vp *PsiByPairs) EncryptIDSet() ([]byte, error) {
	err := vp.readSamples()
	if err != nil {
		return []byte{}, errors.New("happened when PSI read IDs from file")
	}

	encIDs, err := EncryptSampleIDSet(vp.ids, vp.privkey)
	if err != nil {
		return []byte{}, errors.New("happened when PSI encrypt SampleIDSet")
	}

	vp.encIDs = encIDs

	return vp.encIDs, nil
}

func PSIEncSetFromBytes(setBytes []byte) (*EncSet, error) {
	var set map[string]int
	err := json.Unmarshal(setBytes, &set)
	if err != nil {
		return nil, err
	}

	originalSet := make(map[string]int)
	for key, value := range set {
		newKey, err := hex.DecodeString(key)
		if err != nil {
			return nil, err
		}
		originalSet[string(newKey)] = value
	}

	encSet := &EncSet{
		EncIDs: originalSet,
	}
	return encSet, nil
}

func (xcc *XchainCryptoClient) PSIReEncryptIDSet(encSet *EncSet, privateKey *ecdsa.PrivateKey) *EncSet {
	return LRReEncryptIDSet(encSet, privateKey)
}

func ReEncryptIDSet(encSet []byte, privateKey *ecdsa.PrivateKey) ([]byte, error) {
	set, err := PSIEncSetFromBytes(encSet)
	if err != nil {
		return nil, err
	}
	IDs := new(XchainCryptoClient).PSIReEncryptIDSet(set, privateKey)
	return PSIEncSetToBytes(IDs)
}

func (vp *PsiByPairs) ReEncryptIDSet(party string, encIDs []byte) ([]byte, error) {

	reEncIDs, errRe := ReEncryptIDSet(encIDs, vp.privkey)

	// if from unknown party, don't care about any Error
	if _, ok := vp.parties[party]; !ok {
		if errRe != nil {
			reEncIDs = []byte{}
		}
		return reEncIDs, nil
	}

	if errRe != nil {
		return []byte{}, errors.New("happened when PSI encrypt EncryptedSampleIDSet for other party")
	}

	return reEncIDs, nil
}

func (vp *PsiByPairs) SetReEncryptIDSet(party string, reEncIDs []byte) (bool, error) {
	if _, ok := vp.parties[party]; !ok {
		// if from unknown party, ignore
		return false, nil
	}

	vp.reEncryptIDSetsFromOthers.LoadOrStore(party, reEncIDs)

	return true, nil
}
func (vp *PsiByPairs) SetOtherFinalReEncryptIDSet(party string, reEncIDs []byte) error {
	// if from unknown party, don't store result
	if _, ok := vp.parties[party]; !ok {
		return nil
	}
	vp.finalReEncryptIDSetsOfOthers.LoadOrStore(party, reEncIDs)
	return nil
}

func IntersectTwoParts(sampleID []string, reEncSetLocal []byte, reEncSetOthers []byte) ([]string, error) {
	localSet, err := PSIEncSetFromBytes(reEncSetLocal)
	if err != nil {
		return nil, err
	}
	otherSet, err := PSIEncSetFromBytes(reEncSetOthers)
	if err != nil {
		return nil, err
	}
	otherSetList := []*EncSet{otherSet}
	return new(XchainCryptoClient).PSIntersect(sampleID, localSet, otherSetList), nil
}

func (vp *PsiByPairs) getIntersection(a, b []string) []string {
	compareMap := make(map[string]bool)
	for _, v := range b {
		compareMap[v] = true
	}
	var ret []string
	for _, v := range a {
		if compareMap[v] == true {
			ret = append(ret, v)
		}
	}
	return ret
}

func reOrderIDSet(IDs []string) map[string]int {
	idxMap := make(map[string]int)
	sort.Strings(IDs)
	for i := 0; i < len(IDs); i++ {
		idxMap[IDs[i]] = i
	}
	return idxMap
}

func RearrangeFileWithIntersectIDs(fileRows [][]string, idName string, IDs []string) ([][]string, error) {
	if fileRows == nil {
		return nil, fmt.Errorf("empty file content")
	}
	if len(IDs) == 0 {
		return nil, fmt.Errorf("empty ID list")
	}

	reOrderedIDs := reOrderIDSet(IDs)
	// first row is feature list, others are samples
	intersectRows := make([][]string, len(IDs)+1)

	featureNum := len(fileRows[0])
	featureIndex := -1
	for i := 0; i < featureNum; i++ {
		if fileRows[0][i] == idName {
			featureIndex = i
		}
	}
	if featureIndex == -1 {
		return nil, fmt.Errorf("file does not contain sample id: %s", idName)
	}
	var firstRow []string
	firstRow = append(firstRow, fileRows[0][0:featureIndex]...)
	firstRow = append(firstRow, fileRows[0][featureIndex+1:]...)
	intersectRows[0] = firstRow

	// read from all rows to remove ID and re-order rows
	for row := 1; row < len(fileRows); row++ {
		var newRow []string
		id := fileRows[row][featureIndex]

		if idx, exist := reOrderedIDs[id]; exist {
			newRow = append(newRow, fileRows[row][0:featureIndex]...)
			newRow = append(newRow, fileRows[row][featureIndex+1:]...)
			intersectRows[idx+1] = newRow
		}
	}

	return intersectRows, nil
}

func (vp *PsiByPairs) IntersectParts() (bool, [][]string, []string, error) {
	if vp.done {
		return vp.done, vp.newRows, vp.intersect, nil
	}

	var newRows [][]string
	for party := range vp.parties {
		reEncIDsBySelf, ok := vp.reEncryptIDSetsFromOthers.Load(party)
		if !ok {
			return false, newRows, nil, nil
		}

		reEncIDsByOther, ok := vp.finalReEncryptIDSetsOfOthers.Load(party)
		if !ok {
			return false, newRows, nil, nil
		}
		intersect, err := IntersectTwoParts(vp.ids, reEncIDsBySelf.([]byte), reEncIDsByOther.([]byte))
		if err != nil {
			return false, newRows, intersect, errors.New("happened when PSI intersect all parts")
		}
		vp.middleIntersect.LoadOrStore(party, intersect)
	}

	var intersect []string
	firstParty := true
	for party := range vp.parties {
		if firstParty {
			firstParty = false
			if intersectInf, ok := vp.middleIntersect.Load(party); ok {
				intersect = intersectInf.([]string)
			} else {
				return false, newRows, intersect, nil
			}
			continue
		}
		var compare []string
		if compareInf, ok := vp.middleIntersect.Load(party); ok {
			compare = compareInf.([]string)
		} else {
			return false, newRows, intersect, nil
		}
		intersect = vp.getIntersection(intersect, compare)
	}

	vp.intersect = intersect
	newRows, err := RearrangeFileWithIntersectIDs(vp.rows, vp.samplesIdName, intersect)
	if err != nil {
		return false, newRows, intersect, errors.New("happened when PSI rearrange file with intersected IDs")
	}
	vp.newRows = newRows
	vp.done = true

	return vp.done, vp.newRows, vp.intersect, nil
}
