package psi

import (
	"bytes"
	"github.com/PaddlePaddle/PaddleDTX/dai/crypto/vl/feat_eng"
	"github.com/PaddlePaddle/PaddleDTX/dai/errcodes"
	pbCom "github.com/PaddlePaddle/PaddleDTX/dai/protos/common"
	pb "github.com/PaddlePaddle/PaddleDTX/dai/protos/mpc"
	pbLinearRegVl "github.com/PaddlePaddle/PaddleDTX/dai/protos/mpc/learners/linear_reg_vl"
	"github.com/PaddlePaddle/PaddleDTX/xdb/errorx"
	"github.com/golang/protobuf/proto"
	"github.com/sirupsen/logrus"
	"strings"
	"sync"
	"time"
)

var (
	logger = logrus.WithField("module", "mpc.psi.ecdh")
)

type psiStatusType uint8

const (
	startPSI psiStatusType = iota
	endPSI
)

type PSI interface {
	// EncryptSampleIDSet to encrypt local IDs
	EncryptSampleIDSet() ([]byte, error)

	// SetReEncryptIDSet sets re-encrypted IDs from other party,
	// and tries to calculate final re-encrypted IDs
	// returns True if calculation is Done, otherwise False if still waiting for others' parts
	// returns Error if any mistake happens
	SetReEncryptIDSet(party string, reEncIDs []byte) (bool, error)

	// ReEncryptIDSet to encrypt encrypted IDs for other party
	ReEncryptIDSet(party string, encIDs []byte) ([]byte, error)

	// SetOtherFinalReEncryptIDSet sets final re-encrypted IDs of other party
	SetOtherFinalReEncryptIDSet(party string, reEncIDs []byte) error

	// IntersectParts tries to calculate intersection with all parties' samples
	// returns True with final result if calculation is Done, otherwise False if still waiting for others' samples
	// returns Error if any mistake happens
	// You'd better call it when SetReEncryptIDSet returns Done or SetOtherFinalReEncryptIDSet finishes
	IntersectParts() (bool, [][]string, []string, error)
}
type ResultHandler interface {
	SaveResult(*pbCom.PsiTaskResult)
}
type RpcHandler interface {
	StepPsi(req *pb.PsiRequest, peerName string) (*pb.PsiResponse, error)

	StepPsiWithRetry(req *pb.PsiRequest, peerName string, times int, inteSec int64) (*pb.PsiResponse, error)
}

type ecdh struct {
	id          string
	algo        pbCom.Algorithm
	address     string   // address indicates local mpc-node
	parties     []string // parties are other learners who participates in MPC, assigned with mpc-node address usually
	psiParams   *pbCom.PsiParams
	samplesFile []byte // sample file content for training model
	psi         PSI
	procMutex   sync.Mutex
	loopRound   uint64
	rpc         RpcHandler    // rpc is used to request remote mpc-node
	rh          ResultHandler // rh handles final result which is successful or failed
	//lEvaluator   LiveEvaluator
	triggerInter uint64     // triggerInter is the number of interval rounds of triggering `LiveEvaluation`
	triggerRound uint64     // if in `triggerRound`, `LiveEvaluation` will be triggered
	fileRows     [][]string // fileRows returned by psi.IntersectParts

	status psiStatusType

	// stopMsgNeglected means whether to ignore the Stop signal,
	// that's to say, the process will continue as long as receive specific messages
	stopSigNeglected bool
	// if in `pauseRound`, the process will pause
	pauseRound uint64
}

func (e *ecdh) Advance(payload []byte) (*pb.PsiResponse, error) {
	m := &pbLinearRegVl.Message{}
	err := proto.Unmarshal(payload, m)
	if err != nil {
		return nil, errorx.New(errcodes.ErrCodeParam, "failed to Unmarshal payload: %s", err.Error())
	}

	return e.advance(m)
}

func (e *ecdh) advance(message *pbLinearRegVl.Message) (*pb.PsiResponse, error) {
	mType := message.Type
	handleError := func(err error) {
		logger.WithField("error", err.Error()).Warning("failed to psi 。。。")
		res := &pbCom.PsiTaskResult{TaskID: e.id, ErrMsg: err.Error()}
		e.rh.SaveResult(res)
	}

	var ret *pb.PsiResponse
	switch mType {
	case pbLinearRegVl.MessageType_MsgPsiEnc: // local message
		logger.Infof("psi  MessageType_MsgPsiEnc begin")
		encIDs, err := e.psi.EncryptSampleIDSet()
		if err != nil {
			logger.Errorf("psi  MessageType_MsgPsiEnc err err is %s ", err.Error())
			go handleError(err)
			return nil, err
		}
		go func() {
			m := &pbLinearRegVl.Message{
				Type: pbLinearRegVl.MessageType_MsgPsiAskReEnc,
				VlLPsiReEncIDsReq: &pb.VLPsiReEncIDsRequest{
					TaskID: e.id,
					EncIDs: encIDs,
				},
			}
			e.advance(m)
		}()

	case pbLinearRegVl.MessageType_MsgPsiAskReEnc: // local message
		newMess := &pbLinearRegVl.Message{
			Type:              pbLinearRegVl.MessageType_MsgPsiReEnc,
			VlLPsiReEncIDsReq: message.VlLPsiReEncIDsReq,
			LoopRound:         e.loopRound,
		}
		logger.Infof("psi  MessageType_MsgPsiAskReEnc begin")
		logger.Infof("sendMessageWithRetry  address %s", e.parties[0])
		reM, err := e.sendMessageWithRetry(newMess, e.parties[0])
		if err != nil {
			logger.Errorf("psi  MessageType_MsgPsiReEnc err err is %s ", err.Error())
			go handleError(err)
			return nil, err
		}

		done, err := e.psi.SetReEncryptIDSet(e.parties[0], reM.VlLPsiReEncIDsResp.ReEncIDs)
		if err != nil {
			logger.Errorf("psi  MessageType_MsgPsiReEnc (SetReEncryptIDSet) err err is %s ", err.Error())
			go handleError(err)
			return nil, err
		}

		if done {
			go func() {
				m := &pbLinearRegVl.Message{
					Type: pbLinearRegVl.MessageType_MsgPsiIntersect,
				}
				e.advance(m)
			}()
		}

	case pbLinearRegVl.MessageType_MsgPsiReEnc:
		logger.Infof("psi  MessageType_MsgPsiReEnc begin")
		reEncIDs, err := e.psi.ReEncryptIDSet(message.From, message.VlLPsiReEncIDsReq.EncIDs)
		if err != nil {
			logger.Infof("psi  MessageType_MsgPsiReEnc err %s", err.Error())
			go handleError(err)
			return nil, err
		}

		retM := &pbLinearRegVl.Message{
			Type: pbLinearRegVl.MessageType_MsgPsiReEnc,
			To:   message.From,
			From: e.address,
			VlLPsiReEncIDsResp: &pb.VLPsiReEncIDsResponse{
				TaskID:   e.id,
				ReEncIDs: reEncIDs,
			},
		}
		payload, err := proto.Marshal(retM)
		if err != nil {
			logger.Errorf("psi  MessageType_MsgPsiReEnc (proto.Marshal) err err is %s ", err.Error())
			err = errorx.New(errcodes.ErrCodeInternal, "failed to Marshal payload: %s", err.Error())
			go handleError(err)
			return nil, err
		}

		ret = &pb.PsiResponse{
			TaskID:  e.id,
			Payload: payload,
		}

		err = e.psi.SetOtherFinalReEncryptIDSet(message.From, reEncIDs)
		if err != nil {
			logger.Errorf("psi  MessageType_MsgPsiReEnc (SetOtherFinalReEncryptIDSet) err err is %s ", err.Error())
			go handleError(err)
		} else {
			go func() {
				m := &pbLinearRegVl.Message{
					Type: pbLinearRegVl.MessageType_MsgPsiIntersect,
				}
				e.advance(m)
			}()
		}

	case pbLinearRegVl.MessageType_MsgPsiIntersect: // local message
		logger.Infof("psi  MessageType_MsgPsiIntersect begin")
		done, newRows, intersects, err := e.psi.IntersectParts()
		if err != nil {
			go handleError(err)
			return nil, err
		}

		if done {
			logger.Infof("audit-task[%s] PSI intersects: %v", e.id, intersects)
			logger.Infof("audit-task[%s] PSI EncIDs is : %s", e.id, e.psiParams.PsiColum)
			e.fileRows = newRows
			e.status = endPSI

			//go func() {
			//	m := &pbLinearRegVl.Message{
			//		Type: pbLinearRegVl.MessageType_MsgTrainHup,
			//	}
			//	e.Advance(m)
			//}()
			var buffer bytes.Buffer
			//每行数据
			for i, row := range newRows {
				lineStr := ""
				//第一行是表头，要把主键加上
				if i == 0 {
					//todo 目前ecdh算法只支持单字段求交
					lineStr += e.psiParams.PsiColum[0] + "," + strings.Join(row, ",")
				} else {
					lineStr = intersects[i-1] + "," + strings.Join(row, ",")
				}
				buffer.WriteString(lineStr)
				if i != len(newRows)-1 {
					buffer.WriteString("\n")
				}
			}
			bytes := buffer.Bytes()
			// 完成psi计算,更新状态，保存文件
			res := &pbCom.PsiTaskResult{
				TaskID:    e.id,
				PsiResult: bytes,
				Success:   true,
			}
			logger.Infof("psi执行完毕，准备保存文件。。")
			e.rh.SaveResult(res)
		}
	}
	logger.WithFields(logrus.Fields{
		"address":      e.address,
		"loopRound":    e.loopRound,
		"messageRound": message.LoopRound,
	}).Infof("psi[%s] finished advance . message %s", e.id, message.Type.String())
	return ret, nil
}

func NewPsiEcdha(taskId string, address string, algo pbCom.Algorithm, params *pbCom.PsiParams, featEngs []*pbCom.FeatureEngineering,
	samplesFile []byte, parties []string, rpc RpcHandler, rh ResultHandler) (PsiAdvance, error) {
	// handle feature engineering to get new sample file
	newSamplesFile, err := feat_eng.ProcessFeatEngs(samplesFile, featEngs)
	if err != nil {
		return nil, err
	}
	//todo 暂时只支持1个字段求交
	p, err := NewVLTwoPartsPSI(address, newSamplesFile, params.GetPsiColum()[0], parties)
	if err != nil {
		return nil, err
	}
	l := &ecdh{
		id:          taskId,
		algo:        pbCom.Algorithm_PRIVATE_SET_INTERSECTION_VL,
		address:     address,
		parties:     parties,
		psi:         p,
		psiParams:   params,
		samplesFile: newSamplesFile,
		rpc:         rpc,
		rh:          rh,
		status:      startPSI,
	}
	// start training
	go func() {
		m := &pbLinearRegVl.Message{
			Type: pbLinearRegVl.MessageType_MsgPsiEnc,
		}
		l.advance(m)
	}()
	return l, nil
}

// sendMessageWithRetry sends message to remote mpc-node
// retries 2 times at most
func (e *ecdh) sendMessageWithRetry(message *pbLinearRegVl.Message, address string) (*pbLinearRegVl.Message, error) {
	logger.Infof("sendMessageWithRetry  address %s", address)
	times := 3

	var m *pbLinearRegVl.Message
	var err error
	for i := 0; i < times; i++ {
		if i > 0 {
			time.Sleep(3 * time.Second)
		}
		m, err = e.sendMessage(message, address)
		if err == nil {
			break
		}
	}

	return m, err
}

func (e *ecdh) sendMessage(message *pbLinearRegVl.Message, address string) (*pbLinearRegVl.Message, error) {
	message.From = e.address
	message.To = address

	payload, err := proto.Marshal(message)
	if err != nil {
		return nil, errorx.New(errcodes.ErrCodeInternal, "failed to Marshal payload: %s", err.Error())
	}

	psiReq := &pb.PsiRequest{
		TaskID:  e.id,
		Algo:    e.algo,
		Payload: payload,
	}
	resp, err := e.rpc.StepPsi(psiReq, address)
	if err != nil {
		return nil, err
	}

	m := &pbLinearRegVl.Message{}
	if len(resp.Payload) != 0 {
		err := proto.Unmarshal(resp.Payload, m)
		if err != nil {
			return nil, errorx.New(errcodes.ErrCodeInternal, "failed to Unmarshal payload[%s] from[%s] and err is[%s] ", string(resp.Payload), address, err.Error())
		}
	}
	return m, nil
}
