// Copyright (c) 2021 PaddlePaddle Authors. All Rights Reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package dtc

import (
	"encoding/json"
	"fmt"

	dtc_vl "github.com/PaddlePaddle/PaddleDTX/crypto/core/machine_learning/decision_tree/classification/mpc_vertical"

	pbDtcVl "github.com/PaddlePaddle/PaddleDTX/dai/protos/mpc/learners/decision_tree_class_vl"
)

// TrainModels model saved locally for further prediction
type TrainModels struct {
	NodesMap map[string]*dtc_vl.CTreeNode
}

// TrainModelsFromBytes retrieve train models from bytes
func TrainModelsFromBytes(modelsBytes []byte) (*TrainModels, error) {
	var model TrainModels
	err := json.Unmarshal(modelsBytes, &model)
	if err != nil {
		return nil, err
	}
	return &model, nil
}

// PredictionStep predict locally of given samples
// model is the partial model saved locally
// samples is a map from sample id to attributes, like sample_0["Age":"63", "Cp":"1.0"...]
// stepRes is a map from sample id to tree node depth and index
// for each sample, return the prediction result if reached leaf, or next prediction node depth&index
func PredictionStep(model map[string]*dtc_vl.CTreeNode, samples map[int32]map[string]string,
	stepRes map[int32]*pbDtcVl.PredStepResult) (map[int32]*pbDtcVl.PredStepResult, error) {
	ret := make(map[int32]*pbDtcVl.PredStepResult)
	for id, res := range stepRes {
		if _, ok := samples[id]; !ok {
			return nil, fmt.Errorf("samples not contain sample[%d]", id)
		}
		result, depth, index, err := xchainCryptoClient.DtcVLPredictionStep(model, samples[id], int(res.Depth), int(res.Index))
		if err != nil {
			return nil, fmt.Errorf("sample[%d] predict error: %v [%v]", id, err, samples[id])
		}

		ret[id] = &pbDtcVl.PredStepResult{
			Result: result,
			Depth:  int32(depth),
			Index:  int32(index),
		}
	}
	return ret, nil
}
