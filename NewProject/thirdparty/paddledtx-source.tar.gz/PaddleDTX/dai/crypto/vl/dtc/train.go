// Copyright (c) 2021 PaddlePaddle Authors. All Rights Reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package dtc

import (
	"encoding/json"

	"github.com/PaddlePaddle/PaddleDTX/crypto/client/service/xchain"
	ml_common "github.com/PaddlePaddle/PaddleDTX/crypto/core/machine_learning/common"
	dtc_vl "github.com/PaddlePaddle/PaddleDTX/crypto/core/machine_learning/decision_tree/classification/mpc_vertical"

	vl_common "github.com/PaddlePaddle/PaddleDTX/dai/crypto/vl/common"
	pb_common "github.com/PaddlePaddle/PaddleDTX/dai/protos/common"
)

var xchainCryptoClient = new(xchain.XchainCryptoClient)

// prepared material for feature selection of each tree node
// each tree node has a corresponding material, which contains a feature name list, split value list,
// left node sample IDs list, right node sample IDs list
type MaterialForFeatureSelect struct {
	FeatureNames   []string      // available feature list
	SplitValues    []interface{} // feature value that split node samples into two data set
	LeftSampleIDs  [][]int       // sample IDs of left child node, obtained by splitting data set using a feature's split value
	RightSampleIDs [][]int       // sample IDs of right child node, corresponding to sample IDs of left child node
}

// GetTrainDataSetFromFile retrieve train dataset from file for tag/no-tag part
// fileRows is sample rows, first row is feature list, others are values for each sample
// params includes all required parameters for training
func GetTrainDataSetFromFile(fileRows [][]string) (*ml_common.DTDataSet, error) {
	features, err := xchainCryptoClient.DecisionTreeImportFeatures(fileRows)
	if err != nil {
		return nil, err
	}

	dataSet := &ml_common.DTDataSet{
		Features: features,
	}

	return dataSet, nil
}

// PrepForFeatureSelect prepare material for a tree node
// - dataset all train data set
// - idList sample ID list of the tree node
// - params train params
func PrepForFeatureSelect(dataset *ml_common.DTDataSet, idList []uint64, params pb_common.TrainParams) (*MaterialForFeatureSelect, error) {
	ids := vl_common.UintsToInts(idList)
	features, splits, leftIDs, rightIDs, err := xchainCryptoClient.DtcVLPrepForFeatureSelect(dataset, ids, params.Label, params.ContFeatures)
	if err != nil {
		return nil, err
	}
	return &MaterialForFeatureSelect{
		FeatureNames:   features,
		SplitValues:    splits,
		LeftSampleIDs:  leftIDs,
		RightSampleIDs: rightIDs,
	}, nil
}

// CalGini calculate Gini of given id lists, which can be only operated by tag part
// this is operated by tag part
func CalGini(dataset *ml_common.DTDataSet, idsLeft, idsRight []uint64, label string) float64 {
	return xchainCryptoClient.DtcVLCalGiniByTagPart(dataset, vl_common.UintsToInts(idsLeft), vl_common.UintsToInts(idsRight), label)
}

// GetTreeNodeKey calculate key to store node, given node depth and node index
func GetTreeNodeKey(depth, index uint64) string {
	return xchainCryptoClient.DtcVLNodeKeyByDepthIndex(int(depth), int(index))
}

// DecideTerminate determine if a branch should be terminated, return final result if true
// this is operated by tag part
func DecideTerminate(dataset *ml_common.DTDataSet, curIdList, fatherIdList []uint64, curGini, fatherGini float64,
	curDepth int, label string, cond dtc_vl.StopCondition) (bool, string) {
	return xchainCryptoClient.DtcVLDecideTerminateTagPart(dataset, vl_common.UintsToInts(curIdList), vl_common.UintsToInts(fatherIdList),
		curGini, fatherGini, curDepth, label, cond)
}

// GetMaxLabelType get type of target feature with maximum sample number
// this is operated by tag part
func GetMaxLabelType(dataset *ml_common.DTDataSet, idList []int, label string) string {
	return xchainCryptoClient.DtcVLGetMaxLabelTypeTagPart(dataset, idList, label)
}

// IfPruneNode determine if a node should be pruned, that is, to switch the node to leaf and delete two child nodes
// this is operated by tag part
func IfPruneNode(dataset *ml_common.DTDataSet, model map[string]*dtc_vl.CTreeNode, label string, depth, index int, regParam float64) bool {
	return xchainCryptoClient.DtcVLIfPruneNodeByTagPart(dataset, model, label, depth, index, regParam)
}

// IfStopTraining determine if train should be stopped
// this is operated by tag part
func IfStopTraining(leafNum, nonLeafNum uint64) bool {
	return xchainCryptoClient.DtcVLStopTrain(int(leafNum), int(nonLeafNum))
}

// TrainModelsToBytes convert train models to bytes for transfer and storage
func TrainModelsToBytes(nodes map[string]*dtc_vl.CTreeNode) ([]byte, error) {
	trainModels := TrainModels{
		NodesMap: nodes,
	}
	return json.Marshal(trainModels)
}
