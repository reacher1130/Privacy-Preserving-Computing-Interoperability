// Copyright (c) 2021 PaddlePaddle Authors. All Rights Reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package dtc

import dtc_vl "github.com/PaddlePaddle/PaddleDTX/crypto/core/machine_learning/decision_tree/classification/mpc_vertical"

// GetAllPossibleClasses get all possible classes in training data set
// first row of trainset contains all features
func GetAllPossibleClasses(trainset [][]string, label string) []string {
	cMap := make(map[string]bool)
	labelIdx := getLabelIndex(trainset[0], label)
	for i := 1; i < len(trainset); i++ {
		t := trainset[i][labelIdx]
		cMap[t] = true

	}
	ret := make([]string, len(cMap))
	for k := range cMap {
		ret = append(ret, k)
	}
	return ret
}

// GetSampleProbs get sample predicted probs of each class
// leafProb is a map from leaf id to each class's probability
// sampleLeaves is a map from sample id to leaf id
// return a map from sample id to probs map, e.g., sample_0["apple":0.2,"banana":0.5...]
func GetSampleProbs(leafProb map[string]map[string]float64, sampleLeaves map[int]string) map[int]map[string]float64 {
	sampleProbs := make(map[int]map[string]float64)
	for id, leaf := range sampleLeaves {
		sampleProbs[id] = leafProb[leaf]
	}
	return sampleProbs
}

// GetClassProbMapEachLeaf get each leaf's class probability map
// model contains all nodes in tree model
// trainset contains all training samples
func GetClassProbMapEachLeaf(model map[string]*dtc_vl.CTreeNode, trainset [][]string, label string) map[string]map[string]float64 {
	probs := make(map[string]map[string]float64)
	for id, node := range model {
		// find leaf node
		if len(node.Result) != 0 {
			probs[id] = getClassProbMap(node, trainset, label)
		}
	}
	return probs
}

// getClassProbMap get a leaf's class probability map, return a map from class to probability
// 1. find all samples in leaf
// 2. find all samples' classes
// 3. calculate prob for each class
func getClassProbMap(leaf *dtc_vl.CTreeNode, trainset [][]string, label string) map[string]float64 {
	// get all types
	classNum := make(map[string]int)
	prob := make(map[string]float64)
	total := 0

	// get index of target feature
	labelIdx := getLabelIndex(trainset[0], label)

	for i := 0; i < len(leaf.SampleIDList); i++ {
		sampleID := leaf.SampleIDList[i]
		// first row of trainset contains all features
		// sampleID starts with 0
		sample := trainset[sampleID+1]
		class := sample[labelIdx]
		classNum[class]++
		total++
	}
	for k, v := range classNum {
		prob[k] = float64(v) / float64(total)
	}
	return prob
}

// getLabelIndex find label index among sample attributes
func getLabelIndex(features []string, label string) int {
	labelIdx := 0
	for i := 0; i < len(features); i++ {
		if features[i] == label {
			labelIdx = i
			break
		}
	}
	return labelIdx
}
