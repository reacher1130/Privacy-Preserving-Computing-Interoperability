// Copyright (c) 2021 PaddlePaddle Authors. All Rights Reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package feat_eng

import (
	"bytes"
	"encoding/json"

	featureEng "github.com/PaddlePaddle/PaddleDTX/crypto/core/machine_learning/feature_engineering"
	"github.com/PaddlePaddle/PaddleDTX/xdb/errorx"
	"github.com/golang/protobuf/jsonpb"

	"github.com/PaddlePaddle/PaddleDTX/dai/crypto/vl/common/csv"
	"github.com/PaddlePaddle/PaddleDTX/dai/errcodes"
	pbCom "github.com/PaddlePaddle/PaddleDTX/dai/protos/common"
)

// ProcessFeatEngs process feature engineering methods on samples file and return processed file content
// samplesFile is sample file content
// featEngs contains multiple feature engineering methods,
// samples file should be processed in the order of featEngs
func ProcessFeatEngs(samplesFile []byte, featEngs []*pbCom.FeatureEngineering) ([]byte, error) {
	if featEngs == nil || len(featEngs) == 0 {
		return samplesFile, nil
	}

	// resolve data set from fileRows
	fileRows, err := csv.ReadRowsFromFile(samplesFile)
	if err != nil {
		return nil, errorx.New(errcodes.ErrCodeInternal, "mistake[%s] happened when linear_reg_vl processFeatEngs", err.Error())
	}

	for i := 0; i < len(featEngs); i++ {
		if eng := featEngs[i].GetEqualWidthBinning(); eng != nil {
			m := make(map[string]featureEng.BinOpt)
			for k, v := range eng.BinOpts {
				m[k] = featureEng.BinOpt{int(v.BinNum)}
			}
			fileRows, err = featureEng.EqualWidthBinning(fileRows, m)
		} else if eng := featEngs[i].GetEqualFrequencyBinning(); eng != nil {
			m := make(map[string]featureEng.BinOpt)
			for k, v := range eng.BinOpts {
				m[k] = featureEng.BinOpt{int(v.BinNum)}
			}
			fileRows, err = featureEng.EqualFrequencyBinning(fileRows, m)
		} else if eng := featEngs[i].GetFeatureSelect(); eng != nil {
			fileRows = featureEng.FeatureSelect(fileRows, eng.Features)
		} else if eng := featEngs[i].GetIntervalReplace(); eng != nil {
			m := make(map[string]featureEng.ReplaceOpt)
			for k, v := range eng.RepOpts {
				intervals := make([]featureEng.IntervalValue, len(v.Intervals))
				for j := 0; j < len(v.Intervals); j++ {
					interval := featureEng.IntervalValue{v.Intervals[j].Left, v.Intervals[j].Right, v.Intervals[j].Value}
					intervals = append(intervals, interval)
				}
				m[k] = featureEng.ReplaceOpt{intervals}
			}
			fileRows, err = featureEng.ReplaceIntervalsBySpecifiedValues(fileRows, m)
		} else if eng := featEngs[i].GetMissingValues(); eng != nil {
			m := make(map[string]featureEng.FillOpt)
			for k, v := range eng.FillOpts {
				m[k] = featureEng.FillOpt{v.Method, v.Value}
			}
			fileRows, err = featureEng.FillMissingValues(fileRows, m)
		} else if eng := featEngs[i].GetThresholdFilter(); eng != nil {
			m := make(map[string]featureEng.FilterOpt)
			for k, v := range eng.FilterOpts {
				m[k] = featureEng.FilterOpt{v.Threshold, v.FilterMethod}
			}
			fileRows, err = featureEng.FilterByThreshold(fileRows, m)
		}
	}

	return csv.ConvertRowsToBytes(fileRows)
}

// ParseFeatEngs decode feature engineering methods from file content
// file content is as follows:
// [
//    {
//        "equalFrequencyBinning":{
//            "binOpts":{
//                "ZN":{
//                    "binNum":10
//                }
//            }
//        }
//    },
//    {
//        "featureSelect":{
//            "features":[
//                "id",
//                "CRIM",
//            ]
//        }
//    }
// ]
func ParseFeatEngs(s []byte) ([]*pbCom.FeatureEngineering, error) {
	if len(s) == 0 {
		return nil, nil
	}

	var m []map[string]interface{}
	if err := json.Unmarshal(s, &m); err != nil {
		return nil, err
	}

	var engs []*pbCom.FeatureEngineering
	for i := 0; i < len(m); i++ {
		var eng pbCom.FeatureEngineering
		c, err := json.Marshal(m[i])
		if err != nil {
			return nil, err
		}
		if err := jsonpb.Unmarshal(bytes.NewReader(c), &eng); err != nil {
			return nil, err
		}

		engs = append(engs, &eng)
	}

	return engs, nil
}

// CheckFeatEngs check if feature engineering parameters are valid
func CheckFeatEngs(featEngs []*pbCom.FeatureEngineering) error {
	if featEngs == nil || len(featEngs) == 0 {
		return nil
	}

	for _, featEng := range featEngs {
		if featEng.GetEqualWidthBinning() != nil {
			for f, opt := range featEng.GetEqualWidthBinning().BinOpts {
				if opt.BinNum <= 0 {
					return errorx.New(errcodes.ErrCodeParam, "EqualWidthBinning binNum for feature[%s] should be positive", f)
				}
			}
		} else if featEng.GetEqualFrequencyBinning() != nil {
			for f, opt := range featEng.GetEqualFrequencyBinning().BinOpts {
				if opt.BinNum <= 0 {
					return errorx.New(errcodes.ErrCodeParam, "EqualFrequencyBinning binNum for feature[%s] should be positive", f)
				}
			}
		} else if featEng.GetFeatureSelect() != nil {
			if len(featEng.GetFeatureSelect().Features) == 0 {
				return errorx.New(errcodes.ErrCodeParam, "selected features length cannot be 0")
			}
		} else if featEng.GetMissingValues() != nil {
			for f, opt := range featEng.GetMissingValues().FillOpts {
				if opt.Method != featureEng.FillMissingValuesByAverage &&
					opt.Method != featureEng.FillMissingValuesByMedian &&
					opt.Method != featureEng.FillMissingValuesBySpecifiedValue {
					return errorx.New(errcodes.ErrCodeParam, "unsupported method[%s] when filling missing values for feature[%s]", opt.Method, f)
				}
				if opt.Method == featureEng.FillMissingValuesBySpecifiedValue && len(opt.Value) == 0 {
					return errorx.New(errcodes.ErrCodeParam, "value cannot be empty when filling method is %s for feature[%s]", opt.Method, f)
				}
			}
		} else if featEng.GetIntervalReplace() != nil {
			for f, opt := range featEng.GetIntervalReplace().RepOpts {
				for _, interval := range opt.Intervals {
					if interval.Left >= interval.Right {
						return errorx.New(errcodes.ErrCodeParam, "left should be smaller than right value when intervalReplace for feature[%s]", f)
					}
					if len(interval.Value) == 0 {
						return errorx.New(errcodes.ErrCodeParam, "value cannot be empty when intervalReplace for feature[%s]", f)
					}
				}
			}
		} else if featEng.GetThresholdFilter() != nil {
			for f, opt := range featEng.GetThresholdFilter().FilterOpts {
				if opt.FilterMethod != featureEng.FilterByEqual &&
					opt.FilterMethod != featureEng.FilterByNotEqual &&
					opt.FilterMethod != featureEng.FilterByGreater &&
					opt.FilterMethod != featureEng.FilterByGreaterOrEqual &&
					opt.FilterMethod != featureEng.FilterByLess &&
					opt.FilterMethod != featureEng.FilterByLessOrEqual {
					return errorx.New(errcodes.ErrCodeParam, "unsupported method[%s] when thresholdFilter for feature[%s]", opt.FilterMethod, f)
				}
			}
		} else {
			return errorx.New(errcodes.ErrCodeParam, "unsupported feature engineering method")
		}
	}
	return nil
}
