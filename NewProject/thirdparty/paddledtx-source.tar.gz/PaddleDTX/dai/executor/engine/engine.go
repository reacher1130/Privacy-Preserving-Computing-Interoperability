// Copyright (c) 2021 PaddlePaddle Authors. All Rights Reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package engine

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"path/filepath"

	"github.com/golang/protobuf/jsonpb"
	"github.com/sirupsen/logrus"

	"github.com/PaddlePaddle/PaddleDTX/crypto/core/ecdsa"
	"github.com/PaddlePaddle/PaddleDTX/crypto/core/hash"
	"github.com/PaddlePaddle/PaddleDTX/xdb/errorx"
	util "github.com/PaddlePaddle/PaddleDTX/xdb/pkgs/strings"

	"github.com/PaddlePaddle/PaddleDTX/dai/blockchain"
	"github.com/PaddlePaddle/PaddleDTX/dai/config"
	vl_common "github.com/PaddlePaddle/PaddleDTX/dai/crypto/vl/common"
	"github.com/PaddlePaddle/PaddleDTX/dai/errcodes"
	"github.com/PaddlePaddle/PaddleDTX/dai/executor/handler"
	"github.com/PaddlePaddle/PaddleDTX/dai/executor/monitor"
	"github.com/PaddlePaddle/PaddleDTX/dai/mpc/cluster"
	pbCom "github.com/PaddlePaddle/PaddleDTX/dai/protos/common"
	pbTask "github.com/PaddlePaddle/PaddleDTX/dai/protos/task"
)

var (
	logger = logrus.WithField("module", "engine")
)

// Engine task processing engine
//
//	chain is the handler for blockchain operation, which includes node, task and file operations
//	node denotes executor node identity, which includes node id, node private key, host address...
//	storage is the handler for results storage, which includes trained model and prediction result storage
//	mpcHandler is the handler for mpc task execution, which includes task preparation, task execution, results storage...
//	monitor is the handler for task monitoring, that is, monitoring tasks to be executed
type Engine struct {
	chain       handler.Blockchain
	node        handler.Node
	storage     handler.FileStorage
	mpcHandler  handler.MpcHandler
	monitor     *monitor.TaskMonitor
	nodeMonitor *monitor.NodeMonitor
}

// NewEngine initiates Engine by executor node configuration
func NewEngine(conf *config.ExecutorConf) (e *Engine, err error) {
	return initEngine(conf)
}

// Start registers local node to blockchain and starts Monitor
func (e *Engine) Start(ctx context.Context) error {
	// register node
	if err := e.node.Register(e.chain); err != nil {
		return err
	}
	// re-execute tasks in Processing status
	go e.monitor.RetryProcessingTask(ctx)

	// start timed task to find out tasks ready to execute,
	// then starts Multi-Party Computation for each task
	e.monitor.StartTaskLoopRequest(ctx)

	// sends executor node heart beat to blockchain
	e.nodeMonitor.HeartBeat(ctx)

	// start timed task evidence routine to publish task evidence to blockchain
	if e.monitor.TaskEvidence {
		e.monitor.StartEvidenceLoop(ctx)
	}

	return nil
}

// GetMpcService returns mpc service to be registered to grpcServer
func (e *Engine) GetMpcService() *cluster.Service {
	return e.mpcHandler.GetMpcClusterService()
}

// ListTask lists tasks from blockchain by requester or executor's Public Key
func (e *Engine) ListTask(ctx context.Context, in *pbTask.ListTaskRequest) (*pbTask.FLTasks, error) {
	listOptions := &blockchain.ListFLTaskOptions{
		PubKey:     in.PubKey,
		ExecPubKey: in.EPubKey,
		Status:     in.Status,
		TimeStart:  in.TimeStart,
		TimeEnd:    in.TimeEnd,
		Limit:      in.Limit,
	}
	// invoke contract to list tasks
	fts, err := e.chain.ListTask(listOptions)
	if err != nil {
		return &pbTask.FLTasks{}, errorx.Wrap(err, "failed list task")
	}
	// traverse tasks
	resp := &pbTask.FLTasks{}
	for _, ft := range fts {
		resp.FLTasks = append(resp.FLTasks, ft)
	}
	return resp, nil
}

// GetTaskById queries task details by taskID
func (e *Engine) GetTaskById(ctx context.Context, in *pbTask.GetTaskRequest) (*pbTask.FLTask, error) {
	// get task detail
	task, err := e.chain.GetTaskById(in.TaskID)
	if err != nil {
		return &pbTask.FLTask{}, errorx.Wrap(err, "failed get task by id")
	}
	return task, nil
}
func (e *Engine) GetPsiResult(ctx context.Context, in *pbTask.TaskRequest) (*pbTask.PsiResultResponse, error) {

	// get task detail
	task, err := e.chain.GetTaskById(in.TaskID)
	if err != nil {
		return &pbTask.PsiResultResponse{}, errorx.Wrap(err, "failed get psi result")
	}
	// check task type
	if task.AlgoParam.TaskType != pbCom.TaskType_PSI {
		return &pbTask.PsiResultResponse{}, errorx.New(errorx.ErrCodeParam, "illegal taskId, not a psi task")
	}
	if !bytes.Equal(task.Requester, in.PubKey) {
		return &pbTask.PsiResultResponse{}, errorx.New(errorx.ErrCodeParam, "public key is invalid")
	}
	// check signature
	msg, err := util.GetSigMessage(in)
	if err != nil {
		return &pbTask.PsiResultResponse{}, errorx.Internal(err, "failed to get the message to sign")
	}
	if err := e.checkSign(in.Signature, in.PubKey, []byte(msg)); err != nil {
		return &pbTask.PsiResultResponse{}, errorx.Wrap(err, "get psi result failed")
	}

	// get prediction result from XuperDB or LocalPath, if the prediction result is stored
	// on XuperDB, task.Result is fileId, else get the file from LocalPath by prediction task's ID.
	psiFileID := in.TaskID
	if task.Result != nil && len(task.Result[fmt.Sprintf("%x", e.node.ID)]) != 0 {
		psiFileID = task.Result[fmt.Sprintf("%x", e.node.ID)]
	}

	r, err := e.storage.PsiStorage.Read(psiFileID)
	if err != nil {
		return &pbTask.PsiResultResponse{}, errorx.Wrap(err, "psi file failed to get reader")
	}
	text, err := ioutil.ReadAll(r)
	if err != nil {
		return &pbTask.PsiResultResponse{}, errorx.Wrap(err, "psi file failed to get reader")
	}
	defer r.Close()

	// format result
	//rows, err := vl_common.PsiResultFromBytes(text)
	//if err != nil {
	//	return &pbTask.PsiResultResponse{}, errorx.Wrap(err, "failed to read psi file ")
	//}
	payload, err := json.Marshal(text)
	if err != nil {
		return &pbTask.PsiResultResponse{}, errorx.New(errorx.ErrCodeParam, "illegal taskId, not a psi task")
	}

	return &pbTask.PsiResultResponse{
		TaskID:  task.TaskID,
		Payload: payload,
	}, nil
}

// GetPredictResult checks task's initiator and gets prediction result from Xuper db.
//
//	in.PubKey must matches task.Requester, only task.Requester can get prediction result.
func (e *Engine) GetPredictResult(ctx context.Context, in *pbTask.TaskRequest) (*pbTask.PredictResponse, error) {
	// get task detail
	task, err := e.chain.GetTaskById(in.TaskID)
	if err != nil {
		return &pbTask.PredictResponse{}, errorx.Wrap(err, "failed get predict result")
	}
	// check task type
	if task.AlgoParam.TaskType != pbCom.TaskType_PREDICT {
		return &pbTask.PredictResponse{}, errorx.New(errorx.ErrCodeParam, "illegal taskId, not a predict task")
	}
	if !bytes.Equal(task.Requester, in.PubKey) {
		return &pbTask.PredictResponse{}, errorx.New(errorx.ErrCodeParam, "public key is invalid")
	}
	// check signature
	msg, err := util.GetSigMessage(in)
	if err != nil {
		return &pbTask.PredictResponse{}, errorx.Internal(err, "failed to get the message to sign")
	}
	if err := e.checkSign(in.Signature, in.PubKey, []byte(msg)); err != nil {
		return &pbTask.PredictResponse{}, errorx.Wrap(err, "get predict result failed")
	}

	// get prediction result from XuperDB or LocalPath, if the prediction result is stored
	// on XuperDB, task.Result is fileId, else get the file from LocalPath by prediction task's ID.
	predictFileID := in.TaskID
	if task.Result != nil && len(task.Result[fmt.Sprintf("%x", e.node.ID)]) != 0 {
		predictFileID = task.Result[fmt.Sprintf("%x", e.node.ID)]
	}

	r, err := e.storage.PredictStorage.Read(predictFileID)
	if err != nil {
		return &pbTask.PredictResponse{}, errorx.Wrap(err, "failed to get reader from xuperdb")
	}
	text, err := ioutil.ReadAll(r)
	if err != nil {
		return &pbTask.PredictResponse{}, errorx.Wrap(err, "failed to read file from xuperdb")
	}
	defer r.Close()

	// format result
	rows, err := vl_common.PredictResultFromBytes(text)
	if err != nil {
		return &pbTask.PredictResponse{}, errorx.Wrap(err, "failed to read file from xuperdb")
	}
	payload, err := json.Marshal(rows)
	if err != nil {
		return &pbTask.PredictResponse{}, errorx.New(errorx.ErrCodeParam, "illegal taskId, not a predict task")
	}

	return &pbTask.PredictResponse{
		TaskID:  task.TaskID,
		Payload: payload,
	}, nil
}

// GetEvaluationResult checks task's initiator and gets static evaluation results from 'localEvaluationStoragePath'.
// in.PubKey must matches task.Requester, only task.Requester can get static evaluation results.
func (e *Engine) GetEvaluationResult(ctx context.Context, in *pbTask.TaskRequest) (*pbTask.EvaluationResponse, error) {
	// get task detail
	task, err := e.chain.GetTaskById(in.TaskID)
	if err != nil {
		return &pbTask.EvaluationResponse{}, errorx.ParseAndWrap(err, "failed to get task from chain, download evaluation results error")
	}
	// check task type
	if task.AlgoParam.TaskType != pbCom.TaskType_LEARN {
		return &pbTask.EvaluationResponse{}, errorx.New(errorx.ErrCodeParam, "illegal taskId, not a training task")
	}
	// check requester public key
	if !bytes.Equal(task.Requester, in.PubKey) {
		return &pbTask.EvaluationResponse{}, errorx.New(errorx.ErrCodeParam, "public key is invalid")
	}
	// evaluation results can only be downloaded if the task has static evaluation turned on and the task status is finished.
	if task.Status != blockchain.TaskFinished || task.AlgoParam.EvalParams == nil {
		return &pbTask.EvaluationResponse{}, errorx.New(errorx.ErrCodeParam,
			"the task status is not finished, or static model evaluation is not enabled")
	}
	// check signature
	msg, err := util.GetSigMessage(in)
	if err != nil {
		return &pbTask.EvaluationResponse{}, errorx.Internal(err, "failed to get the message to sign")
	}

	if err := e.checkSign(in.Signature, task.Requester, []byte(msg)); err != nil {
		return &pbTask.EvaluationResponse{}, errorx.Wrap(err, "check signature failed")
	}
	// read static model evaluation results
	r, err := e.storage.EvaluationStorage.Read(in.TaskID)
	if err != nil {
		return &pbTask.EvaluationResponse{}, errorx.ParseAndWrap(err, "failed to get reader from local evalus path")
	}
	defer r.Close()
	payload := &pbCom.EvaluationMetricScores{}
	if err := jsonpb.Unmarshal(r, payload); err != nil {
		return &pbTask.EvaluationResponse{}, errorx.ParseAndWrap(err, "unmarshal evaluation results error")
	}
	// return evaluation result
	return &pbTask.EvaluationResponse{
		TaskID:                      task.TaskID,
		BinaryClassCaseMetricScores: payload.GetBinaryClassCaseMetricScores(),
		RegressionCaseMetricScores:  payload.GetRegressionCaseMetricScores(),
		MultiClassCaseMetricScores:  payload.GetMultiClassCaseMetricScores(),
	}, nil
}

// GetLiveEvaluationResult checks task's initiator and gets live evaluation results from 'localLiveEvaluationStoragePath'.
// in.PubKey must matches task.Requester, only task.Requester can get live evaluation results.
func (e *Engine) GetLiveEvaluationResult(ctx context.Context, in *pbTask.TaskRequest) (*pbTask.LiveEvaluationResponse, error) {
	// get task detail
	task, err := e.chain.GetTaskById(in.TaskID)
	if err != nil {
		return &pbTask.LiveEvaluationResponse{}, errorx.ParseAndWrap(err, "failed to get task from chain, download live evaluation results error")
	}
	// check task type
	if task.AlgoParam.TaskType != pbCom.TaskType_LEARN {
		return &pbTask.LiveEvaluationResponse{}, errorx.New(errorx.ErrCodeParam, "illegal taskId, not a training task")
	}
	// check requester public key
	if !bytes.Equal(task.Requester, in.PubKey) {
		return &pbTask.LiveEvaluationResponse{}, errorx.New(errorx.ErrCodeParam, "public key is invalid")
	}
	// evaluation results can only be downloaded if the task has live evaluation turned on and the task status is finished or processing.
	if (task.Status != blockchain.TaskFinished && task.Status != blockchain.TaskProcessing) || task.AlgoParam.LivalParams == nil {
		return &pbTask.LiveEvaluationResponse{}, errorx.New(errorx.ErrCodeParam,
			"the task status is not finished or processing, or live model evaluation is not enabled")
	}
	// check signature
	msg, err := util.GetSigMessage(in)
	if err != nil {
		return &pbTask.LiveEvaluationResponse{}, errorx.Internal(err, "failed to get the message to sign")
	}
	if err := e.checkSign(in.Signature, task.Requester, []byte(msg)); err != nil {
		return &pbTask.LiveEvaluationResponse{}, errorx.ParseAndWrap(err, "check signature failed")
	}
	// read static model evaluation results
	r, err := e.storage.LiveEvaluationStorage.GetLEvaluationMetrics(in.TaskID)
	if err != nil {
		return &pbTask.LiveEvaluationResponse{}, errorx.ParseAndWrap(err, "failed to get reader from local evalus path")
	}
	return &pbTask.LiveEvaluationResponse{
		TaskStartTime:        task.StartTime,
		TaskID:               in.TaskID,
		TaskStatus:           task.Status,
		LiveEvalMetricScores: r,
	}, nil
}

// StartTask starts mpc-training or mpc-prediction after received "task starting" message from remote executor
func (e *Engine) StartTask(ctx context.Context, in *pbTask.TaskRequest) (*pbTask.TaskResponse, error) {
	logger.Debugf("got StartTaskRequest: %v", in)
	// get task detail
	task, err := e.chain.GetTaskById(in.TaskID)
	if err != nil {
		return &pbTask.TaskResponse{}, errorx.Wrap(err, "get task from chain error")
	}
	// check task status
	if task.Status != blockchain.TaskProcessing {
		return &pbTask.TaskResponse{}, errorx.Wrap(err, "illegal task status")
	}

	// check sign
	msg, err := util.GetSigMessage(in)
	if err != nil {
		return &pbTask.TaskResponse{}, errorx.Internal(err, "failed to get the message to sign for start mpc task")
	}
	if err := e.checkSign(in.Signature, in.PubKey, []byte(msg)); err != nil {
		return &pbTask.TaskResponse{}, errorx.Wrap(err, "start task failed, signature error")
	}
	// make sure the request must come from executor who confirmed the task
	isExecutorNodeExist := false
	for _, ds := range task.DataSets {
		if bytes.Equal(ds.Executor, in.PubKey) {
			isExecutorNodeExist = true
			break
		}
	}
	if !isExecutorNodeExist {
		return &pbTask.TaskResponse{}, errorx.New(errcodes.ErrCodeParam, "wrong request source[%x]", in.PubKey)
	}
	// TODO check executor did

	// add audit log
	logger.Infof("audit-task[%s] task started", task.TaskID)
	logger.Infof("audit-task[%s] requester: %s", task.TaskID, fmt.Sprintf("%x", task.Requester))

	// prepare resources before start mpc
	startRequest, err := e.mpcHandler.TaskStartPrepare(task)
	if err != nil {
		if code, _ := errorx.Parse(err); code == errcodes.ErrCodeTaskExists {
			logger.Info("Local mpc task already start")
			return &pbTask.TaskResponse{
				TaskID: in.TaskID,
			}, nil
		}
		logger.WithError(err).Error("failed to start local mpc, task start preparation error")
		return &pbTask.TaskResponse{}, errorx.Wrap(err, "task start prepare error")
	}

	// start local mpc
	go func() {
		if err := e.mpcHandler.StartLocalMpcTask(startRequest, false); err != nil {
			logger.WithError(err).Errorf("failed to start local mpc , taskId: %s", task.TaskID)
		}
	}()

	logger.Info("Start local mpc successfully after receive task starting signal")

	return &pbTask.TaskResponse{
		TaskID: in.TaskID,
	}, nil
}

// OnlineExecutorNode set executor node online
func (e *Engine) OnlineExecutorNode(ctx context.Context, in *pbTask.OnlineExecutorNodeRequest) (*pbTask.OnlineExecutorNodeResponse, error) {
	if err := e.chain.OnlineExecutorNode(in); err != nil {
		return &pbTask.OnlineExecutorNodeResponse{}, errorx.Wrap(err, "failed to set executor node online")
	}
	return &pbTask.OnlineExecutorNodeResponse{}, nil
}

// OfflineExecutorNode set executor node offline
func (e *Engine) OfflineExecutorNode(ctx context.Context, in *pbTask.OfflineExecutorNodeRequest) (*pbTask.OfflineExecutorNodeResponse, error) {
	if err := e.chain.OfflineExecutorNode(in); err != nil {
		return &pbTask.OfflineExecutorNodeResponse{}, errorx.Wrap(err, "failed to set executor node offline")
	}
	return &pbTask.OfflineExecutorNodeResponse{}, nil
}

// GetExecutorNodeHealth get executor node health status
func (e *Engine) GetExecutorNodeHealth(ctx context.Context, in *pbTask.GetExecutorNodeHealthRequest) (*pbTask.GetExecutorNodeHealthResponse, error) {
	health, err := e.chain.GetExecutorNodeHealth(in)
	if err != nil {
		return &pbTask.GetExecutorNodeHealthResponse{}, errorx.Wrap(err, "failed to get executor node health status")
	}
	return &pbTask.GetExecutorNodeHealthResponse{Health: health}, nil
}

// ListTaskEvidence lists tasks evidence from blockchain by executor's Public Key
func (e *Engine) ListTaskEvidence(ctx context.Context, in *pbTask.ListTaskEvidenceRequest) (*pbTask.ListTaskEvidenceResponse, error) {
	// invoke contract to list tasks evidence
	evds, err := e.chain.ListEvidences(in)
	if err != nil {
		return &pbTask.ListTaskEvidenceResponse{}, errorx.Wrap(err, "failed to list tasks evidence")
	}
	// traverse tasks evidence
	resp := &pbTask.ListTaskEvidenceResponse{}
	for _, evd := range evds {
		resp.Evidences = append(resp.Evidences, evd)
	}
	return resp, nil
}

// GetTaskEvidenceById queries task evidence details by evidenceID
func (e *Engine) GetTaskEvidenceById(ctx context.Context, in *pbTask.GetTaskEvidenceByIdRequest) (*pbTask.GetTaskEvidenceByIdResponse, error) {
	// get task detail
	evidence, err := e.chain.GetEvidence(in.Id)
	if err != nil {
		return &pbTask.GetTaskEvidenceByIdResponse{}, errorx.Wrap(err, "failed to get task evidence by id")
	}
	return &pbTask.GetTaskEvidenceByIdResponse{Evidence: evidence}, nil
}

// GetTaskLog queries task evidence details by evidenceID
func (e *Engine) GetTaskLog(ctx context.Context, in *pbTask.GetTaskLogRequest) (*pbTask.GetTaskLogResponse, error) {
	// get task log
	filePath := filepath.Join(config.GetLogConf().Path, in.Id)
	log, err := ioutil.ReadFile(filePath)
	if err != nil {
		return &pbTask.GetTaskLogResponse{}, errorx.Wrap(err, "failed to get task log by id")
	}
	return &pbTask.GetTaskLogResponse{Log: log}, nil
}

// checkSign verify if signature is valid
//
//	sign is the signature signed by private key
//	owner is the public key of signer
//	mes is the signed message
func (e *Engine) checkSign(sign, owner, mes []byte) (err error) {
	// verify sig
	if len(sign) != ecdsa.SignatureLength {
		return errorx.New(errorx.ErrCodeParam, "bad param:signature")
	}
	var pubkey [ecdsa.PublicKeyLength]byte
	var sig [ecdsa.SignatureLength]byte
	copy(pubkey[:], owner)
	copy(sig[:], sign)
	if err := ecdsa.Verify(pubkey, hash.HashUsingSha256(mes), sig); err != nil {
		return errorx.NewCode(err, errorx.ErrCodeBadSignature, "failed to verify signature")
	}
	return nil
}

// Close waits until all inner services stop
func (e *Engine) Close() {
	if e.monitor != nil {
		e.monitor.StopLoopReq()
		e.monitor.StopRetryReq()
		if e.monitor.TaskEvidence {
			e.monitor.StopLoopEvd()
		}
	}
	if e.mpcHandler != nil {
		e.mpcHandler.Close()
	}
	if e.chain != nil {
		e.chain.Close()
	}
	if e.nodeMonitor != nil {
		e.nodeMonitor.StopHeartBeat()
	}
}
