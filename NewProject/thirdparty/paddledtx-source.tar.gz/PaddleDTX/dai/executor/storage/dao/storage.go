// Copyright (c) 2021 PaddlePaddle Authors. All Rights Reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package dao

import (
	"database/sql"
	"os"

	"github.com/jmoiron/sqlx"
	_ "github.com/mattn/go-sqlite3"

	pbCom "github.com/PaddlePaddle/PaddleDTX/dai/protos/common"
	"github.com/PaddlePaddle/PaddleDTX/xdb/errorx"
)

// Storage stores files locally
type Storage struct {
	db *sqlx.DB
}

// DaoType defines the default database type
const DaoType = "sqlite3"
const DaoFileName = "le_metrics.db"

// DefaultSQLiteSchema defines the default sql used to create tables and indexes
const DefaultSQLiteSchema = `
create table if not exists task_le_metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    taskId varchar(100) NOT NULL,
    loopTime int(10) NOT NULL, 
    createTime DATETIME DEFAULT CURRENT_TIMESTAMP,
    loopRound int(10) NOT NULL,
	rmse float NOT NULL DEFAULT 0.00,
	accuracy float NOT NULL DEFAULT 0.00,
    precision float NOT NULL DEFAULT 0.00,
    recall float NOT NULL DEFAULT 0.00,
	f1Score float NOT NULL DEFAULT 0.00
);
CREATE INDEX IF NOT EXISTS idx_taskId ON task_le_metrics(taskId);
`

// New initiates Storage
func New(dbPath string) (*Storage, error) {
	// create sqlite file if not exist
	if _, err := os.Stat(dbPath); err != nil && os.IsNotExist(err) {
		if err := os.Mkdir(dbPath, 0777); err != nil {
			return nil, errorx.NewCode(err, errorx.ErrCodeConfig, "failed to mkdir for live evaluation storage")
		}
		file, err := os.Create(dbPath + "/" + DaoFileName)
		if err != nil {
			return nil, errorx.NewCode(err, errorx.ErrCodeInternal, "failed to create dao file for live evaluation storage")
		}
		defer file.Close()
	}

	// new database connection
	var db *sqlx.DB
	db, err := sqlx.Connect(DaoType, dbPath+"/"+DaoFileName)
	if err != nil {
		return nil, errorx.Wrap(err, "failed to connect sqlite db")
	}
	// initialize the database
	if _, err := db.Exec(DefaultSQLiteSchema); err != nil {
		return nil, errorx.Wrap(err, "failed to execute default sql")
	}
	return &Storage{db: db}, nil
}

// Close closes the database and prevents new queries from starting.
// Close then waits for all queries that have started processing on the server to finish.
func (s *Storage) Close() {
	s.db.Close()
}

// SetLEvaluationMetrics insert task metrics into db
func (s *Storage) SetLEvaluationMetrics(lmetrics *pbCom.LiveEvaluationMetricScores) (int64, error) {
	id, err := s.insert("INSERT INTO task_le_metrics(`taskId`, `loopTime`, `loopRound`, `rmse`, `accuracy`, `precision`, `recall`, `f1Score`) VALUES (?,?,?,?,?,?,?,?)",
		lmetrics.TaskID,
		lmetrics.LoopTime,
		lmetrics.LoopRound,
		lmetrics.Rmse,
		lmetrics.Accuracy,
		lmetrics.Precision,
		lmetrics.Recall,
		lmetrics.F1Score,
	)
	if err != nil {
		return 0, err
	}
	return id, nil
}

// GetLEvaluationMetrics get live evaluation metrics by taskID
func (s *Storage) GetLEvaluationMetrics(taskID string) (les []*pbCom.LiveEvaluationMetricScores, err error) {
	rows, err := s.get("SELECT loopTime, loopRound, rmse, accuracy, precision, recall, f1Score FROM task_le_metrics WHERE taskId=?", taskID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	// iterate over each row
	for rows.Next() {
		lMetrics := pbCom.LiveEvaluationMetricScores{}
		err = rows.Scan(&lMetrics.LoopTime, &lMetrics.LoopRound, &lMetrics.Rmse,
			&lMetrics.Accuracy, &lMetrics.Precision, &lMetrics.Recall, &lMetrics.F1Score)
		if err != nil {
			return nil, err
		}
		les = append(les, &lMetrics)
	}
	return les, nil
}

// insert insert into db
func (s *Storage) insert(query string, args ...interface{}) (int64, error) {
	result, err := s.db.Exec(query, args...)
	if err != nil {
		return 0, errorx.NewCode(err, errorx.ErrCodeInternal, "insert into db error, query is %s", query)
	}
	id, err := result.LastInsertId()
	if err != nil {
		return 0, errorx.NewCode(err, errorx.ErrCodeInternal, "get last insert id from db error, query is %s", query)
	}
	return id, nil
}

// update update info
func (s *Storage) update(query string, args ...interface{}) (int64, error) {
	result, err := s.db.Exec(query, args...)
	if err != nil {
		return 0, errorx.NewCode(err, errorx.ErrCodeInternal, "update info from db error, query is %s", query)
	}
	affectedRows, err := result.RowsAffected()
	if err != nil {
		return 0, errorx.NewCode(err, errorx.ErrCodeInternal, "get rows affected from db error, query is %s", query)
	}
	return affectedRows, nil
}

// delete delete info
func (s *Storage) delete(query string, args ...interface{}) (int64, error) {
	result, err := s.db.Exec(query, args...)
	if err != nil {
		return 0, errorx.NewCode(err, errorx.ErrCodeInternal, "delete info from db error, query is %s", query)
	}
	affectedRows, err := result.RowsAffected()
	if err != nil {
		return 0, errorx.NewCode(err, errorx.ErrCodeInternal, "get rows affected from db error, query is %s", query)
	}
	return affectedRows, nil
}

// get gets results from db
func (s *Storage) get(query string, args ...interface{}) (*sql.Rows, error) {
	rows, err := s.db.Query(query, args...)
	if err != nil {
		return nil, errorx.NewCode(err, errorx.ErrCodeInternal, "get results from db error, query is %s", query)
	}
	return rows, nil
}
