// Copyright (c) 2021 PaddlePaddle Authors. All Rights Reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package monitor

import (
	"context"
	"time"

	"github.com/PaddlePaddle/PaddleDTX/crypto/core/ecdsa"
	"github.com/PaddlePaddle/PaddleDTX/crypto/core/hash"
	util "github.com/PaddlePaddle/PaddleDTX/xdb/pkgs/strings"

	"github.com/PaddlePaddle/PaddleDTX/dai/blockchain"
	utilNode "github.com/PaddlePaddle/PaddleDTX/dai/util/node"
)

// heartbeat sends heartbeats regularly in order to claim it's alive
func (n *NodeMonitor) heartbeat(ctx context.Context) {
	logger.Info("node loop start")

	ticker := time.NewTicker(utilNode.HeartBeatFreq)
	defer ticker.Stop()

	n.doneHbC = make(chan struct{})
	defer close(n.doneHbC)

	defer logger.Info("node loop stopped")

	for {
		select {
		case <-ctx.Done():
			return
		case <-n.doneHbC:
			close(n.doneHbC)
			return
		case <-ticker.C:
		}

		now := time.Now().UnixNano()
		opt := &blockchain.ExecutorNodeHeartbeatOpts{
			ID:            n.PublicKey[:],
			CurrentTime:   now,
			BeginningTime: utilNode.TodayBeginning(now),
		}
		msg, err := util.GetSigMessage(opt)
		if err != nil {
			logger.WithError(err).Error("failed to get message to sign")
			continue
		}
		sig, err := ecdsa.Sign(n.PrivateKey, hash.HashUsingSha256([]byte(msg)))
		opt.Signature = sig[:]

		if err := n.Blockchain.ExecutorNodeHeartbeat(opt); err != nil {
			logger.WithError(err).Error("failed to update heartbeat of executor node")
		} else {
			logger.Info("successfully updated executorNode heartbeat at ", now)
		}
	}
}
