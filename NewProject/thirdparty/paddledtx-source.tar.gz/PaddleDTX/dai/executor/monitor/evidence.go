// Copyright (c) 2021 PaddlePaddle Authors. All Rights Reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package monitor

import (
	"context"
	"encoding/json"
	"time"

	"github.com/PaddlePaddle/PaddleDTX/crypto/core/ecdsa"
	"github.com/PaddlePaddle/PaddleDTX/crypto/core/hash"
	"github.com/sirupsen/logrus"

	"github.com/PaddlePaddle/PaddleDTX/dai/blockchain"
	"github.com/PaddlePaddle/PaddleDTX/dai/mpc/evidence"
)

// loopRequest checks task evidence pool periodically to find evidence ready to be published to blockchain
func (t *TaskMonitor) loopEvidence(ctx context.Context) {
	logger.Info("task evidence loop start")

	ticker := time.NewTicker(t.EvidenceInterval)
	defer ticker.Stop()

	t.doneLoopEvdC = make(chan struct{})
	defer close(t.doneLoopEvdC)

	defer logger.Info("task evidence loop stopped")

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
		}

		num := len(evidence.TaskEvidencePool)
		if num > 0 {
			// publish evidence on blockchain
			t.publishTaskEvidence(num)
		}
	}
}

// publishTaskEvidence the executor node publishes task evidence to blockchain
func (t *TaskMonitor) publishTaskEvidence(total int) {
	for i := 0; i < total; i++ {
		evd := <-evidence.TaskEvidencePool
		evd.PubKey = t.PublicKey[:]

		s, err := json.Marshal(evd)
		if err != nil {
			logger.WithFields(logrus.Fields{
				"task_id":     evd.Title,
				"evidence_id": evd.Id,
			}).Errorf("error occurred when marshal task evidence: %v", err)
			continue
		}

		sig, err := ecdsa.Sign(t.PrivateKey, hash.HashUsingSha256(s))
		if err != nil {
			logger.WithFields(logrus.Fields{
				"task_id":     evd.Title,
				"evidence_id": evd.Id,
			}).Errorf("error occurred when sign task evidence: %v", err)
			continue
		}

		opt := blockchain.PublishEvidenceOptions{
			Evidence:  s,
			Signature: sig[:],
		}
		if err := t.Blockchain.PublishEvidence(&opt); err != nil {
			logger.WithFields(logrus.Fields{
				"task_id":     evd.Title,
				"evidence_id": evd.Id,
			}).Errorf("error occurred when publish task evidence: %v", err)
		} else {
			logger.WithFields(logrus.Fields{
				"task_id":       evd.Title,
				"evidence_id":   evd.Id,
				"evidence_type": evd.Type,
			}).Info("successfully published task evidence")
		}
	}
}
