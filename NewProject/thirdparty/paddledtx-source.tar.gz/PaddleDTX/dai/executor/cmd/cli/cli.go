// Copyright (c) 2021 PaddlePaddle Authors. All Rights Reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package cli

import (
	"os"

	"github.com/spf13/cobra"

	"github.com/PaddlePaddle/PaddleDTX/dai/executor/cmd/cli/evidence"
	"github.com/PaddlePaddle/PaddleDTX/dai/executor/cmd/cli/key"
	"github.com/PaddlePaddle/PaddleDTX/dai/executor/cmd/cli/nodes"
	"github.com/PaddlePaddle/PaddleDTX/dai/executor/cmd/cli/task"
)

// rootCmd represents the base command when called without any subcommands
var rootCmd = &cobra.Command{
	Use:   "executor-cli",
	Short: "a cli tool for the executor to manage tasks.",
}

// Execute adds all child commands to the root command and sets flags appropriately.
// This is called by main.main(). It only needs to happen once to the rootCmd.
func Execute() {
	if err := rootCmd.Execute(); err != nil {
		os.Exit(1)
	}
}
func init() {
	rootCmd.AddCommand(task.RootCmd())
	rootCmd.AddCommand(key.RootCmd())
	rootCmd.AddCommand(nodes.RootCmd())
	rootCmd.AddCommand(evidence.RootCmd())
}
