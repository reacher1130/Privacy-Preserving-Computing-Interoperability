// Copyright (c) 2021 PaddlePaddle Authors. All Rights Reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package nodes

import (
	"context"
	"fmt"

	"github.com/spf13/cobra"

	executorClient "github.com/PaddlePaddle/PaddleDTX/dai/executor/client"
)

var healthCmd = &cobra.Command{
	Use:   "health",
	Short: "get executor node health status",
	Run: func(cmd *cobra.Command, args []string) {
		client, err := executorClient.GetExecutorClient(host)
		if err != nil {
			fmt.Printf("GetChainClient failed: %v\n", err)
			return
		}

		health, err := client.GetExecutorNodeHealth(context.Background(), id)
		if err != nil {
			fmt.Printf("GetExecutorNodeHealth of %s failed：%v\n", id, err)
			return
		}

		fmt.Println(health)
	},
}

func init() {
	rootCmd.AddCommand(healthCmd)

	healthCmd.Flags().StringVarP(&id, "id", "i", "", "node id")

	healthCmd.MarkFlagRequired("id")
}
