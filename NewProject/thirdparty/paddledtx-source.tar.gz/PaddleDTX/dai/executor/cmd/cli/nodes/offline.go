// Copyright (c) 2021 PaddlePaddle Authors. All Rights Reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package nodes

import (
	"context"
	"fmt"
	"strings"

	"github.com/spf13/cobra"

	executorClient "github.com/PaddlePaddle/PaddleDTX/dai/executor/client"
	"github.com/PaddlePaddle/PaddleDTX/dai/util/file"
)

var offlineCmd = &cobra.Command{
	Use:   "offline",
	Short: "offline executor node",
	Run: func(cmd *cobra.Command, args []string) {
		client, err := executorClient.GetExecutorClient(host)
		if err != nil {
			fmt.Printf("GetChainClient failed: %v\n", err)
			return
		}
		if privateKey == "" {
			prvkeyBytes, err := file.ReadFile(keyPath, file.PrivateKeyFileName)
			if err != nil {
				fmt.Printf("Read private key failed, err: %v\n", err)
				return
			}
			privateKey = strings.TrimSpace(string(prvkeyBytes))
		}
		if err := client.OfflineExecutorNode(context.Background(), privateKey, id); err != nil {
			fmt.Printf("OfflineExecutorNode failed：%v\n", err)
			return
		}

		fmt.Printf("OK")
	},
}

func init() {
	rootCmd.AddCommand(offlineCmd)

	offlineCmd.Flags().StringVarP(&id, "id", "i", "", "node id")
	offlineCmd.Flags().StringVarP(&privateKey, "priv", "", "", "private key hex string")
	offlineCmd.Flags().StringVarP(&keyPath, "keyPath", "", "./keys", "executor's key path")

	offlineCmd.MarkFlagRequired("id")
}
