// Copyright (c) 2021 PaddlePaddle Authors. All Rights Reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package evidence

import (
	"context"
	"fmt"
	"strings"
	"time"

	"github.com/spf13/cobra"

	"github.com/PaddlePaddle/PaddleDTX/dai/blockchain"
	executorClient "github.com/PaddlePaddle/PaddleDTX/dai/executor/client"
	"github.com/PaddlePaddle/PaddleDTX/dai/util/file"
)

var (
	taskID  string
	etype   string
	ePubkey string
)

// listEvidenceCmd lists tasks from blockchain with specific participant public key and task status
var listEvidenceCmd = &cobra.Command{
	Use:   "list",
	Short: "list tasks from blockchain through executor node",
	Run: func(cmd *cobra.Command, args []string) {
		client, err := executorClient.GetExecutorClient(host)
		if err != nil {
			fmt.Printf("GetExecutorClient failed: %v\n", err)
			return
		}

		var startTime int64 = 0
		if start != "" {
			s, err := time.ParseInLocation(timeTemplate, start, time.Local)
			if err != nil {
				fmt.Printf("ParseInLocation failed：%v\n", err)
				return
			}
			startTime = s.UnixNano()
		}
		endTime, err := time.ParseInLocation(timeTemplate, end, time.Local)
		if err != nil {
			fmt.Printf("ParseInLocation failed：%v\n", err)
			return
		}

		if limit > blockchain.TaskListMaxNum {
			fmt.Printf("invalid limit, the value must smaller than %v \n", blockchain.TaskListMaxNum)
			return
		}

		if ePubkey == "" {
			pubkeyBytes, err := file.ReadFile(keyPath, file.PublicKeyFileName)
			if err != nil {
				fmt.Printf("Read publicKey failed, err: %v\n", err)
				return
			}
			ePubkey = strings.TrimSpace(string(pubkeyBytes))
		}

		evidences, err := client.ListTaskEvidence(context.Background(), ePubkey, taskID, etype, startTime, endTime.UnixNano(), limit)
		if err != nil {
			fmt.Printf("ListTaskEvidence failed：%v\n", err)
			return
		}

		for _, evd := range evidences {
			ptime := time.Unix(0, evd.Time).Format(timeTemplate)
			fmt.Printf("EvidenceID: %s\nTaskID: %s\nEvidenceType: %s\nExecutor: %x\nContent: %s\nPublishTime: %s\n\n",
				evd.Id, evd.Title, evd.Type, evd.PubKey, evd.Content, ptime)
		}

		fmt.Printf("evidenceNum : %d\n\n", len(evidences))
	},
}

func init() {
	rootCmd.AddCommand(listEvidenceCmd)

	listEvidenceCmd.Flags().StringVarP(&ePubkey, "ePubkey", "p", "", "executor public key hex string, list executor's tasks, default './keys/public.key'")
	listEvidenceCmd.Flags().StringVarP(&keyPath, "keyPath", "", "./keys", "executor's key path")
	listEvidenceCmd.Flags().StringVar(&taskID, "task", "", "task id of evidences to look for")
	listEvidenceCmd.Flags().StringVar(&etype, "type", "", "type of task evidence, support EvidenceTaskProcess and EvidenceTaskResult, default for all types")
	listEvidenceCmd.Flags().StringVarP(&start, "start", "s", "", "start of time range during which tasks evidence was published, example '2021-06-10 12:00:00'")
	listEvidenceCmd.Flags().StringVarP(&end, "end", "e", time.Unix(0, time.Now().UnixNano()).Format(timeTemplate), "end of time range during which tasks evidence was published, example '2021-06-10 12:00:00'")
	listEvidenceCmd.Flags().Int64VarP(&limit, "limit", "l", blockchain.TaskListMaxNum, "limit of number for listing tasks evidence")
}
