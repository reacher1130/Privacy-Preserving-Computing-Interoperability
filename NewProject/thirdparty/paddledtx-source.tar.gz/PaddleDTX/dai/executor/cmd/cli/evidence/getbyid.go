// Copyright (c) 2021 PaddlePaddle Authors. All Rights Reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package evidence

import (
	"context"
	"fmt"
	"time"

	"github.com/spf13/cobra"

	executorClient "github.com/PaddlePaddle/PaddleDTX/dai/executor/client"
)

// getByIDCmd get task evidence by evidenceID
var getByIDCmd = &cobra.Command{
	Use:   "getbyid",
	Short: "get the task evidence by id",
	Run: func(cmd *cobra.Command, args []string) {
		client, err := executorClient.GetExecutorClient(host)
		if err != nil {
			fmt.Printf("GetExecutorClient failed: %v\n", err)
			return
		}

		evd, err := client.GetTaskEvidenceById(context.Background(), id)
		if err != nil {
			fmt.Printf("GetTaskEvidenceById failed：%v\n", err)
			return
		}

		ptime := time.Unix(0, evd.Time).Format(timeTemplate)
		fmt.Printf("EvidenceID: %s\nTaskID: %s\nEvidenceType: %s\nExecutor: %x\nContent: %s\nPublishTime: %s\n\n",
			evd.Id, evd.Title, evd.Type, evd.PubKey, evd.Content, ptime)
	},
}

func init() {
	rootCmd.AddCommand(getByIDCmd)

	getByIDCmd.Flags().StringVarP(&id, "id", "i", "", "task evidence id")

	getByIDCmd.MarkFlagRequired("id")
}
